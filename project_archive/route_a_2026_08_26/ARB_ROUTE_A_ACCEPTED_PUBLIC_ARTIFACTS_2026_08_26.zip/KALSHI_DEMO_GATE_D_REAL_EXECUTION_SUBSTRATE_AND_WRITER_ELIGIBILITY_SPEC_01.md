# KALSHI_DEMO_GATE_D_REAL_EXECUTION_SUBSTRATE_AND_WRITER_ELIGIBILITY_SPEC_01

```yaml
artifact_class: TECHNICAL_SPECIFICATION
task_class: SPEC_ONLY
technical_scope: KALSHI_DEMO_PRE_EXECUTION_CONFLICT_DOMAIN_INCEPTION_OR_HISTORICAL_DOMAIN_RESOLUTION_AND_WRITER_ELIGIBILITY_ONLY
risk_tier: HIGH
repository: rigolugo/ARB
canonical_main: 0d77bd55087a8b63f74f2b4d95f9a63745e30056
canonical_tree: bfcf137b4805a7c1899e1cff5d47a5c7b129e555
canonical_parent: 35916c62a0867e59e3954b4b35b6cfdec597b64c
current_conflict_domain_ref: KALSHI|KALSHI_DEMO|ARB_KALSHI_DEMO_PRIMARY_ACCOUNT|SUBACCOUNT=0
current_domain_readiness: NOT_GATE_D_EXECUTION_READY
route_a_disposition: ROUTE_A_NOT_CURRENTLY_EXECUTION_READY__NEW_BOUNDED_HISTORICAL_RECONCILIATION_EVIDENCE_REQUIRED
route_b_disposition: ROUTE_B_NOT_CURRENTLY_EXECUTION_READY__DOMAIN_EXISTENCE_AND_INCEPTION_UNPROVEN__PERSISTENCE_REVISION_REQUIRED
persistence_compatibility_disposition: PERSISTENT_CLEAN_DOMAIN_BOOTSTRAP_NOT_REPRESENTABLE_UNDER_CURRENT_SCHEMA
overall_disposition: NO_CURRENTLY_VALID_EXECUTION_SUBSTRATE_PATH
authority_schema_revision_observed: 1
ledger_schema_revision_observed: 1
event_schema_revision_observed: 1
preledger_history_mode_observed: LEGACY_IMPORT_REQUIRED
implementation_performed_by_this_artifact: false
tests_executed_by_this_artifact: false
credential_activity_by_this_artifact: NONE
venue_requests_by_this_artifact: 0
persistent_state_mutated_by_this_artifact: false
repository_modified_by_this_artifact: false
git_write_activity_by_this_artifact: NONE
```

## 1. Purpose and boundary

This specification defines the exact **pre-execution substrate and writer-eligibility contract** that must exist before the already-installed Gate-D minimal two-sided market-maker can become eligible for a later, separately specified, one-shot Kalshi Demo experiment.

The installed Gate-D implementation is not sufficient by itself. The current canonical real conflict domain remains safety-held by an unresolved historical CREATE result and therefore cannot reach the genuine Stage-3K `NORMAL_WRITER` state required by Gate D.

This specification answers one bounded architectural question:

```text
What exact technical path, if any, can produce a trustworthy real execution
substrate without weakening the existing historical hold?
```

It evaluates exactly two high-level routes:

```text
ROUTE A
    resolve the existing primary-account/subaccount-0 conflict domain

ROUTE B
    establish a genuinely separate venue/economic conflict domain with a
    trustworthy inception boundary
```

This artifact is **not**:

- a Gate-D execution specification;
- a venue execution authorization;
- an account-inspection task;
- a credential-use task;
- a subaccount-creation task;
- a funding/transfer task;
- a writer-proof release task;
- an implementation task;
- a test task;
- a persistent-state migration or mutation;
- a Git/repository write.

A later execution task may exist only after the substrate path selected by a future workflow is technically implemented, independently evidenced, canonically installed, and separately gated.

The next possible market-maker execution specification remains outside this artifact:

```text
KALSHI_DEMO_MINIMAL_TWO_SIDED_MARKET_MAKER_EXECUTION_SPEC_01
```

No requirement in this specification grants capability to prepare or execute that later artifact.

---

## 2. Exact canonical repository and provenance gate

### GD-SUB-BASE-001 — canonical repository identity

The exact canonical state used for this specification is:

```text
repository = rigolugo/ARB
default_branch = main
required_main =
0d77bd55087a8b63f74f2b4d95f9a63745e30056

required_tree =
bfcf137b4805a7c1899e1cff5d47a5c7b129e555

required_parent =
35916c62a0867e59e3954b4b35b6cfdec597b64c
```

These three identities were reverified read-only during preparation.

Any later task that relies on this specification MUST independently reverify the exact repository/base required by that later task. It MUST NOT silently advance, rebase, retarget, or reinterpret this specification against a different base when a base-specific code contract is load-bearing.

Failure classifications:

```text
CANONICAL_BASE_MISMATCH
CANONICAL_TREE_MISMATCH
CANONICAL_PARENT_MISMATCH
```

An unexplained mismatch is a halt.

### GD-SUB-BASE-002 — exact current canonical code contracts inspected

The following canonical source contracts at the required base are load-bearing:

```text
src/arb/execution_ledger.py
  git_blob =
  2f62f3d5ea8be1ee355034ac2d4b9f3ac9ef35ad

src/arb/venues/kalshi/ledger_binding.py
  git_blob =
  177cdd89a5a5d6da745ad684efcb2029c6cf2a49

src/arb/venues/kalshi/minimal_market_maker_experiment_runner.py
  bytes =
  188248
  sha256 =
  9b94f982bee2a4de049a08fe3150721a182444b1fe1ee4f13a944413090c70bb
  git_blob =
  7a6cbe15a6b6c037aa1fda2194df4256223bc9e8

src/arb/venues/kalshi/quote_lifecycle.py
  bytes =
  56569
  sha256 =
  309cf69d8578b473b8595cd0fa91c78cb0eb7d9077154a656e7182bf4b342451
  git_blob =
  ac94e2ac3eae13e9140d79821afcfc8d8f2aab81
```

The source-code identities are technical provenance. They are not authority to execute or modify those files.

### GD-SUB-BASE-003 — exact controlling accepted technical artifacts used

The following accepted artifacts are controlling where this specification cites their technical contracts:

```text
KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_03.md
  bytes = 141566
  sha256 =
  98592d719db2dcb59bb5ade6f18700b9acf4ae1049480f409b60f228f1518ead

HANDOFF_KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_03.md
  bytes = 17942
  sha256 =
  43dd06f5a7d976bff54574f60298c7568f74e9c24b8f257e32306b45c8289b93

KALSHI_DEMO_EMERGENCY_CANCELLATION_AND_RISK_LIMITS_SPEC_03.md
  bytes = 183042
  sha256 =
  bb8f078185eb766ed1589441712d9cc6fcd77f574a1a2100a1901cfb75e9c8cb

HANDOFF_KALSHI_DEMO_EMERGENCY_CANCELLATION_AND_RISK_LIMITS_SPEC_03.md
  bytes = 19785
  sha256 =
  335048d61acd9367755629f90f584553ece7eed8553ffcf9c881a6feb4b944f3

KALSHI_DEMO_POST_HALT_EXACT_WRITE_RESULT_RECONCILIATION_SPEC_01.md
  bytes = 69923
  sha256 =
  61fd39b87d8b837e1a16b2b21cd133614f2607a3c21130682b53ace6ac4715e7

HANDOFF_KALSHI_DEMO_POST_HALT_EXACT_WRITE_RESULT_RECONCILIATION_SPEC_01.md
  bytes = 17704
  sha256 =
  ce6d3ef37339d118a0a390c69432833b50cedb3820017dbc66ef443934724a5e

KALSHI_DEMO_POST_HALT_EXACT_WRITE_RESULT_RECONCILIATION_EVIDENCE_01.json
  bytes = 10541
  sha256 =
  a10eb4a6d7490755bbe055056cbe4960d075fd73048967d7e3d1c846c7be34fe

KALSHI_DEMO_POST_HALT_FILL_DISCOVERY_BINDING_FALLBACK_SPEC_01.md
  bytes = 62219
  sha256 =
  361f7bbc172c1a2ecd7f2278f0371966288e4ef63a41a018820f0a7a1d893c0b

HANDOFF_KALSHI_DEMO_POST_HALT_FILL_DISCOVERY_BINDING_FALLBACK_SPEC_01.md
  bytes = 12699
  sha256 =
  f81a99e0b3aec7a831065c6da622c6a029cb3d137e2cb4708b8b940445799924

KALSHI_DEMO_POST_HALT_FILL_DISCOVERY_BINDING_FALLBACK_EXECUTION_EVIDENCE_01.json
  bytes = 10882
  sha256 =
  5e9cb2690854309f5684fa1b31cc4d837e301152a8466732382acb913dd73aa2

KALSHI_DEMO_MINIMAL_TWO_SIDED_MARKET_MAKER_SPEC_06.md
  bytes = 48453
  sha256 =
  d6f78c4b00f3de57532cfa5e8f30eff2bddd37846752340725bbc5e66e8da07f

HANDOFF_KALSHI_DEMO_MINIMAL_TWO_SIDED_MARKET_MAKER_SPEC_06.md
  bytes = 11172
  sha256 =
  02dbd926c3959f3edd3c8d231940981d6d696ed73471bb227e90f97376a96990

KALSHI_DEMO_MINIMAL_TWO_SIDED_MARKET_MAKER_SPEC_07.md
  bytes = 41916
  sha256 =
  ec16676b35ab9eb9ca08f0fd54b105dc2086636724f5a4924ea5965794c48360

HANDOFF_KALSHI_DEMO_MINIMAL_TWO_SIDED_MARKET_MAKER_SPEC_07.md
  bytes = 14322
  sha256 =
  74faabd42e8e8416115700e8812115c11151c7a55f5733b39089ce3b82853796
```

The latest Gate-D specification is Revision 07. Revision 06 remains controlling only where Revision 07 explicitly preserves it.

### GD-SUB-BASE-004 — runner lineage used

The exact Stage-3 pre-release architecture used by this specification is the accepted runner lineage in which Stage 3 is:

```text
3A. process starts BOOT_HOLD
3B. open exact authority/ledger read/local-gate path and replay
3C. reject locally if any non-freshness release predicate is already false
3D. if structurally release-capable, expose only PreReleaseReadCapabilityV1
3E. collect bounded current-process read/reconciliation truth
3F. close venue-read phase; assemble exact ReleaseEvaluationStateV1
3G. acquire canonical RELEASE_ONLY
3H. complete exact durable release sequence
3I. receive CurrentProcessReleaseCompletionV1 after final readback/session end
3J. acquire NORMAL_WRITER using all durable predicates + exact token
3K. revalidate returned post-start projection/session/locks
```

The accepted code at the required base implements the Stage-3C local rejection described in Section 6.

No part of this specification weakens, bypasses, or relocates Stage 3C.

---

## 3. Premise authority taxonomy

Every material premise in this artifact belongs to exactly one of:

```text
CONTROLLING_ARB_REQUIREMENT
NON_CONTROLLING_EXTERNAL_RESEARCH
ARB_INFERENCE
UNRESOLVED_FACT
```

Definitions:

### `CONTROLLING_ARB_REQUIREMENT`

A requirement or current-state fact established by an accepted ARB artifact or the exact canonical source contract at the required base.

### `NON_CONTROLLING_EXTERNAL_RESEARCH`

A technical observation from retained external research or supplied official-source observations that is useful for design but does not become normative merely by being cited.

### `ARB_INFERENCE`

A conclusion derived from controlling ARB requirements, canonical source behavior, or explicitly identified research. The inference becomes normative only where this specification expressly adopts it.

### `UNRESOLVED_FACT`

A fact required to choose or execute a route but not established by this task.

The source taxonomy is part of review traceability; it is not a hierarchy that allows research to override controlling ARB contracts.

---

## 4. Immutable current safety state

### GD-SUB-HIST-001 — exact current incident

The following current state is preserved exactly:

```text
incident_id =
KALSHI_DEMO_ONE_ORDER_LIFECYCLE_EXECUTION_01

disposition =
WRITE_UNRESOLVED_ZERO_MATCH

bound_order_id =
null

created_order_upper_bound =
1

active_order_upper_bound =
1

unknown_result =
true

writer_proof_state =
HELD

writer_proof_release_eligible =
false

protected_unresolved_legacy_write_count =
1

history_completeness =
COMPLETE_WITH_PROTECTED_UNRESOLVED_LEGACY_WRITE

restart_classification =
RESTART_UNRESOLVED_WRITE_HELD

normal_writer_handle =
NONE

historical_incident_cancel_target =
NONE

historical_unresolved_exposure =
UNKNOWN_UNBOUNDED

release_eligible =
false
```

Premise class:

```text
CONTROLLING_ARB_REQUIREMENT
```

### GD-SUB-HIST-002 — prohibited historical inferences

This specification MUST NOT infer:

```text
CREATE_NEVER_EXISTED
CREATE_DEFINITELY_FAILED
SAFE_TO_RETRY_CREATE
SAFE_TO_CANCEL
ZERO_EXPOSURE
WRITER_PROOF_RELEASED
INCIDENT_CLOSED
```

The prior bounded order/fill searches returned zero matching evidence, but the controlling reconciliation contracts explicitly preserve that absence as unresolved rather than converting it to proof of nonexistence.

### GD-SUB-HIST-003 — consumed predecessor execution attempts

The accepted project evidence records that:

```text
KALSHI_DEMO_ONE_ORDER_LIFECYCLE_EXECUTION_01
    prior one-shot execution = consumed

KALSHI_DEMO_POST_HALT_EXACT_WRITE_RESULT_RECONCILIATION_EXECUTION_01
    bounded read-only execution = consumed

KALSHI_DEMO_POST_HALT_FILL_DISCOVERY_BINDING_FALLBACK_EXECUTION_01
    bounded read-only execution = consumed
```

No prior execution permission is reusable or replayable.

The presence of installed read-only code does not imply permission to call it against Kalshi again.

---

## 5. Logical conflict-domain theorem

### GD-SUB-DOM-001 — current primary conflict domain

The installed Kalshi binding fixes:

```text
venue =
KALSHI

environment =
KALSHI_DEMO

account_scope_ref =
ARB_KALSHI_DEMO_PRIMARY_ACCOUNT

subaccount =
0

conflict_domain_ref =
KALSHI|KALSHI_DEMO|ARB_KALSHI_DEMO_PRIMARY_ACCOUNT|SUBACCOUNT=0
```

The market ticker is an event/strategy attribute. It is **not** part of this conflict-domain identity.

### GD-SUB-DOM-002 — different ticker is not different conflict domain

The following theorem is load-bearing:

```text
SELECTING A DIFFERENT TICKER
!=
SELECTING A DIFFERENT CONFLICT DOMAIN
```

Therefore:

```text
same environment
+
same account_scope_ref
+
same subaccount
+
different ticker
=
same logical conflict domain
```

A different market cannot bypass the historical hold.

### GD-SUB-DOM-003 — no logical-domain aliasing

The following transformations do not establish a new conflict domain:

```text
same account/subaccount + new ticker
    -> NOT A NEW DOMAIN

same account/subaccount + new ledger path
    -> NOT A NEW DOMAIN

same account/subaccount + new authority file
    -> NOT A NEW DOMAIN

same account/subaccount + new namespace string
    -> NOT A NEW DOMAIN

same account/subaccount + new strategy instance
    -> NOT A NEW DOMAIN

same account/subaccount + new process
    -> NOT A NEW DOMAIN

same account/subaccount + process restart
    -> NOT A NEW DOMAIN

same account/subaccount + new local database
    -> NOT A NEW DOMAIN
```

This adopts the following design rule as a normative ARB requirement for this scope:

> Logical conflict-domain separation MUST correspond to independently justified venue/economic isolation. Local filesystem, process, strategy, ticker, or naming differences are not economic isolation.

Rationale class:

```text
CONTROLLING_ARB_REQUIREMENT
+
ARB_INFERENCE
```

The controlling persistent-ledger contract already makes writer exclusivity conflict-domain-wide and rejects an alternate local writer universe for the same domain.

### GD-SUB-DOM-004 — minimum identity dimensions for a distinct Kalshi domain

A candidate distinct Kalshi execution domain MUST be identified at minimum by:

```text
venue
environment
account_scope_ref
subaccount
```

A canonical future construction is conceptually:

```text
KALSHI|<environment>|<account_scope_ref>|SUBACCOUNT=<exact venue subaccount>
```

This specification does not freeze a new concrete `account_scope_ref` or subaccount value because none is established.

Ticker MUST NOT be added merely to obtain a different string.

A future specification may change the conflict-domain theorem only if it proves an independent controlling economic-isolation theorem and explicitly supersedes this requirement. Convenience or historical-hold avoidance is not such a theorem.

---

## 6. Current runner impossibility theorem

### GD-SUB-RUN-001 — exact Stage-3C blockers

At the required canonical base, Stage 3C rejects locally before issuing `PreReleaseReadCapabilityV1` when, among other controlling predicates:

```text
history_completeness != COMPLETE

OR

protected_unresolved_legacy_write_count != 0

OR

unresolved_write_request_ids is non-empty
```

The current historical primary-domain projection is:

```text
history_completeness =
COMPLETE_WITH_PROTECTED_UNRESOLVED_LEGACY_WRITE

protected_unresolved_legacy_write_count =
1
```

Therefore Stage 3C rejects before the runner's venue-read phase.

### GD-SUB-RUN-002 — Gate D requires a genuine normal writer

Gate D requires a genuine Stage-3K `NORMAL_WRITER` acquisition and zero durable unresolved writes.

The current primary domain therefore has exact readiness:

```text
NOT_GATE_D_EXECUTION_READY
```

This is a controlling current result, not a strategy preference.

### GD-SUB-RUN-003 — no Stage-3C routing workaround

A future task MUST NOT:

- expose `PreReleaseReadCapabilityV1` before Stage 3C;
- issue equivalent credentials/network access through a second runner surface to evade Stage 3C;
- manufacture a `CurrentProcessReleaseCompletionV1`;
- construct a `NORMAL_WRITER` without the accepted acquisition path;
- replace the current projection with a locally claimed clean state;
- reinterpret the protected legacy count as zero.

If additional venue truth is needed while Stage 3C is deliberately closed, that truth must be acquired through a **separate, specifically bounded READ_ONLY historical reconciliation task** with its own capability, source binding, deadlines, evidence, and one-shot execution gate.

This specification does not authorize that future read.

---

## 7. Current clean-bootstrap impossibility theorem

### GD-SUB-BOOT-001 — observed persistence constants

The current canonical persistence contract fixes:

```text
AUTHORITY_SCHEMA_REVISION = 1
LEDGER_SCHEMA_REVISION = 1
EVENT_SCHEMA_REVISION = 1
PRELEDGER_HISTORY_MODE = LEGACY_IMPORT_REQUIRED
```

The initialization contract rejects a different pre-ledger history mode with:

```text
PRELEDGER_EMPTY_ASSERTION_UNSUPPORTED
```

### GD-SUB-BOOT-002 — replay of a ledger without an imported incident

Current replay classifies:

```text
if no imported_incident_ids:
    history_completeness = INCOMPLETE
    restart_classification = RESTART_LEGACY_HISTORY_INCOMPLETE
```

Therefore:

```text
NEW SQLITE FILE
!=
CLEAN HISTORY

NEW LEDGER INSTANCE
!=
CLEAN HISTORY

NEW AUTHORITY NAMESPACE
!=
NEW LOGICAL CONFLICT DOMAIN

NEW PROCESS
!=
CLEAN HISTORY
```

### GD-SUB-BOOT-003 — unsupported empty-history assertion remains prohibited

This specification MUST NOT introduce or reinterpret:

```text
PRELEDGER_HISTORY_PROVEN_EMPTY
```

and MUST NOT instruct an implementation to pass a new string under revision-1 semantics.

A new local store is evidence only of local store creation time. It is not evidence of venue-domain inception.

### GD-SUB-BOOT-004 — no legacy-incident cloning

A separate domain MUST NOT satisfy revision-1 completeness by copying or importing:

```text
KALSHI_DEMO_ONE_ORDER_LIFECYCLE_EXECUTION_01
```

into another account/subaccount namespace.

That incident belongs to the exact original conflict domain:

```text
KALSHI|KALSHI_DEMO|ARB_KALSHI_DEMO_PRIMARY_ACCOUNT|SUBACCOUNT=0
```

Cloning it would corrupt provenance and would not prove the alternate domain's history.

---

## 8. Required architecture decision

### GD-SUB-DEC-001 — exact route dispositions

This specification reaches these route-specific dispositions:

```text
ROUTE A =
ROUTE_A_NOT_CURRENTLY_EXECUTION_READY__NEW_BOUNDED_HISTORICAL_RECONCILIATION_EVIDENCE_REQUIRED

ROUTE B =
ROUTE_B_NOT_CURRENTLY_EXECUTION_READY__DOMAIN_EXISTENCE_AND_INCEPTION_UNPROVEN__PERSISTENCE_REVISION_REQUIRED
```

### GD-SUB-DEC-002 — exact overall closed-set disposition

The required closed-set overall result is:

```text
NO_CURRENTLY_VALID_EXECUTION_SUBSTRATE_PATH
```

Reason:

- Route A is technically resolvable **in principle** under the current safety architecture, but the evidence required to make the existing proof release-eligible is not currently available and the installed runner intentionally cannot acquire it from the held state.
- Route B is architecturally plausible only if a truly isolated venue/economic domain exists or is later created, but no such account/subaccount fact is established and the current revision-1 persistence contract cannot represent a trustworthy clean-domain inception.

A conditional future route is not a currently valid execution substrate.

---

## 9. ROUTE A — resolving the existing primary conflict domain

### GD-SUB-A-001 — Route A is not a hold bypass

Route A keeps the exact original domain:

```text
KALSHI|KALSHI_DEMO|ARB_KALSHI_DEMO_PRIMARY_ACCOUNT|SUBACCOUNT=0
```

It can become writer-eligible only by positively resolving the historical uncertainty under the accepted ledger/reconciliation/release architecture.

Route A MUST preserve:

- no cancellation without an exact authoritative `order_id`;
- no CREATE replay;
- no blind resend;
- no inference from zero current search results;
- unknown historical exposure remains `UNKNOWN_UNBOUNDED` while unresolved;
- no writer release until every controlling release predicate passes;
- explicit durable release remains mandatory.

### GD-SUB-A-002 — current cancellation target remains none

Current:

```text
bound_order_id = null
historical_incident_cancel_target = NONE
```

Therefore Route A currently has no historical cancellation operation.

No fuzzy identity, client-order-ID-only cancellation, ticker-wide cancellation, `cancel_all`, or inferred order ID may be introduced.

If a future reconciliation binds exactly one authoritative active `order_id`, cancellation—if required—becomes a new exact-target operation under the existing emergency/ordinary cancellation contracts and requires the separate capability applicable at that time.

### GD-SUB-A-003 — sufficient positive closure theorem

For Route A, a future evidence package may make the historical proof release-eligible only if it establishes one exact closure theorem.

At minimum the evidence MUST establish:

```text
A1. exact original conflict-domain identity;

A2. exact original incident identity;

A3. exact frozen client_order_id;

A4. either:
      exactly one authoritative venue order identity is bound
    OR
      a task-current official negative theorem explicitly proves, for the
      complete relevant source horizon, that the prior CREATE could not have
      produced any order/economic effect;

A5. if an order is bound:
      its immutable identity/economic fields agree with the frozen incident;

A6. if an order is bound:
      authoritative state proves no active remainder at the closure snapshot;

A7. complete required fill history is established across every applicable
    live/historical partition and retention boundary;

A8. every retained fill is exactly identity-bound and economically reconciled;

A9. no duplicate identity conflict, unknown order state, incomplete cursor,
    source gap, cutoff gap, or ambiguous write/cancel remains;

A10. incident exposure is no longer UNKNOWN_UNBOUNDED;

A11. the reconciliation result permits:
      writer_proof_release_eligible = true;

A12. all evidence is source-bound, timestamped, secret-safe, and immutable
     enough for later deterministic validation.
```

Under the **currently accepted historical sources**, complete zero order matches plus complete zero relevant fill discovery did not satisfy A4. It remained `WRITE_UNRESOLVED_ZERO_MATCH`.

A future task MUST NOT simply repeat the same negative inference and rename it closure.

### GD-SUB-A-004 — existing accepted read-only surfaces

The accepted exact-write-result reconciliation and fill-discovery fallback surfaces remain useful technical precedents because they already define:

- exact order identity;
- live/historical order/fill traversal;
- exact candidate binding;
- no fuzzy matching;
- pagination completeness;
- zero automatic retries;
- bounded deadlines;
- fail-closed handling of absent evidence.

However:

```text
installed code exists
!=
execution attempt remains available
```

The corresponding accepted execution attempts are consumed.

A future Route-A read task MUST have a new bounded task identity and new execution gating. It MAY reuse accepted implementation code only after the later task verifies that the exact current official source semantics and canonical implementation remain suitable.

### GD-SUB-A-005 — Stage-3C forces a separate future evidence lane

Because current Stage 3C rejects before the runner issues pre-release venue-read capability, the existing market-maker runner cannot be used to collect the historical evidence needed to cure the Stage-3C blocker.

This is deliberate architectural separation.

If Route A is pursued, the next technical task MUST be a separate future task conceptually equivalent to:

```text
KALSHI_DEMO_PRIMARY_DOMAIN_HISTORICAL_INCIDENT_RESOLUTION_READ_ONLY_SPEC_01
```

The exact future task name is not normative; the capability boundary is.

That future task must be:

```text
READ_ONLY venue evidence acquisition
exact original conflict domain
no CREATE
no CANCEL
no amend/decrease/replace
no funding
no writer release
no Stage-3C bypass
```

### GD-SUB-A-006 — durable evidence-ingest transition

A future read-only evidence artifact, by itself, MUST NOT mutate the proof.

After a qualifying evidence artifact exists, a separate bounded local durable-state integration task MUST validate that exact artifact identity and append only the existing schema-compatible authoritative events that the accepted contract permits.

For the current revision-1 architecture, the pivotal existing replay rule is:

```text
RECONCILIATION_RECORDED
with:
writer_proof_release_eligible = true
for the exact held incident

->
the held proof's replayed release eligibility may become true
```

For the imported historical incident, revision-1 replay removes the protected unresolved legacy count only when exactly one controlling held proof is associated with that incident and replay derives release eligibility `true` from a qualifying `RECONCILIATION_RECORDED`.

The current restricted-session event contract admits `RECONCILIATION_RECORDED` in `EMERGENCY_CONTROL_ONLY`; `RELEASE_ONLY` admits only the release/proof-release/risk-state subset and MUST NOT be repurposed to ingest reconciliation. Therefore any revision-1 durable historical-evidence ingest must use the accepted authority-first/ledger-second `EMERGENCY_CONTROL_ONLY` restricted-session path, without acquiring a normal writer and without exposing cancellation unless a separate exact-target cancellation contract actually applies.

Therefore, if and only if a future reconciliation satisfies GD-SUB-A-003 and all existing event-schema rules, the durable state-update sequence may conceptually be:

```text
1. acquire the exact EMERGENCY_CONTROL_ONLY restricted session under the
   accepted authority-first / ledger-second lock order;

2. validate exact authority + ledger identities and trusted tail;

3. validate exact qualifying reconciliation evidence;

4. append an exact schema-valid RECONCILIATION_RECORDED for the original
   incident with writer_proof_release_eligible = true and an
   authoritative-result closure classification justified by the evidence;

5. commit, advance the trusted authority anchor, and read back;

6. end the restricted session durably and verify final authority/ledger tail;

7. replay and require:
      protected_unresolved_legacy_write_count = 0
      history_completeness = COMPLETE
      writer_proof_state = HELD
      writer_proof_release_eligible = true
   plus no other controlling unresolved write;

8. stop. The evidence-ingest task itself does NOT release the writer proof.
```

If revision-1 event semantics cannot truthfully encode the actual new reconciliation result, the state-update task MUST halt rather than invent a compatible payload. A later persistence/spec revision would then be required.

### GD-SUB-A-007 — explicit durable release remains a distinct transition

Only after the durable projection in GD-SUB-A-006 is structurally release-capable may the accepted runner's later Stage 3 proceed through:

```text
3D/3E current read/reconciliation truth
    ->
3F ReleaseEvaluationStateV1
    ->
3G RELEASE_ONLY
    ->
3H exact durable release sequence
    ->
3I CurrentProcessReleaseCompletionV1
    ->
3J NORMAL_WRITER
    ->
3K final revalidation
```

The existing release architecture remains controlling. In particular, a qualifying historical reconciliation does not itself imply `WRITER_ELIGIBLE`.

### GD-SUB-A-008 — Route A halt classifications

Any of the following preserves the hold:

```text
HISTORICAL_EVIDENCE_INCOMPLETE
HISTORICAL_RETENTION_BOUNDARY_UNPROVEN
HISTORICAL_SOURCE_SEMANTICS_UNPROVEN
HISTORICAL_ORDER_IDENTITY_AMBIGUOUS
HISTORICAL_FILL_HISTORY_INCOMPLETE
HISTORICAL_EXPOSURE_UNKNOWN
HISTORICAL_RECONCILIATION_CONFLICT
HISTORICAL_RECONCILIATION_RESULT_AMBIGUOUS
RECONCILIATION_INGEST_NOT_SCHEMA_REPRESENTABLE
AUTHORITY_OR_LEDGER_IDENTITY_MISMATCH
AUTHORITY_ANCHOR_UPDATE_FAILED_OR_UNKNOWN
```

In every such case:

```text
writer_eligible = false
historical_unresolved_exposure = UNKNOWN_UNBOUNDED
```

unless a stronger exact known exposure is separately established without resolving writer eligibility. Unknown MUST NOT be defaulted to zero.

### GD-SUB-A-009 — Route A disposition

Current Route-A disposition:

```text
ROUTE_A_NOT_CURRENTLY_EXECUTION_READY__NEW_BOUNDED_HISTORICAL_RECONCILIATION_EVIDENCE_REQUIRED
```

Route A is **technically possible in principle** because the existing revision-1 replay architecture already has a schema-defined `RECONCILIATION_RECORDED` mechanism capable of making the exact held proof release-eligible when authoritative closure evidence exists.

But the required evidence does not currently exist, and this task neither acquires nor authorizes it.

---

## 10. ROUTE B — genuinely separate real execution substrate

### GD-SUB-B-001 — no assumption that an alternate domain exists

This task establishes none of the following:

```text
the account has a nonzero subaccount
the account can create subaccounts
the account is institution/market-maker eligible for subaccount creation
a numbered subaccount is unused
a numbered subaccount is history-free
an alternate account_scope_ref exists
an alternate account is funded
an alternate domain is authorized for ARB
```

Each is:

```text
UNRESOLVED_FACT
```

### GD-SUB-B-002 — venue/economic isolation requirement

A legitimate Route-B domain must be separated by actual venue/economic scope.

The minimum candidate separation dimensions are:

```text
environment
account_scope_ref
subaccount
```

A numbered subaccount MAY be a useful technical isolation dimension only if a future source-bound task proves that Kalshi treats it as a distinct order/position/balance/economic scope sufficient for ARB's conflict-domain theorem.

This specification does not promote the supplied subaccount research to current account fact.

### GD-SUB-B-003 — retained subaccount research authority

The supplied observations that Kalshi portfolio/order/position operations expose subaccount scoping, that Create Order V2 carries a subaccount field, that subaccount 0 is described as primary, that numbered subaccounts are described as separate scopes, that Create Subaccount has eligibility restrictions, and that authenticated subaccount-balance enumeration exists are classified:

```text
NON_CONTROLLING_EXTERNAL_RESEARCH
```

They justify investigating Route B. They do not prove that Route B exists for this account.

A later task that depends on exact current API behavior MUST reverify current official Kalshi documentation and bind the exact operations it uses.

### GD-SUB-B-004 — no primary fallback

If a future Route-B process selects a nonzero/alternate domain, any inability to resolve, initialize, fund, validate, or use that exact domain MUST fail closed.

It MUST NOT:

- fall back to subaccount `0`;
- omit the subaccount field and accept a default to primary;
- substitute the original account scope;
- switch to a different ticker on the primary account;
- use a local namespace that aliases primary.

Failure classification:

```text
ALTERNATE_DOMAIN_EXACT_IDENTITY_REQUIRED
```

---

## 11. Clean-domain inception theorem

### GD-SUB-INCEPT-001 — local recording start is not venue inception

The following are not proof of clean domain inception:

```text
first local ledger timestamp
authority-store creation time
SQLite file creation time
process start time
first ARB read time
first ARB strategy start time
```

A trustworthy clean-domain theorem MUST prove that ARB's durable history begins at the **actual venue-domain inception boundary**, not merely when ARB began observing it.

### GD-SUB-INCEPT-002 — exact two inception classes

Route B distinguishes exactly:

```text
NEWLY_CREATED_DOMAIN

PREEXISTING_BUT_APPARENTLY_UNUSED_DOMAIN
```

These classes have different proof burdens.

### GD-SUB-INCEPT-003 — clean inception predicate

A domain may be classified:

```text
DOMAIN_INCEPTION_PROVEN_CLEAN
```

only if all applicable predicates are true:

```text
1. exact venue/economic domain identity is proven;

2. actual venue inception boundary is proven;

3. no time exists before that boundary in which the same economic domain
   could have accepted orders, fills, positions, transfers, or other
   economically relevant state;

4. every operation that can create economic state at or after that boundary
   is either:
      a. durably recorded/reconciled by ARB, or
      b. authoritatively proven absent for the required interval;

5. historical data retention/cutoff semantics cannot hide relevant
   pre-ledger activity;

6. no ambiguous venue write exists;

7. no unresolved order/fill/position/inventory/exposure exists;

8. exact local authority/ledger binding begins from the proven inception
   theorem rather than a caller assertion.
```

If any predicate is unknown:

```text
DOMAIN_HISTORY_UNKNOWN
writer_eligible = false
```

### GD-SUB-INCEPT-004 — absence observations are insufficient for a preexisting domain

For a preexisting domain, none of these is individually sufficient:

```text
zero current orders
zero current positions
zero current fills
zero balance
```

Nor does this specification assume their conjunction is sufficient.

A domain may have had completed/canceled orders, fills followed by flattening, transfers, expired history, settlement, or other prior economic activity that leaves current snapshots empty.

---

## 12. NEWLY_CREATED_DOMAIN future contract

This section defines a conceptual future contract only. It performs no subaccount creation.

### GD-SUB-NEW-001 — prerequisite capabilities are separate

Before a new venue subaccount/domain can be created, a future task must separately establish:

```text
current official operation semantics
account eligibility for that operation
exact account scope
exact Demo environment
credential references
creation capability
creation request schema
creation result schema
creation reconciliation surface
durable local persistence path
```

Subaccount creation is a venue write.

It requires a separate future authorization and a durable write/reconciliation specification before execution.

### GD-SUB-NEW-002 — durable creation intent before send

A future new-domain creation contract MUST persist, before venue transport:

```text
domain_creation_attempt_id
exact environment
exact parent account_scope_ref
requested creation operation identity
request body hash / canonical non-secret request identity
send-boundary intent
creation purpose
automatic_retry = 0
```

The pre-send state MUST be authority-anchored and read back before transport, using a persistence contract suitable for the creation operation.

A network exception after send MUST NOT be interpreted as noncreation.

### GD-SUB-NEW-003 — creation result classes

A future creation contract MUST distinguish at least:

```text
DOMAIN_CREATION_CONFIRMED_EXACT
    task-current official semantics and authoritative venue evidence establish
    the exact venue-assigned new domain identity;

DOMAIN_CREATION_DEFINITIVELY_NOT_SENT
    local durable evidence proves the venue send boundary was never crossed;

DOMAIN_CREATION_DEFINITIVELY_REJECTED_NO_DOMAIN_CREATED
    only when task-current official semantics and exact response evidence
    positively establish no domain creation;

DOMAIN_CREATION_RESULT_UNKNOWN
    send may have occurred but exact resulting domain identity/existence is
    not authoritatively established.
```

`DOMAIN_CREATION_RESULT_UNKNOWN` MUST NOT be retried blindly.

It requires a separate exact creation-result reconciliation path.

### GD-SUB-NEW-004 — exact venue-assigned identity

A successfully created domain is not identified by a locally requested ordinal.

The future evidence MUST capture the exact authoritative venue-assigned subaccount/domain identity and bind:

```text
environment
parent account_scope_ref
exact venue subaccount identity
creation attempt identity
creation authoritative result identity
```

Only that exact identity may enter conflict-domain construction.

### GD-SUB-NEW-005 — proof the domain did not previously exist

A new-domain route is trustworthy only if the future source-bound creation semantics establish that:

```text
the newly assigned domain identity did not exist as the same economic scope
before the confirmed creation boundary
```

This proof must come from authoritative venue semantics/result evidence, not from an empty ARB ledger or from the fact that a numeric ID is new to the local program.

If the operation can return or reactivate an existing scope, that ambiguity must be resolved explicitly. Otherwise:

```text
DOMAIN_INCEPTION_UNKNOWN
writer_eligible = false
```

### GD-SUB-NEW-006 — post-creation initial-state snapshot

After exact creation is authoritatively confirmed and before any funding, transfer, order, or other economic write, a future separately authorized read-only step MUST capture the exact new-domain initial state required by the eventual writer-eligibility theorem.

At minimum the future contract must address:

```text
balance / collateral state
working orders
completed/historical orders where applicable
fills
positions
historical cutoff/retention boundary
transfers/funding ledger where exposed and relevant
```

The purpose of these reads is to corroborate post-inception state and bind the first usable local snapshot.

The proof of **no pre-inception history** comes from the confirmed new-domain creation theorem, not from empty current lists.

### GD-SUB-NEW-007 — funding/transfer provenance

Any funding or transfer into the new domain is a separate future economic write.

Before Gate-D use, each such write MUST have:

- durable pre-send intent;
- exact send boundary;
- exact source-bound request;
- no blind retry;
- authoritative result or unresolved classification;
- reconciliation of resulting balance/economic state;
- durable provenance linking the transfer to the exact new conflict domain.

A nonzero balance with unknown provenance is not clean writer eligibility.

This specification authorizes no funding or transfer.

### GD-SUB-NEW-008 — local conflict-domain and authority binding

Only after exact venue creation identity is confirmed may a future local bootstrap construct an exact new conflict-domain reference.

The future persistence revision MUST bind:

```text
exact new conflict_domain_ref
exact environment
exact account_scope_ref
exact venue subaccount identity
exact authority namespace identity
exact authority store
exact ledger instance/path
exact clean-inception evidence identity
exact inception boundary
```

The namespace is a persistence implementation detail; the venue/economic identity controls domain separation.

### GD-SUB-NEW-009 — failure after creation but before local durable binding

If the venue confirms creation but the local clean-domain authority/ledger binding is absent, fails, or is ambiguous:

```text
DOMAIN_CREATED_LOCAL_BINDING_INCOMPLETE
writer_eligible = false
```

The implementation MUST NOT create another subaccount to escape the failure.

A future reconciliation must recover the exact created venue identity and complete or safely quarantine the local binding.

### GD-SUB-NEW-010 — failure after local binding but before first execution

If the venue domain is confirmed, the clean-inception binding is durably complete, and no funding/order/write has occurred, a crash/restart does not erase the inception theorem.

On restart, the future persistence contract MUST replay the same exact domain identity and inception evidence.

However, restart alone MUST NOT imply `WRITER_ELIGIBLE`. All current writer predicates and any required current read/reconciliation freshness still apply.

### GD-SUB-NEW-011 — no primary fallback after any failure

At every future new-domain failure boundary:

```text
fallback_to_primary_subaccount_0 = PROHIBITED
```

---

## 13. PREEXISTING_BUT_APPARENTLY_UNUSED_DOMAIN future contract

### GD-SUB-PRE-001 — account fact first

Before a preexisting alternate domain is analyzed, a future read-only account-facts task must establish the exact domain identity.

This task does not access account metadata and therefore cannot enumerate such domains.

### GD-SUB-PRE-002 — complete-history requirement

A preexisting alternate domain may be accepted only if authoritative evidence establishes complete prior economic history from its actual venue inception through the evaluation snapshot.

The future evidence contract MUST address, at minimum:

```text
domain creation/inception evidence if exposed
all relevant order history
all relevant fill history
current and historical positions
current working orders
balance/collateral history to the extent required to prove unexplained
economic state absent
funding/transfer history to the extent required
settlement/state transitions where economically relevant
every historical API cutoff/retention boundary
pagination completeness
duplicate/conflict handling
```

The exact set must be narrowed by task-current official semantics.

### GD-SUB-PRE-003 — retention/cutoff theorem

If a historical endpoint returns only a retained window, or if the earliest accessible record is later than actual domain inception, a future task MUST NOT classify the missing interval as empty.

A valid completeness theorem must prove one of:

```text
A. the official source provides complete history back to actual domain inception;

B. an authoritative venue-created inception record establishes a later
   boundary from which the available historical sources are complete;

C. another authoritative export/audit source, explicitly source-bound by the
   future task, covers the otherwise missing interval.
```

Otherwise:

```text
DOMAIN_HISTORY_UNKNOWN
writer_eligible = false
```

### GD-SUB-PRE-004 — current zeros are only snapshot facts

The following may be recorded as snapshot observations:

```text
current_orders = 0
current_positions = 0
current_fills_in_returned_window = 0
current_balance = 0
```

They MUST NOT be transformed into:

```text
NO_PRIOR_HISTORY
DOMAIN_INCEPTION_PROVEN_CLEAN
```

without the complete-history theorem.

### GD-SUB-PRE-005 — prior writes must be closed

If any prior order/write is found, the future task must prove an exact closure state for every write that could still create or conceal economic exposure.

Any unresolved write yields:

```text
DOMAIN_HISTORY_UNKNOWN
writer_eligible = false
```

This rule applies even if current positions are zero.

---

## 14. Persistence compatibility decision

### GD-SUB-PERSIST-001 — exact compatibility question

The compatibility question is:

> Can a trustworthy clean-domain inception be represented truthfully using the currently installed `AUTHORITY_SCHEMA_REVISION=1`, `LEDGER_SCHEMA_REVISION=1`, `EVENT_SCHEMA_REVISION=1`, and `PRELEDGER_HISTORY_MODE=LEGACY_IMPORT_REQUIRED` without changing their meanings?

Answer:

```text
NO
```

### GD-SUB-PERSIST-002 — exact disposition

The required persistence disposition is:

```text
PERSISTENT_CLEAN_DOMAIN_BOOTSTRAP_NOT_REPRESENTABLE_UNDER_CURRENT_SCHEMA
```

Reasons:

1. initialization accepts only `LEGACY_IMPORT_REQUIRED`;
2. no imported incident yields `history_completeness=INCOMPLETE`;
3. the current Kalshi legacy-import binding is exact to the existing historical incident/domain;
4. caller-asserted empty pre-ledger history is explicitly rejected;
5. importing the original primary-domain incident into an alternate domain is prohibited and false;
6. no current revision-1 event encodes a distinct venue-proven clean-domain inception theorem;
7. silently reinterpreting `LEDGER_INITIALIZED` or `LEGACY_INCIDENT_IMPORTED` as clean-domain proof would change the persistent technical contract without a schema decision.

### GD-SUB-PERSIST-003 — future bounded persistence revision required

Before Route B can become a valid execution substrate, a later bounded persistent-ledger specification revision is required.

That future specification must decide explicitly whether to introduce:

```text
a new clean-domain inception event
and/or
a new pre-ledger history mode
and/or
a new authority/ledger metadata field set
and/or
a schema revision increment
```

It MUST NOT preserve numeric revision `1` while silently assigning new semantics to existing revision-1 bytes.

The exact future revision numbers and event names are deliberately **not** invented here. They must be selected by the future persistence specification after exact compatibility analysis.

### GD-SUB-PERSIST-004 — minimum semantics future persistence must support

Whatever representation is chosen, it must durably bind:

```text
conflict_domain_ref
environment
account_scope_ref
exact venue subaccount/domain identity
domain_inception_class
domain_inception_boundary_utc or exact source-native equivalent
inception_evidence_artifact identity
inception source identities
whether the domain was newly created or preexisting
history completeness theorem identity
authority instance/namespace identity
ledger instance/path identity
terminal trusted sequence/hash
```

Replay must distinguish at least:

```text
CLEAN_DOMAIN_INCEPTION_PROVEN
DOMAIN_HISTORY_UNKNOWN
DOMAIN_CREATION_RESULT_UNKNOWN
```

and must fail closed on unknown.

### GD-SUB-PERSIST-005 — migration/compatibility rule

A future persistence change MUST define:

- whether existing revision-1 primary-domain stores remain readable;
- whether migration is prohibited or explicitly required;
- exact old-binary/new-store failure behavior;
- exact new-binary/old-store behavior;
- authority/ledger schema matching;
- crash cases before/after inception-record commit;
- no automatic recreation of missing established stores;
- no rollback of a trusted anchor;
- deterministic export/evidence.

This specification itself performs no migration.

---

## 15. Universal writer-eligibility theorem

Regardless of Route A or B, Gate D may become structurally eligible only when all controlling predicates are true for the **same exact conflict domain**.

### GD-SUB-WRITER-001 — durable history predicates

At minimum:

```text
history_completeness = COMPLETE
protected_unresolved_legacy_write_count = 0
unresolved_write_request_ids = []
no unresolved domain-creation write
no unresolved funding/transfer write required for domain state
no unresolved emergency cancellation
no fill identity conflicts
no order identity conflicts
```

For a future clean-domain persistence revision, `COMPLETE` must mean the new source-bound inception theorem, not merely a new empty database.

### GD-SUB-WRITER-002 — exposure and reconciliation predicates

At minimum:

```text
inventory known
position known/corroborated as required by controlling risk contract
working-order set known and complete
fill history complete under task-current retention/cutoff semantics
historical exposure != UNKNOWN_UNBOUNDED
current exposure deterministically within configured limits
current market/reconciliation freshness valid
```

Unknown values remain unknown, never numeric zero.

### GD-SUB-WRITER-003 — proof and risk predicates

At minimum:

```text
controlling writer proof release-eligible
explicit durable release completed
risk state = WRITER_ELIGIBLE
active risk configuration exact and conflict-domain-bound
authority/ledger tails equal and read back
no active restricted session
no outstanding permit from another state
```

### GD-SUB-WRITER-004 — same-process release continuity

The accepted Stage-3 contract remains:

```text
qualifying persistent state
->
bounded current truth
->
RELEASE_ONLY
->
durable release
->
CurrentProcessReleaseCompletionV1
->
NORMAL_WRITER
->
Stage 3K revalidation
```

A prior process's token/handle cannot be reused.

### GD-SUB-WRITER-005 — no automatic restoration

None of the following implies writer eligibility:

```text
timer elapsed
reconnect succeeded
process restarted
API healthy
market changed
ticker changed
new day
strategy restarted
new ledger file
new authority file
new namespace string
```

Writer eligibility is an exact durable state transition plus current validated predicates.

---

## 16. Unknown remains fail-closed

### GD-SUB-UNK-001 — exact fail-closed rule

Preserve:

```text
unknown inventory
unknown position
unknown working orders
unknown fills
unknown historical completeness
unknown domain inception
unknown exposure
ambiguous venue write
unknown domain-creation result
unknown funding/transfer result

=>
risk-increasing write prohibited
```

### GD-SUB-UNK-002 — no default zeros

No implementation may coerce:

```text
None
missing field
empty response caused by incomplete pagination
read error
auth error
timeout
retention gap
unknown write result
```

into an economic zero.

### GD-SUB-UNK-003 — ambiguous creation is itself a protected write uncertainty

If a future subaccount/domain creation request crosses a send boundary and its result is ambiguous, that ambiguity must be durably preserved.

The system MUST NOT:

- assume no domain was created;
- retry creation blindly;
- allocate a second local namespace and forget the first attempt;
- use primary as fallback.

---

## 17. Capability matrix for this specification task

| Capability | This specification task |
|---|---|
| Canonical repository synchronization/inspection | PERMITTED, read-only only |
| Exact commit/tree/blob/file inspection | PERMITTED, read-only only |
| Project Knowledge / retained artifact reads | PERMITTED |
| Retained non-controlling research reads | PERMITTED |
| Public official documentation | NOT REQUIRED / NOT USED FOR A NEW CURRENT OPERATION BINDING |
| General internet research | NOT REQUIRED / NOT USED |
| Source-code changes | PROHIBITED |
| Test-source changes | PROHIBITED |
| Test execution | PROHIBITED |
| Project import/runtime execution | PROHIBITED |
| Package installation | PROHIBITED |
| Package registry | PROHIBITED |
| Persistent-state access/mutation | PROHIBITED |
| Kalshi Demo venue requests | PROHIBITED |
| Kalshi production venue requests | PROHIBITED |
| Credential/private-key/signing use | PROHIBITED |
| Account metadata inspection | PROHIBITED |
| Subaccount enumeration | PROHIBITED |
| Subaccount creation | PROHIBITED |
| Funding/transfer | PROHIBITED |
| CREATE/CANCEL/amend/decrease/replace | PROHIBITED |
| WebSocket | PROHIBITED |
| Local Git branch/commit/write | PROHIBITED |
| Remote Git push/PR/merge | PROHIBITED |

Repository read access does not imply venue access.

Specification description of future capabilities does not grant those capabilities.

### GD-SUB-CAP-001 — deadline/retry/redirect status

For this SPEC_ONLY artifact:

```text
venue_request_deadline = NOT_APPLICABLE
venue_request_retry_count = 0
venue_redirect_count = 0
```

because no venue request is permitted or performed.

Every future Route-A or Route-B venue task MUST freeze its own exact request set and, before execution:

```text
one executor-entry absolute monotonic master deadline
finite per-request ceiling
deadline coverage through response parsing/reconciliation/evidence close
automatic write retry = 0
automatic ambiguous-result retry = 0
redirects followed = 0
```

Read-only automatic retries also default to `0` unless a later controlling specification explicitly proves a different idempotent policy and freezes it. Deadline exhaustion is fail-closed and cannot convert unknown state into zero/clean history.

---

## 18. Future bounded task decomposition

This section specifies sequencing dependencies, not authorizations.

### GD-SUB-FUT-001 — if Route A is pursued

Required future work sequence:

```text
A1. dedicated bounded READ_ONLY historical incident-resolution specification

A2. separately authorized implementation + offline tests for that read-only
    task, if current accepted code is insufficient

A3. separately authorized one-shot read-only evidence acquisition

A4. bounded durable reconciliation-ingest/state-update specification that
    validates exact evidence and writes only schema-valid authoritative local
    state

A5. implementation + tests of A4 if not already represented by an accepted
    canonical path

A6. canonical installation/readiness verification

A7. only then run the existing Stage-3 release path under a separately
    authorized later execution task
```

No step inherits venue/write capability from a previous step.

### GD-SUB-FUT-002 — if Route B is pursued

Minimum future work sequence:

```text
B1. READ_ONLY account/subaccount capability-and-facts task
    - establish whether a distinct domain exists or creation is available
    - reverify task-current official subaccount semantics
    - no writes

B2. persistent clean-domain bootstrap specification revision
    - exact schema/history-mode/event compatibility decision
    - no venue write required merely to specify it

B3. implementation + offline tests of the persistent revision

B4a. if using a preexisting alternate domain:
     bounded complete-history READ_ONLY reconciliation task

OR

B4b. if creating a new domain:
     separate subaccount/domain-creation write specification
     + durable creation-result reconciliation
     + separate execution authorization

B5. separately specified funding/transfer contract if funding is required

B6. clean-domain bootstrap binding using exact inception evidence

B7. canonical installation/readiness review

B8. only then a later Gate-D market-maker execution specification
```

A future task may merge compatible **specification-only** questions, but it must not merge capabilities in a way that makes creation/funding/trading implicit.

---

## 19. Required future tests and evidence

This artifact runs no tests. It freezes what later implementation evidence must prove.

### GD-SUB-TEST-001 — conflict-domain identity tests

Required:

1. same account/subaccount + different ticker => same conflict domain;
2. same account/subaccount + different ledger path => same conflict domain;
3. same account/subaccount + different authority namespace => same conflict domain;
4. process restart => same conflict domain;
5. exact distinct account/subaccount identity => distinct candidate domain only when explicitly source/economically justified;
6. primary fallback is impossible after alternate-domain failure.

### GD-SUB-TEST-002 — current primary-domain denial

Against synthetic/offline canonical projection:

```text
history_completeness =
COMPLETE_WITH_PROTECTED_UNRESOLVED_LEGACY_WRITE

protected_unresolved_legacy_write_count =
1
```

prove:

```text
Stage 3C rejects
PreReleaseReadCapabilityV1 not issued
venue request count = 0
NORMAL_WRITER not acquired
Gate D not entered
```

### GD-SUB-TEST-003 — current revision-1 clean-bootstrap denial

Prove:

1. new authority/ledger under `LEGACY_IMPORT_REQUIRED` with no import replays `INCOMPLETE`;
2. restart class is `RESTART_LEGACY_HISTORY_INCOMPLETE`;
3. unsupported empty-history mode yields `PRELEDGER_EMPTY_ASSERTION_UNSUPPORTED`;
4. local path/namespace changes do not establish domain separation;
5. cloning the primary incident into a different domain is rejected.

### GD-SUB-TEST-004 — Route-A positive reconciliation transition

If Route A implementation is later built, prove with synthetic authoritative evidence:

1. qualifying exact terminal order/fill reconciliation appends exact schema-valid `RECONCILIATION_RECORDED`;
2. replay sets `writer_proof_release_eligible=true`;
3. protected unresolved legacy count becomes zero only for the exact associated incident/proof;
4. history becomes `COMPLETE`;
5. proof remains `HELD` until explicit release;
6. unrelated or conflicting reconciliation cannot release eligibility;
7. authority commit/readback failure prevents relying on the event;
8. no cancellation is constructed when `bound_order_id=null`.

### GD-SUB-TEST-005 — Route-B clean inception revision

A future persistence revision must prove, at minimum:

- newly created exact domain identity;
- domain inception evidence binding;
- preexisting-domain unknown history denial;
- ambiguous creation result denial;
- failure after venue creation/before local binding;
- failure after local binding/before first execution;
- restart replay of exact inception proof;
- no primary fallback;
- no legacy-incident cloning;
- old/new schema compatibility and fail-closed behavior;
- authority/ledger anchor failure handling.

### GD-SUB-TEST-006 — evidence identity

Every future venue evidence artifact used to alter safety state must carry or be externally bound to:

```text
task_id
repository/base identity
implementation identity
official-source identities
environment
account_scope_ref
subaccount
conflict_domain_ref
request ledger
retry/redirect counts
deadlines
response identities
pagination completeness
terminal classification
secret-redaction confirmation
```

The durable state update must bind the exact artifact byte length and SHA-256, or another equivalently exact immutable identity frozen by its controlling specification.

---

## 20. Material premise register

| Premise | Classification | Current value / interpretation |
|---|---|---|
| Current primary conflict domain is account/subaccount-wide | CONTROLLING_ARB_REQUIREMENT | `KALSHI|KALSHI_DEMO|ARB_KALSHI_DEMO_PRIMARY_ACCOUNT|SUBACCOUNT=0` |
| Ticker is not part of that conflict domain | CONTROLLING_ARB_REQUIREMENT | Different ticker does not escape the hold |
| Historical CREATE remains unresolved | CONTROLLING_ARB_REQUIREMENT | `WRITE_UNRESOLVED_ZERO_MATCH` |
| No authoritative order ID is bound | CONTROLLING_ARB_REQUIREMENT | `bound_order_id=null` |
| Historical exposure remains unknown | CONTROLLING_ARB_REQUIREMENT | `UNKNOWN_UNBOUNDED` |
| Stage 3C rejects incomplete/protected/unresolved history | CONTROLLING_ARB_REQUIREMENT | Canonical runner code |
| Gate D requires genuine Stage-3K `NORMAL_WRITER` | CONTROLLING_ARB_REQUIREMENT | No synthetic handle/token |
| New revision-1 ledger without imported incident is incomplete | CONTROLLING_ARB_REQUIREMENT | Canonical replay |
| Empty pre-ledger assertion is unsupported | CONTROLLING_ARB_REQUIREMENT | `PRELEDGER_EMPTY_ASSERTION_UNSUPPORTED` |
| Qualifying `RECONCILIATION_RECORDED` can make exact held proof release-eligible | CONTROLLING_ARB_REQUIREMENT | Canonical replay |
| Prior reconciliation/fill-discovery executions are consumed | CONTROLLING_ARB_REQUIREMENT | No implicit rerun |
| Unknown must not become zero | CONTROLLING_ARB_REQUIREMENT | Fail closed |
| Venue subaccounts may be separate economic scopes | NON_CONTROLLING_EXTERNAL_RESEARCH | Must be reverified before use |
| Create Subaccount may have account-class eligibility restrictions | NON_CONTROLLING_EXTERNAL_RESEARCH | Does not prove this account qualifies |
| This account has another subaccount | UNRESOLVED_FACT | Not inspected |
| This account may create a subaccount | UNRESOLVED_FACT | Not inspected |
| Any alternate subaccount is unused/history-free | UNRESOLVED_FACT | Not inspected |
| A newly created exact venue domain can supply a trustworthy inception boundary if current venue semantics prove non-preexistence | ARB_INFERENCE adopted conditionally | Requires future source-bound proof |
| A local file/namespace/process cannot itself create economic isolation | ARB_INFERENCE adopted as requirement, consistent with controlling ledger architecture | No local aliasing |
| Current revision-1 persistence cannot truthfully represent clean-domain inception | ARB_INFERENCE from controlling canonical code, adopted as this specification's compatibility disposition | Future persistence revision required |

---

## 21. Requirement traceability matrix

| SPEC REQUIREMENT | CONTROLLING PREDECESSOR / CODE CONTRACT | RATIONALE | REQUIRED FUTURE EVIDENCE | STATUS |
|---|---|---|---|---|
| GD-SUB-DOM-002 different ticker != different domain | Persistent Ledger Spec 03; `CURRENT_CONFLICT_DOMAIN_REF` in `ledger_binding.py` | Historical hold is account/subaccount-wide | Static identity test | SPEC_DEFINED |
| GD-SUB-DOM-003 no local aliasing | Persistent Ledger Spec 03 authority/conflict-domain exclusivity | New local state is not economic isolation | Negative alias tests | SPEC_DEFINED |
| GD-SUB-RUN-001 Stage-3C local denial | canonical `minimal_market_maker_experiment_runner.py` | Prevents venue reads from a structurally unreleasable state | Current-state denial test | SPEC_DEFINED |
| GD-SUB-A-003 positive closure theorem | Exact Reconciliation Spec 01 + Fill Discovery Fallback Spec 01 | Zero matches never proved nonexistence | New bounded historical evidence | FUTURE_EVIDENCE_REQUIRED |
| GD-SUB-A-006 durable reconciliation ingest | `RECONCILIATION_RECORDED` replay in `execution_ledger.py` | Existing schema has a legitimate proof-eligibility transition | Exact evidence artifact + anchored event/readback | FUTURE_TASK_REQUIRED |
| GD-SUB-A-007 explicit release | Emergency/Risk Spec 03 + runner Stage 3 | Reconciliation eligibility is not writer release | Release predicate vector + authority/ledger evidence | FUTURE_TASK_REQUIRED |
| GD-SUB-B-002 actual venue/economic separation | controlling conflict-domain architecture + research | Local naming cannot isolate risk | Account/subaccount source-bound evidence | UNRESOLVED_FACT |
| GD-SUB-INCEPT-003 clean inception theorem | Persistent Ledger Spec 03 + ARB inference | Ledger start must match venue history boundary | Creation or full-history evidence | FUTURE_EVIDENCE_REQUIRED |
| GD-SUB-PRE-003 retention theorem | accepted reconciliation source/cutoff architecture | Missing historical interval cannot be called empty | Current official retention/cutoff binding | FUTURE_EVIDENCE_REQUIRED |
| GD-SUB-PERSIST-002 current schema not representable | `execution_ledger.py` rev1 constants/replay/init | No import => incomplete; empty assertion rejected | Static compatibility review | SPEC_RESOLVED |
| GD-SUB-PERSIST-003 later persistence revision | same | Clean-domain inception needs explicit durable semantics | New bounded persistent-ledger spec | FUTURE_TASK_REQUIRED |
| GD-SUB-WRITER-005 no automatic restoration | Emergency/Risk Spec 03 + runner architecture | Restart/timer/API health are not proof transitions | Restart/timer negative tests | SPEC_DEFINED |
| GD-SUB-UNK-001 unknown fail-closed | accepted risk/reconciliation architecture | Prevents hidden exposure from becoming new risk | Failure-path tests | SPEC_DEFINED |
| GD-SUB-NEW-003 ambiguous domain creation | ARB inference from durable ambiguous-write architecture | A domain-creation write can be unknown after send | Future creation reconciliation evidence | FUTURE_TASK_REQUIRED |
| GD-SUB-NEW-011 no fallback to primary | current primary hold + separate-domain theorem | Fallback would re-enter held domain | Negative routing tests | SPEC_DEFINED |

---

## 22. External research usage and adoption map

### GD-SUB-RESEARCH-001 — retained research ledger

`MARCO_ARB_EXTERNAL_RESEARCH_FINDINGS_MASTER_01.md` is used only as:

```text
NON_CONTROLLING_EXTERNAL_RESEARCH
```

Research themes considered:

- unknown is not zero;
- absence is not proof of nonexistence;
- unresolved CREATE with no exact order ID has no cancellation target;
- single-writer scope should cover the logical conflict domain rather than one database file;
- restart/reconnect/timer should not restore writer eligibility;
- alternate local namespace is not economic isolation;
- venue-side subaccount separation is useful only if exact economic isolation and inception are established.

### GD-SUB-RESEARCH-002 — what became normative here

Research does not directly create requirements.

This specification independently adopts only the following conclusions because they are also consistent with controlling ARB safety architecture:

1. local namespace/path/process differences do not establish conflict-domain separation;
2. unknown domain inception is fail-closed;
3. a preexisting alternate domain requires authoritative historical completeness, not empty current snapshots;
4. a future newly created domain is potentially useful only if creation semantics positively prove a non-preexisting economic scope and the result is durably reconciled.

The source of normativity is this specification plus its controlling ARB rationale, not the research ledger.

### GD-SUB-RESEARCH-003 — no new current official API claim

This specification does not depend on a newly verified current Create Subaccount or account-enumeration operation.

No new official-source operation binding is frozen here.

Any later task that uses such an operation must reverify task-current official Kalshi documentation and record source provenance.

---

## 23. Exact unresolved account/subaccount facts

The following remain unresolved after this specification:

```text
alternate_subaccounts_present = UNKNOWN
alternate_subaccount_ids = UNKNOWN
alternate_subaccount_inception_times = UNKNOWN
alternate_subaccount_history_completeness = UNKNOWN
alternate_subaccount_unused = UNKNOWN
alternate_subaccount_balance = UNKNOWN
alternate_subaccount_positions = UNKNOWN
alternate_subaccount_orders = UNKNOWN
alternate_subaccount_fills = UNKNOWN
account_subaccount_creation_eligibility = UNKNOWN
subaccount_creation_current_api_semantics = NOT_REVERIFIED_BY_THIS_TASK
subaccount_creation_authorized = false
funding_transfer_authorized = false
```

No unresolved fact may be filled from assumption.

---

## 24. Exact completion dispositions

### GD-SUB-COMP-001 — current domain

```text
current_conflict_domain =
KALSHI|KALSHI_DEMO|ARB_KALSHI_DEMO_PRIMARY_ACCOUNT|SUBACCOUNT=0

current_domain_readiness =
NOT_GATE_D_EXECUTION_READY
```

### GD-SUB-COMP-002 — Route A

```text
route_a_disposition =
ROUTE_A_NOT_CURRENTLY_EXECUTION_READY__NEW_BOUNDED_HISTORICAL_RECONCILIATION_EVIDENCE_REQUIRED
```

The route is technically resolvable in principle under current revision-1 persistence if genuinely authoritative closure evidence can be obtained and durably ingested. No such evidence is established here.

### GD-SUB-COMP-003 — Route B

```text
route_b_disposition =
ROUTE_B_NOT_CURRENTLY_EXECUTION_READY__DOMAIN_EXISTENCE_AND_INCEPTION_UNPROVEN__PERSISTENCE_REVISION_REQUIRED
```

A newly created isolated domain is a plausible architecture only after account eligibility/current venue semantics are established and a clean-domain persistence contract is implemented. A preexisting alternate domain remains `DOMAIN_HISTORY_UNKNOWN` until complete prior history is proven.

### GD-SUB-COMP-004 — persistence

```text
persistence_compatibility_disposition =
PERSISTENT_CLEAN_DOMAIN_BOOTSTRAP_NOT_REPRESENTABLE_UNDER_CURRENT_SCHEMA
```

### GD-SUB-COMP-005 — required closed-set overall outcome

Exactly:

```text
NO_CURRENTLY_VALID_EXECUTION_SUBSTRATE_PATH
```

### GD-SUB-COMP-006 — next-stage boundary

This artifact does not authorize:

```text
KALSHI_DEMO_MINIMAL_TWO_SIDED_MARKET_MAKER_EXECUTION_SPEC_01
```

That later task is permitted to become a specification candidate only after a valid substrate route is implemented/readiness-proven and canonically installed under later bounded tasks.

---

## 25. Final self-check

This specification is complete only if all of the following remain true:

- exact canonical commit/tree/parent are recorded;
- current historical incident is unchanged;
- current conflict-domain identity is unchanged;
- ticker is not used as a conflict-domain escape;
- Stage 3C predicates are not weakened;
- existing runner read capability is not used to route around Stage 3C;
- consumed historical read executions are not inferred reusable;
- Route A requires new authoritative evidence if pursued;
- no cancellation target is invented;
- no CREATE replay or blind resend is permitted;
- Route B assumes no alternate account/subaccount exists;
- newly created and preexisting alternate domains use different inception proof burdens;
- zero current orders/fills/positions/balance do not prove clean prior history;
- domain creation/funding are future venue writes with separate durable contracts;
- no legacy incident is cloned into a separate domain;
- no new local namespace is treated as economic isolation;
- revision-1 clean bootstrap is classified non-representable;
- no new event/history mode/schema interpretation is smuggled into revision 1;
- unknown remains fail-closed;
- explicit durable release remains mandatory;
- Gate D still requires genuine Stage-3K `NORMAL_WRITER`;
- no implementation, tests, credentials, venue requests, persistent mutation, or repository/Git writes were performed.

`STOP_AFTER_KALSHI_DEMO_GATE_D_REAL_EXECUTION_SUBSTRATE_AND_WRITER_ELIGIBILITY_SPEC_01_AND_HANDOFF_DELIVERY`
