# HANDOFF_KALSHI_DEMO_EMERGENCY_CANCELLATION_AND_RISK_LIMITS_SPEC_03

```yaml
artifact_class: TECHNICAL_HANDOFF
subordinate_to: KALSHI_DEMO_EMERGENCY_CANCELLATION_AND_RISK_LIMITS_SPEC_03.md
implementation_performed_by_this_artifact: false
tests_executed_by_this_artifact: false
venue_capability_granted: false
correction_scope: HALT_OWNERSHIP_LOCK_HANDOFF_ONLY
```

## 1. Controlling artifact and precedence

This handoff is subordinate to Revision 03. If any wording in this handoff differs from the specification, the specification controls.

```text
controlling_specification = KALSHI_DEMO_EMERGENCY_CANCELLATION_AND_RISK_LIMITS_SPEC_03.md
bytes = 183042
sha256 = bb8f078185eb766ed1589441712d9cc6fcd77f574a1a2100a1901cfb75e9c8cb
```

Revision 03 is a bounded same-scope correction of blocked Revision 02. It changes exactly one contract: ownership and lock handoff for durable HALT when a live `NORMAL_WRITER ws_` already owns the authority+ledger exclusive pair.

## 2. Exact canonical repository

```text
repository = rigolugo/ARB
canonical_main = f9fcd96b5b3efa7a3adfc2d9eabb133aa09cac82
canonical_tree = f3992ba10735c4cafafa541f598add1b6e5e80ba
canonical_parent = 5a65ccadb05b29d6e8692a108bcf46347ec0d214
lock_model = AUTHORITY_THEN_LEDGER_SQLITE_EXCLUSIVE_V1
```

Do not advance, rebase, retarget, or substitute another base.

## 3. Exact blocked Revision-02 identities

```text
blocked_specification:
  KALSHI_DEMO_EMERGENCY_CANCELLATION_AND_RISK_LIMITS_SPEC_02.md
  bytes = 158408
  sha256 = 4b59f5449d950856f4a16c10d573c4def8eae675a3d1e8f9481ba1540a6d73ff

blocked_handoff:
  HANDOFF_KALSHI_DEMO_EMERGENCY_CANCELLATION_AND_RISK_LIMITS_SPEC_02.md
  bytes = 36284
  sha256 = 82ba54be053cd0e6eeccb275d7f4eb6b2460217bf0ea35051eaa91a779c3edb9
```

Revision 02 is blocked only for the HALT-ownership/exclusive-lock contradiction. Its event schemas, restricted-session model, permit model, economic/reference/freshness rules, release contract, historical incident treatment, and persistence architecture are preserved.

## 4. Controlling persistent-ledger and current-state identities

```text
KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_03.md
  bytes = 141566
  sha256 = 98592d719db2dcb59bb5ade6f18700b9acf4ae1049480f409b60f228f1518ead

HANDOFF_KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_03.md
  bytes = 17942
  sha256 = 43dd06f5a7d976bff54574f60298c7568f74e9c24b8f257e32306b45c8289b93

KALSHI_DEMO_PERSISTENT_LEDGER_BOOTSTRAP_AND_LEGACY_IMPORT_EXECUTION_01_EVIDENCE.json
  bytes = 5835
  sha256 = d73dd836137804fca1e472327ca6f742c754579a5503ad3dea21706ba547e35e

KALSHI_DEMO_PERSISTENT_LEDGER_BOOTSTRAP_AND_LEGACY_IMPORT_EXECUTION_01_RESTART_EXPORT.json
  bytes = 1817
  sha256 = 2f541e372efd5f5c65dab1c77972ddcf24bb7f0824a5d77e97b90020f80b5a6a
```

Current historical incident remains exactly:

```text
incident_id = KALSHI_DEMO_ONE_ORDER_LIFECYCLE_EXECUTION_01
disposition = WRITE_UNRESOLVED_ZERO_MATCH
bound_order_id = null
created_order_upper_bound = 1
active_order_upper_bound = 1
unknown_result = true
writer_proof_state = HELD
writer_proof_release_eligible = false
protected_unresolved_legacy_write_count = 1
history_completeness = COMPLETE_WITH_PROTECTED_UNRESOLVED_LEGACY_WRITE
restart_classification = RESTART_UNRESOLVED_WRITE_HELD
normal_writer_handle = NONE
historical_incident_cancel_target = NONE
historical_unresolved_exposure = UNKNOWN_UNBOUNDED
release_eligible = false
```

Never infer `CREATE_NEVER_EXISTED`, `CREATE_DEFINITELY_FAILED`, `SAFE_TO_RETRY_CREATE`, `SAFE_TO_CANCEL`, `WRITER_PROOF_RELEASED`, or `INCIDENT_CLOSED`.

## 5. Revision-03 correction theorem

The exact ownership ordering is:

```text
HARD VIOLATION
→ NORMAL PERMITS INVALID / HARD-HALT LATCHED
→ HALT APPENDED BY CURRENT LIVE ws_ WHEN ws_ OWNS BOTH STORES
→ HALT LEDGER COMMITTED
→ AUTHORITY ADVANCED + COMMITTED
→ AUTHORITY + LEDGER TAIL POSITIVELY READ BACK
→ NORMAL ws_ CLEANLY ENDED
→ SESSION-END AUTHORITY + LEDGER READ BACK
→ NORMAL HANDLES CLOSED / LOCKS RELEASED
→ ONLY THEN EMERGENCY_CONTROL_ONLY MAY FRESHLY ACQUIRE
→ rs_ SESSION MAY START
```

There is no `ws_→rs_` in-place conversion, no simultaneous live `ws_`/`rs_` ownership, no lock transfer by object reuse, and no restricted acquisition before normal lock release.

## 6. CASE A — active normal writer owns both stores

Preconditions:

- live current-process `NORMAL_WRITER ws_` exists;
- same handle owns authority and ledger exclusive locks;
- projected state is `WRITER_ELIGIBLE`;
- hard safety violation is detected.

Exact sequence:

1. under the gate-private synchronization shared with adapter entry, set `hard_halt_requested=true`;
2. invalidate every outstanding permit/progress whose transport has not irrevocably entered, including T3-consumed progress with `transport_invocation_count=0`;
3. prohibit new permit minting and further T0→T3 progression;
4. do not invoke or construct `EMERGENCY_CONTROL_ONLY` acquisition while the live `ws_` owns either store;
5. current `ws_` appends the exact Revision-02 `RISK_CONTROL_STATE_CHANGED` event:

```text
previous_state = WRITER_ELIGIBLE
new_state = HALTED
cause = HARD_SAFETY_VIOLATION
writer_session_id = current live ws_
incident_id = null
execution_attempt_id = null
```

All other payload fields are exactly Section 7.4 of Revision 03 / preserved Revision 02: epoch before/after, risk-config identity, null emergency/release refs, immediate prior state-event ref, and exact pre-event authority/ledger tail identity.

6. ledger commit succeeds;
7. authority trusted tail advances/commits;
8. authority sequence/hash and ledger terminal sequence/hash are positively read back equal to each other and to the HALT row;
9. only then append the existing exact `WRITER_SESSION_ENDED` for that same live `ws_`;
10. ledger-commit / authority-advance / read back the clean end;
11. close normal ledger/authority handles and release the locks;
12. only after release may a later emergency phase call fresh restricted acquisition;
13. the fresh emergency acquisition replays trusted HALT and must not append a duplicate HALT before starting its `rs_` session.

## 7. CASE B — no live normal writer owns the stores

Exact sequence:

1. call fresh `EMERGENCY_CONTROL_ONLY` acquisition;
2. acquire authority first and ledger second, exclusively;
3. validate path/schema/integrity/hash/authority relation and replay;
4. an unended prior `ws_` may be marked `WRITER_SESSION_ABANDONED` only now, because the fresh lock pair proves the old owner no longer owns the required stores;
5. clean stale prior `rs_` under preserved restricted-session abandonment rules;
6. prove no active session remains;
7. append/anchor/read back exactly one `RESTRICTED_SESSION_STARTED(mode=EMERGENCY_CONTROL_ONLY)`;
8. if HALT is already trusted, do not duplicate it;
9. if a valid held/HALT transition is still required by the closed state table, append/commit/authority-anchor/read back that exact transition under the active emergency `rs_`;
10. continue emergency planning only after the required held/HALT state is trusted.

CASE B creates no ordinary `ws_`, restores no normal permit, and infers no venue outcome from session cleanup.

## 8. HALT event ownership by mode

Preserve the Revision-02 event admission table with this explicit ownership rule:

```text
live current-process ws_ owns both stores
AND projected state = WRITER_ELIGIBLE
AND cause = HARD_SAFETY_VIOLATION
    => only that same NORMAL_WRITER ws_ may append
       RISK_CONTROL_STATE_CHANGED(WRITER_ELIGIBLE→HALTED)
```

`EMERGENCY_CONTROL_ONLY` must reject/not attempt the same transition while the live normal owner exists. After clean normal close/release, the emergency `rs_` may append only valid subsequent transitions already admitted by Revision 02. Ownership change itself is never a reason to append a duplicate HALT.

## 9. `NormalWriterPermit` hard-HALT interaction

Revision-02 T0→T1→T2→T3 remains unchanged for ordinary writes. Hard HALT adds one terminal arbitration rule:

- adapter-entry and hard-HALT invalidation share one process-private gate synchronization;
- if hard HALT wins first, every not-entered permit/progress becomes `INVALIDATED`, including T3-consumed progress with invocation count zero, and adapter entry is prohibited;
- if adapter entry atomically changes invocation count `0→1` first, that one invocation is already entered and may return/raise, but no second invocation is possible;
- no new permit may be minted after the hard-HALT latch;
- the `ws_` HALT append is an intentional control event, not a request-stage successor and not a reason to continue or recreate the normal permit;
- a trusted normal write send boundary remains conservative after process loss; HALT never converts ambiguity into `NO_SEND_PROVEN`;
- already-entered/ambiguous normal writes remain subject to exact predecessor reconciliation and blind resend is prohibited.

## 10. HALT failure and authority-unknown behavior

### 10.1 Failure before HALT ledger COMMIT

Required:

- normal permits stay invalidated;
- no new normal transport;
- no emergency transport;
- no restricted acquisition using still-owned normal locks;
- no new normal request/permit retry;
- close/reopen only under predecessor durability rules;
- restart remains write-ineligible;
- do not claim trusted persistent `HALTED` without positive durable proof.

### 10.2 HALT ledger COMMIT succeeds; authority advancement definitely fails

Required:

- no normal or emergency venue transport;
- no clean-end append or restricted acquisition on the uncertain handle;
- close the handle;
- fresh reopen validates authority first and ledger second;
- if exact predecessor `LEDGER_AHEAD` catch-forward is valid, catch forward only to the validated ledger tail and positively read it back;
- no duplicate HALT;
- no writer restoration.

### 10.3 HALT authority commit result unknown

Required:

- no transport or normal continuation;
- close current handle;
- fresh reopen determines `EQUAL` versus valid `LEDGER_AHEAD` only from durable state;
- catch forward only where predecessor rules prove it;
- never assume HALT absent;
- never append a duplicate HALT until replay proves exact state and the transition remains valid;
- never restore writer eligibility or reconstruct the old permit.

Only positive HALT authority+ledger readback permits the live-success path to normal clean shutdown and later emergency acquisition.

## 11. Clean `ws_` versus abandoned `ws_`

Live-success CASE A MUST use:

```text
WRITER_SESSION_ENDED
writer_session_id = same live ws_
payload = {"writer_session_id": same live ws_}
```

The end event must itself ledger-commit, authority-advance, and read back before normal lock release.

`WRITER_SESSION_ABANDONED` is reserved for a later fresh acquisition/reopen that already owns both exclusive stores and thereby proves a replayed old session no longer owns them. It must not be used against a currently live `ws_` merely to get an `rs_`.

If HALT is trusted but the live session-end append/authority result fails or is unknown, close; a later fresh acquisition may use abandonment cleanup if the clean end is not trusted. No duplicate HALT is emitted.

## 12. Lock release and restricted acquisition ordering

Exact boundary:

```text
trusted HALT under ws_
→ trusted WRITER_SESSION_ENDED under ws_
→ close normal ledger/authority handles
→ normal lock ownership = NONE
→ create/invoke fresh EMERGENCY_CONTROL_ONLY acquisition
→ authority EXCLUSIVE
→ ledger EXCLUSIVE
→ replay/cleanup
→ trusted RESTRICTED_SESSION_STARTED(rs_)
```

No API may convert the old `LockedLedger`, ordinary handle, `ws_`, normal permit, or its locks into restricted capability by reuse.

## 13. Restart/replay

Every restart begins `BOOT_HOLD`, exposes no normal or emergency permit, opens/validates/replays existing state, and derives the trusted prefix. A historical `WRITER_ELIGIBLE` event does not auto-restore normal execution.

After HALT commit/authority failure or unknown result, only durable `EQUAL`/`LEDGER_AHEAD` predecessor semantics determine the state. A new explicit durable release remains required wherever Revision 02 required it.

## 14. Focused mandatory tests

All Revision-02 tests remain mandatory. Add:

### HALT-OWN-01

Active `ws_` owns both locks; `WRITER_ELIGIBLE`; unused permit. Inject hard violation. Require permit invalidated; zero early restricted acquisitions; exact `ws_` HALT append; ledger commit + authority advance/readback; zero normal transport; PASS only after trusted HALT.

### HALT-OWN-02

Instrument restricted acquisition constructor/call. Before trusted HALT + trusted `WRITER_SESSION_ENDED` + normal handle close/lock release, restricted acquisition count is exactly zero. First restricted acquisition may occur only after release.

### HALT-OWN-03

Assert exact trace:

```text
ws_ HALT event
→ HALT authority+ledger readback
→ WRITER_SESSION_ENDED
→ end authority+ledger readback
→ lock close/release
→ fresh EMERGENCY_CONTROL_ONLY acquire
→ RESTRICTED_SESSION_STARTED
```

No duplicate HALT; no `WRITER_SESSION_ABANDONED` on live-success path.

### HALT-OWN-04

Inject HALT ledger failure before COMMIT. Permit invalid; no normal/emergency transport; no `rs_` acquisition through still-owned locks; no trusted-HALT claim; restart fail closed.

### HALT-OWN-05

Inject HALT ledger COMMIT success + definite authority failure. No transport; close; fresh replay identifies valid ledger-ahead; predecessor catch-forward only; no duplicate HALT; no automatic writer restoration.

### HALT-OWN-06

Inject authority commit result unknown. No transport; close/reopen; derive only `EQUAL` or `LEDGER_AHEAD`; no duplicate HALT; no automatic writer restoration.

### HALT-OWN-07

No live normal owner. Emergency mode may acquire directly authority-first/ledger-second; clean stale sessions only under fresh locks; start `rs_`; persist a required valid held/HALT transition if needed; create no normal session.

### HALT-OWN-08

Trusted normal write send boundary exists before hard violation and transport is entered/ambiguous. HALT persists; ambiguity remains; no `NO_SEND_PROVEN`; no blind resend; reconciliation required; no second invocation.

### HALT-OWN-09

After successful CASE A and later `rs_` acquisition, prior normal permit remains invalid/absent and cannot be reconstructed; strategy has no normal transport; emergency handle remains cancel/control-only; no object/session/lock conversion path exists.

Also require deterministic adapter-entry race tests proving exactly one of two outcomes: one transport entry atomically wins before HALT latching, or HALT latching invalidates before transport. No interleaving permits transport after the latch or a second invocation.

## 15. Preservation confirmation

Every other Revision-02 contract is preserved. In particular, Revision 03 does not modify:

- the nine new event payload schemas, event-ID rules, exact references, idempotency, or replay;
- restricted `rs_` session schemas and mode surfaces except the exact acquisition ownership cross-reference;
- `RELEASE_ONLY` session/release behavior;
- ordinary T0/T1/T2/T3 successor construction or T3-before-transport theorem;
- Decimal binary-contract FIFO exposure;
- working/candidate exposure;
- risk-config fields and identities;
- `price_ranges` validation and midpoint reference;
- current-process monotonic freshness;
- exact cancel target eligibility and result classes;
- batch transport policy;
- emergency rate lane;
- Order Group defense-in-depth policy;
- release predicate vector;
- current historical incident treatment;
- future writable-path envelope; or
- SQLite schema revisions/authority model.

## 16. Future implementation path envelope

No implementation is performed here. The exact Revision-02 future path envelope is preserved:

**Modify existing:**

```text
src/arb/execution_ledger.py
src/arb/venues/kalshi/ledger_binding.py
src/arb/venues/kalshi/order_lifecycle.py
tests/test_execution_ledger.py
tests/test_kalshi_ledger_binding.py
tests/test_kalshi_one_order_lifecycle.py
```

**Add:**

```text
src/arb/venues/kalshi/risk_control.py
src/arb/venues/kalshi/emergency_cancel.py
tests/test_kalshi_risk_control.py
tests/test_kalshi_emergency_cancel.py
```

Revision-03 implementation implications within that unchanged envelope:

- `execution_ledger.py`: ownership-sensitive HALT admission; clean-vs-abandoned session semantics; preserve authority anchoring and schema revision 1;
- `ledger_binding.py`: refuse/avoid restricted acquisition while a live normal owner holds stores; fresh acquisition only after release; no in-place conversion;
- `order_lifecycle.py`: atomic hard-HALT/adapter-entry arbitration; not-entered permit invalidation; no second transport; clean normal shutdown after trusted HALT;
- `risk_control.py`: process-private hard-HALT latch and exact owner-sensitive transition request;
- tests: add HALT-OWN-01 through HALT-OWN-09 plus deterministic adapter-entry race coverage.

## 17. Persistence compatibility

Preserve exactly:

```text
AUTHORITY_SCHEMA_REVISION = 1
LEDGER_SCHEMA_REVISION = 1
EVENT_SCHEMA_REVISION = 1
sqlite_structural_migration_required = false
lock_model = AUTHORITY_THEN_LEDGER_SQLITE_EXCLUSIVE_V1
```

No DB deletion/recreation, historical event rewrite, new persistence authority, lock-model change, or structural migration.

## 18. Prohibited capabilities

This specification/handoff grants none of the following:

```text
implementation
source changes
test-source changes
test execution
project imports
package/dependency installation
persistent SQLite access or mutation
credentials/private keys/signing
Kalshi account access
Kalshi Demo requests
Kalshi production requests
CREATE
CANCEL
batch cancel
amend/decrease/replace
Order Group trigger/reset
WebSocket venue execution
funding/trading
local Git writes
remote Git writes
branch/commit/push/PR/merge
canonical repository modification
```

Canonical repository reads are read-only. No new Kalshi venue semantic was needed for Revision 03; Revision-02 source bindings are preserved rather than expanded.

## 19. Unresolved questions

```text
NONE
```

The HALT ownership, normal-to-emergency lock handoff, normal clean-session close, authority-failure recovery, permit/HALT interaction, and persistence compatibility are all frozen by the controlling specification.

## 20. Requirement/evidence review map

| Requirement | Implementation surface | Mandatory evidence |
|---|---|---|
| live `ws_` owns hard HALT while holding stores | `risk_control.py`, `execution_ledger.py` | HALT-OWN-01/02/03 |
| no restricted acquire before normal release | `ledger_binding.py` | HALT-OWN-02/03 |
| hard-HALT permit/transport arbitration | `risk_control.py`, `order_lifecycle.py` | HALT-OWN-01/08/09 + race tests |
| pre-commit HALT failure stays blocked | ledger + gate | HALT-OWN-04 |
| ledger-ahead catch-forward only | `execution_ledger.py` | HALT-OWN-05 |
| authority-result unknown reopen only | `execution_ledger.py` | HALT-OWN-06 |
| direct CASE-B restricted acquisition | `ledger_binding.py`, ledger | HALT-OWN-07 |
| ambiguous normal write remains ambiguous | lifecycle/reconciliation | HALT-OWN-08 |
| no permit/handle/lock conversion | gate/binding API surface | HALT-OWN-09 |
| live close uses `WRITER_SESSION_ENDED`; stale reopen uses abandonment | ledger/session validator | HALT-OWN-03/07 |
| all Revision-02 contracts preserved | all Revision-02 paths | complete Revision-02 regression matrix |

## 21. No venue capability granted

Revision-03 specification acceptance, later implementation, or offline tests do not grant any Kalshi Demo or production network/write capability. Any future venue execution remains a separate explicit bounded task.
