# KALSHI_DEMO_EMERGENCY_CANCELLATION_AND_RISK_LIMITS_SPEC_03

```yaml
artifact_class: TECHNICAL_SPECIFICATION
task_class: SPEC_ONLY
technical_scope: KALSHI_DEMO_PERSISTENT_EMERGENCY_CONTROL_RISK_LIMITS_HALT_OWNERSHIP_CORRECTION_ONLY
risk_tier: HIGH
repository: rigolugo/ARB
canonical_main: f9fcd96b5b3efa7a3adfc2d9eabb133aa09cac82
canonical_tree: f3992ba10735c4cafafa541f598add1b6e5e80ba
canonical_parent: 5a65ccadb05b29d6e8692a108bcf46347ec0d214
implementation_performed_by_this_artifact: false
tests_executed_by_this_artifact: false
venue_execution_performed_by_this_artifact: false
correction_scope: HALT_OWNERSHIP_LOCK_HANDOFF_ONLY
blocked_predecessor: KALSHI_DEMO_EMERGENCY_CANCELLATION_AND_RISK_LIMITS_SPEC_02.md
```

## 1. Purpose and non-goals

### 1.1 Purpose

This Revision-03 specification is a bounded same-scope correction of Revision 02. It preserves the complete fail-closed persistent emergency-control and hard-risk boundary and resolves exactly one contradiction: ownership of the durable HALT transition when a live `NORMAL_WRITER` `ws_` session already owns the authority+ledger exclusive lock pair.

The controlling theorem is:

> **BLOCK NEW RISK → CANCEL ONLY PROVEN ACTIVE IDENTITIES → RECONCILE → REMAIN HELD WHEREVER UNCERTAINTY SURVIVES**

The design separates three independent questions:

1. `MAY_NORMAL_WRITES_OCCUR?`
2. `ARE_THERE_AUTHORITATIVE_ORDERS THAT EMERGENCY CONTROL MAY CANCEL?`
3. `IS THE SYSTEM FULLY RECONCILED AND ELIGIBLE FOR RELEASE?`

No implementation may collapse these questions. In particular, `NO_KNOWN_ORDER_TO_CANCEL` never implies `SAFE_TO_WRITE`.

### 1.2 Non-goals

This artifact does not implement code, execute tests, access a persistent SQLite database, load credentials, sign requests, access a Kalshi account, send Demo or production requests, create orders, cancel orders, batch-cancel orders, amend/decrease/replace orders, trigger/reset Order Groups, open WebSockets, trade, fund an account, create Git branches/commits, or modify canonical repository state.

This artifact does not specify a general multi-venue risk framework, a general strategy engine, a generalized OMS, or a production-trading release process.

### 1.3 Capability matrix for this specification task

| Capability | State |
|---|---|
| Canonical `rigolugo/ARB` read/sync | PERMITTED, read-only |
| Current official Kalshi documentation/OpenAPI retrieval | PERMITTED, read-only |
| General internet | PROHIBITED |
| Other venue network | PROHIBITED |
| Kalshi venue/API account traffic | PROHIBITED |
| Credentials/signing | PROHIBITED |
| Source/test changes | PROHIBITED |
| Test execution/project imports | PROHIBITED |
| Package installation/dependency change | PROHIBITED |
| Local persistent DB access/mutation | PROHIBITED |
| Local/remote Git writes | PROHIBITED |
| CREATE/CANCEL/amend/decrease/replace | PROHIBITED |
| Order Group trigger/reset | PROHIBITED |
| WebSocket venue execution | PROHIBITED |

### 1.4 Revision-03 bounded correction scope

Revision 03 is a standalone same-scope correction of the exact blocked Revision-02 artifact. Revision 02 is blocked for exactly one defect: its durable-HALT wording is contradictory when an active `NORMAL_WRITER` `ws_` session already owns the same authority-first/ledger-second exclusive lock pair that `EMERGENCY_CONTROL_ONLY` would need to acquire.

Revision 03 changes only the ownership and lock-handoff contract required to resolve that contradiction. It freezes:

1. CASE A: the currently locked `NORMAL_WRITER` `ws_` session persists and authority-anchors `WRITER_ELIGIBLE→HALTED` before ending and releasing its locks;
2. CASE B: when no live normal writer owns the stores, `EMERGENCY_CONTROL_ONLY` may acquire authority first and ledger second, clean stale replayed sessions under the already accepted restricted-session rules, and persist a required valid held/HALT transition;
3. hard-HALT interaction with the immutable `NormalWriterPermit` and gate-private progress record;
4. exact ledger-commit / authority-advance / authority-result-unknown recovery behavior;
5. clean `WRITER_SESSION_ENDED` versus fresh-reopen `WRITER_SESSION_ABANDONED` semantics; and
6. the precise normal-to-emergency lock release/acquisition ordering.

Every other Revision-02 contract is preserved without weakening, including all nine new event schemas, restricted `rs_` sessions, `RELEASE_ONLY`, the T0→T1→T2→T3 permit successor algorithm, Decimal economic formulas, price/reference/freshness rules, cancellation identity/result semantics, release predicates, historical incident treatment, future writable-path envelope, and SQLite schema revisions.

### 1.5 Preserved Revision-02 architecture

Revision 03 preserves as normative, without redesign:

- the central theorem `BLOCK NEW RISK → CANCEL ONLY PROVEN ACTIVE IDENTITIES → RECONCILE → REMAIN HELD WHEREVER UNCERTAINTY SURVIVES`;
- independent Questions A/B/C for normal writer eligibility, authoritative emergency-cancel eligibility, and release eligibility;
- `BOOT_HOLD`, `HALTED`, `EMERGENCY_CANCELING`, `RECONCILING`, `QUIESCENT_HELD`, `SAFE_HELD`, `WRITER_ELIGIBLE`;
- exact authoritative venue `order_id` cancellation only, with no `cancel_all`, fuzzy matching, guessed IDs, blind resend, or client-ID substitution;
- dedicated `ws_` normal sessions and `rs_` restricted sessions with mutual exclusion under `AUTHORITY_THEN_LEDGER_SQLITE_EXCLUSIVE_V1`;
- separate persistent emergency-control mutation, exact emergency venue permit, and `RELEASE_ONLY` capability surfaces;
- durable HALT-before-emergency-cancel ordering;
- exact nine new event schemas/IDs/references/replay rules from Revision 02;
- the immutable `NormalWriterPermit` plus gate-private T0→T1→T2→T3 progress model;
- exact Decimal binary-contract exposure, price-grid/reference, and monotonic freshness rules;
- explicit durable release and the predecessor writer-proof hold;
- the current historical incident's `cancel_target=NONE`, `release_eligible=false`, and `historical_unresolved_exposure=UNKNOWN_UNBOUNDED`; and
- `AUTHORITY_SCHEMA_REVISION=1`, `LEDGER_SCHEMA_REVISION=1`, `EVENT_SCHEMA_REVISION=1` with no structural migration or third persistence authority.

The only Revision-03 semantic change is who owns the HALT append and how lock ownership transitions from live normal operation to a later restricted emergency acquisition.

## 2. Canonical/base and predecessor identities

### 2.1 Canonical repository predicates

The specification is bound to exactly:

```text
repository = rigolugo/ARB
canonical_main = f9fcd96b5b3efa7a3adfc2d9eabb133aa09cac82
canonical_tree = f3992ba10735c4cafafa541f598add1b6e5e80ba
canonical_parent = 5a65ccadb05b29d6e8692a108bcf46347ec0d214
```

These predicates were re-read from canonical `main` during Revision-03 preparation. A future implementation MUST start from this exact base unless a later accepted specification explicitly changes it. Silent advance, rebase, retarget, or substitution is prohibited.

### 2.2 Exact blocked Revision-02 predecessor

```text
blocked_specification = KALSHI_DEMO_EMERGENCY_CANCELLATION_AND_RISK_LIMITS_SPEC_02.md
bytes = 158408
sha256 = 4b59f5449d950856f4a16c10d573c4def8eae675a3d1e8f9481ba1540a6d73ff

blocked_handoff = HANDOFF_KALSHI_DEMO_EMERGENCY_CANCELLATION_AND_RISK_LIMITS_SPEC_02.md
bytes = 36284
sha256 = 82ba54be053cd0e6eeccb275d7f4eb6b2460217bf0ea35051eaa91a779c3edb9
```

Revision 02 is lineage/provenance for this bounded correction. It is blocked for the HALT-ownership/exclusive-lock contradiction only. All other Revision-02 requirements are carried into this complete Revision-03 text; an implementer MUST use Revision 03 as the standalone controlling emergency/risk contract rather than merging revisions by discretion.

### 2.3 Controlling persistent-ledger predecessor

```text
specification:
  KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_03.md
  bytes = 141566
  sha256 = 98592d719db2dcb59bb5ade6f18700b9acf4ae1049480f409b60f228f1518ead

handoff:
  HANDOFF_KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_03.md
  bytes = 17942
  sha256 = 43dd06f5a7d976bff54574f60298c7568f74e9c24b8f257e32306b45c8289b93
```

The persistent-ledger specification controls; its handoff is subordinate.

### 2.4 Installed persistent-ledger sources

```text
src/arb/execution_ledger.py
  bytes = 103287
  sha256 = 31c4f62fbf28c10edf782e33603522fc7d4abb1ba85fbc8aade76f2423fb2098
  git_blob = 6e64d21dfa5013557a26cc27652dc69b8e4cb9bf

src/arb/venues/kalshi/ledger_binding.py
  bytes = 36685
  sha256 = 040f85577201811895cb0502ef6c3ac123e27e0e43093cf14def54613eb843c8
  git_blob = 41616684083abd5cd79756e36275502d7d873f30
```

The installed generic ledger declares:

```text
AUTHORITY_SCHEMA_REVISION = 1
LEDGER_SCHEMA_REVISION = 1
EVENT_SCHEMA_REVISION = 1
AcquisitionMode = { NORMAL_WRITER, LEGACY_IMPORT_ONLY }
```

Its current validator requires an active ordinary `WRITER_SESSION_STARTED` session for ordinary execution events including `ORDER_OBSERVED`, `FILL_OBSERVED`, `RECONCILIATION_RECORDED`, `EXECUTION_HALTED`, and `WRITER_PROOF_RELEASED`. Its append path validates full proposed replay before ledger commit, commits the append-only ledger, advances the trusted authority tail, and verifies both authority and ledger readback. Revision 03 preserves the Revision-02 restricted-session semantics and adds only the Section-12 HALT-ownership rule: a live normal `ws_` owner persists its own `WRITER_ELIGIBLE→HALTED` event before clean end/release; restricted acquisition begins only after those locks are no longer owned by the live normal session.

### 2.5 Persistence compatibility decision

No SQLite structural migration is required.

Future implementation SHALL:

- retain `AUTHORITY_SCHEMA_REVISION = 1`;
- retain `LEDGER_SCHEMA_REVISION = 1`;
- retain `EVENT_SCHEMA_REVISION = 1` for the event envelope;
- retain the existing authority and ledger databases in place;
- preserve every historical event byte-for-byte, including the existing first three events;
- preserve existing sequence numbers, hashes, authority trusted-tail semantics, and two durability domains;
- add only explicitly specified event-type semantics and replay projections;
- fail closed as unsupported event vocabulary when an old binary encounters any newly added event type;
- never rewrite, normalize, backfill, delete, recreate, or migrate the historical ledger;
- never create a third persistence authority.

The semantic extension is compatible with the existing `ledger_events` table because `event_type` is stored as text and the envelope/schema remains revision `1`. Adding enum/validator/replay support in a newer binary does not alter historical rows. An old binary's closed `EventType` conversion fails closed on the first new event rather than silently reinterpreting it.

## 3. Current durable unresolved-state contract

The following project evidence is controlling current-state input:

```text
KALSHI_DEMO_PERSISTENT_LEDGER_BOOTSTRAP_AND_LEGACY_IMPORT_EXECUTION_01_EVIDENCE.json
bytes = 5835
sha256 = d73dd836137804fca1e472327ca6f742c754579a5503ad3dea21706ba547e35e

KALSHI_DEMO_PERSISTENT_LEDGER_BOOTSTRAP_AND_LEGACY_IMPORT_EXECUTION_01_RESTART_EXPORT.json
bytes = 1817
sha256 = 2f541e372efd5f5c65dab1c77972ddcf24bb7f0824a5d77e97b90020f80b5a6a
```

The specification MUST preserve exactly:

```text
incident_id = KALSHI_DEMO_ONE_ORDER_LIFECYCLE_EXECUTION_01
disposition = WRITE_UNRESOLVED_ZERO_MATCH
bound_order_id = null
created_order_upper_bound = 1
active_order_upper_bound = 1
unknown_result = true
writer_proof_state = HELD
writer_proof_release_eligible = false
protected_unresolved_legacy_write_count = 1
history_completeness = COMPLETE_WITH_PROTECTED_UNRESOLVED_LEGACY_WRITE
restart_classification = RESTART_UNRESOLVED_WRITE_HELD
authority_trusted_sequence = 3
ledger_terminal_sequence = 3
normal_writer_handle = NONE
```

It MUST NOT infer any of:

```text
CREATE_NEVER_EXISTED
CREATE_DEFINITELY_FAILED
SAFE_TO_RETRY_CREATE
SAFE_TO_CANCEL
WRITER_PROOF_RELEASED
INCIDENT_CLOSED
```

For writer-eligibility arithmetic, the accepted evidence supplied to this task does not itself establish a complete exact economic payload sufficient to prove a finite unresolved-write exposure. Consequently, until exact authoritative durable evidence is replayed by a future accepted implementation and proves a finite upper bound, this incident contributes:

```text
unresolved_write_count = 1
unresolved_write_exposure_upper_bound = UNKNOWN_UNBOUNDED
```

`UNKNOWN_UNBOUNDED` is not zero and is not a numerical limit value. It makes risk-increasing writer eligibility false and release eligibility false.

## 4. Authority and capability boundaries

### 4.1 Required structural architecture

Normal path:

```text
Strategy
   ↓
RiskController
   ↓
WriterEligibilityGate
   ↓
PersistentExecutionLedger
   ↓
Kalshi normal-write adapter surface
```

Emergency path:

```text
EmergencySupervisor
   ↓
Persistent HALT
   ↓
AuthoritativeKnownOrderSet
   ↓
EmergencyCancelGate
   ↓
Persistent cancel intent/send boundary
   ↓
Kalshi emergency-cancel adapter surface
   ↓
RECONCILING
```

Strategy code MUST NOT receive the raw risk-increasing transport function or a generic adapter write method.

### 4.2 Independent capabilities

The future implementation MUST have separate, non-interchangeable capability types:

1. `NormalWriterPermit`
2. `EmergencyControlLedgerHandle`
3. `EmergencyCancelPermit`
4. `ReleaseLedgerHandle`

Possession of one MUST NOT imply or construct another.

### 4.3 Supported-API non-forgeability

In Python, the requirement is non-forgeability within the supported application API, not resistance to hostile code with arbitrary reflection or monkey-patching.

A conforming implementation MUST satisfy all of:

- capability constructors are not public API;
- capability objects cannot be created from caller-provided dict/JSON/pickle data;
- capability objects are immutable and process-local;
- capability validation includes exact originating gate instance identity, a random process-local nonce or equivalent private sentinel, and the exact current ledger/authority epoch;
- capability copy/clone/deepcopy/serialization is rejected;
- every adapter write entry point validates the exact capability class and current epoch;
- the normal adapter exposes no supported write entry point that omits a valid `NormalWriterPermit`;
- the emergency adapter exposes no supported operation except exact cancellation using a valid `EmergencyCancelPermit`;
- strategy modules are not passed emergency handles/permits;
- a state change, restart, risk-config change, permit consumption, or any **unrelated/unexpected** ledger/authority tail movement invalidates prior permits; the permit's own exact T0→T1→T2→T3 successor chain in Section 8 is the only tail movement that does not self-invalidate;
- permits are one-shot; T3 authority+ledger positive readback consumes the permit before transport becomes callable.

A test MUST demonstrate that direct supported strategy-to-adapter write invocation is impossible without a valid permit.

### 4.4 Separation required by current `normal_writer_handle = NONE`

The emergency layer MUST NOT reacquire or re-enable `NORMAL_WRITER` merely to persist HALT or cancel an authoritative active order.

Instead, future implementation shall extend `AcquisitionMode` with two closed restricted modes:

```text
EMERGENCY_CONTROL_ONLY
RELEASE_ONLY
```

`EMERGENCY_CONTROL_ONLY` provides only the persistent mutation surface specified in Section 9 and never a normal writer surface.

`RELEASE_ONLY` provides only the durable release surface in Section 22. It never provides a venue transport surface.

Actual venue cancellation requires a separate one-shot `EmergencyCancelPermit` minted only after persistent HALT and exact target validation.

## 5. Current official Kalshi source-binding record

### 5.1 Revision-01 provenance preserved

Revision 01 observed KSR-01 through KSR-12 from official `docs.kalshi.com` material at:

```text
revision_01_observed_at_utc = 2026-08-13T20:18:41Z
```

Those records remain provenance for the unchanged cancel, batch, order/fill reconciliation, Order Group, pause, and rate-limit contracts. Their HTML retrieval interface exposed rendered semantics but did not expose reproducible raw response bodies:

```text
raw_body_bytes = NOT_EXPOSED_BY_RETRIEVAL_INTERFACE
raw_body_sha256 = NOT_EXPOSED_BY_RETRIEVAL_INTERFACE
document_version = NOT_EXPOSED
```

The Revision-01 OpenAPI observation is also preserved as provenance:

```text
openapi_url = https://docs.kalshi.com/openapi.yaml
revision_01_observed_at = 2026-08-13T20:18:41Z
revision_01_http_status = 200
revision_01_reported_content_length_bytes = 311201
revision_01_raw_bytes_materialized = false
revision_01_raw_sha256 = null
revision_01_openapi_version = NOT_EXPOSED
```

No hash is invented.

### 5.2 Preserved KSR-01 through KSR-12 records

| ID | Official URL | Bound current semantics preserved from Revision 01 |
|---|---|---|
| KSR-01 | `https://docs.kalshi.com/api-reference/orders/create-order-v2` | V2 Create route; event-market V2 quotes the YES leg; `bid` buys YES and `ask` sells YES; exact count/price fixed-point request fields; `cancel_order_on_pause`, `reduce_only`, `order_group_id`, `post_only` fields |
| KSR-02 | `https://docs.kalshi.com/api-reference/orders/cancel-order-v2` | exact `DELETE /trade-api/v2/portfolio/events/orders/{order_id}` target; response `order_id`, `reduced_by`, `ts_ms`; exact order-id targeting remains load-bearing |
| KSR-03 | `https://docs.kalshi.com/api-reference/orders/batch-cancel-orders-v2` | explicit per-member order IDs and per-order results/errors; batch is not a safety-atomic theorem |
| KSR-04 | `https://docs.kalshi.com/api-reference/orders/get-orders` | order enumeration/status/count/price identities used by reconciliation |
| KSR-05 | `https://docs.kalshi.com/api-reference/orders/get-order` | exact order read by `order_id` and fixed-point order-state fields |
| KSR-06 | `https://docs.kalshi.com/api-reference/portfolio/get-fills` | fill identities/count/price/fee/time fields and order-id filter used by reconciliation |
| KSR-07 | `https://docs.kalshi.com/getting_started/order_groups` | rolling Order Group protection/trigger/reset behavior; defense in depth only |
| KSR-08 | `https://docs.kalshi.com/api-reference/order-groups/get-order-group` | group membership/order-ID observation and group state |
| KSR-09 | `https://docs.kalshi.com/api-reference/order-groups/trigger-order-group` | explicit trigger venue write; never local release proof |
| KSR-10 | `https://docs.kalshi.com/api-reference/order-groups/reset-order-group` | explicit reset venue write; never automatic restart/reconnect action |
| KSR-11 | `https://docs.kalshi.com/getting_started/maintenance_and_pauses` | pause/cancel behavior and `cancel_order_on_pause`; defense in depth only |
| KSR-12 | `https://docs.kalshi.com/getting_started/rate_limits` | shared venue Write bucket for order/amend/cancel/group writes; local emergency reservation cannot guarantee venue capacity |

For the exact cancel-intent/request event schemas, the preserved KSR-02 record is referenced by the closed local provenance identifier:

```text
cancel_source_binding_id = KSR-02_CANCEL_ORDER_V2_2026-08-13T20:18:41Z
```

This identifier names the KSR-02 provenance record; it is not a credential, venue token, or claim of a raw-body hash.

### 5.2.1 Revision-03 source-research scope

Revision 03 introduces no new Kalshi venue semantic. The blocking defect is internal lock/capability/persistence ownership. No new official Kalshi source observation is required to resolve it. All Revision-02 current-source records and economic operation bindings remain preserved exactly as provenance/technical inputs; they are not reinterpreted or refreshed by this correction.

### 5.3 Revision-02 current economic/source refresh

Correction 04 makes binary-contract payout, normalized direction, price complement, price-grid, and fixed-point precision load-bearing. Those facts were re-observed from current official material during this correction and finalized at:

```text
revision_02_economic_observed_at_utc = 2026-08-13T23:01:12Z
network_class = OFFICIAL_DOCUMENTATION_READ_ONLY
account_endpoint_activity = NONE
authenticated_venue_activity = NONE
```

For every KSR-13 through KSR-18 HTML page:

```text
raw_body_bytes = NOT_EXPOSED_BY_RETRIEVAL_INTERFACE
raw_body_sha256 = NOT_EXPOSED_BY_RETRIEVAL_INTERFACE
document_version = NOT_EXPOSED
```

| ID | Official URL | Newly load-bearing Revision-02 rule |
|---|---|---|
| KSR-13 | `https://docs.kalshi.com/getting_started/market_settlement` | binary settlement pays `$1` per correct YES or NO contract and only net positions settle; this fixes the payout unit used by Section 11 |
| KSR-14 | `https://docs.kalshi.com/getting_started/order_direction` | canonical direction is `outcome_side`/`book_side`; `bid ≡ yes`, `ask ≡ no`; buy-YES/sell-NO are long YES, buy-NO/sell-YES are long NO; direction does not alter the matching price |
| KSR-15 | `https://docs.kalshi.com/api-reference/orders/create-order-v2` | event-market V2 is YES-leg quoted; `bid` buys YES; `ask` sells YES and is economically equivalent to buying NO at `1-price` |
| KSR-16 | `https://docs.kalshi.com/getting_started/orderbook_responses` | `orderbook_fp` contains YES bids and NO bids only; best YES bid is highest YES bid; best YES ask is `1 - highest NO bid` |
| KSR-17 | `https://docs.kalshi.com/getting_started/fixed_point_migration` | price strings use fixed-point dollars with up to 4 decimal places for price fields; contract counts use fixed-point strings with 0-2 input decimals / 2-decimal responses; `price_ranges` provides exact valid price intervals/tick sizes; price×fractional-count calculations can require 6 decimal places |
| KSR-18 | `https://docs.kalshi.com/api-reference/market/get-market` | market ticker, `price_level_structure`, and `price_ranges[{start,end,step}]` are available to bind the dynamic valid-price grid used by candidate-price validation |

The API changelog was also observed only to guard precision interpretation. It records that selected portfolio `_dollars` response fields can emit up to 6 decimal places. Revision 02 therefore never parses arbitrary portfolio-dollar values as a 4-decimal **price** merely by suffix; it applies the exact field-specific domains in Section 6. Economic fill/order price fields admitted to the hard-risk formulas must pass the price-field contract; costs/fees are separate Decimal domains and are not silently substituted as prices.

A current official documentation inconsistency was also observed but is **not load-bearing to this specification's bound rule set**: the `Get Market Orderbook` API-reference page renders authentication headers as required, while the `Orderbook Responses` guide states that no authentication is required. Revision 02 binds only the `orderbook_fp` response structure, ascending-price ordering, and YES/NO complement arithmetic; it neither authorizes nor specifies a venue request and therefore does not choose between those authentication statements. No risk formula, state transition, permit, release predicate, or persistence rule depends on that authentication fact. A future task that must actually acquire the snapshot over the venue network MUST freshly resolve/bind the authentication contract before request construction; if the conflict remains material to that task, it MUST stop `OFFICIAL_SOURCE_CONFLICT`. This correction does not silently select either statement.

### 5.4 Revision-02 OpenAPI observation

A fresh read of `https://docs.kalshi.com/openapi.yaml` during this correction returned an interface error because the retrieval tool does not materialize `text/yaml`:

```text
openapi_url = https://docs.kalshi.com/openapi.yaml
revision_02_observed_at_utc = 2026-08-13T23:01:12Z
retrieval_interface_result = UNSUPPORTED_CONTENT_TYPE_TEXT_YAML
raw_bytes_materialized = false
raw_body_bytes = NOT_MATERIALIZED
raw_sha256 = null
openapi_version = NOT_EXPOSED
```

Revision 02 does not claim a raw OpenAPI identity. KSR-13 through KSR-18 official HTML semantics are sufficient for the newly load-bearing economic contract. If a future implementation requires a field/operation semantic not fixed by the bound records, it MUST stop for a fresh source binding rather than infer it.

### 5.5 Source-binding consequences

1. Emergency cancel remains exact venue `order_id` only.
2. `bound_order_id = null` for the current historical incident still yields no cancel target.
3. Cancel response alone remains insufficient; order/fill truth controls economic reconciliation.
4. The local binary-contract liability model in Section 11 uses the exact `$1` payout and canonical YES/NO direction semantics above.
5. Working opposite orders receive no offset credit before fill.
6. Candidate price validity is checked against the exact current market `price_ranges`; absent/unusable price-grid evidence denies.
7. Price reasonability uses the exact two-sided YES reference algorithm in Section 19; no vague market-price fallback exists.
8. Order Groups, pause flags, `reduce_only`, and `post_only` remain defense in depth and do not release local writer proof.
9. No source record grants venue execution.

A material contradiction among current official sources yields `OFFICIAL_SOURCE_CONFLICT`; the affected source-dependent design halts rather than choosing silently.

## 6. Terminology and exact data domains

### 6.1 Core terms

**AuthoritativeKnownOrderSet**  
The canonical sorted set of exact venue order IDs that are bound by accepted ledger identity evidence, currently reconciled as `resting`, have exact positive `remaining_count_fp`, and have no identity conflict.

**Normal writer eligibility**  
Question A: whether one exact normal risk-increasing request can receive a one-shot `NormalWriterPermit`.

**Emergency-cancellation eligibility**  
Question B: whether one exact authoritative active `order_id` can receive one one-shot `EmergencyCancelPermit`.

**Release eligibility**  
Question C: whether every release predicate passes and a durable release transition may proceed.

**Risk state epoch**  
A monotonic non-negative integer projected from `RISK_CONTROL_STATE_CHANGED`. Before the first such event the derived state is `BOOT_HOLD` and epoch is `0`. Every valid `RISK_CONTROL_STATE_CHANGED` increments the epoch by exactly one. No other event changes it.

**Restricted session**  
A durable lock-holding session whose `writer_session_id` uses the `rs_` lexical domain and whose exact acquisition mode is `EMERGENCY_CONTROL_ONLY` or `RELEASE_ONLY`. It is not an ordinary writer session.

**UNKNOWN_UNBOUNDED**  
A non-numeric fail-closed risk classification. Any applicable hard-risk aggregate containing this value is `UNKNOWN_UNBOUNDED`; it fails normal writer eligibility and release eligibility.

### 6.2 Exact lexical/identity domains

All textual values are exact built-in `str`, NFC-normalized, and secret-safe under the predecessor canonical JSON rules. ASCII-regex domains below additionally prohibit other Unicode.

```text
EventId              := ^evt_[0-9a-f]{32}$
NormalWriterSessionId:= ^ws_[0-9a-f]{32}$
RestrictedSessionId  := ^rs_[0-9a-f]{32}$
NormalWriterPermitId := ^nwp_[0-9a-f]{32}$
RiskAssessmentId     := ^ra_[0-9a-f]{32}$
EmergencyActionId    := ^ea_[0-9a-f]{32}$
CancelAttemptId      := ^ca_[0-9a-f]{32}$
RequestId            := ^req_[0-9a-f]{32}$
DeadlineId           := ^dl_[0-9a-f]{32}$
ReleaseId            := ^rel_[0-9a-f]{32}$
ProcessInstanceId    := ^proc_[0-9a-f]{32}$
Sha256Hex            := ^[0-9a-f]{64}$
CanonicalTimestamp   := ^YYYY-MM-DDTHH:MM:SS.ffffffZ$ under predecessor validator
```

`KalshiOrderIdV1` is a non-empty exact built-in `str` obtained from authoritative validated Kalshi order data and re-used byte-for-byte in the cancel path. Revision 02 does **not** invent a venue regex the official source does not state. It MUST satisfy predecessor canonical-text/secret-safety rules, contain no leading/trailing whitespace, and be exactly equal to the order ID stored in the authoritative observation/binding. A value failing those local constraints is not cancel-eligible.

`ConflictDomainRef` is exactly the already-bound ledger conflict-domain string. For this deployment it is:

```text
KALSHI|KALSHI_DEMO|ARB_KALSHI_DEMO_PRIMARY_ACCOUNT|SUBACCOUNT=0
```

### 6.3 Numeric domains

Binary floating point is prohibited at every economic boundary.

`ContractQty`:
- exact `Decimal` runtime value obtained from a canonical fixed-point contract string;
- finite, non-negative;
- scale 0-2 on accepted inputs; canonical risk records render exactly two fractional digits;
- quantum `0.01` contract.

`OrderPrice`:
- exact `Decimal` runtime value obtained from a canonical price field or candidate request price;
- finite;
- `0.0000 <= p <= 1.0000` before market-grid validation;
- no exponent notation;
- scale 0-4 for the V2 candidate price and market/orderbook price fields bound by KSR-15/KSR-17;
- canonical risk records render exactly four fractional digits.

`UsdExposure`:
- exact non-negative `Decimal`;
- produced only by the formulas in Section 11;
- internal products/sums are exact and must be representable to six fractional decimal places for `ContractQty × OrderPrice` under the supported 2+4 fixed-point contract;
- canonical risk records render exactly six fractional digits;
- a value requiring unsupported precision/range yields `RISK_NUMERIC_RANGE_UNSUPPORTED`, never rounding by implementation preference.

`FeeUsd` and other portfolio monetary values are separate exact Decimal fields and MAY have greater field-specific precision when current source semantics say so. They are not accepted as `OrderPrice` merely because they end in `_dollars`.

Integers are exact built-in `int`, never `bool`, within signed 64-bit range unless a narrower domain is stated. Millisecond limits and counters are non-negative or strictly positive exactly as Section 10 specifies.

### 6.4 Exact units

```text
contracts                    = ContractQty
price                        = USD per contract, YES-leg quoted for V2/orderbook formulas
worst_case_exposure_usd      = USD settlement-liability/capital-at-risk bound, excluding fees
fee_usd                      = USD, tracked separately
age_ms / lag_ms / window_ms  = integer milliseconds
monotonic timestamps         = integer nanoseconds from one process-local monotonic clock
rate                         = durable send-boundary count in exact sliding window
```

No percent, cents, integer-cent legacy field, float, or generic securities notional may be silently substituted.

## 7. Persistent risk-control state machine and exact event schemas

The normative state set is exactly:

```text
BOOT_HOLD
HALTED
EMERGENCY_CANCELING
RECONCILING
QUIESCENT_HELD
SAFE_HELD
WRITER_ELIGIBLE
```

### 7.1 State semantics

**BOOT_HOLD**
- process-local start state on every process start;
- no normal write and no automatic emergency venue write;
- authority/ledger replay and source/config binding validation precede any transition;
- prior durable HALT/HELD state is never erased by startup.

**HALTED**
- all new risk-increasing writes prohibited;
- the state is durably committed and authority-anchored;
- HALT must be trusted before any emergency cancel send boundary.

**EMERGENCY_CANCELING**
- only exact authoritative risk-reducing cancellation may cross a venue send boundary;
- no CREATE, MODIFY, REPLACE, DECREASE, speculative discovery write, reset, or unresolved-CREATE retry.

**RECONCILING**
- exact order/fill/cancel truth is being or must be established;
- no normal writes and no release from an acknowledgement alone.

**QUIESCENT_HELD**
- no exact known cancellable active order and no unresolved emergency cancel send;
- uncertainty/exposure may remain;
- normal writer eligibility is false and this state may persist indefinitely.

**SAFE_HELD**
- all release safety predicates currently pass;
- explicit durable release has not completed;
- no normal write.

**WRITER_ELIGIBLE**
- entered only through the Section-22 release sequence;
- each normal request still requires fresh candidate-specific risk evaluation and a one-shot permit.

### 7.2 Closed transition table and cause domain

The pair and cause must match exactly:

| From | To | Exact `cause` |
|---|---|---|
| BOOT_HOLD | HALTED | `REPLAY_OR_CURRENT_HARD_VIOLATION` |
| BOOT_HOLD | QUIESCENT_HELD | `REPLAY_UNCERTAINTY_NO_CANCEL_TARGET` |
| BOOT_HOLD | SAFE_HELD | `REPLAY_ALL_SAFETY_PREDICATES_PASS` |
| HALTED | EMERGENCY_CANCELING | `EXACT_CANCEL_TARGET_SET_OPENED` |
| HALTED | RECONCILING | `AUTHORITATIVE_TRUTH_REQUIRED` |
| HALTED | QUIESCENT_HELD | `NO_CANCEL_TARGET_UNCERTAINTY_REMAINS` |
| EMERGENCY_CANCELING | RECONCILING | `CANCEL_WAVE_ENDED_OR_AMBIGUOUS` |
| RECONCILING | EMERGENCY_CANCELING | `RECONCILIATION_REVEALED_EXACT_ACTIVE_TARGET` |
| RECONCILING | QUIESCENT_HELD | `NO_CANCEL_TARGET_RELEASE_PREDICATE_FALSE_OR_UNKNOWN` |
| RECONCILING | SAFE_HELD | `ALL_RELEASE_PREDICATES_EXCEPT_EXPLICIT_RELEASE_PASS` |
| QUIESCENT_HELD | RECONCILING | `NEW_RECONCILIATION_REQUIRED` |
| QUIESCENT_HELD | SAFE_HELD | `UNCERTAINTY_RESOLVED_ALL_RELEASE_PREDICATES_PASS` |
| SAFE_HELD | WRITER_ELIGIBLE | `DURABLE_RELEASE_COMPLETED` |
| WRITER_ELIGIBLE | HALTED | `HARD_SAFETY_VIOLATION` |

No other state pair or cause is valid. Restart begins in derived `BOOT_HOLD`; no state is restored merely from the previous process's in-memory state.

### 7.3 Common event-envelope, duplicate, and secret rules

Every new event in Sections 7.4-7.12 uses the existing `ledger_events` envelope and exactly:

```text
event_schema_revision = 1
event_id = EventId
recorded_at_utc = CanonicalTimestamp
payload = exact object specified by that event
```

Each event subsection fixes `writer_session_id`, `incident_id`, and `execution_attempt_id`. No unspecified envelope interpretation is permitted.

For all new event types:

1. payload key equality is exact; one missing key or one additional key is `EVENT_SCHEMA_CONTRACT_VIOLATION`;
2. exact built-in Python types are required; `bool` never satisfies an `int` field;
3. nullable fields are nullable only where explicitly marked;
4. string enum domains are closed;
5. list ordering/uniqueness rules are normative;
6. every referenced event ID must exist in the same validated ledger prefix and have the required event type/content/hash;
7. deterministic replay validates semantics before changing the projection;
8. malformed content fails closed; it is never ignored;
9. every authoritative append uses the predecessor append path: full proposed replay validation → ledger commit → authority trusted-tail advance → authority and ledger readback;
10. every event payload passes predecessor `assert_secret_safe`; raw credentials, headers, signatures, private keys, tokens, authorization material, environment dumps, and raw secret-bearing bodies are prohibited;
11. a deterministic retry of the same logical event MUST reuse the same `event_id` and original `recorded_at_utc`; if the complete reconstructed event core/hash is byte-identical, existing `append_batch` semantics return `IDEMPOTENT_DUPLICATE` and do not advance either tail;
12. same `event_id` with any changed envelope/payload/time/hash is `EVENT_ID_CONTENT_CONFLICT`;
13. a batch mixing an already-existing event ID with a new ID is prohibited by the predecessor mixed-duplicate rule;
14. new logical event IDs are generated as `evt_` plus the first 32 lowercase hex characters of `SHA256(domain_separator || canonical_json(logical_identity))`, with the exact per-event domain separator specified below; this identity rule does not change historical event IDs.

The `logical_identity` object is exact for each new event:

| Event type | Exact `logical_identity` object |
|---|---|
| `RISK_CONTROL_STATE_CHANGED` | `{"risk_state_epoch_after": <int>}` |
| `EMERGENCY_ACTION_OPENED` | `{"emergency_action_id": <EmergencyActionId>}` |
| `CANCEL_INTENT_RECORDED` | `{"cancel_attempt_id": <CancelAttemptId>,"stage":"INTENT"}` |
| `CANCEL_SEND_BOUNDARY_ENTERED` | `{"cancel_attempt_id": <CancelAttemptId>,"stage":"SEND_BOUNDARY"}` |
| `CANCEL_RESULT_RECORDED` | `{"cancel_attempt_id": <CancelAttemptId>,"result_revision": <int>}` |
| `RISK_RELEASE_RECORDED` | `{"release_id": <ReleaseId>}` |
| `RESTRICTED_SESSION_STARTED` | `{"restricted_session_id": <RestrictedSessionId>,"stage":"START"}` |
| `RESTRICTED_SESSION_ENDED` | `{"restricted_session_id": <RestrictedSessionId>,"stage":"END"}` |
| `RESTRICTED_SESSION_ABANDONED` | `{"abandoned_restricted_session_id": <RestrictedSessionId>,"stage":"ABANDON"}` |

The domain separator bytes are the exact UTF-8 bytes of the literal event-specific domain string followed by one NUL byte. No implementation-selected UUID may replace this deterministic ID for the new events.

### 7.4 `RISK_CONTROL_STATE_CHANGED`

**Domain separator:** `ARB_RISK_CONTROL_STATE_CHANGED_V1\0`.

**Envelope:**

```text
writer_session_id = active NormalWriterSessionId or active RestrictedSessionId whose mode permits this exact transition
incident_id = null
execution_attempt_id = null
```

**Exact payload key set and types:**

| Key | Exact type/domain |
|---|---|
| `previous_state` | one state from Section 7 |
| `new_state` | one state from Section 7 |
| `cause` | exact cause paired to the transition in Section 7.2 |
| `risk_state_epoch_before` | built-in int >= 0 |
| `risk_state_epoch_after` | built-in int = `before + 1` |
| `risk_config_sha256` | `Sha256Hex` or null |
| `related_emergency_action_id` | `EmergencyActionId` or null |
| `related_release_id` | `ReleaseId` or null |
| `predecessor_state_event_id` | `EventId` or null |
| `observed_authority_trusted_sequence` | built-in int >= 1 |
| `observed_authority_trusted_hash` | `Sha256Hex` |
| `observed_ledger_terminal_sequence` | built-in int >= 1 |
| `observed_ledger_terminal_hash` | `Sha256Hex` |

`predecessor_state_event_id=null` is valid only for the first risk-state event, where `previous_state=BOOT_HOLD`, `risk_state_epoch_before=0`, and the observed trusted/ledger tails are the exact pre-event replay tails. Otherwise it references the immediately preceding `RISK_CONTROL_STATE_CHANGED` projection event.

`related_emergency_action_id` is non-null exactly for transitions that enter or leave `EMERGENCY_CANCELING` because of one open emergency action; otherwise null. `related_release_id` is non-null exactly for `SAFE_HELD→WRITER_ELIGIBLE` and MUST reference a prior trusted `RISK_RELEASE_RECORDED`; otherwise null. `risk_config_sha256` may be null while config is missing/invalid in held/halted states; it MUST be non-null for any transition into `SAFE_HELD` or `WRITER_ELIGIBLE`.

The observed authority and ledger identities MUST equal each other and the actual pre-event trusted terminal pair. This event increments `risk_state_epoch` exactly once and projects `new_state`, the new epoch, and active config identity. An invalid transition/cause/reference is `RISK_STATE_TRANSITION_INVALID`. Exact idempotent duplicate does not increment the epoch twice.

### 7.5 `EMERGENCY_ACTION_OPENED`

**Domain separator:** `ARB_EMERGENCY_ACTION_OPENED_V1\0`.

**Envelope:** `writer_session_id` = active `RestrictedSessionId` in `EMERGENCY_CONTROL_ONLY`; `incident_id=null`; `execution_attempt_id=null`.

**Exact payload:**

| Key | Exact type/domain |
|---|---|
| `emergency_action_id` | `EmergencyActionId` |
| `conflict_domain_ref` | exact bound `ConflictDomainRef` |
| `cause` | `HARD_RISK_HALT` \| `EXPLICIT_EMERGENCY_CONTROL` \| `RESTART_RECOVERY_OF_PERSISTED_HALT` |
| `starting_control_state` | exactly `HALTED` |
| `target_set_kind` | `EXACT_ORDER_ID_SET` \| `EMPTY` |
| `target_order_ids` | built-in list of `KalshiOrderIdV1`, sorted ascending by exact code point, unique |
| `target_set_sha256` | `Sha256Hex` of predecessor canonical JSON bytes for `target_order_ids` |
| `risk_config_sha256` | `Sha256Hex` or null |
| `risk_state_epoch` | built-in int >= 0, equal current projection |
| `authority_trusted_sequence` | built-in int >= 1, exact pre-event trusted tail |
| `authority_trusted_hash` | `Sha256Hex`, exact pre-event trusted tail |
| `ledger_terminal_sequence` | built-in int >= 1, exact pre-event ledger tail |
| `ledger_terminal_hash` | `Sha256Hex`, exact pre-event ledger tail |
| `opened_at_utc` | `CanonicalTimestamp`, exactly equal envelope `recorded_at_utc` |
| `deduplication_key_sha256` | `Sha256Hex` over canonical object `{conflict_domain_ref,risk_state_epoch,cause,target_set_sha256}` |

`EXACT_ORDER_ID_SET` requires a non-empty list; `EMPTY` requires `[]`. `conflict_domain_ref` MUST equal the locked ledger conflict domain. Every non-empty member MUST already be in `AuthoritativeKnownOrderSet`. An action with the same deduplication key but a different action ID/content is `EMERGENCY_ACTION_DUPLICATE_CONFLICT`. This event does not change `risk_state_epoch`. Replay projects one open emergency action and immutable target-set identity.

### 7.6 `CANCEL_INTENT_RECORDED`

**Domain separator:** `ARB_CANCEL_INTENT_RECORDED_V1\0`.

**Envelope:** active `EMERGENCY_CONTROL_ONLY` `RestrictedSessionId`; `incident_id=null`; `execution_attempt_id=null`.

**Exact payload:**

| Key | Exact type/domain |
|---|---|
| `emergency_action_id` | open `EmergencyActionId` |
| `cancel_attempt_id` | `CancelAttemptId` |
| `target_order_id` | `KalshiOrderIdV1` |
| `conflict_domain_ref` | exact bound `ConflictDomainRef` |
| `subaccount` | built-in int, `0 <= x <= 63` |
| `exchange_index` | built-in int >= 0 |
| `source_binding_id` | exactly `KSR-02_CANCEL_ORDER_V2_2026-08-13T20:18:41Z` |
| `risk_state_epoch` | built-in int >= 0, current projection |
| `risk_config_sha256` | `Sha256Hex` or null; exact match to action's config identity |
| `authoritative_order_observation_event_id` | `EventId` referencing validated authoritative `ORDER_OBSERVED` |
| `authoritative_order_observation_event_hash` | exact referenced event `Sha256Hex` |
| `prior_order_status` | exactly `resting` |
| `prior_remaining_count_fp` | canonical positive two-decimal `ContractQty` string |
| `attempt_ordinal` | built-in int >= 1 |
| `request_id` | `RequestId` |
| `intent_recorded_at_utc` | `CanonicalTimestamp`, equal envelope time |

The referenced observation MUST prove the same exact target, conflict-domain/account/subaccount scope, `resting` status, and positive remaining quantity; the target MUST occur in the open action target set. For one `(emergency_action_id,target_order_id)`, ordinals are contiguous starting at `1`; a later ordinal is forbidden while any earlier attempt has unresolved send state. `request_id`, `cancel_attempt_id`, and logical ordinal are unique. The event does not change `risk_state_epoch`.

### 7.7 Secret-free `EmergencyCancelPreparedRequestV1`

The prepared request is not a separate ledger event. It is an immutable process-local value deterministically derived after an anchored cancel intent and before the send-boundary event. Its exact canonical object is:

```text
{
  "request_schema_id": "KALSHI_EMERGENCY_CANCEL_PREPARED_REQUEST_V1",
  "request_id": RequestId,
  "operation_name": "CANCEL_ORDER_V2",
  "method": "DELETE",
  "path_without_query": "/trade-api/v2/portfolio/events/orders/" + exact target_order_id,
  "canonical_query": {},
  "canonical_body": null,
  "target_order_id": exact KalshiOrderIdV1,
  "source_binding_id": "KSR-02_CANCEL_ORDER_V2_2026-08-13T20:18:41Z"
}
```

`canonical_request_sha256 = SHA256(predecessor canonical_json_bytes(exact object))`. No header, signature, key ID, token, credential reference value, or raw transport object participates. A transport adapter may add authentication only outside this persistent secret-free identity under a separate future venue authorization.

### 7.8 `CANCEL_SEND_BOUNDARY_ENTERED`

**Domain separator:** `ARB_CANCEL_SEND_BOUNDARY_ENTERED_V1\0`.

**Envelope:** active `EMERGENCY_CONTROL_ONLY` `RestrictedSessionId`; `incident_id=null`; `execution_attempt_id=null`.

**Exact payload:**

| Key | Exact type/domain |
|---|---|
| `emergency_action_id` | `EmergencyActionId` matching intent |
| `cancel_attempt_id` | `CancelAttemptId` matching intent |
| `target_order_id` | exact target matching intent |
| `request_id` | `RequestId` matching intent/prepared request |
| `canonical_request_sha256` | `Sha256Hex` of Section-7.7 object |
| `operation_name` | exactly `CANCEL_ORDER_V2` |
| `method` | exactly `DELETE` |
| `path_without_query` | exact `/trade-api/v2/portfolio/events/orders/{target_order_id}` after substitution |
| `attempt_ordinal` | exact intent ordinal |
| `deadline_id` | `DeadlineId` |
| `deadline_budget_ms` | built-in int > 0 |
| `deadline_process_instance_id` | `ProcessInstanceId` for current process |
| `deadline_started_monotonic_ns` | built-in int >= 0 |
| `deadline_absolute_monotonic_ns` | built-in int > start and exactly `start + budget_ms*1_000_000` |
| `predecessor_intent_event_id` | exact `CANCEL_INTENT_RECORDED` `EventId` |
| `predecessor_intent_event_hash` | exact referenced event `Sha256Hex` |
| `predecessor_authority_trusted_sequence` | built-in int >= 1; exact tail before this event |
| `predecessor_authority_trusted_hash` | exact pre-event `Sha256Hex` |
| `predecessor_ledger_terminal_sequence` | built-in int >= 1; exact tail before this event |
| `predecessor_ledger_terminal_hash` | exact pre-event `Sha256Hex` |
| `write_ambiguity_rule` | exactly `CANCEL_MAY_HAVE_BEEN_SENT_AFTER_THIS_ANCHORED_EVENT` |
| `boundary_recorded_at_utc` | `CanonicalTimestamp`, equal envelope time |

The intent MUST already be authority-anchored. The pre-event authority and ledger pairs MUST equal each other and the actual tail. Only one send-boundary event is valid per `cancel_attempt_id`. After this event itself is committed, authority-advanced, and positively read back, replay MUST classify that attempt `cancel_may_have_been_sent=true` until an evidence-supported `CANCEL_RESULT_RECORDED` closes it. Crash or transport ambiguity after this boundary never means “not sent.” Blind resend is prohibited. This event does not change `risk_state_epoch`.

### 7.9 `CANCEL_RESULT_RECORDED`

**Domain separator:** `ARB_CANCEL_RESULT_RECORDED_V1\0`.

**Envelope:** active `EMERGENCY_CONTROL_ONLY` `RestrictedSessionId`; `incident_id=null`; `execution_attempt_id=null`.

**Exact payload:**

| Key | Exact type/domain |
|---|---|
| `emergency_action_id` | matching `EmergencyActionId` |
| `cancel_attempt_id` | matching `CancelAttemptId` |
| `target_order_id` | matching `KalshiOrderIdV1` |
| `result_revision` | built-in int >= 1 |
| `prior_result_event_id` | null for revision 1; otherwise prior contiguous result `EventId` |
| `result_class` | `CANCELED_CONFIRMED` \| `FILLED_BEFORE_CANCEL` \| `PARTIAL_FILL_THEN_REMAINDER_CANCELED` \| `ALREADY_TERMINAL` \| `CANCEL_REJECTED_CONFIRMED` \| `CANCEL_UNRESOLVED` |
| `response_present` | exact built-in bool |
| `response_http_status` | built-in int 100-599 or null iff response absent |
| `response_media_type_class` | `APPLICATION_JSON` \| `OTHER` \| `MISSING` when response present; null iff no HTTP response |
| `response_body_sha256` | `Sha256Hex` or null iff response absent |
| `response_byte_length` | built-in int >=0 or null iff response absent |
| `response_order_id` | `KalshiOrderIdV1` or null |
| `response_reduced_by_fp` | canonical non-negative two-decimal `ContractQty` string or null |
| `reconciliation_basis_event_ids` | sorted unique built-in list of `EventId` |
| `fill_basis_event_ids` | sorted unique built-in list of referenced `FILL_OBSERVED` `EventId` |
| `order_state_basis_event_ids` | sorted unique built-in list of referenced `ORDER_OBSERVED` `EventId` |
| `canceled_quantity_fp` | canonical non-negative two-decimal quantity string or null |
| `filled_quantity_fp` | canonical non-negative two-decimal quantity string |
| `remaining_quantity_fp` | canonical non-negative two-decimal quantity string or null |
| `write_closure_class` | `AUTHORITATIVE_RESULT_CLOSED` \| `UNRESOLVED` |
| `unresolved` | exact built-in bool |
| `result_at_utc` | `CanonicalTimestamp`, equal envelope time |

Evidence rules are closed:

When `response_present=false`, status/media/hash/byte-length/response-order/reduced-by are null. When `response_present=true`, `response_http_status`, `response_body_sha256`, and `response_byte_length` are non-null; an empty body is represented by length `0` and SHA-256 of the empty byte string. `response_media_type_class=APPLICATION_JSON` means the validated base media-type token after case-normalization and parameter removal is exactly `application/json`; `OTHER` means another syntactically valid media type; `MISSING` means no Content-Type header. Semantic fields parsed from a response body (`response_order_id`, `response_reduced_by_fp`) may be non-null only when the response was validated as the expected JSON schema. Non-JSON/missing-media responses cannot by themselves establish a positive cancel result, although later authoritative order/fill evidence may still establish a terminal class.

- `CANCELED_CONFIRMED`: post-intent fill delta `0.00`; authoritative terminal canceled order; `remaining=0.00`; `canceled_quantity=prior_remaining`; `unresolved=false`; closure `AUTHORITATIVE_RESULT_CLOSED`.
- `FILLED_BEFORE_CANCEL`: authoritative full execution of the intent-time remaining quantity; `filled_quantity=prior_remaining`; `canceled_quantity=0.00`; `remaining=0.00`; `unresolved=false`; closure closed.
- `PARTIAL_FILL_THEN_REMAINDER_CANCELED`: `0 < filled_quantity < prior_remaining`; authoritative canceled terminal remainder; `canceled_quantity=prior_remaining-filled_quantity`; `remaining=0.00`; closure closed.
- `ALREADY_TERMINAL`: authoritative evidence proves the order became terminal by a non-fill cancellation/expiry/venue-terminal mechanism before this cancel attempt can be credited with reduction; all post-intent fills are included; `remaining=0.00`; `canceled_quantity=prior_remaining-filled_quantity`; closure closed. Full execution uses `FILLED_BEFORE_CANCEL`, not this class. A response `reduced_by` for this class is null or `0.00`; it cannot claim this attempt canceled the remainder.
- `CANCEL_REJECTED_CONFIRMED`: a definitive validated rejection is present and authoritative reconciliation proves the target remains `resting`; `canceled_quantity=0.00`; `remaining_quantity=prior_remaining-filled_quantity`; `unresolved=false`; closure closed for the **cancel attempt**, but the still-resting target remains risk and may require a later ordinal subject to rate/backoff policy.
- `CANCEL_UNRESOLVED`: transport/result or authoritative post-state is insufficient; `unresolved=true`; closure `UNRESOLVED`; `canceled_quantity` and `remaining_quantity` may be null only in this class.

`filled_quantity_fp` is the exact deduplicated fill quantity attributable to the target after the intent observation and through the reconciliation cut. Every fill/order basis event must match the target and have no identity conflict. For closed classes, the quantity identity `prior_remaining = filled_quantity + canceled_quantity + remaining_quantity` MUST hold with missing terms treated only as prohibited, not as zero. Response `reduced_by`, when present for a successful cancel, MUST equal the reconciled canceled quantity.

`result_revision=1` requires `prior_result_event_id=null`. Revision `n>1` requires the immediately prior valid result revision for the same attempt and `n-1`. Only `CANCEL_UNRESOLVED` may be superseded. Once a closed result exists, later result revisions conflict. Replay uses the highest contiguous valid revision. A result class unsupported by its exact basis is `CANCEL_RESULT_EVIDENCE_CONFLICT`. This event does not change `risk_state_epoch`.

### 7.10 `RISK_RELEASE_RECORDED`

**Domain separator:** `ARB_RISK_RELEASE_RECORDED_V1\0`.

**Envelope:** active `RELEASE_ONLY` `RestrictedSessionId`; `incident_id=null`; `execution_attempt_id=null`.

**Exact payload:**

| Key | Exact type/domain |
|---|---|
| `release_id` | `ReleaseId` |
| `risk_config_sha256` | non-null `Sha256Hex` |
| `risk_state_epoch` | built-in int >=0, current projection |
| `authority_trusted_sequence` | exact pre-event built-in int >=1 |
| `authority_trusted_hash` | exact pre-event `Sha256Hex` |
| `ledger_terminal_sequence` | exact pre-event built-in int >=1 |
| `ledger_terminal_hash` | exact pre-event `Sha256Hex` |
| `reconciliation_snapshot_sha256` | `Sha256Hex` |
| `risk_snapshot_sha256` | `Sha256Hex` |
| `predicate_vector` | exact object defined below |
| `predicate_vector_sha256` | `Sha256Hex` of predecessor canonical JSON bytes of vector |
| `writer_proof_id` | exact controlling canonical writer-proof string |
| `safe_held_state_event_id` | `EventId` of current `RISK_CONTROL_STATE_CHANGED` into `SAFE_HELD` |
| `safe_held_state_event_hash` | exact referenced `Sha256Hex` |
| `release_recorded_at_utc` | `CanonicalTimestamp`, equal envelope time |

`predicate_vector` has exactly these 19 built-in-bool keys and every value MUST be `true`:

```text
ledger_integrity_pass
authority_anchor_consistency_pass
binding_identity_pass
supported_event_set_pass
trusted_replay_complete
no_unresolved_emergency_cancel
known_active_orders_reconciled
fills_reconciled
zero_identity_conflicts
conservative_exposure_finite_and_within_limits
risk_config_complete_valid
market_data_fresh
reconciliation_fresh
venue_defense_pass
protected_unresolved_legacy_write_count_zero
no_controlling_unresolved_write
writer_proof_release_eligible
state_safe_held
no_outstanding_permits
```

The pre-event authority and ledger pairs MUST be equal and current; the state event MUST be the current `SAFE_HELD` projection event at the same epoch/config. The two snapshot hashes MUST be the exact snapshots used to evaluate the vector. Duplicate release IDs obey Section 7.3. Replay records a durable release decision pending proof release; **this event does not release writer proof, does not itself change the risk state, and does not create writer eligibility**.

### 7.11 Restricted-session event family required by Correction 02

These three event types are added only to make restricted persistence compatible with the installed active-session validator without changing historical ordinary-session semantics.

#### `RESTRICTED_SESSION_STARTED`

Domain: `ARB_RESTRICTED_SESSION_STARTED_V1\0`.

Envelope: `writer_session_id=RestrictedSessionId`; `incident_id=null`; `execution_attempt_id=null`.

Exact payload:

```text
restricted_session_id: RestrictedSessionId, equal envelope writer_session_id
acquisition_mode: "EMERGENCY_CONTROL_ONLY" | "RELEASE_ONLY"
session_schema_revision: built-in int exactly 1
lock_model: exactly "AUTHORITY_THEN_LEDGER_SQLITE_EXCLUSIVE_V1"
prior_restricted_session_state: "NONE" | "CLEAN" | "ABNORMAL"
opening_trusted_sequence: built-in int >= 1
opening_trusted_event_hash: Sha256Hex
opening_ledger_sequence: built-in int >= 1
opening_ledger_event_hash: Sha256Hex
```

The opening authority/ledger pairs MUST equal each other and the actual pre-event tail. No ordinary or restricted session may already be active. The event projects one active restricted session with exact mode. It does not change `risk_state_epoch`.

#### `RESTRICTED_SESSION_ENDED`

Domain: `ARB_RESTRICTED_SESSION_ENDED_V1\0`.

Envelope: active session's exact `RestrictedSessionId`; `incident_id=null`; `execution_attempt_id=null`.

Exact payload:

```text
restricted_session_id: RestrictedSessionId, equal envelope
acquisition_mode: exact active restricted mode
pre_end_trusted_sequence: built-in int >= 1
pre_end_trusted_event_hash: Sha256Hex
pre_end_ledger_sequence: built-in int >= 1
pre_end_ledger_event_hash: Sha256Hex
end_reason: exactly "CLEAN_RELEASE_OF_EXCLUSIVE_LOCKS"
```

The pre-end pairs MUST equal current tails before this event. The end event itself is appended/authority-anchored/read back while the exclusive locks remain held; only then may the handle close/release locks. Replay removes the active restricted session and records a clean end. It does not change `risk_state_epoch`.

#### `RESTRICTED_SESSION_ABANDONED`

Domain: `ARB_RESTRICTED_SESSION_ABANDONED_V1\0`.

Envelope: `writer_session_id=null`; `incident_id=null`; `execution_attempt_id=null`.

Exact payload:

```text
abandoned_restricted_session_id: RestrictedSessionId
acquisition_mode: "EMERGENCY_CONTROL_ONLY" | "RELEASE_ONLY"
reason: exactly "PREVIOUS_RESTRICTED_SESSION_NO_LONGER_HOLDS_REQUIRED_AUTHORITY_AND_LEDGER_LOCKS"
observed_trusted_sequence: built-in int >= 1
observed_trusted_event_hash: Sha256Hex
observed_ledger_sequence: built-in int >= 1
observed_ledger_event_hash: Sha256Hex
```

It may be appended only after a fresh `_open_locked`-equivalent acquisition has acquired authority-first/ledger-second exclusive locks and replay proves a prior restricted start with no end/abandon event. The observed pairs MUST be equal/current. The abandonment event is anchored/read back before any replacement restricted start. Replay marks that session abnormal and inactive. It does not infer anything about venue sends or cancel results and does not change `risk_state_epoch`.

### 7.12 Closed predecessor/successor/replay matrix

| Event | Required predecessor condition | Permitted successor/replay effect | `risk_state_epoch` |
|---|---|---|---|
| `RISK_CONTROL_STATE_CHANGED` | current projected state/epoch and exact pre-event trusted tail; additionally Section 12 fixes the owning session/mode for HALT transitions | only Section-7.2 state/cause; project state/config/epoch; no duplicate HALT on later ownership change | increments exactly 1 |
| `EMERGENCY_ACTION_OPENED` | projected `HALTED`; active emergency restricted session; exact target set | project one immutable open action; later state/action events may reference it | unchanged |
| `CANCEL_INTENT_RECORDED` | open action contains exact resting target; no unresolved prior attempt | project one attempt in `INTENT_PERSISTED` | unchanged |
| `CANCEL_SEND_BOUNDARY_ENTERED` | exact trusted intent + exact prepared request + exact predecessor tail | project `MAY_HAVE_BEEN_SENT`; only observation/result/reconciliation may close | unchanged |
| `CANCEL_RESULT_RECORDED` | matching attempt; valid contiguous result revision and evidence | project highest valid revision; closed result terminal, unresolved may be superseded | unchanged |
| `RISK_RELEASE_RECORDED` | current `SAFE_HELD`; all exact predicate-vector values true | project durable release decision only; proof/state unchanged | unchanged |
| `RESTRICTED_SESSION_STARTED` | no active ordinary/restricted session under fresh exclusive locks | project active `rs_` session and mode | unchanged |
| `RESTRICTED_SESSION_ENDED` | matching active restricted session | project clean inactive session before lock close | unchanged |
| `RESTRICTED_SESSION_ABANDONED` | fresh locks + replayed prior unended restricted session | project prior session abnormal/inactive; may then start replacement | unchanged |

For every row, an exact duplicate has no second projection effect; a conflicting duplicate or malformed/reference-invalid event fails replay closed. Authority anchoring is required for every appended row.

### 7.13 New-event replay and predecessor-state compatibility

The complete new event-type set introduced by this scope is exactly:

```text
RISK_CONTROL_STATE_CHANGED
EMERGENCY_ACTION_OPENED
CANCEL_INTENT_RECORDED
CANCEL_SEND_BOUNDARY_ENTERED
CANCEL_RESULT_RECORDED
RISK_RELEASE_RECORDED
RESTRICTED_SESSION_STARTED
RESTRICTED_SESSION_ENDED
RESTRICTED_SESSION_ABANDONED
```

The first six are the Revision-01 risk/emergency vocabulary. The final three are the minimum semantic additions strictly required to solve the Revision-02 restricted-session defect. No new SQL column/table/index/trigger/schema revision is required.

Existing historical events keep their exact schemas and meanings. Session compatibility is mode-gated in Section 9; it is not implemented by changing historical payloads or interpreting a restricted session as an ordinary writer session.

### 7.14 Prohibited automatic transitions

None of the following can transition to `WRITER_ELIGIBLE`: process restart, strategy restart, timer expiry, REST success, WebSocket reconnect, network reconnect, API health recovery, empty active-order result, cancel acknowledgement, batch cancel success, Order Group trigger/reset, or exchange-status recovery.

## 8. Writer eligibility and exact `NormalWriterPermit` lifecycle

### 8.1 Question A

`normal_write_eligible` is true for one candidate only when all are true under one already-held exclusive `NORMAL_WRITER` acquisition:

1. effective state is `WRITER_ELIGIBLE`;
2. authority/ledger integrity, exact binding, and equal trusted/terminal tail pass;
3. no unresolved protected write exists;
4. controlling writer proof is `RELEASED` under predecessor rules;
5. risk configuration is complete/valid and its exact hash is current;
6. all hard limits pass after including the candidate;
7. required market data is usable/fresh under Section 19;
8. reconciliation is usable/fresh under Section 19;
9. identity-conflict count is zero;
10. no emergency cancellation result is unresolved;
11. required venue-defense predicates pass;
12. the normal writer acquisition remains active and exclusively locked;
13. exact risk epoch and all bound snapshot/config identities match the candidate assessment.

Any false/unknown predicate yields `normal_write_eligible=false` and no permit.

### 8.2 Lock point and T0 assessment

The exact sequence begins **after** the predecessor normal-writer acquisition has:

1. opened the trusted authority store;
2. acquired its exclusive lock;
3. opened the exact bound ledger;
4. acquired its exclusive lock;
5. validated/caught forward only as permitted by the predecessor;
6. replayed complete history;
7. appended/anchored/read back its ordinary `WRITER_SESSION_STARTED` if one is required by the accepted normal-writer implementation.

The authority-first/ledger-second exclusive locks remain continuously held through T3 and transport invocation. Risk evaluation occurs against exact tail `T0` after the ordinary session-start tail is trusted:

```text
T0 = {
  trusted_sequence,
  trusted_event_hash,
  ledger_terminal_sequence,
  ledger_terminal_hash
}
```

The two sequence/hash pairs MUST be equal. A non-equal pair denies and no permit is minted.

### 8.3 Exact immutable permit and private progress record

`NormalWriterPermit` is immutable, private-constructor, non-serializable, process-local, one-shot, and has exactly these safety-relevant fields:

```text
permit_id: NormalWriterPermitId
risk_assessment_id: RiskAssessmentId
process_instance_id: ProcessInstanceId
normal_writer_session_id: NormalWriterSessionId
conflict_domain_ref: ConflictDomainRef
operation_kind: closed normal-write operation enum
request_id: RequestId
candidate_request_sha256: Sha256Hex
candidate_economic_sha256: Sha256Hex
risk_config_sha256: Sha256Hex
market_data_snapshot_sha256: Sha256Hex
market_data_freshness_identity_sha256: Sha256Hex
reconciliation_snapshot_sha256: Sha256Hex
reconciliation_freshness_identity_sha256: Sha256Hex
risk_state_epoch: built-in int >= 0
initial_trusted_sequence: built-in int >= 1
initial_trusted_hash: Sha256Hex
initial_ledger_sequence: built-in int >= 1
initial_ledger_hash: Sha256Hex
intent_event_id: EventId
prepared_event_id: EventId
send_boundary_event_id: EventId
issued_at_utc: CanonicalTimestamp
issued_monotonic_ns: built-in int >= 0
freshness_deadline_monotonic_ns: built-in int >= issued_monotonic_ns
private_gate_instance_identity: process-private non-serializable sentinel
```

The candidate request/economic hashes are derived with predecessor canonical JSON over exact closed request/economic objects. The freshness deadline is the minimum monotonic expiry among every market-data and reconciliation input bound to the assessment. The three stage event IDs are allocated once when the permit is minted and can never be replaced.

Mutable lifecycle position is **not stored in the permit**. The same private `WriterEligibilityGate` that constructs the permit creates exactly one non-serializable `NormalWriterPermitProgress` record keyed by `permit_id`:

```text
permit_id: exact NormalWriterPermitId
stage: "INTENT" | "PREPARED" | "SEND_BOUNDARY" | "CONSUMED" | "INVALIDATED"
expected_trusted_sequence: built-in int >= 1
expected_trusted_hash: Sha256Hex
expected_ledger_sequence: built-in int >= 1
expected_ledger_hash: Sha256Hex
last_monotonic_ns: built-in int >= 0
transport_invocation_count: built-in int exactly 0 until CONSUMED, then 0 or 1
```

At mint, `stage="INTENT"`; both expected sequence/hash pairs equal exact T0; `last_monotonic_ns=issued_monotonic_ns`; `transport_invocation_count=0`. The progress record is gate-private, cannot be serialized/reconstructed, is not strategy-visible, and may mutate only through the exact stage algorithm below. A missing, duplicate, externally supplied, or mismatched progress record invalidates the permit.

### 8.4 Expected-successor chain

The permit authorizes exactly one request and exactly this progression:

```text
exclusive NORMAL_WRITER acquisition held
→ replay + candidate risk evaluation at T0
→ mint one immutable permit + private progress bound to T0
→ construct/append/anchor exact EXECUTION_INTENT_RECORDED → T1
→ verify T1 is exact gate-computed successor; progress := T1/PREPARED
→ construct/append/anchor exact REQUEST_PREPARED → T2
→ verify T2; progress := T2/SEND_BOUNDARY
→ construct/append/anchor exact WRITE_SEND_BOUNDARY_ENTERED → T3
→ verify T3 authority + ledger readback; progress := T3/CONSUMED
→ only now invoke adapter transport once
```

Before **each** stage, the gate MUST:

1. read one new monotonic value, require it is `>= progress.last_monotonic_ns` and within the permit freshness deadline, then store it as `progress.last_monotonic_ns`;
2. require current locked authority pair and ledger tail both exactly equal `progress.expected_*` and equal each other;
3. require the permit-bound state/config/request/economic/market-data/reconciliation/session/process identities still match;
4. select exactly one `recorded_at_utc` from the gate clock for this stage and retain that exact string in the stage `EventInput`;
5. construct the complete exact predecessor event input internally from the immutable permit, bound request data and this retained timestamp; no caller supplies arbitrary event content;
6. call the predecessor event constructor **before persistence** with sequence `progress.expected_sequence + 1` and previous hash `progress.expected_hash` to compute the exact expected event core/hash;
7. require the expected event type and event ID equal the closed stage and the permit's preallocated stage event ID;
8. append that same exact `EventInput` through the authority-anchored append path.

After each append, the returned persisted event and positive authority+ledger readback MUST satisfy:

```text
new.sequence = prior_expected_sequence + 1
new.previous_event_hash = prior_expected_hash
new.event_id = permit's exact stage event_id
new.event core = the pre-persistence exact expected event core
new.event_hash = the pre-persistence exact expected event_hash
authority readback = new sequence/hash
ledger tail readback = new sequence/hash
```

Only then does the **private progress record** advance its expected sequence/hash to the new pair and advance to the next stage. The immutable permit itself never changes. This exact gate-derived tail movement does **not** self-invalidate; no other tail movement is permitted.

### 8.5 Invalidation conditions

The gate atomically sets private progress `stage="INVALIDATED"` and permanently refuses transport, with transport count remaining zero unless T3 had already been positively anchored/read back and progress had already become `CONSUMED`, on any of:

- authority or ledger tail not equal to the progress record's expected pair;
- any event appears between stages that is not the gate's exact expected next event;
- stage event content/retained timestamp/ID/previous hash/successor hash differs;
- risk state epoch or control state differs;
- risk-config hash differs;
- candidate request/economic identity differs;
- market-data or reconciliation snapshot identity differs;
- `now_monotonic_ns > freshness_deadline_monotonic_ns`;
- current monotonic read `< progress.last_monotonic_ns`;
- ordinary writer session ends/is abandoned/changes;
- exclusive lock continuity is lost;
- process instance changes/restart occurs;
- permit/progress association is missing, duplicated or mismatched;
- progress has already become `CONSUMED` or `INVALIDATED`.

An unrelated tail movement is never accepted as a legitimate successor merely because its sequence is `+1`.

### 8.6 Append/authority failure behavior

If the intent or prepared append fails before a committed/anchored stage is proven, invalidate the permit and do not transport.

If ledger commit succeeds but authority advancement fails or is unknown, close the handle and do not transport. A later reopen uses the predecessor ledger-ahead validation/catch-forward rules; the old permit is gone.

If the send-boundary ledger commit or authority advancement is not positively read back at T3, the current process MUST NOT invoke transport. If later replay discovers a trusted send boundary, the predecessor ambiguous-write theorem controls: the request may have been sent and blind automatic resend is prohibited.

### 8.7 Consumption and restart

T3 positive authority+ledger readback atomically changes the gate-private progress `stage` to `CONSUMED` **before** transport is callable; the immutable permit does not mutate. The adapter requires that exact consumed-at-T3 permit/progress association. Immediately before entering the transport callable, while still under the same exclusive acquisition, the gate requires `transport_invocation_count==0` and sets it to `1`; only then may the one bound transport invocation begin. The count is never decremented if transport raises or returns ambiguously. Any second invocation is rejected.

A permit is never persisted and never reconstructed. Restart invalidates every pre-restart permit even when a durable release remains in history. Restart begins `BOOT_HOLD`, replays, and must satisfy the current release/writer contract before a new process may mint a new permit.

### 8.8 No strategy bypass

No supported runtime `bypass`, `disable_risk`, `force_send`, `reset_to_active`, direct generic adapter writer, or equivalent strategy-accessible route may exist. Strategy receives neither raw transport nor emergency/release handles.

### 8.9 Hard-safety-violation interaction with a live normal writer

Section 12 is a special terminating control transition, not a new normal request. When `HARD_SAFETY_VIOLATION` is detected while a live `NORMAL_WRITER` `ws_` session owns both exclusive stores:

1. the `WriterEligibilityGate` MUST atomically latch `hard_halt_requested=true` under the same process-private synchronization that guards permit progress and adapter transport entry;
2. every `NormalWriterPermitProgress` whose bound transport has **not** irrevocably entered is set to `INVALIDATED`, including a progress record that already reached `CONSUMED` at T3 but still has `transport_invocation_count=0`;
3. no new normal permit may be minted and no invalidated permit may advance T0→T3;
4. adapter entry MUST acquire the same gate synchronization, require `hard_halt_requested=false`, require the exact bound progress, and atomically set `transport_invocation_count` from `0` to `1`; therefore either adapter entry wins first and that already-entered invocation must be reconciled, or HALT invalidation wins first and no invocation begins;
5. an invocation with `transport_invocation_count=1` is never invoked again; HALT cannot retract a transport call that has already entered;
6. a trusted `WRITE_SEND_BOUNDARY_ENTERED` whose transport outcome is absent/ambiguous remains governed by the predecessor ambiguous-write theorem; HALT never converts it to `NO_SEND_PROVEN` and never authorizes blind resend; and
7. the subsequent `RISK_CONTROL_STATE_CHANGED(WRITER_ELIGIBLE→HALTED, HARD_SAFETY_VIOLATION)` append by the same live `ws_` is an intentional terminal control event outside that permit's request-successor chain. Its appearance after hard-HALT latching does not rehabilitate or continue any normal permit.

The gate's hard-HALT latch is process-local safety state, not a new persistence authority. Durable system state changes only through the authority-anchored HALT event defined in Section 12.

## 9. Restricted acquisition/session compatibility and emergency capability

### 9.1 Exact acquisition-mode extension

Future implementation extends the Python `AcquisitionMode` enum exactly to:

```text
NORMAL_WRITER
LEGACY_IMPORT_ONLY
EMERGENCY_CONTROL_ONLY
RELEASE_ONLY
```

This is not a database schema change. Every mode obtains the same logical conflict-domain authority/ledger locks in the same authority-first then ledger order. At most one mode may hold the locked conflict-domain pair at one time.

`NORMAL_WRITER` continues to use only existing `WRITER_SESSION_STARTED/ENDED/ABANDONED` semantics and `ws_...` IDs. `LEGACY_IMPORT_ONLY` remains exactly as accepted by the predecessor and does not start either ordinary or restricted session events.

`EMERGENCY_CONTROL_ONLY` and `RELEASE_ONLY` use only `RESTRICTED_SESSION_STARTED/ENDED/ABANDONED` and `rs_...` IDs. They MUST NOT append existing `WRITER_SESSION_STARTED` and therefore can never create an ordinary writer session.

### 9.2 Restricted acquisition algorithm

For either restricted mode:

1. this algorithm may begin only when no **live current-process** `NORMAL_WRITER` or restricted handle owns the authority+ledger lock pair; Section 12 CASE A forbids trying to enter this algorithm while the live normal `ws_` still owns those stores;
2. call the same authority-first/ledger-second `_open_locked`-equivalent path with full schema, path, integrity, hash-chain, authority relation, and history validation;
3. replay both ordinary and restricted session projections;
4. because this fresh acquisition has now obtained both exclusive locks, any replayed unended session record belongs to a prior owner that cannot still own these same required locks; cleanup is performed **under the newly held locks before the new restricted session starts**;
5. if replay shows an unended prior ordinary `ws_...` session, append the existing predecessor `WRITER_SESSION_ABANDONED` event with its unchanged exact payload schema and exact predecessor reason `PREVIOUS_SESSION_NO_LONGER_HOLDS_REQUIRED_AUTHORITY_AND_LEDGER_LOCKS`; authority-anchor/read back it; this is fresh-reopen cleanup only and MUST NOT be used to terminate a currently live `ws_` merely to obtain restricted capability;
6. if replay shows an unended prior restricted `rs_...` session, append the exact `RESTRICTED_SESSION_ABANDONED` event from Section 7.11; authority-anchor/read back it;
7. after cleanup replay MUST prove no active ordinary or restricted session; otherwise fail `RESTRICTED_SESSION_STATE_CONFLICT`;
8. append/anchor/read back one `RESTRICTED_SESSION_STARTED` for the requested exact mode;
9. return a narrow typed handle whose public methods are the exact mode-specific methods in Sections 9.4/9.5, not `LockedLedger.append_batch`;
10. on clean close, append/anchor/read back `RESTRICTED_SESSION_ENDED`, then close ledger then authority connections as required by the predecessor handle;
11. on process crash, no end event is fabricated; the next fresh exclusive acquisition deterministically performs steps 4-8.

The underlying `LockedLedger.append_batch` remains internal. A restricted handle wraps it with a closed event constructor/validator surface and never exposes it to callers.

### 9.3 Exact mode/event admission

For events relevant to this extension, session/mode admission is closed:

| Event type | `NORMAL_WRITER` (`ws_`) | `EMERGENCY_CONTROL_ONLY` (`rs_`) | `RELEASE_ONLY` (`rs_`) | Rule |
|---|---:|---:|---:|---|
| `WRITER_SESSION_STARTED` | yes | no | no | predecessor ordinary semantics only |
| `WRITER_SESSION_ENDED` | yes | no | no | predecessor ordinary semantics only |
| `WRITER_SESSION_ABANDONED` | predecessor yes | acquisition-cleanup only | acquisition-cleanup only | exact existing payload/reason; never returned-handle method |
| `EXECUTION_INTENT_RECORDED` | yes | no | no | ordinary write only |
| `REQUEST_PREPARED` | yes | no | no | ordinary request only |
| `WRITE_SEND_BOUNDARY_ENTERED` | yes | no | no | ordinary write only |
| `READ_SEND_BOUNDARY_ENTERED` | predecessor ordinary semantics | no | no | restricted persistence handle has no generic read transport |
| `HTTP_RESPONSE_CLASSIFIED` | predecessor ordinary semantics | no | no | emergency cancel uses exact new result event |
| `TRANSPORT_UNKNOWN_AFTER_SEND` | predecessor ordinary semantics | no | no | emergency cancel ambiguity projects from its exact boundary/result events |
| `ORDER_IDENTITY_BOUND` | yes under predecessor | no | no | no emergency inference/rebinding |
| `ORDER_OBSERVED` | yes under predecessor | yes | no | same historical payload schema; emergency observation only |
| `FILL_OBSERVED` | yes under predecessor | yes | no | same historical payload schema; emergency observation only |
| `RECONCILIATION_RECORDED` | yes under predecessor | yes | no | same historical payload schema; emergency reconciliation only |
| `EXECUTION_HALTED` | yes under predecessor | yes | no | same historical payload schema |
| `EXECUTION_TERMINAL` | yes under predecessor | no | no | no restricted terminalization shortcut |
| `WRITER_PROOF_HELD` | predecessor semantics | yes | no | same historical payload schema |
| `WRITER_PROOF_RELEASED` | no for new Revision-02 append admission; historical predecessor events still replay unchanged | no | yes under Section 9.5 | release-only special admission, existing payload schema |
| `LEGACY_INCIDENT_IMPORTED` | no normal/restricted extension | no | no | remains `LEGACY_IMPORT_ONLY` predecessor surface |
| `RISK_CONTROL_STATE_CHANGED` | exactly `WRITER_ELIGIBLE→HALTED` with `HARD_SAFETY_VIOLATION` when that live `ws_` owns the lock pair | every Section-7.2 transition except `SAFE_HELD→WRITER_ELIGIBLE` and except reproducing a `WRITER_ELIGIBLE→HALTED` transition while a live normal owner exists; after normal close/release it may append only still-required valid subsequent transitions | only `SAFE_HELD→WRITER_ELIGIBLE` | exact cause/epoch/reference rules; ownership change never creates a duplicate HALT |
| `EMERGENCY_ACTION_OPENED` | no | yes | no | exact Section 7.5 |
| `CANCEL_INTENT_RECORDED` | no | yes | no | exact Section 7.6 |
| `CANCEL_SEND_BOUNDARY_ENTERED` | no | yes | no | exact Section 7.8 |
| `CANCEL_RESULT_RECORDED` | no | yes | no | exact Section 7.9 |
| `RISK_RELEASE_RECORDED` | no | no | yes | exact Section 7.10 |
| restricted session start/end | no | mode-matching lifecycle | mode-matching lifecycle | exact Section 7.11 |
| restricted session abandonment | no ordinary mode | acquisition cleanup | acquisition cleanup | exact Section 7.11 |

`LEDGER_INITIALIZED` and the entire `LEGACY_IMPORT_ONLY` event surface remain exactly predecessor-defined and are not broadened by this table. A restricted acquisition attempt while a live current-process normal `ws_` owns the lock pair MUST be rejected/never invoked; it cannot append the same `WRITER_ELIGIBLE→HALTED` event in parallel or by in-place capability conversion.

### 9.4 `EMERGENCY_CONTROL_ONLY` exact returned-handle surface

An `EmergencyControlLedgerHandle` may expose methods whose only possible event outputs are:

```text
RESTRICTED_SESSION_STARTED / ENDED / ABANDONED   (lifecycle only)
RISK_CONTROL_STATE_CHANGED                       (all allowed transitions except SAFE_HELD→WRITER_ELIGIBLE)
EMERGENCY_ACTION_OPENED
CANCEL_INTENT_RECORDED
CANCEL_SEND_BOUNDARY_ENTERED
CANCEL_RESULT_RECORDED
existing ORDER_OBSERVED                          (emergency authoritative observation)
existing FILL_OBSERVED                           (emergency authoritative observation)
existing RECONCILIATION_RECORDED                 (emergency reconciliation)
existing EXECUTION_HALTED                        (where predecessor exact schema applies)
existing WRITER_PROOF_HELD                       (where predecessor exact schema applies)
```

For existing events admitted under this mode, the event payload schema remains byte-for-byte the predecessor schema. The only semantic extension is session eligibility: `_validate_event_semantics` MUST look up the referenced `rs_...` session, prove its mode is `EMERGENCY_CONTROL_ONLY`, and prove the event type is in the list above. Existing `ws_...` validation remains unchanged. The restricted mode MUST supply exact source-request/basis event references required by the existing event; it cannot manufacture `ORDER_IDENTITY_BOUND`.

`WRITER_SESSION_ABANDONED` is the sole existing ordinary-session event a restricted **acquisition routine** may append, and only as the step-4 predecessor cleanup above. It is not exposed on the returned emergency handle and it uses the unchanged predecessor schema/reason.

The handle MUST NOT expose or append:

```text
CREATE
MODIFY
REPLACE
DECREASE
EXECUTION_INTENT_RECORDED
REQUEST_PREPARED
WRITE_SEND_BOUNDARY_ENTERED
READ_SEND_BOUNDARY_ENTERED
ORDER_IDENTITY_BOUND
WRITER_PROOF_RELEASED
RISK_RELEASE_RECORDED
SAFE_HELD→WRITER_ELIGIBLE
generic append_batch
generic transport
Order Group trigger/reset
```

### 9.5 `RELEASE_ONLY` exact append surface

A `ReleaseLedgerHandle` may expose only:

```text
RESTRICTED_SESSION_STARTED / ENDED / ABANDONED   (lifecycle only)
RISK_RELEASE_RECORDED
existing WRITER_PROOF_RELEASED
RISK_CONTROL_STATE_CHANGED only for SAFE_HELD→WRITER_ELIGIBLE
```

For existing `WRITER_PROOF_RELEASED`, its historical payload schema remains unchanged. Restricted replay admits it only when:

1. session mode is exactly `RELEASE_ONLY`;
2. immediately preceding trusted release sequence contains a valid `RISK_RELEASE_RECORDED` for the same proof/config/epoch;
3. the existing `release_basis_event_ids` includes that exact release event ID;
4. the predecessor `LockedLedger.append_batch` proof-release prerequisites independently pass;
5. no predicate in the release record has become false/stale between release record and proof release.

The handle exposes no venue transport, emergency permit, CREATE/CANCEL/MODIFY/REPLACE/DECREASE, ordinary writer-session start, generic append, or generic adapter. Any predecessor `WRITER_SESSION_ABANDONED` needed to clean a crashed ordinary session occurs only inside the common restricted acquisition prelude before this handle is returned.

### 9.6 Replay/session validation

Replay maintains separate maps:

```text
ordinary_sessions_by_ws_id
restricted_sessions_by_rs_id_with_mode
active_ordinary_session_id
active_restricted_session_id
abnormal_ordinary_session_ids
abnormal_restricted_session_ids
```

The invariant is:

```text
count(active ordinary sessions) + count(active restricted sessions) <= 1
```

A `ws_` ID can never refer to a restricted session and an `rs_` ID can never refer to an ordinary session. An existing `WRITER_SESSION_ABANDONED` may close a replayed prior `ws_` session only under fresh exclusive-lock proof as Section 9.2 defines; a live current-process normal owner that successfully anchors HALT instead uses `WRITER_SESSION_ENDED` before releasing locks. Abandonment does not make a restricted session ordinary. Event-type/session-mode mismatches are `RESTRICTED_SESSION_EVENT_NOT_PERMITTED` and fail closed.

### 9.7 Emergency venue capability remains separate

`EmergencyCancelPermit` is not the restricted ledger handle. It is immutable/process-local/one-shot and may be minted only after:

1. state is `HALTED` or `EMERGENCY_CANCELING` as permitted by the action;
2. durable HALT/state epoch is trusted;
3. exact target is in the open action's authoritative target set;
4. exact target observation remains `resting` with positive remaining quantity and no conflict;
5. `CANCEL_INTENT_RECORDED` is anchored/read back;
6. Section-7.7 prepared request hash is exact;
7. no unresolved previous attempt exists for target/action;
8. local emergency concurrency/rate budget allows one send;
9. KSR-02 source binding is current for the implementation acceptance point;
10. current authority/ledger tail equals the permit-bound tail.

The emergency adapter supports exactly one DELETE for the permit's exact path/target. It has no risk-increasing method. The permit cannot release writer proof or state.

### 9.8 Crash/restart semantics

A crashed restricted session is not evidence of venue outcome. On restart:

- open/catch-forward and full replay occur first;
- a prior restricted session is marked abandoned only after fresh exclusive locks prove the old session cannot still own them;
- a trusted `CANCEL_SEND_BOUNDARY_ENTERED` remains possibly sent until reconciled regardless of session abandonment;
- no cancel is blind-resubmitted;
- no normal writer session is created by restricted recovery;
- prior HALT/HELD state remains held.

## 10. Risk-limit configuration and evaluation

### 10.1 Exact `RiskLimitConfigV1`

The future implementation uses one immutable config object. Every listed field is mandatory; omission is invalid. Decimal fields are exact Python `Decimal` and predecessor canonical serialization stores them through its canonical Decimal tag. Binary float is rejected.

```text
RiskLimitConfigV1
  schema_version: built-in int exactly 1
  conflict_domain: exact ConflictDomainRef
  currency: exactly "USD"

  per_order:
    max_contracts: Decimal > 0
    max_worst_case_exposure_usd: Decimal > 0
    price_reasonability_required: exact bool
    max_abs_reference_price_deviation_usd: Decimal >= 0
    max_market_data_age_ms: built-in int > 0

  per_market:
    max_abs_net_position_contracts: Decimal >= 0
    max_gross_exposure_usd: Decimal >= 0
    max_authoritative_working_orders: built-in int >= 0
    max_working_contracts: Decimal >= 0
    max_working_order_exposure_usd: Decimal >= 0

  conflict_domain_account:
    max_aggregate_exposure_usd: Decimal >= 0
    max_aggregate_working_orders: built-in int >= 0
    max_aggregate_working_contracts: Decimal >= 0
    max_unresolved_write_count: built-in int >= 0
    max_conservative_unresolved_write_exposure_usd: Decimal >= 0

  flow:
    create_max_sends: built-in int >= 0
    create_window_ms: built-in int > 0
    modify_replace_max_sends: built-in int >= 0
    modify_replace_window_ms: built-in int > 0
    ordinary_cancel_max_sends: built-in int >= 0
    ordinary_cancel_window_ms: built-in int > 0
    automated_execution_max_sends: built-in int >= 0
    automated_execution_window_ms: built-in int > 0
    emergency_cancel_max_sends: built-in int > 0
    emergency_cancel_window_ms: built-in int > 0
    emergency_cancel_max_in_flight: built-in int > 0
    emergency_cancel_request_deadline_ms: built-in int > 0
    emergency_retry_max_attempts_per_target_per_action: built-in int >= 0
    emergency_backoff_base_ms: built-in int > 0
    emergency_backoff_max_ms: built-in int >= emergency_backoff_base_ms

  state_integrity:
    max_reconciliation_lag_ms: built-in int > 0
    max_required_market_data_age_ms: built-in int > 0
    max_future_wall_clock_skew_ms: built-in int >= 0
    max_reconciliation_attempts_per_cycle: built-in int > 0
    reconciliation_read_deadline_ms: built-in int > 0
    reconciliation_backoff_base_ms: built-in int > 0
    reconciliation_backoff_max_ms: built-in int >= reconciliation_backoff_base_ms

  venue_defense:
    order_group_mode: "NOT_REQUIRED" | "REQUIRED_FOR_EXPERIMENT"
    required_order_group_id: exact built-in str or null
    cancel_order_on_pause_required: exact bool
    reduce_only_policy: "NO_SAFETY_CREDIT" | "REQUIRED_WHEN_OPERATION_IS_PROVEN_RISK_REDUCING"
    post_only_policy: exactly "NO_SAFETY_CREDIT"
```

`required_order_group_id` MUST be null exactly when mode is `NOT_REQUIRED`; it MUST be a non-empty canonical string when mode is `REQUIRED_FOR_EXPERIMENT`. There are no numerical defaults in this specification. Exact numerical limit values require separate configuration acceptance before venue-write execution.

### 10.2 Configuration identity and persistence

The full config is serialized with predecessor canonical JSON/Decimal rules and:

```text
risk_config_sha256 = SHA256(canonical_json_bytes(RiskLimitConfigV1))
```

The hash is bound into risk-state events, risk assessments, cancel actions where a valid config exists, normal permits, and release records. Config change invalidates all process-local permits and requires complete re-evaluation; it never silently preserves writer eligibility.

### 10.3 Deterministic normal evaluation order

Normal candidate evaluation under the locked T0 acquisition is exactly:

1. authority/ledger schema/path/integrity/hash-chain/equal-tail relation;
2. replay completeness and control state;
3. writer-proof state and protected unresolved history;
4. config presence/type/value/hash;
5. identity/conflict-domain consistency;
6. unresolved-write count/exposure;
7. required market metadata/price grid;
8. required orderbook snapshot and freshness;
9. reconciliation snapshot and freshness;
10. deduplicated filled-position exposure;
11. authoritative working-order exposure/count/contracts;
12. candidate per-order size/exposure/price-grid/reasonability;
13. projected per-market position/gross/working limits;
14. projected conflict-domain/account gross/working/unresolved limits;
15. flow/repeated-execution limits;
16. required venue-defense predicates;
17. exact T0 recheck;
18. permit mint.

The first false/unknown hard predicate denies. Integrity/identity/control faults additionally require the appropriate durable HALT transition.

### 10.4 Exact hard-limit boundaries

Every maximum is inclusive:

```text
usage <= configured_max  => pass
usage >  configured_max  => deny
```

Age is inclusive exactly as Section 19 specifies. Flow windows count trusted send-boundary events with:

```text
evaluation_time_ms - window_ms < send_time_ms <= evaluation_time_ms
```

A candidate send passes only if `existing_count + 1 <= max_sends`. Durable send history, not successful-response count, drives write-flow limits.

### 10.5 Missing/invalid/overflow behavior

```text
missing field/type/value             → RISK_LIMIT_CONFIG_MISSING/INVALID → deny
NaN/Infinity/exponent/binary float   → RISK_LIMIT_CONFIG_INVALID → deny
unsupported precision/range          → RISK_NUMERIC_RANGE_UNSUPPORTED → deny
unknown required risk input          → RISK_INPUT_UNAVAILABLE → deny
unknown/unbounded exposure            → UNKNOWN_UNBOUNDED → deny + no release
missing price-grid/reference input    → MARKET_DATA_UNUSABLE → deny
stale data                            → MARKET_DATA_STALE or RECONCILIATION_STALE → deny
```

Missing never means unlimited.

## 11. Exact Kalshi binary-contract economic risk model

### 11.1 Safety metric and payout unit

The hard-risk metric is a conservative **open settlement-liability/capital-at-risk bound**, not mark-to-market value, VaR, generic securities notional, or realized PnL.

For one correct binary contract, KSR-13 fixes:

```text
PAYOUT = Decimal("1.0000") USD per contract
```

For a YES-leg price `p`:

```text
long YES unit maximum loss = p
long NO  unit maximum loss = 1.0000 - p
```

KSR-14/KSR-15 fix direction:

```text
book_side=bid / outcome_side=yes => long YES
book_side=ask / outcome_side=no  => long NO
Create-V2 side=bid               => candidate long YES
Create-V2 side=ask               => candidate long NO, economically sell YES / buy NO at 1-p
```

Fees are validated/deduplicated as economic evidence but are **excluded from `worst_case_exposure_usd`**. This hard limit therefore bounds open contract settlement loss/capital at risk. Any future all-in loss/fee budget is a separate explicit limit; fees are never silently added/subtracted by implementation preference.

### 11.2 Fill normalization and deduplication

A fill enters risk only if all required authoritative fields validate: exact `fill_id`, target/order identity, market ticker, canonical direction (`outcome_side` or equivalent validated `book_side`), `count_fp`, exact YES-leg price field, subaccount, and authoritative timestamp/basis identity.

Deduplicate by `fill_id`:

- exact same canonical fill content contributes once;
- any conflicting field for the same `fill_id` is `DUPLICATE_FILL_CONFLICT`, HALT, and no finite risk/release result.

For deterministic replay, sort unique fills by `(authoritative_created_time_utc, fill_id)` ascending. Equal timestamps are ordered by exact `fill_id` code-point order. If complete authoritative fill history required to establish the current position is not proven for the evaluated market/conflict-domain scope, `known_filled_exposure` and signed net position are `UNKNOWN_UNBOUNDED`; the implementation may not start the FIFO model from an assumed zero position.

### 11.3 Known filled exposure: FIFO open-lot algorithm

Maintain two FIFO lot queues per market:

```text
YES lots: (remaining_qty, yes_entry_price)
NO  lots: (remaining_qty, yes_entry_price)
```

For a `bid/yes` fill `(q,p)`:
1. consume `q` against oldest NO lots until either q=0 or NO queue empty;
2. any excess opens a YES lot `(q,p)`.

For an `ask/no` fill `(q,p)`:
1. consume `q` against oldest YES lots;
2. any excess opens a NO lot `(q,p)`.

Closing lots affects realized PnL but contributes zero to this **open** exposure measure after closure. No implementation-chosen average-cost/LIFO alternative is permitted.

Then:

```text
known_filled_exposure_market =
    Σ(YES_open_qty_i * yes_entry_price_i)
  + Σ(NO_open_qty_j  * (1.0000 - yes_entry_price_j))

signed_net_position_market =
    Σ YES_open_qty_i - Σ NO_open_qty_j
```

If both queues are empty, both values are exactly zero. All products/sums use Section-6 exact Decimal semantics.

### 11.4 Authoritative working-order exposure

Only authoritative orders currently reconciled as `resting` with exact positive `remaining_count_fp` contribute. An order's contribution is **not** reduced because it might offset current inventory or another working order.

For exact remaining quantity `r` and YES-leg order price `p`:

```text
resting bid/yes contribution = r * p
resting ask/no  contribution = r * (1.0000 - p)
```

`worst_case_known_working_order_exposure_market` is the arithmetic sum of every such non-negative contribution. A missing/conflicting direction, status, remaining count, price, target identity, market, or subaccount makes the affected aggregate `UNKNOWN_UNBOUNDED`.

After a partial fill, the filled delta enters the FIFO fill model and the order contribution uses only the **authoritative latest** `remaining_count_fp`. The same contracts MUST NOT be counted as both remaining and filled.

### 11.5 Candidate projected exposure

A candidate is included before permit issuance using its full requested quantity `c` and YES-leg limit price `p`:

```text
candidate bid exposure = c * p
candidate ask exposure = c * (1.0000 - p)
```

The candidate receives no offset credit against current position or opposite working orders. Its full quantity counts toward projected working contracts and one prospective working order for hard-limit evaluation, even when its time-in-force may avoid resting; a later accepted contract may only reduce that conservatism by explicitly proving a stronger invariant.

Per-order checks are:

```text
c <= per_order.max_contracts
candidate_exposure <= per_order.max_worst_case_exposure_usd
```

plus exact price-grid, reasonability, freshness, and other configured predicates.

### 11.6 Per-market signed-net worst case

Let:

```text
q = signed_net_position_market from filled FIFO lots
B = sum remaining ContractQty of all authoritative resting bid/yes orders
A = sum remaining ContractQty of all authoritative resting ask/no orders
cb = candidate quantity if candidate bid else 0
ca = candidate quantity if candidate ask else 0
```

No working-order offset is assumed. Evaluate both one-sided execution extremes:

```text
q_up   = q + B + cb
q_down = q - A - ca
worst_case_abs_net_position = max(abs(q_up), abs(q_down))
```

Pass iff `worst_case_abs_net_position <= max_abs_net_position_contracts`.

### 11.7 Per-market gross exposure

For a market with finite attributable unresolved exposure:

```text
projected_market_gross_exposure =
    known_filled_exposure_market
  + worst_case_known_working_order_exposure_market
  + candidate_exposure_if_candidate_is_this_market
  + unresolved_write_exposure_upper_bound_market
```

Pass iff finite and `<= per_market.max_gross_exposure_usd`.

Working-only sublimits use:

```text
projected_working_order_count = current_authoritative_resting_count + 1 candidate
projected_working_contracts   = Σ authoritative remaining counts + candidate full count
projected_working_exposure    = working exposure + candidate exposure
```

for a normal candidate.

### 11.8 Conflict-domain/account aggregate

No markets are netted against one another. Compute:

```text
projected_account_aggregate_exposure =
    Σ projected_market_gross_exposure
  + unallocated_unresolved_write_exposure_upper_bound
```

`unallocated_unresolved_write_exposure_upper_bound` contains any unresolved write whose market/economic upper bound cannot be proven and allocated exactly. If that term or any market term is `UNKNOWN_UNBOUNDED`, the account aggregate is `UNKNOWN_UNBOUNDED` and both writer/release eligibility are false.

Aggregate working-order/contract counts are straight sums across the conflict domain plus the candidate. Opposite markets, event relationships, correlation, mutual exclusion, or strategy-intended hedges receive zero offset credit unless a later accepted contract proves an atomic economic relationship.

### 11.9 Conservative unresolved writes

The core invariant remains:

```text
conservative_risk_usage =
    known_filled_exposure
  + worst_case_known_working_order_exposure
  + unresolved_write_exposure_upper_bound
```

For an unresolved write, a finite value exists only if exact authoritative durable original economic intent proves market, direction, quantity, and price sufficient to apply this section's formula. Otherwise:

```text
unresolved_write_exposure_upper_bound = UNKNOWN_UNBOUNDED
```

Missing order ID, empty order/fill reads, disconnect, process restart, or cancellation of other orders never sets the term to zero.

For the current historical incident:

```text
historical_unresolved_exposure = UNKNOWN_UNBOUNDED
normal_write_eligible = false
release_eligible = false
```

## 12. HALT persistence and exact lock ownership

### 12.1 HALT ownership theorem

A hard safety violation first blocks new normal risk and then durably records HALT. Ownership of the HALT append depends only on who currently owns the exclusive stores:

```text
CASE A: live NORMAL_WRITER ws_ owns authority+ledger locks
  HARD VIOLATION
  → atomically latch hard HALT + invalidate non-entered normal permits
  → current ws_ appends WRITER_ELIGIBLE→HALTED
  → ledger commit
  → authority advance/commit
  → positive authority+ledger sequence/hash readback
  → clean WRITER_SESSION_ENDED append/anchor/readback
  → close/release ordinary locks
  → only then may EMERGENCY_CONTROL_ONLY freshly acquire
  → rs_ session may start

CASE B: no live NORMAL_WRITER owns the stores
  → EMERGENCY_CONTROL_ONLY freshly acquires authority first, ledger second
  → clean stale replayed sessions only under fresh-lock proof
  → start exact rs_ session
  → if a valid held/HALT transition is required, append/anchor/read it back
  → only then continue emergency planning
```

There is no `ws_→rs_` in-place capability conversion, no simultaneous live `ws_` and `rs_` ownership, no lock transfer by object reuse, and no restricted-mode acquisition before a live normal owner has released its locks.

### 12.2 CASE A — active `NORMAL_WRITER` owns the lock pair

Preconditions are all true:

- one live current-process `NORMAL_WRITER` `ws_` session exists;
- that same process/handle owns the authority-first/ledger-second exclusive lock pair continuously;
- effective risk state is exactly `WRITER_ELIGIBLE` for the hard-violation transition defined by Section 7.2; and
- `HARD_SAFETY_VIOLATION` is detected.

The exact algorithm is:

1. under the gate synchronization defined in Section 8.9, set `hard_halt_requested=true`, invalidate every permit/progress record whose transport has not already irrevocably entered, and prohibit new permit minting;
2. prevent any new normal transport entry; a transport invocation that had already atomically changed its bound progress `transport_invocation_count` from `0` to `1` before the latch may finish/return/raise, but is never invoked a second time and its result remains subject to normal reconciliation;
3. **do not** call or construct `EMERGENCY_CONTROL_ONLY` acquisition while the live `ws_` still owns either required store lock;
4. using the same live `ws_` session and same held `LockedLedger`/authority pair, construct exactly one `RISK_CONTROL_STATE_CHANGED` event with:

```text
previous_state = WRITER_ELIGIBLE
new_state = HALTED
cause = HARD_SAFETY_VIOLATION
risk_state_epoch_before = exact current projected epoch
risk_state_epoch_after = before + 1
risk_config_sha256 = exact current config hash or null only if already unusable under Section 7.4
related_emergency_action_id = null
related_release_id = null
predecessor_state_event_id = exact immediately preceding risk-state event ID
observed_authority_trusted_sequence/hash = exact equal pre-HALT trusted pair
observed_ledger_terminal_sequence/hash = exact equal pre-HALT ledger pair
```

   The event envelope is the unchanged Section-7.4 envelope with `writer_session_id` equal to this live `ws_`; `incident_id=null`; `execution_attempt_id=null`.
5. validate the complete proposed replay, commit the HALT row to the ledger, and do not begin any venue transport;
6. advance/commit the authority trusted tail to the exact HALT sequence/hash;
7. positively read back the authority row and ledger terminal row and require exact equality to each other and to the HALT event returned by the append path;
8. only after Step 7 succeeds is `HALTED` a trusted persistent state; append the existing exact predecessor `WRITER_SESSION_ENDED` event for this same live `ws_`, authority-anchor it, and positively read back its exact authority/ledger terminal equality;
9. close the ordinary ledger and authority connections according to the predecessor handle contract, thereby releasing the normal session's locks;
10. after lock release, no normal permit/progress is restorable; a later emergency phase may invoke the fresh Section-9.2 `EMERGENCY_CONTROL_ONLY` acquisition algorithm;
11. that acquisition replays the already trusted HALT and MUST NOT append a duplicate `WRITER_ELIGIBLE→HALTED` event merely because ownership changed; it may then start exactly one `rs_` session and perform only its closed Revision-02 emergency surface.

The HALT append is a control-state termination operation admitted to the live normal session by Section 9.3. It is not `EXECUTION_INTENT_RECORDED`, not a new normal request, and not permit-authorized venue transport.

### 12.3 CASE B — no active normal writer owns the stores

CASE B applies when no live current-process ordinary writer handle owns either required exclusive store lock, including startup/restart, already-held operation, or an emergency supervisor acting after the normal writer released its locks.

The exact algorithm is:

1. invoke `EMERGENCY_CONTROL_ONLY` acquisition through Section 9.2;
2. acquire authority first, then the exact bound ledger, both exclusively;
3. perform predecessor integrity/path/hash/authority-relation validation and full replay;
4. if replay contains an unended prior `ws_`, it may be marked `WRITER_SESSION_ABANDONED` **only now**, because the newly acquired exclusive pair proves that prior process/session no longer owns the required locks; a live session is never abandoned in place;
5. clean any prior unended restricted session under the exact `RESTRICTED_SESSION_ABANDONED` rules;
6. replay MUST prove no active session remains, then append/anchor/read back exactly one `RESTRICTED_SESSION_STARTED(mode=EMERGENCY_CONTROL_ONLY)`;
7. derive the current risk state. If the trusted history already contains the required HALT, do not duplicate it. If no HALT exists and Section-7.2 permits a required held/HALT transition from the replay-derived state, append the exact `RISK_CONTROL_STATE_CHANGED` under the active emergency `rs_`, then ledger-commit, authority-advance, and positively read back exact equality;
8. emergency action planning or cancel-permit minting may begin only after the required held/HALT state is trusted.

CASE B never creates a `ws_`, never restores a prior normal permit, and never infers a venue outcome from session cleanup.

### 12.4 Event admission consequence

The Section-9.3 admission table is interpreted exactly as follows:

- while a live current-process `NORMAL_WRITER` `ws_` owns both stores and the projected state is `WRITER_ELIGIBLE`, **only that same `ws_`** may append `RISK_CONTROL_STATE_CHANGED(WRITER_ELIGIBLE→HALTED, HARD_SAFETY_VIOLATION)`;
- `EMERGENCY_CONTROL_ONLY` MUST NOT be acquired or used to reproduce that transition while the live normal owner exists;
- after the clean normal session ends and releases its locks, a newly acquired emergency `rs_` replays HALT and appends no duplicate HALT;
- `EMERGENCY_CONTROL_ONLY` may append only the still-valid subsequent state transitions already admitted by Sections 7.2 and 9.3; and
- exact idempotent retry of the same HALT event uses the Section-7.3 deterministic event identity rules; it is not a second state transition or epoch increment.

### 12.5 Permit interaction and already-entered transport

Section 8.9 controls permit invalidation. The ordering is race-safe:

```text
adapter-entry synchronization outcome A:
  transport_invocation_count 0→1 occurs first
  → that one invocation is already entered
  → HARD HALT may then latch and persist
  → no second invocation; outcome/reconciliation theorem controls

adapter-entry synchronization outcome B:
  hard_halt_requested false→true occurs first
  → every not-entered permit/progress invalidated
  → adapter entry fails
  → HALT persists before any emergency cancel send
```

A T3 send-boundary event can therefore exist even when transport never begins. If the current process has positive local proof that adapter entry never occurred (`transport_invocation_count=0`), HALT blocks the call; this process-local fact does not rewrite the already persisted predecessor write-boundary semantics. After process loss, replay of a trusted write send boundary remains conservative and cannot be converted to `NO_SEND_PROVEN` from vanished in-memory counters.

If transport entered or its outcome is ambiguous, HALT does not close that normal request. Existing write-result reconciliation remains mandatory.

### 12.6 Failure before HALT ledger COMMIT

If the HALT event is not committed:

- all current-process normal permits remain invalidated and `hard_halt_requested` remains latched;
- no new normal transport may enter;
- no emergency cancel transport may occur;
- no restricted acquisition is attempted using the still-owned normal locks;
- the process does not retry by creating a new normal request or minting a new normal permit;
- the current handle closes/reopens only according to predecessor durability rules; and
- restart begins write-ineligible and derives state solely from trusted replay.

Because no positive HALT commit+authority readback exists, the process MUST NOT claim a trusted persistent `HALTED` state. The local safety outcome remains blocked/write-ineligible.

### 12.7 HALT ledger COMMIT succeeds; authority advancement definitely fails

Required behavior:

1. normal and emergency venue transport remain prohibited;
2. no `WRITER_SESSION_ENDED` or restricted acquisition is attempted from the uncertain/ledger-ahead handle;
3. close the handle, preserving the committed ledger row and older trusted authority prefix;
4. fresh reopen uses the predecessor authority-first/ledger-second validation;
5. when the authority row is behind the validated ledger and exact predecessor catch-forward predicates pass, catch forward only to the exact validated ledger tail and positively read it back;
6. do not append another HALT event during recovery; the committed deterministic HALT row is replayed as the candidate trusted suffix;
7. if catch-forward cannot be proven, remain write-ineligible and do not claim durable HALT; and
8. never restore writer eligibility or any pre-failure permit.

### 12.8 Authority advancement result unknown

If HALT authority commit outcome is unknown:

- no normal continuation, ordinary-session clean-end append, emergency venue send, or restricted acquisition occurs on the current handle;
- close the handle;
- fresh reopen determines only from durable state whether authority and ledger are `EQUAL` or `LEDGER_AHEAD`;
- apply exact predecessor catch-forward rules only if `LEDGER_AHEAD` is valid;
- never assume HALT absent;
- never append a duplicate HALT until replay proves no such committed event exists and the state transition is still valid; and
- never restore writer eligibility or reconstruct the old permit.

### 12.9 Positive HALT readback and ordinary session close

Only exact positive HALT readback authorizes the live-success path to ordinary session shutdown.

The same live `ws_` MUST use the predecessor clean event:

```text
WRITER_SESSION_ENDED
payload = {"writer_session_id": <same live ws_ id>}
writer_session_id = <same live ws_ id>
```

That end event is ledger-committed, authority-advanced, and positively read back before the handle closes. `WRITER_SESSION_ABANDONED` is prohibited on this live-success path.

If the clean session-end append/authority result fails or is unknown **after HALT itself is already trusted**, normal transport remains prohibited and no in-place restricted acquisition occurs. Close the handle. A later fresh exclusive acquisition may replay the trusted HALT and, because it now proves the old process/session no longer owns the locks, use the predecessor `WRITER_SESSION_ABANDONED` cleanup semantics if the clean end was not durably trusted. It then starts the new restricted session. No duplicate HALT is appended.

### 12.10 Lock release → restricted acquisition ordering

The required ownership boundary is:

```text
trusted HALT under current ws_
→ trusted WRITER_SESSION_ENDED under current ws_
→ close normal ledger/authority handles
→ normal lock ownership = NONE
→ create/invoke fresh EMERGENCY_CONTROL_ONLY acquisition
→ authority EXCLUSIVE acquired
→ ledger EXCLUSIVE acquired
→ full replay/cleanup
→ trusted RESTRICTED_SESSION_STARTED(rs_, EMERGENCY_CONTROL_ONLY)
```

No API may accept the old `LockedLedger`, ordinary handle, normal session object, or normal permit as an argument that converts it into restricted capability. The emergency acquisition returns a newly constructed narrow restricted handle only after fresh acquisition/replay.

### 12.11 Restart persistence

A durable HALT survives restart. Every process starts `BOOT_HOLD`, exposes no permit, opens/validates/replays existing persistent state, and derives the trusted held state. A historical `WRITER_ELIGIBLE` event does not restore normal execution in a new process. A new explicit durable release remains required wherever the Revision-02 release contract requires it.

After any CASE-A HALT failure or authority-result uncertainty, restart does not infer success or failure from process memory. Only predecessor durable equality/catch-forward/replay determines the trusted prefix and projected state.

## 13. Emergency cancellation target eligibility

### 13.1 Question B

An order is emergency-cancel eligible only if every condition is true:

```text
target_order_id is exact non-empty KalshiOrderIdV1
target identity comes from accepted authoritative persistent provenance
conflict domain/environment/subaccount match the locked scope
no identity conflict exists
latest authoritative order status = "resting"
latest authoritative remaining_count_fp > 0
that exact observation event is referenced by the cancel intent
no prior cancel send for this action/target is unresolved
HALT is durably authority-anchored
open emergency action target set contains the exact target_order_id
```

Only the exact `target_order_id` is substituted into KSR-02 single-cancel path. No other identifier can satisfy the target predicate.

### 13.2 Explicit exclusions

Not eligible:
- `order_id = null`;
- client ID only;
- ticker/price/time/quantity similarity;
- guessed UUID/order ID;
- fuzzy recovery candidate;
- account-wide `cancel_all` or startup/reconnect cancellation sweep;
- another conflict-domain/subaccount order;
- conflicting order identity;
- non-`resting`, zero-remaining, malformed, or stale/unreconciled target observation;
- target whose earlier cancel send may have occurred and remains unresolved.

### 13.3 Empty-order response

An empty live order result can prove only that the exact read returned no live order under that read contract. It does not prove a historical unresolved CREATE never existed, does not set unresolved-write exposure to zero, does not manufacture a cancel target, and does not release writer proof.

## 14. Emergency action identity

### 14.1 Closed logical-ID domains

Economic order identity and emergency-control identity are separate. New logical IDs are generated before their first corresponding durable event and use lower-case UUID4 hex under these exact lexical forms:

```text
emergency_action_id = "ea_"  + uuid4().hex   → ^ea_[0-9a-f]{32}$
cancel_attempt_id   = "ca_"  + uuid4().hex   → ^ca_[0-9a-f]{32}$
request_id          = "req_" + uuid4().hex   → ^req_[0-9a-f]{32}$
deadline_id         = "dl_"  + uuid4().hex   → ^dl_[0-9a-f]{32}$
release_id          = "rel_" + uuid4().hex   → ^rel_[0-9a-f]{32}$
risk_assessment_id  = "ra_"  + uuid4().hex   → ^ra_[0-9a-f]{32}$
normal_permit_id    = "nwp_" + uuid4().hex   → ^nwp_[0-9a-f]{32}$
process_instance_id = "proc_"+ uuid4().hex   → ^proc_[0-9a-f]{32}$
restricted_session  = "rs_"  + uuid4().hex   → ^rs_[0-9a-f]{32}$
```

UUID version/variant bits MUST be those produced by a standard UUID4 generator; caller-supplied arbitrary 32-hex strings are not accepted as newly minted IDs. IDs are immutable after minting and are not venue order IDs.

### 14.2 Relationship and uniqueness

```text
emergency_action_id
  → target_set_sha256 over canonical exact order IDs
  → zero or more cancel_attempt_id
  → exactly one target_order_id per cancel_attempt_id
  → at most one trusted send boundary per cancel_attempt_id
  → one contiguous CANCEL_RESULT_RECORDED revision chain per cancel_attempt_id
```

For one `(emergency_action_id,target_order_id)`, only one logical attempt may be unresolved at a time. A new attempt/ordinal is permitted only after the previous attempt is proven unsent (no trusted boundary) or has an evidence-supported closed result that still leaves the exact target `resting`, and retry/rate/backoff limits allow it.

Event identity is distinct again: each durable event uses the deterministic `evt_...` rule in Section 7.3. Reusing an order ID, action ID, attempt ID, or release ID as an event ID is invalid.

## 15. Cancel send-boundary semantics

### 15.1 Required durable lifecycle

Per target:

```text
CANCEL_INTENT_RECORDED
        ↓
ledger commit + authority anchor/readback
        ↓
CANCEL_SEND_BOUNDARY_ENTERED
        ↓
ledger commit + authority anchor/readback
        ↓
transport may begin
        ↓
response / timeout / connection failure / crash ambiguity
        ↓
CANCEL_RESULT_RECORDED or unresolved projection
        ↓
RECONCILING
```

### 15.2 Exact cancel-intent contract

`CANCEL_INTENT_RECORDED` is exactly the Section-7.6 event schema. No field may be added, omitted, renamed, defaulted, or inferred. The referenced authoritative `ORDER_OBSERVED` is the exact target-eligibility proof; `client_order_id` is not a cancel target.

### 15.3 Exact cancel send-boundary contract

`CANCEL_SEND_BOUNDARY_ENTERED` is exactly the Section-7.8 event schema over the Section-7.7 secret-free prepared request. Transport MUST remain uncallable until that event is ledger-committed, authority-advanced, and both tails read back at its sequence/hash. After that trusted boundary, crash/timeout/response loss preserves `may_have_been_sent=true` until evidence-supported result closure.

### 15.4 Exact emergency-cancel deadline

One monotonic deadline is created once at the **emergency cancel-attempt executor entry**, before request preparation/send-boundary entry, and is never reset. Its exact identity/value is the Section-7.8 `deadline_*` tuple. The budget equals current `risk_config.flow.emergency_cancel_request_deadline_ms` and the stored absolute value is exactly:

```text
deadline_absolute_monotonic_ns =
    deadline_started_monotonic_ns + deadline_budget_ms * 1_000_000
```

The executor checks the same absolute deadline before every potentially blocking local/transport phase and before returning. If arithmetic cannot be represented exactly, the attempt does not send.

If the deadline is exceeded before a trusted `CANCEL_SEND_BOUNDARY_ENTERED`, transport count remains zero. A persisted intent without a trusted boundary is replayed as `INTENT_PERSISTED_NOT_SENT`; it is not a write ambiguity and may be superseded by a later ordinal only under normal retry/rate rules.

If the deadline is exceeded after T-boundary authority+ledger readback, the cancellation may have been sent and is `CANCEL_UNRESOLVED` until authoritative reconciliation. No second deadline and no blind resend is allowed.

## 16. Cancel/fill reconciliation

### 16.1 Authoritative inputs

One cancel attempt may be classified only from a validated combination of:

- exact `CANCEL_INTENT_RECORDED` and, if transport could begin, exact trusted `CANCEL_SEND_BOUNDARY_ENTERED`;
- validated HTTP response identity when one exists;
- authoritative exact-order observations for the target;
- deduplicated authoritative fills bound to that target/order;
- historical partition reads when required for complete truth;
- predecessor ledger identity/binding evidence.

An acknowledgement is one input, never the safety conclusion.

### 16.2 Deduplication/conflict

Existing `ORDER_OBSERVED` and `FILL_OBSERVED` schemas remain controlling. Duplicate fill IDs with identical canonical content contribute once. Any conflicting duplicate, conflicting order identity, wrong target, impossible count transition, or response order-ID mismatch is a fail-closed reconciliation conflict.

### 16.3 Deterministic result classes

The result class domain and all quantity/closure/evidence predicates are exactly Section 7.9. No independent classifier vocabulary exists here:

```text
CANCELED_CONFIRMED
FILLED_BEFORE_CANCEL
PARTIAL_FILL_THEN_REMAINDER_CANCELED
ALREADY_TERMINAL
CANCEL_REJECTED_CONFIRMED
CANCEL_UNRESOLVED
```

A classifier MUST generate `CANCEL_RESULT_RECORDED` only when the referenced evidence satisfies that event's exact class predicate. Unsupported class/evidence pair is `CANCEL_RESULT_EVIDENCE_CONFLICT` and cannot advance safety state.

### 16.4 Reconciliation precedence

1. identity/integrity conflict dominates all economic classifications and HALTs;
2. a trusted send boundary with incomplete transport/post-state truth is `CANCEL_UNRESOLVED`;
3. authoritative fill/order truth dominates assumptions from response timing;
4. response `reduced_by` is reconciled to authoritative canceled quantity; it does not erase fills;
5. full execution is `FILLED_BEFORE_CANCEL`, not `ALREADY_TERMINAL`;
6. partial post-intent fill plus terminal canceled remainder is `PARTIAL_FILL_THEN_REMAINDER_CANCELED`;
7. no result class alone moves the system to `SAFE_HELD`; the state machine/release predicates control.

### 16.5 Fill/cancel race accounting

For each target, freeze the intent-time `prior_remaining_count_fp`. Reconcile every post-intent fill once and obtain the latest authoritative order state. Closed quantity MUST satisfy exactly:

```text
prior_remaining = post_intent_filled + canceled + remaining
```

where every term is explicit `ContractQty`; no unknown term is replaced by zero. Economic filled exposure is then updated through Section-11 FIFO lots. A later fill observation that changes a previously closed economic picture forces new reconciliation and cannot be ignored because a cancel response was earlier accepted.

### 16.6 Transport-ambiguous cancellation

After a trusted send boundary, timeout, connection loss, process crash, or lost response does not prove non-send. Recovery first performs authoritative reads; it never blind-resends. If authoritative truth remains unavailable, result is `CANCEL_UNRESOLVED`, the emergency action remains unreconciled, and release is false.

## 17. Batch cancellation semantics

Batch cancellation remains a **future optional optimization**, not a correctness requirement. Revision 02 deliberately excludes batch transport from the first implementation envelope because the newly frozen send-boundary schema is single-target and exact-request-bound. The implementation defined by this specification MUST use KSR-02 single-order cancellation only.

This narrowing preserves Revision-01 safety semantics: no `cancel_all`, no batch-level atomicity assumption, and no batch HTTP success as safety proof.

A later specification may add batch transport only if it freezes a separate exact batch prepared-request/send-boundary event contract and preserves all of:

- one exact authoritative `target_order_id` and `cancel_attempt_id` per member;
- exact ordered membership bound before transport;
- per-member result/reconciliation identity;
- mixed response remains mixed;
- transport ambiguity marks every potentially sent member unresolved;
- no member is blind-retried;
- batch response alone never creates `SAFE_HELD`;
- finite emergency concurrency/rate and venue token accounting.

Until such a later exact contract exists:

```text
batch_cancel_transport_supported = false
batch_cancel_venue_capability = PROHIBITED
```

## 18. Emergency rate lane

### 18.1 Separate local lane

Normal strategy throttles and the emergency lane MUST be distinct.

Normal CREATE/MODIFY/ordinary-CANCEL activity cannot consume the local capacity reserved for emergency exact cancels.

The emergency lane is bounded by:
- `emergency_cancel_max_sends`;
- `emergency_cancel_window_ms`;
- `emergency_cancel_max_in_flight`;
- per-target/action retry budget;
- request deadline;
- backoff policy.

### 18.2 Venue token-bucket reality

Kalshi currently accounts event-contract write operations, including cancels and Order Groups, against a Write token bucket. A local reserved emergency lane does **not** reserve Kalshi tokens and MUST NOT claim guaranteed venue capacity.

If venue capacity is unavailable:
- retain HALT;
- do not spill into unbounded retry;
- apply bounded exponential backoff;
- remain `EMERGENCY_CANCELING`/`RECONCILING`/`QUIESCENT_HELD` as appropriate;
- never restore writer eligibility.

### 18.3 Retry rules

After a cancel send boundary:
- timeout/ambiguous transport → no blind resend; reconcile first;
- definite rejection → reconcile first;
- only if reconciliation proves exact target still active and retry budget remains may a new `cancel_attempt_id` be generated;
- each retry re-enters intent and send-boundary persistence;
- backoff is `min(backoff_max_ms, backoff_base_ms * 2^n)` for zero-based retry index `n`;
- arithmetic overflow in backoff calculation clamps to configured maximum without wrapping;
- reaching retry maximum leaves held; it never converts to success.

## 19. Exact price-reference and freshness/timestamp algorithms

### 19.1 Price-grid validity

Before reasonability, the candidate price MUST match current market metadata for the same ticker:

```text
market.ticker == candidate.ticker
price_level_structure = present canonical string
price_ranges = non-empty canonical ordered array of {start,end,step}
```

Revision 02 freezes this exact local validator over the documented interval metadata; it does not infer any additional venue acceptance rule beyond the supplied `price_ranges` values:

1. every `start`, `end`, and `step` parses as exact `OrderPrice`; `Decimal("0") <= start <= end <= Decimal("1.0000")`; `step > 0`;
2. `(end - start) / step` MUST be an exact non-negative integer. No binary floating point, quantization, or tolerance is permitted;
3. ranges MUST be strictly increasing by `start`. For adjacent ranges, `next.start < prior.end` is malformed overlap; `next.start == prior.end` is the only permitted shared-boundary overlap; `next.start > prior.end` is a documented gap and is permitted but prices in the gap are invalid;
4. local containment is inclusive: a range contains candidate `p` iff `start <= p <= end`;
5. the candidate MUST be contained by one or two ranges. Zero containing ranges is invalid. More than two containing ranges is malformed metadata;
6. for **every** containing range, `(p - start) / step` MUST be an exact non-negative integer. Thus a shared boundary is accepted only if both adjacent interval grids agree that the boundary is a valid price;
7. the accepted candidate price is the original exact `OrderPrice`; no snapping, nearest-tick selection, rounding, fallback tick, or inferred cent grid is allowed.

This inclusive shared-boundary rule is an ARB fail-closed local validation convention over current official `price_ranges` metadata, not a claim that undocumented venue endpoint semantics were independently observed. A future official-source contradiction is `OFFICIAL_SOURCE_CONFLICT`, not a reason to silently change the algorithm.

The market-metadata response has its own Section-19.3 freshness stamp and MUST satisfy the same effective market-data age limit as the orderbook reference. Any missing/malformed/conflicting/stale market metadata yields `MARKET_DATA_UNUSABLE` or `MARKET_DATA_STALE`; no static cent-tick fallback exists.

### 19.2 Exact `OrderbookReferenceV1`

When `price_reasonability_required=true`, the only accepted reference source is one validated `Get Market Orderbook`/`orderbook_fp` snapshot for the exact candidate ticker with:

```text
yes_dollars: array of [OrderPriceString, positive ContractQtyString]
no_dollars:  array of [OrderPriceString, positive ContractQtyString]
```

Every level is validated. Each side array MUST be strictly ascending by price, each price level is unique on that side, every count is positive, and every price/count meets Section-6 precision. Malformed, unsorted, duplicate-price, or conflicting data makes the snapshot unusable. Both arrays MUST be non-empty. One-sided or fully empty books are `MARKET_DATA_UNUSABLE`; there is no last-trade, midpoint-of-one-side, prior-snapshot, or synthetic fallback.

Compute exactly:

```text
best_yes_bid = max(yes_dollars.price)
best_no_bid  = max(no_dollars.price)
best_yes_ask = Decimal("1.0000") - best_no_bid
```

If `best_yes_bid > best_yes_ask`, the book is crossed/invalid and unusable. Equality is a valid locked book.

The exact reference is:

```text
reference_yes_price = (best_yes_bid + best_yes_ask) / Decimal("2")
```

No quantization or rounding occurs before comparison. With 4-decimal input levels, the midpoint has no more than 5 decimal places and is within the supported exact internal domain.

Create-V2 candidate `price` is YES-leg quoted for both bid and ask. Therefore:

```text
deviation = abs(candidate_yes_price - reference_yes_price)
pass iff deviation <= max_abs_reference_price_deviation_usd
deny iff deviation >  max_abs_reference_price_deviation_usd
```

If `price_reasonability_required=false`, this reference predicate is skipped; price-grid validity remains mandatory. The deviation config field remains present because the config schema is closed, but it is not evaluated for that candidate.

### 19.3 `FreshnessStampV1`

Every market-data or reconciliation snapshot used for a permit carries an immutable process-local freshness record:

```text
process_instance_id: ProcessInstanceId
received_at_utc: CanonicalTimestamp
received_monotonic_ns: built-in int >= 0
source_timestamp_kind: "NONE" | "VENUE_RFC3339_UTC" | "VENUE_UNIX_MS"
source_timestamp_utc: CanonicalTimestamp | null
snapshot_sha256: Sha256Hex
```

`source_timestamp_utc` is null iff kind is `NONE`. Conversion from a supported venue timestamp to canonical UTC is exact; malformed/missing required provenance makes the source unusable.

For the REST `orderbook_fp` reference, the supported contract does not depend on an embedded exchange snapshot-generation timestamp. Therefore:

```text
source_timestamp_kind = "NONE"
source_timestamp_utc = null
```

and process-local monotonic receipt time controls age.

### 19.4 Authoritative freshness clock by supported source

The freshness authority is exact:

| Source used by risk decision | Age authority | Venue/source timestamp treatment |
|---|---|---|
| `Get Market` metadata / `price_ranges` | local monotonic receipt time | `market.updated_time` may be retained as content provenance but is not snapshot-generation freshness authority |
| `Get Market Orderbook` / `orderbook_fp` | local monotonic receipt time | no embedded venue snapshot-generation timestamp is required; source kind `NONE` |
| complete order/fill reconciliation cycle | local monotonic **cycle completion** time | individual order/fill venue timestamps govern sequencing/evidence consistency where their accepted schemas require them, but do not replace completion time for cycle freshness |
| individual order/fill observation outside a completed reconciliation snapshot | not sufficient by itself to satisfy release/normal reconciliation freshness | its validated venue timestamp remains evidence only |

Thus exchange wall-clock timestamps never make an old local snapshot young. Local monotonic time is the sole age clock for current-process writer/release freshness.

### 19.5 Exact age calculation

For a stamp from the current process:

```text
delta_ns = now_monotonic_ns - received_monotonic_ns
```

If `delta_ns < 0`, classify `CLOCK_REGRESSION` and the input is unusable.

Otherwise integer age is ceiling-rounded:

```text
age_ms = (delta_ns + 999_999) // 1_000_000
```

The effective market-data maximum for a normal candidate is:

```text
market_data_max_age_ms = min(
    per_order.max_market_data_age_ms,
    state_integrity.max_required_market_data_age_ms
)
```

Boundary is exact:

```text
age_ms <= market_data_max_age_ms  => fresh
age_ms >  market_data_max_age_ms  => MARKET_DATA_STALE
```

Thus exactly-equal age passes; one nanosecond beyond an exact millisecond maximum ceiling-rounds to the next millisecond and fails.

### 19.6 Wall/source timestamp sanity

Wall time is a sanity check, not the freshness-age source. Parse canonical UTC timestamps without floating point. For any ordered pair `(later, earlier)`, compute the exact signed UTC duration in integer microseconds `delta_us`. For a positive future delta only, convert with ceiling division:

```text
future_ms(delta_us) = (delta_us + 999) // 1000   when delta_us > 0
future_ms(delta_us) = 0                            when delta_us <= 0
```

For receipt versus evaluation:

```text
receipt_future_us = exact_microseconds(received_at_utc - now_utc)
receipt_future_ms = future_ms(receipt_future_us)
```

If `receipt_future_ms > max_future_wall_clock_skew_ms`, classify `MARKET_DATA_UNUSABLE` or `RECONCILIATION_STALE` as appropriate. Equality passes. No truncation toward zero is permitted.

If a source timestamp exists:

```text
source_future_us = exact_microseconds(source_timestamp_utc - received_at_utc)
source_future_ms = future_ms(source_future_us)
```

and `source_future_ms > max_future_wall_clock_skew_ms` makes the source unusable; equality passes. A source timestamp that is older than receipt never makes the snapshot fresher; monotonic age still controls current-process freshness.

Within one process, every freshness evaluation also compares the newly read monotonic value with the immediately prior monotonic value held by that gate/evaluation chain. Any decrease is `CLOCK_REGRESSION`, even if the resulting age relative to the original receipt would remain non-negative. Wall-clock backward movement within the configured future-skew tolerance does not refresh or extend age and cannot compensate for monotonic regression.

### 19.7 Reconciliation freshness

A complete reconciliation cycle obtains its freshness stamp only after every required page/read is validated and the canonical reconciliation snapshot is finalized. `received_monotonic_ns` therefore means **cycle completion monotonic time** for reconciliation.

Use the same ceiling formula and exact boundary with:

```text
max_age = state_integrity.max_reconciliation_lag_ms
```

Incomplete cycle has no valid stamp and yields `RECONCILIATION_STALE`/unusable.

### 19.8 Duplicate/replayed snapshots

Replaying, re-reading from persistence, or receiving an exact duplicate snapshot does not update its receipt/completion stamp. Only a newly completed source acquisition/reconciliation cycle with a new current-process stamp can establish new freshness.

### 19.9 Restart

Process-local monotonic clocks are not portable across restart. A stamp whose `process_instance_id` differs from the current process is unusable for current freshness, regardless of wall-clock age. Historical bytes remain evidence, but the process must obtain fresh market data and complete fresh reconciliation before release or permit minting.

### 19.10 Permit expiry

At T0, compute each bound input's exact monotonic expiry. `NormalWriterPermit.freshness_deadline_monotonic_ns` is the minimum. Before T1, T2, and T3 append, and immediately before T3 permit consumption, require:

```text
now_monotonic_ns <= freshness_deadline_monotonic_ns
```

If exceeded, invalidate permit and keep transport count zero.

## 20. Order Groups defense-in-depth decision

### 20.1 Decision

Kalshi Order Groups are **supported optional defense in depth**, not a core safety theorem and not mandatory for historical recovery.

A future repeated Demo experiment may choose:

```text
order_group_mode = REQUIRED_FOR_EXPERIMENT
```

If selected, every future normal CREATE MUST include the exact configured `required_order_group_id`, and missing/wrong group identity denies before send.

### 20.2 Membership proof

For required mode:
- configured group ID is part of risk config identity;
- CREATE permit binds the same group ID;
- create request must contain the exact same group ID;
- later group membership may be observed from exact Order Group `orders[]`;
- membership conflict HALTs;
- an order is not treated as group-protected solely because a client intended it to be.

### 20.3 Trigger/reset

Order Group trigger and reset are venue writes not granted by this specification.

A future trigger:
- is defense in depth;
- does not replace per-order local cancellation/reconciliation;
- does not prove every historical unknown belongs to the group;
- does not prove all fills are reconciled;
- does not release writer eligibility.

A future reset:
- is release-like because it allows new orders again;
- must never happen automatically on startup/reconnect;
- requires separate explicit future venue-write capability;
- must be reconciled before local release when group mode requires an active group.

### 20.4 Historical incident exclusion

The historical unresolved CREATE has no exact group-membership proof in the controlling current-state facts. It MUST remain outside every Order Group safety theorem.

### 20.5 Other create flags

`cancel_order_on_pause` may be configured as required defense in depth. Its automatic cancel behavior still requires local order/fill reconciliation.

`reduce_only` receives safety credit only when a future accepted operation-specific rule proves the candidate is strictly risk reducing and the current position used by the venue/local calculation is reconciled. It never bypasses local limits.

`post_only` receives no safety credit under this source binding.

## 21. Startup/restart behavior

### 21.1 Boot sequence

Every process start:

```text
1. state = BOOT_HOLD
2. expose no normal permit and no emergency venue permit
3. open existing authority/ledger only under predecessor rules
4. verify exact path/binding/schema/integrity/hash chain
5. replay complete trusted history
6. reconstruct risk-control projection
7. reconstruct unresolved cancel/action projection
8. reconstruct working-order/fill/unresolved exposure projection
9. bind active risk configuration identity
10. derive held/safe state
11. do not restore WRITER_ELIGIBLE automatically
```

### 21.2 Prior HALT/held state

A prior persistent HALT/HELD condition survives restart. Section 12 controls CASE-A failure/unknown replay and explicitly prohibits restoration from a historical `WRITER_ELIGIBLE` record.

### 21.3 Crash after cancel send boundary

Replay of a `CANCEL_SEND_BOUNDARY_ENTERED` without exact reconciled terminal cancel result produces:
- `cancel_may_have_been_sent = true`;
- `CANCEL_UNRESOLVED`;
- no automatic resend;
- `RECONCILING` or held equivalent until exact venue truth is obtained under separate authorized reads.

### 21.4 Restart after prior writer eligibility

A prior durable `WRITER_ELIGIBLE` record proves only historical release. The new process starts `BOOT_HOLD`, revalidates, reaches at most `SAFE_HELD`, and requires a new explicit durable release before normal writes.

## 22. Release contract

### 22.1 Question C

Release eligibility is true only when all are true in one `RELEASE_ONLY` exclusive session:

1. persistent-ledger integrity PASS;
2. authority/ledger exact binding and equal trusted tail PASS;
3. supported event vocabulary/replay PASS;
4. no unresolved emergency cancel result;
5. every authoritative known active order reconciled;
6. all fills reconciled/deduplicated;
7. zero identity conflicts;
8. conservative exposure finite and within every configured hard limit;
9. complete valid risk config with exact current hash;
10. required market metadata/data fresh under Section 19;
11. reconciliation fresh under Section 19;
12. required venue defense proven when configured;
13. `protected_unresolved_legacy_write_count == 0`;
14. no controlling unresolved write;
15. predecessor writer proof reports release-eligible;
16. current state is `SAFE_HELD` at the same epoch/config;
17. no outstanding normal or emergency permit exists;
18. exact release snapshots/predicate vector are stable through the release sequence.

Any false/unknown value makes release false.

### 22.2 Exact durable release sequence

The only path is:

```text
acquire RELEASE_ONLY with rs_ session
→ replay/revalidate all predicates
→ state must already be SAFE_HELD
→ append/anchor/readback RISK_RELEASE_RECORDED (Section 7.10)
→ re-read tails and revalidate every predicate + freshness
→ append/anchor/readback existing WRITER_PROOF_RELEASED
   under the exact Section-9.5 restricted admission rule
→ revalidate state/config/epoch/tails and no outstanding permits
→ append/anchor/readback RISK_CONTROL_STATE_CHANGED
   SAFE_HELD → WRITER_ELIGIBLE
   cause = DURABLE_RELEASE_COMPLETED
   related_release_id = exact release_id
→ append/anchor/readback RESTRICTED_SESSION_ENDED
→ close locks
```

`RISK_RELEASE_RECORDED` alone cannot release proof or writer eligibility. `WRITER_PROOF_RELEASED` alone cannot move state. The final state transition cannot occur without both prior events and all predicates remaining true.

A failure/unknown authority commit at any step stops the sequence. Reopen/replay determines the trusted prefix; no missing later step is assumed complete. A partially completed release never reconstructs a `NormalWriterPermit`.

### 22.3 Current historical state

Current evidence has:

```text
unknown_result = true
writer_proof_state = HELD
writer_proof_release_eligible = false
protected_unresolved_legacy_write_count = 1
historical_unresolved_exposure = UNKNOWN_UNBOUNDED
```

Therefore the current state cannot satisfy the release vector. Revision 02 creates no alternate release route.

## 23. Current historical incident treatment

For exactly:

```text
incident_id = KALSHI_DEMO_ONE_ORDER_LIFECYCLE_EXECUTION_01
bound_order_id = null
```

the required result is:

```text
normal_write_eligible = false
authoritative_cancel_target_for_historical_incident = NONE
historical_incident_cancel_target = NONE
historical_incident_writer_release_eligible = false
emergency_cancel_target = NONE
release_eligible = false
historical_unresolved_exposure = UNKNOWN_UNBOUNDED
```

The emergency layer MUST NOT:
- guess an order ID;
- fuzzy-match recent orders by ticker/price/time/quantity;
- substitute `client_order_id` for the required venue `order_id`;
- cancel all account orders hoping to include it;
- infer nonexistence from an empty live-order result;
- infer safe retry;
- bind a discovered candidate order by similarity;
- infer group membership;
- release writer proof because no cancel target is available.

If no other exact active order is known and no emergency cancel is in flight, the correct future risk-control projection for this historical condition is `QUIESCENT_HELD`, not `SAFE_HELD` or `WRITER_ELIGIBLE`.

## 24. Failure/stop classifications

### 24.1 Specification-preparation stop classifications

```text
CANONICAL_BASE_MISMATCH
CANONICAL_TREE_MISMATCH
CANONICAL_PARENT_MISMATCH
BLOCKED_PREDECESSOR_IDENTITY_MISMATCH
HALT_OWNERSHIP_CONTRACT_UNRESOLVED
NORMAL_TO_EMERGENCY_LOCK_HANDOFF_UNRESOLVED
NORMAL_WRITER_SESSION_CLOSE_SEMANTICS_UNRESOLVED
HALT_AUTHORITY_FAILURE_RECOVERY_UNRESOLVED
NORMAL_WRITER_PERMIT_HALT_INTERACTION_UNRESOLVED
PERSISTENT_LEDGER_COMPATIBILITY_UNRESOLVED
UNRESOLVED_WRITE_SEMANTIC_REGRESSION
TASK_SCOPE_AMBIGUOUS
```

No Revision-03 stop condition was observed during specification preparation. The Revision-02 event/session/permit/economic/source contracts were not reopened beyond the exact HALT-ownership cross-references in this correction.

### 24.2 Future runtime failure classifications

The future implementation uses deterministic secret-safe classifications including:

```text
RISK_LIMIT_CONFIG_MISSING
RISK_LIMIT_CONFIG_INVALID
RISK_NUMERIC_RANGE_UNSUPPORTED
RISK_INPUT_UNAVAILABLE
RISK_STATE_TRANSITION_INVALID
RISK_STATE_UNKNOWN
RISK_LIMIT_EXCEEDED
RISK_RATE_LIMIT_EXCEEDED
MARKET_DATA_UNUSABLE
MARKET_DATA_STALE
RECONCILIATION_STALE
CLOCK_REGRESSION
IDENTITY_CONFLICT
UNKNOWN_UNBOUNDED_EXPOSURE
EVENT_SCHEMA_CONTRACT_VIOLATION
EVENT_REQUIRED_REFERENCE_INVALID
EVENT_ID_CONTENT_CONFLICT
RESTRICTED_SESSION_EVENT_NOT_PERMITTED
RESTRICTED_SESSION_STATE_CONFLICT
NORMAL_WRITER_PERMIT_INVALID
NORMAL_WRITER_PERMIT_UNEXPECTED_TAIL
NORMAL_WRITER_PERMIT_STAGE_MISMATCH
NORMAL_WRITER_PERMIT_EXPIRED
NORMAL_WRITER_PERMIT_ALREADY_CONSUMED
EMERGENCY_ACTION_DUPLICATE_CONFLICT
EMERGENCY_TARGET_NOT_AUTHORITATIVE
EMERGENCY_TARGET_NOT_ACTIVE
EMERGENCY_CANCEL_CAPACITY_UNAVAILABLE
CANCEL_ATTEMPT_PREDECESSOR_INVALID
CANCEL_SEND_RESULT_UNKNOWN
CANCEL_RESULT_EVIDENCE_CONFLICT
CANCEL_RESULT_REVISION_CONFLICT
CANCEL_UNRESOLVED
ORDER_GROUP_PROOF_MISSING
ORDER_GROUP_RESET_NOT_AUTHORIZED
RELEASE_PREDICATE_FAILED
RELEASE_PREDICATE_CHANGED
PERSISTENT_LEDGER_INTEGRITY_FAILURE
AUTHORITY_LEDGER_ANCHOR_FAILURE
HALT_PERSISTENCE_FAILED
HALT_AUTHORITY_RESULT_UNKNOWN
HALT_SESSION_END_NOT_TRUSTED
NORMAL_TO_EMERGENCY_LOCK_HANDOFF_BLOCKED
```

A runtime integrity/schema/hash/session/reference conflict cannot be downgraded to an ordinary limit deny; it is held/halted according to the state machine. All logs/exports are secret-safe under predecessor rules.

## 25. Deterministic future implementation path envelope

### 25.1 Exact proposed writable paths

No implementation is performed by this artifact. The smallest future implementation envelope remains the exact Revision-02 set; Revision 03 changes responsibilities only inside that existing path envelope:

**Modify existing:**

```text
src/arb/execution_ledger.py
src/arb/venues/kalshi/ledger_binding.py
src/arb/venues/kalshi/order_lifecycle.py
tests/test_execution_ledger.py
tests/test_kalshi_ledger_binding.py
tests/test_kalshi_one_order_lifecycle.py
```

**Add:**

```text
src/arb/venues/kalshi/risk_control.py
src/arb/venues/kalshi/emergency_cancel.py
tests/test_kalshi_risk_control.py
tests/test_kalshi_emergency_cancel.py
```

No other repository path is writable under the first future implementation contract unless a later implementation task explicitly changes the envelope.

### 25.2 Readable protected dependencies

Canonical dependencies may be read/imported but remain protected unless separately writable, including:

```text
src/arb/venues/kalshi/models.py
src/arb/venues/kalshi/validation.py
src/arb/venues/kalshi/serialization.py
src/arb/venues/kalshi/errors.py
src/arb/venues/kalshi/orderbook.py
src/arb/venues/kalshi/connectivity.py
src/arb/venues/kalshi/write_result_reconciliation.py
pyproject.toml
```

Use exact canonical versions from the required base; do not fabricate stand-ins when repository synchronization is available.

### 25.3 Exact responsibility mapping

| Path | Required responsibility |
|---|---|
| `execution_ledger.py` | preserve Revision-02 four-mode/event/session extension; enforce ownership-sensitive `RISK_CONTROL_STATE_CHANGED` admission, clean-vs-abandoned session semantics, and authority-anchored replay without SQL changes |
| `ledger_binding.py` | preserve narrow emergency/release handles; prohibit restricted acquisition while a live normal owner holds stores; require fresh acquisition after normal lock release; no in-place handle conversion or generic append escape |
| `order_lifecycle.py` | preserve exact normal permit T0→T3 flow and add hard-HALT gate synchronization so not-entered transports are invalidated, already-entered transport is never repeated, and live `ws_` HALT/clean-end occurs before lock release |
| `risk_control.py` | preserve Revision-02 risk/economic/reference/freshness logic; own the process-private hard-HALT latch, atomic permit invalidation/adapter-entry arbitration, and ownership-sensitive state transition request |
| `emergency_cancel.py` | exact target planner, prepared cancel request identity, `EmergencyCancelPermit`, bounded emergency lane, cancel result reconciliation integration; cancel-only transport surface |
| tests | exact offline conformance/fault/race/precision/replay tests in Section 26 |

### 25.4 Projection additions

Without SQL structural change, replay adds in-memory projections for:

```text
risk_control_state
risk_state_epoch
active_risk_config_sha256
restricted_sessions_by_id_and_mode
active_restricted_session_id
abnormal_restricted_session_ids
emergency_actions_by_id
cancel_attempts_by_id
cancel_send_may_have_been_sent_by_attempt
cancel_result_revision_by_attempt
release_records_by_id
```

Existing projections remain unchanged for historical events. Existing `ORDER_OBSERVED`, `FILL_OBSERVED`, `RECONCILIATION_RECORDED`, and writer-proof projections continue to represent the same data independent of whether a newer event was validly produced under an ordinary or explicitly permitted restricted session.

### 25.5 No structural migration

```text
AUTHORITY_SCHEMA_REVISION = 1
LEDGER_SCHEMA_REVISION = 1
EVENT_SCHEMA_REVISION = 1
sqlite_structural_migration_required = false
```

No DB deletion/recreation, row rewrite, event backfill, new durability store, or authority reset is permitted.

## 26. Mandatory offline test matrix

No tests are executed by this specification. A future implementation MUST provide deterministic offline fakes/mocks only and cover at least:

### Persistent halt/restart

1. persisted `HALTED` → restart → still held;
2. unresolved-write-held → restart → normal writer unavailable;
3. reconnect does not restore eligibility;
4. strategy restart does not restore eligibility;
5. reset API cannot bypass durable release.

### Pre-trade risk

6. missing required size limit → deny;
7. exact boundary limit → pass comparison deterministically;
8. above order/exposure limit → deny before send boundary;
9. stale required data → deny;
10. CREATE rate exceeded → deny;
11. known working orders count toward exposure;
12. unresolved exposure counts toward risk, including `UNKNOWN_UNBOUNDED`;
13. direct strategy adapter-write bypass impossible.

### Emergency targets

14. exact authoritative active `order_id` → cancel eligible;
15. `order_id=null` → no cancel generated;
16. mixed known + unresolved set → only known exact IDs targeted;
17. duplicate exact target → one logical cancel;
18. conflicting identity evidence → HALT, no guess.

### Cancellation races

19. clean cancel;
20. partial fill then cancel remainder;
21. full fill before cancel;
22. cancel timeout after send boundary → unresolved;
23. cancel response lost → unresolved;
24. truth read temporarily unavailable → unresolved/held;
25. duplicate cancel observation → idempotent;
26. mixed batch results → per-order outcomes;
27. crash after cancel send boundary → no blind resend; reconcile first.

### Emergency lane

28. HALT durable before first cancel send;
29. normal rate budget exhausted but bounded emergency local lane available;
30. emergency capability cannot CREATE/MODIFY/REPLACE/DECREASE;
31. emergency path respects retry/concurrency bounds and cannot retry storm.

### Order Groups when `REQUIRED_FOR_EXPERIMENT`

32. exact required group membership/config;
33. missing/wrong group blocks CREATE;
34. triggered group does not restore writer;
35. restart never auto-resets;
36. trigger ambiguity does not imply safe;
37. historical unresolved order remains outside group theorem absent proof.

### Release

38. no known active orders + unresolved legacy write → `QUIESCENT_HELD`;
39. cancel unresolved → no release;
40. fills unreconciled → no release;
41. stale required data → no release;
42. required limit absent → no release;
43. ledger corruption → no release;
44. all predicates pass but no durable release → `SAFE_HELD`;
45. durable release + every predicate pass → `WRITER_ELIGIBLE`.

### Additional mandatory edge tests

46. HALT ledger commit succeeds but authority anchor fails → no cancel send;
47. cancel intent persists but send boundary does not → transport invocation count zero;
48. cancel boundary persists then process dies before transport mock records call → restart treats send as possibly sent;
49. cancel boundary/response persists but authority tail is behind → catch-forward-only predecessor rules, no unsafe release;
50. configuration hash changes while a normal permit exists → permit invalid;
51. risk state epoch changes while emergency permit exists → permit invalid;
52. Decimal exact-equality boundary; no binary-float coercion;
53. NaN/Infinity/exponent/malformed Decimal rejects;
54. missing emergency lane config → no automatic cancel send, held;
55. exchange-pause fake denies cancel transport → remain held, no assumption of auto-cancel;
56. `cancel_order_on_pause=true` observation does not itself mark cancel reconciled;
57. `post_only` cannot satisfy any hard safety predicate;
58. Order Group reset fake success does not create writer eligibility;
59. prior `WRITER_ELIGIBLE` → process restart → `BOOT_HOLD`/`SAFE_HELD`, explicit release required again;
60. batch transport ambiguity marks every potentially sent member unresolved.

Tests 26 and 60 preserve the Revision-01 batch safety scenarios. Under Revision 02's first implementation, which prohibits batch transport, they are satisfied by (a) proving the batch transport entry point is absent/rejected and (b) exercising the same per-target mixed/unresolved classifier semantics over a synthetic multi-target emergency wave. If a later specification introduces an exact batch send-boundary event, those tests additionally become direct batch-transport conformance tests; Revision 02 does not pre-authorize that extension.

### Revision-02 Correction-01 exact-event-schema tests

For **each of the nine new event types** in Section 7, parameterized offline tests MUST prove:

- exact valid envelope+payload accepted;
- each required payload key independently removed → reject;
- one arbitrary extra payload key → reject;
- each field independently supplied with wrong exact built-in type → reject;
- malformed ID/hash/timestamp/Decimal lexical value → reject;
- every nullable field accepts null only in its specified branch and rejects null otherwise;
- invalid parent/reference event type, content, hash, or ordering → reject;
- invalid state/session transition → reject;
- deterministic replay projection equals the specified effect;
- exact event-ID/core retry → `IDEMPOTENT_DUPLICATE`, no tail movement;
- same event ID with one changed byte/field/time → `EVENT_ID_CONTENT_CONFLICT`;
- secret-denylist key/value → reject before persistence.

Additional class-specific tests MUST cover every `RISK_CONTROL_STATE_CHANGED` transition/cause pair; action target-set hash/EMPTY rule; contiguous cancel ordinals; cancel boundary predecessor-tail/deadline identity; all six cancel result class predicates and result revisions; all 19 release predicates and predicate hash; restricted start/end/abandon lifecycle.

### Revision-02 Correction-02 restricted-session compatibility tests

Require:

1. the exact current imported 3-event ledger with proof `HELD` still returns no `NORMAL_WRITER`;
2. `EMERGENCY_CONTROL_ONLY` starts `rs_` session only and never `ws_`;
3. `RELEASE_ONLY` starts `rs_` session only and never `ws_`;
4. emergency mode can append only its Section-9.4 exact surface;
5. release mode can append only its Section-9.5 exact surface;
6. both handles expose no public `append_batch` and no generic append;
7. both handles expose no generic venue transport;
8. emergency mode cannot append ordinary intent/prepared/write-boundary, identity-bound, proof-release, or release events;
9. release mode cannot append cancel/intent/boundary/emergency action or venue operations;
10. emergency `ORDER_OBSERVED`, `FILL_OBSERVED`, `RECONCILIATION_RECORDED` replay exactly into existing projections without altering their payload schemas;
11. `WRITER_PROOF_RELEASED` is rejected in release mode without exact prior release record and predecessor prerequisites;
12. clean restricted end is anchored before lock close;
13. crash with open restricted session + fresh exclusive reopen produces one deterministic abandonment before replacement start;
14. abandonment never closes a trusted cancel send result;
15. simultaneous normal/restricted or restricted/restricted acquisition is fail-closed;
16. all historical existing session/event bytes and replay results are unchanged;
17. an old binary presented with a new event fails unsupported-event closed rather than interpreting it;
18. a crashed/unended ordinary `ws_` session followed by fresh restricted exclusive acquisition gets exactly one existing-schema `WRITER_SESSION_ABANDONED`, no new `WRITER_SESSION_STARTED`, then the requested `rs_` start; transport remains absent during cleanup.

### Revision-02 Correction-03 `NormalWriterPermit` progression tests

Require deterministic fake-clock/fake-tail tests proving:

1. T0 candidate risk assessment + one permit under already-held normal acquisition;
2. exact expected T0→T1 intent append remains valid;
3. exact expected T1→T2 prepared append remains valid;
4. exact expected T2→T3 send-boundary append remains valid;
5. transport count is zero before T3 authority+ledger readback and exactly one only afterward;
6. unrelated tail movement inserted before T1, before T2, and before T3 independently invalidates;
7. wrong stage event type/content/event ID/previous hash/successor hash independently invalidates;
8. risk-config hash change invalidates;
9. risk-state epoch/state change invalidates;
10. market-data snapshot identity change invalidates;
11. reconciliation snapshot identity change invalidates;
12. freshness expiry before each stage independently invalidates;
13. monotonic clock regression invalidates;
14. normal writer-session loss/abandonment invalidates;
15. process restart/process-instance change invalidates and no permit reconstructs;
16. second permit use/second adapter invocation rejected;
17. ledger append failure before any stage prevents transport;
18. authority advancement failure and commit-result-unknown at T1/T2/T3 prevent transport;
19. reopen after a ledger-ahead T3 never blind-resends the old request;
20. the immutable permit object is byte/field-identical across T0→T3 while only the private progress record advances;
21. each stage chooses one canonical `recorded_at_utc`, computes the expected event/hash before append, persists that same exact EventInput, and rejects any timestamp/core substitution.

### Revision-02 Correction-04 economic/reference/freshness tests

Use synthetic values only and exact `Decimal`; require:

1. filled bid/YES lot exposure `q*p`;
2. filled ask/NO lot exposure `q*(1-p)`;
3. opposite fill FIFO closes oldest opposite lots exactly;
4. excess opposite fill opens new-direction lot;
5. zero open position exposure exactly zero;
6. resting bid full remaining exposure;
7. resting ask full remaining exposure;
8. partial fill moves filled delta to FIFO and only latest remaining stays in working exposure;
9. candidate bid projected exposure;
10. candidate ask projected exposure;
11. candidate counted before every per-order/per-market/account comparison;
12. exact configured maximum equality passes;
13. one supported Decimal quantum above maximum denies;
14. absent/conflicting direction/price/remaining/provenance → `UNKNOWN_UNBOUNDED`;
15. opposing working orders do not offset gross exposure;
16. current position does not reduce a working order's standalone contribution;
17. no cross-market netting;
18. signed-net `max(abs(q+B+cb),abs(q-A-ca))` exact cases;
19. unresolved finite bound only with complete durable economic proof;
20. current historical unresolved state remains `UNKNOWN_UNBOUNDED`;
21. exact price-grid membership at start/end/tick boundaries;
22. off-grid price rejects;
23. both-sided book computes exact best bid/ask/midpoint;
24. locked book valid;
25. crossed book unusable;
26. YES side empty unusable;
27. NO side empty unusable;
28. both sides empty unusable;
29. price deviation exactly equal maximum passes;
30. one exact supported quantum above deviation maximum denies;
31. `price_reasonability_required=false` skips midpoint only, not price-grid validation;
32. age exactly at max passes;
33. one nanosecond beyond exact max ceiling-rounds stale;
34. negative monotonic delta → `CLOCK_REGRESSION`;
35. wall receipt too far in future unusable;
36. venue source timestamp too far ahead of receipt unusable;
37. duplicate/replayed snapshot does not refresh receipt time;
38. prior-process freshness stamp unusable after restart;
39. incomplete reconciliation has no valid freshness stamp;
40. binary float at any economic boundary rejects;
41. NaN/Infinity/exponent textual economic value rejects;
42. unsupported precision/range denies without rounding preference;
43. adjacent `price_ranges` sharing exactly one boundary are accepted only when that boundary is grid-valid under both containing ranges;
44. true interval overlap (`next.start < prior.end`), more than two containing ranges, or a shared boundary invalid under either adjacent grid makes metadata unusable;
45. receipt/source future skew exactly equal to `max_future_wall_clock_skew_ms` passes, while the smallest positive microsecond delta that ceiling-rounds to the next millisecond fails;
46. a monotonic read lower than the immediately prior read in the same evaluation/permit chain yields `CLOCK_REGRESSION` even if age relative to original receipt is non-negative.


### Revision-03 focused HALT-ownership tests

Preserve every Revision-02 mandatory test. Add exactly these focused ownership tests:

**HALT-OWN-01 — live normal owner persists HALT**

Setup: active `NORMAL_WRITER ws_` owns both locks; state `WRITER_ELIGIBLE`; valid unused normal permit exists. Inject `HARD_SAFETY_VIOLATION`.

Required: permit/progress invalidated before transport entry; restricted acquisition count remains zero; current `ws_` appends exact `WRITER_ELIGIBLE→HALTED/HARD_SAFETY_VIOLATION`; HALT ledger commit and authority+ledger readback succeed; normal transport count remains zero; PASS only after trusted HALT.

**HALT-OWN-02 — restricted constructor not invoked early**

Instrument the restricted acquisition constructor/call. While the live `ws_` owns stores, and before trusted HALT + trusted clean end + handle close/lock release, `EMERGENCY_CONTROL_ONLY` acquisition count MUST equal `0`. The first restricted acquisition may occur only after exact release.

**HALT-OWN-03 — exact successful ownership sequence**

Assert the trace is exactly:

```text
ws_ RISK_CONTROL_STATE_CHANGED(WRITER_ELIGIBLE→HALTED)
→ HALT authority+ledger readback
→ ws_ WRITER_SESSION_ENDED
→ end authority+ledger readback
→ normal handle close / locks released
→ EMERGENCY_CONTROL_ONLY fresh acquire
→ RESTRICTED_SESSION_STARTED(rs_)
```

No duplicate HALT and no `WRITER_SESSION_ABANDONED` on the live-success path.

**HALT-OWN-04 — HALT ledger failure before COMMIT**

Inject pre-commit failure. Require: permit invalid; no normal transport; no emergency transport; no restricted acquisition while locks are still normal-owned; no trusted-HALT claim; restart remains fail closed.

**HALT-OWN-05 — HALT ledger COMMIT + definite authority failure**

Require: no transport; handle closes; fresh replay detects valid ledger-ahead state; exact predecessor catch-forward only; no duplicate HALT; no automatic writer restoration; trusted HALT only after positive catch-forward/readback.

**HALT-OWN-06 — HALT authority commit result unknown**

Require: no transport; current handle closes; fresh reopen derives `EQUAL` or `LEDGER_AHEAD` only from durable data; no duplicate HALT; no automatic writer restoration; no assumption that HALT was absent.

**HALT-OWN-07 — no live normal owner**

Require: `EMERGENCY_CONTROL_ONLY` may acquire authority-first/ledger-second directly; stale prior sessions may be cleaned only under fresh-lock proof; exact `rs_` session starts; a required valid held/HALT transition may persist under Section 9.3; no normal writer session is created.

**HALT-OWN-08 — trusted normal send boundary before hard violation**

Setup: normal write send boundary is trusted and adapter transport outcome is ambiguous/already entered. Require: HALT persists; ambiguous write remains ambiguous; no `NO_SEND_PROVEN`; no blind resend; reconciliation remains required; no second transport invocation.

**HALT-OWN-09 — invalidated permit cannot cross ownership boundary**

After successful CASE A and later `rs_` acquisition, require: prior `NormalWriterPermit`/progress remains invalid or absent; cannot be reconstructed; no strategy normal transport exists; emergency handle remains exact cancel/control-only; no object/lock/session conversion path exists.

Additional deterministic race coverage MUST prove the adapter-entry mutex/latch has only two outcomes: either one transport entry atomically wins before hard-HALT latching, or hard-HALT latching invalidates the permit before transport. No interleaving may produce a second invocation or a transport entry after the latch.

## 27. Future bounded Demo validation prerequisites

Acceptance/implementation of this risk layer does NOT authorize venue execution.

Before any future repeated Demo write experiment, all of the following are prerequisites:

1. this specification is accepted as the controlling technical contract;
2. an implementation is separately authorized, accepted and installed;
3. the exact implementation commit/tree and writable-path set are verified;
4. persistent risk/halt/restart and cancellation crash boundaries pass the full offline matrix;
5. current historical unresolved-write policy remains satisfied; no alternate release path exists;
6. all mandatory risk-limit configuration values are explicitly accepted;
7. current official Kalshi operation/source semantics are freshly bound at implementation/execution time;
8. any required Order Group state is proven under separate authorized venue reads/writes;
9. exact environment separation remains Demo-only;
10. a separate explicit bounded Demo venue-write authorization names exact permitted operations, targets, request budget and credentials;
11. the historical incident remains non-cancelable unless an exact authoritative venue `order_id` is later proven through an accepted reconciliation contract.

A future Demo cancellation is not implied by this specification.

## 28. Explicitly prohibited inferences and unsafe patterns

A conforming implementation MUST explicitly reject:

```text
GET orders empty → no historical order existed
startup → cancel_all
reconnect → cancel_all
fuzzy ticker/time/price/quantity cancellation matching
guessed venue order_id
client_order_id substitution for cancel target
strategy-visible risk bypass
restart → ACTIVE/WRITER_ELIGIBLE
send-then-cancel as pre-trade control
normal throttling may starve emergency cancel
cancel response → SAFE_HELD
batch response → SAFE_HELD
disconnect → orders canceled
Order Group trigger → all uncertainty resolved
Order Group reset on startup/reconnect
filled inventory alone = complete exposure
reconnect loop → strategy writes restored
no known cancel target → safe to write
no known cancel target → writer proof released
canceling other orders → historical unresolved exposure becomes zero
```

## 29. Acceptance criteria

The specification is technically implementable only if a reviewer can map it without chat-history inference to concrete code/tests and answer YES to all:

1. canonical main/tree/parent are exact;
2. predecessor and current-state identities are explicit;
3. two-store ledger invariants remain intact;
4. current historical unresolved incident remains unresolved and non-cancelable;
5. Question A/B/C are structurally separate;
6. normal strategy cannot bypass the risk gate through supported API;
7. emergency persistent mutation does not require normal writer capability;
8. emergency venue capability is cancel-only and target-scoped;
9. release capability is distinct and venue-transport-free;
10. HALT is durably anchored before first cancel send boundary;
11. exact target eligibility is unambiguous;
12. cancel crash ambiguity never causes blind resend;
13. fill/cancel races have deterministic result classes;
14. batch behavior is per-target and non-atomic;
15. emergency lane is locally reserved but bounded and does not falsely promise venue capacity;
16. every risk-limit family has exact units, missing behavior, comparison boundaries and persistence;
17. Decimal/fixed-point behavior is exact and binary float is prohibited;
18. unresolved exposure can become `UNKNOWN_UNBOUNDED` and fails closed;
19. stale data/reconciliation freshness are exact;
20. startup/reconnect never auto-restores writer;
21. Order Groups are defense in depth only;
22. explicit durable release cannot bypass predecessor writer-proof hold;
23. existing SQLite schema revision remains unchanged;
24. future writable/readable path envelope is exact;
25. mandatory offline tests are measurable;
26. no Demo/production venue execution is authorized by this artifact.
27. all nine new event schemas are closed, exact-type, exact-reference, idempotency-defined, and replay-defined;
28. restricted sessions use `rs_` identities and cannot become ordinary writer sessions;
29. every existing event admitted under restricted mode is mode-gated without changing its historical payload schema;
30. `NormalWriterPermit` accepts only its own exact T0→T1→T2→T3 successor chain and unrelated tail movement invalidates it;
31. transport remains impossible until T3 authority+ledger readback;
32. binary-contract exposure formulas are unique and Decimal-only;
33. price-grid/reference selection is algorithmic with no one-sided fallback;
34. freshness uses exact process-local monotonic ceiling-ms semantics and restart invalidates old freshness;
35. no SQLite structural migration is required.
36. a hard violation detected under a live normal `ws_` never attempts restricted acquisition before the current `ws_` persists/read-backs HALT, cleanly ends, and releases its locks;
37. the live-success path uses `WRITER_SESSION_ENDED`, while `WRITER_SESSION_ABANDONED` is reserved for fresh-reopen proof that a prior session no longer owns the stores;
38. hard-HALT permit invalidation is atomic with adapter-entry arbitration: not-entered transports are blocked, already-entered transports are never repeated, and ambiguity is preserved;
39. ledger-ahead/authority-unknown HALT recovery uses predecessor reopen/catch-forward rules without duplicate HALT or writer restoration;
40. a later emergency `rs_` acquisition replays trusted HALT and cannot convert or reuse the prior `ws_` handle/locks/permits.

## 30. Requirement-to-evidence matrix

### 30.1 Load-bearing RISK invariants

| Requirement | Normative requirement | Future implementation surface | Required test/evidence | Failure/held behavior |
|---|---|---|---|---|
| RISK-01 | All normal venue writes pass through a non-bypassable risk/writer gate. | `risk_control.py`, `order_lifecycle.py` | tests 8, 13 | deny before send |
| RISK-02 | Any unsafe, unknown, stale, corrupt, incomplete, or unresolved controlling state makes risk-increasing writer eligibility false. | risk evaluator + ledger replay | tests 2, 9, 12, 39-43 | deny/hold |
| RISK-03 | HALT is durably persisted and survives restart. | ledger events/projection | tests 1, 46 | held |
| RISK-04 | HALT becomes durable before the first emergency cancellation send boundary. | ledger + emergency cancel gate | tests 28, 46 | no cancel if not anchored |
| RISK-05 | Emergency cancellation targets only authoritative exact venue `order_id` values. | ledger binding + emergency target planner | tests 14-18 | no guess |
| RISK-06 | Unresolved write with no bound `order_id` is never canceled, retried, replaced, amended, decreased, rebound by inference, or otherwise acted upon. | ledger binding/risk projection | tests 15, 16, 37, 38 | QUIESCENT_HELD |
| RISK-07 | Risk usage includes reconciled fills, worst-case authoritative working orders, and conservative unresolved-write upper bounds. | exposure projection | tests 11, 12 | unknown/limit deny |
| RISK-08 | Missing required risk limits means DENY, not unlimited. | config validator | tests 6, 42 | deny |
| RISK-09 | Stale/unusable required market data blocks every dependent write. | freshness evaluator | tests 9, 41 | deny |
| RISK-10 | Emergency cancellation has reserved bounded local execution capacity that normal throttling cannot consume. | emergency rate lane | tests 29, 31, 54 | held if unavailable |
| RISK-11 | Every cancellation operation has durable identity and crash/restart semantics. | action/attempt events | tests 17, 22, 23, 27, 47-49 | reconcile |
| RISK-12 | Cancellation acknowledgement is not reconciled safe state. | cancel classifier/reconciler | tests 19-27 | RECONCILING |
| RISK-13 | Resulting fills and terminal order states reconcile before emergency action completion. | order/fill reconciliation | tests 19-27, 40 | no release |
| RISK-14 | Restart/reconnect/timers/API recovery/strategy init/venue reachability cannot restore normal writer eligibility. | state machine | tests 1-5, 59 | held |
| RISK-15 | Writer re-enable requires a distinct durable release after every safety predicate passes. | `RELEASE_ONLY`, release events | tests 44, 45, 59 | SAFE_HELD |
| RISK-16 | Order Groups, if adopted, are defense in depth and do not replace local ledger/risk/reconciliation truth. | group policy | tests 32-37, 58 | held |
| RISK-17 | Nothing authoritative remains to cancel is distinct from safe to resume. | state machine/release | test 38 | QUIESCENT_HELD |
| RISK-18 | `QUIESCENT_HELD` is a valid persistent state when quiet but unresolved. | state projection | tests 38, 54, 55 | writer false |

### 30.2 Additional specification requirements

| ID | Requirement | Code location | Test/evidence |
|---|---|---|---|
| ER-CAP-001 | `EMERGENCY_CONTROL_ONLY` cannot expose venue transport. | `execution_ledger.py`, `ledger_binding.py` | test 30 + API surface inspection |
| ER-CAP-002 | `EmergencyCancelPermit` is exact-target, one-shot, process-local and epoch-bound. | `risk_control.py`, `emergency_cancel.py` | tests 17, 51 |
| ER-CAP-003 | `RELEASE_ONLY` cannot cancel/create and cannot bypass writer-proof release rules. | `execution_ledger.py`, `ledger_binding.py` | tests 5, 44, 45 |
| ER-NUM-001 | Economic values are exact Decimal; binary float prohibited. | config/exposure/parsers | tests 52, 53 |
| ER-LIMIT-001 | All mandatory limit fields explicit; no numeric defaults. | `risk_control.py` | tests 6, 42, 54 |
| ER-LIMIT-002 | Exact maximum boundary is `<=` pass, `>` deny. | `risk_control.py` | tests 7, 8 |
| ER-FLOW-001 | Sliding-window sends survive restart through durable history. | ledger/risk projection | tests 10, 59 |
| ER-DATA-001 | Data age/reconciliation lag use Section-19 exact monotonic ceiling-ms rules; stale is fail-closed. | `risk_control.py` | tests 9, 41 + Correction-04 32-39 |
| ER-HALT-001 | HALT commit + authority readback precedes emergency send permit. | ledger/emergency gate | tests 28, 46 + HALT-OWN-01 |
| ER-HALT-002 | A live normal `ws_` that owns both stores is the sole owner of `WRITER_ELIGIBLE→HALTED/HARD_SAFETY_VIOLATION`; no restricted acquire may occur before its clean end and lock release. | `risk_control.py`, `execution_ledger.py`, `ledger_binding.py` | HALT-OWN-01/02/03 |
| ER-HALT-003 | Hard-HALT latching atomically invalidates all not-entered normal permits against adapter entry; already-entered transport is never repeated and remains reconcilable. | `risk_control.py`, `order_lifecycle.py` | HALT-OWN-01/08/09 + race coverage |
| ER-HALT-004 | HALT ledger-ahead/authority-unknown recovery closes and reopens under predecessor rules, catches forward only when proven, and never duplicates HALT/restores writer. | `execution_ledger.py` | HALT-OWN-04/05/06 |
| ER-HALT-005 | Live successful normal shutdown uses `WRITER_SESSION_ENDED`; `WRITER_SESSION_ABANDONED` is fresh-reopen cleanup only. | `execution_ledger.py`, `ledger_binding.py` | HALT-OWN-03/07 |
| ER-CAN-001 | Cancel target is exact path `order_id`; no client-ID substitution. | `emergency_cancel.py` | tests 14-18 |
| ER-CAN-002 | Send-boundary crash means may-have-been-sent; no blind resend. | ledger/emergency replay | tests 22, 23, 27, 48 |
| ER-REC-001 | Fill dedupe/conflict is exact and economic truth follows fills. | reconciliation integration | tests 20, 21, 25, 40 |
| ER-BATCH-001 | Batch is optional, per-target, and non-atomic for safety. | `emergency_cancel.py` | tests 26, 60 |
| ER-OG-001 | Required experiment group ID, if configured, is permit/request-bound. | `risk_control.py`, `order_lifecycle.py` | tests 32, 33 |
| ER-OG-002 | Trigger/reset do not release local writer. | `risk_control.py` | tests 34-36, 58 |
| ER-RESTART-001 | Prior writer eligibility is not auto-restored on restart. | state machine/replay | test 59 |
| ER-REL-001 | Release sequence uses exact `RELEASE_ONLY` restricted session: `RISK_RELEASE_RECORDED` → predecessor `WRITER_PROOF_RELEASED` → state transition. | ledger + binding | tests 44, 45 + Correction-02 11 |
| ER-HIST-001 | Current incident target is NONE and release false. | `ledger_binding.py` | tests 15, 37, 38 |
| ER-SCHEMA-001 | SQLite authority/ledger schema revisions remain 1; no migration. | `execution_ledger.py` | file/schema identity tests |
| ER-SOURCE-001 | Future implementation refreshes current official source binding before venue-capable acceptance. | source-binding constants/record | deterministic source identity evidence |
| ER-DEMO-001 | Spec/implementation acceptance alone does not grant venue execution. | handoff/evidence contract | review of capability matrix |
| ER-EVT-001 | Every new event has an exact closed envelope/payload/reference/replay/idempotency contract. | `execution_ledger.py` | Correction-01 parameterized schema suite |
| ER-SESS-001 | Restricted `rs_` sessions are mode-distinct from ordinary `ws_` sessions and mutually exclusive under same locks. | `execution_ledger.py`, `ledger_binding.py` | Correction-02 tests 1-18 |
| ER-SESS-002 | Emergency/release handles expose no generic append/transport and only exact mode event surfaces. | `ledger_binding.py` | API-surface + negative tests |
| ER-PERMIT-001 | Normal permit remains valid only through its own exact expected T0→T3 successor chain. | `risk_control.py`, `order_lifecycle.py`, ledger | Correction-03 tests 1-19 |
| ER-PERMIT-002 | T3 authority+ledger positive readback precedes one transport invocation. | `order_lifecycle.py` | Correction-03 tests 5,17-19 |
| ER-ECON-001 | Filled exposure uses exact FIFO open-lot YES/NO liability model. | `risk_control.py` | Correction-04 tests 1-5 |
| ER-ECON-002 | Working/candidate exposure uses full non-offset `r*p` or `r*(1-p)`. | `risk_control.py` | Correction-04 tests 6-17 |
| ER-PRICE-001 | Candidate price uses exact `price_ranges` validity and two-sided YES midpoint reference. | `risk_control.py` | Correction-04 tests 21-31 |
| ER-FRESH-001 | Freshness is current-process monotonic ceiling-ms; restart stamps are unusable. | `risk_control.py` | Correction-04 tests 32-39 |

---

## 31. Revision-03 explicit preservation and prohibited inferences

The following Revision-02 conclusions remain normative without weakening:

1. current historical incident has no emergency cancel target;
2. unresolved historical exposure is not zero and is currently `UNKNOWN_UNBOUNDED`;
3. current release eligibility is false;
4. `QUIESCENT_HELD` is valid and may persist indefinitely;
5. nothing authoritative to cancel does not mean safe to write;
6. durable HALT precedes emergency cancel send boundary;
7. cancel requires exact authoritative venue `order_id`;
8. cancel acknowledgement does not imply safe state;
9. fill/cancel races reconcile before action closure/release;
10. blind cancel resend after trusted ambiguous send boundary is prohibited;
11. restart/reconnect never automatically releases writer;
12. release is explicit and durable;
13. Order Groups remain defense in depth only;
14. normal and emergency capabilities remain distinct;
15. emergency and release capabilities remain distinct;
16. schema migration/recreation is not silently permitted;
17. specification acceptance grants no venue execution.

It remains prohibited to infer:

```text
CREATE_NEVER_EXISTED
CREATE_DEFINITELY_FAILED
SAFE_TO_RETRY_CREATE
SAFE_TO_CANCEL
WRITER_PROOF_RELEASED
INCIDENT_CLOSED
```

from the current unresolved incident or from any absence of a current exact cancel target.

## Appendix A. Non-controlling research patterns adopted narrowly

The non-controlling design memo's external prior-art patterns are used only as architectural input:

- central pre-trade gate;
- kill-switch ordering that blocks new risk before cancellation;
- working-order-aware exposure;
- persistent hold rather than reset-to-active;
- independent action identity for emergency commands;
- reserved cancellation capacity;
- explicit durable release;
- Order Groups as defense in depth.

No external system's self-described role, authorization language, securities/futures regulation, or implementation architecture is imported as controlling ARB policy.

## Appendix B. Revision-03 correction closure map

| Blocking defect | Frozen decision | Primary sections | Future evidence |
|---|---|---|---|
| HALT ownership / exclusive-lock transition | CASE A live normal owner persists/anchors HALT with current `ws_`, cleanly ends, releases locks, then fresh emergency acquisition may begin; CASE B permits direct restricted acquisition only when no live normal owner exists | 8.9, 9.2-9.3, 12 | HALT-OWN-01 through HALT-OWN-09 |

The four Revision-02 corrections remain preserved as controlling subcontracts:

| Preserved Revision-02 correction | Frozen decision | Preserved sections |
|---|---|---|
| event schemas | exact six risk/emergency + three restricted-session event schemas, IDs/references/replay | 7.3-7.13 |
| restricted compatibility | dedicated `rs_` sessions and exact mode-gated surfaces | 9, 22, 25 |
| normal permit lifecycle | exact T0→T1→T2→T3 successor chain and T3 readback-before-transport | 8.1-8.8 |
| economic semantics | exact `$1` binary payout, FIFO open lots, non-offset working/candidate liability, midpoint reference, monotonic freshness | 5, 6, 10, 11, 19 |

## Appendix C. Core safety theorem

```text
HARD VIOLATION / WRITER INELIGIBLE
        │
        ▼
CURRENT LOCK OWNER PERSISTS HALT + AUTHORITY ANCHOR
        │
        ▼
NORMAL ws_ CLEAN END + LOCK RELEASE IF CASE A
        │
        ▼
EXACT AUTHORITATIVE ACTIVE ORDER IDs ONLY
        │
        ├── none ───────────────► QUIESCENT_HELD
        │                            │
        │                            └── unresolved uncertainty remains
        │
        ▼
PERSIST CANCEL INTENT
        │
        ▼
PERSIST CANCEL SEND BOUNDARY
        │
        ▼
BOUNDED EXACT CANCEL
        │
        ▼
RECONCILE ORDER + FILLS
        │
        ├── uncertainty remains ─► QUIESCENT_HELD / RECONCILING
        │
        └── all predicates pass ─► SAFE_HELD
                                      │
                                      ▼
                            EXPLICIT DURABLE RELEASE
                                      │
                                      ▼
                               WRITER_ELIGIBLE
```

For the current historical incident:

```text
bound_order_id = null
→ emergency_cancel_target = NONE
→ unresolved exposure remains
→ writer_proof_release_eligible = false
→ QUIESCENT_HELD is permitted
→ WRITER_ELIGIBLE is prohibited
```
