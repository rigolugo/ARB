# HANDOFF — KALSHI DEMO PRIMARY-DOMAIN HISTORICAL INCIDENT RESOLUTION READ-ONLY — SPECIFICATION REVISION 05

```text
artifact_class = TECHNICAL_HANDOFF
task_class = SPEC_ONLY_HANDOFF
technical_scope = REV04_MARKET_RESULT_RENDERED_OBSERVATION_SOURCE_CONTRACT_CORRECTION_ONLY
repository = rigolugo/ARB
implementation_not_performed_by_this_artifact = true
```

## 1. Controlling specification identity

This handoff is subordinate to exactly:

```text
KALSHI_DEMO_PRIMARY_DOMAIN_HISTORICAL_INCIDENT_RESOLUTION_READ_ONLY_SPEC_05.md
raw_bytes = 591027
sha256 = 5e51550edf3a644b07a640631564be4e53d248e7fa73c86f29e8fa15316457d6
```

If this handoff conflicts with the specification, the specification controls.

## 2. Exact repository/base

```text
repository = rigolugo/ARB
branch = main
HEAD = 8787dd4b4ec5a8ba1fbb5b0e8c81ad2d8706cd39
tree = 6fa6e9ff940e0729c7dad27256e96e3c7fe4e3a5
parent = 28b295570bbd8a88a84fa1c589e4b7415f21c99e
verification = PASS__READ_ONLY
```

Do not silently advance, rebase, or retarget a later implementation from this base unless that later task explicitly provides a different base.

Current repository surfaces observed at this base:

```text
src/arb/venues/kalshi/write_result_reconciliation.py
  git_blob = be8ae2c4ded47b8686b3046e03f8ad2909b8ba28
  raw_bytes = 186818

tests/test_kalshi_write_result_reconciliation.py
  git_blob = 49a49e4865774d28b53db7e3cf7e70e2c5805b20
  raw_bytes = 117411
```

These current-base identities are repository-startup provenance. The older Revision-04 installed-file byte/blob observations must not be mistaken for the current base.

## 3. Controlling predecessor

```text
KALSHI_DEMO_PRIMARY_DOMAIN_HISTORICAL_INCIDENT_RESOLUTION_READ_ONLY_SPEC_04.md
raw_bytes = 583254
sha256 = 7973a871048ccccf80cd12307e1f5851ade9c26d8f5446f7cbecc61afead3d2b

HANDOFF_KALSHI_DEMO_PRIMARY_DOMAIN_HISTORICAL_INCIDENT_RESOLUTION_READ_ONLY_SPEC_04.md
raw_bytes = 15871
sha256 = d5aaf0196542b1300113bd544b02dd592b627f00744c477ede6c4b13bfa60350
```

Revision 04 remains controlling for every requirement not explicitly corrected by Revision 05.

## 4. Exact correction

The only source-semantic correction is:

```text
path = $.market_result_contract.rendered_observation
old = NOT_POSITIVELY_EXPOSED_AS_CHILD_IN_CURRENT_RENDERED_RESEARCH_INTERFACE
new = POSITIVELY_EXPOSED_AS_CHILD_IN_CURRENT_RENDERED_RESEARCH_INTERFACE
```

Current rendered Get Settlements evidence positively exposes `market_result` in the rendered 200 response example. Current OpenAPI also exposes `Settlement.market_result` and source-requiredness.

Do not infer execution materiality from that positive source visibility.

Preserve exactly:

```text
market_result = NOT_CONFIRMED__NOT_EXECUTION_MATERIAL
a3_parse = false
a3_compare = false
a3_identity_use = false
a3_economic_use = false
absence_alone_malformed = false
conflict_consequence = FULL_SCHEMA_PROVENANCE_ONLY__NO_A3_GATE_FAILURE_UNLESS_A_CONSUMED_SEMANTIC_CHANGES
```

## 5. Controlling evidence

```text
PROVIDER_02J_CURRENT_SOURCE_PREFLIGHT_OUTPUT_01.txt
raw_bytes = 10635
sha256 = ea6a60a97b2a03eec7501f87a5bb925c7dea607efd32507e245fd1fab472a399

PROVIDER_02J_REV04_DRIFT_LOCALIZATION_OUTPUT_01.txt
raw_bytes = 13020
sha256 = dcfa97d0a6685df1de0a7494401b734f16ef3a24ec733bbbbbb3a9369252b36d

CURRENT_RENDERED_GET_SETTLEMENTS_MARKET_RESULT_01.png
raw_bytes = 164839
sha256 = 22805c0b9064daaa24b1cc07a9f28f2cc04d9da75f2c09970d4720be983f0216
```

Evidence facts to preserve:

```text
A2_BINDING = PASS
SOURCE_SNAPSHOT_BUILD = PASS
SOURCE_DOCS_GET_COUNT = 19
RESPONSIBILITY_COUNT = 1028
CANDIDATE_CURRENT_ATOM_COUNT = 1028
PROOF_COUNT = 1028
MISSING_CANDIDATE_ATOM_COUNT = 0
MISSING_PROOF_COUNT = 0
EXTRA_PROOF_COUNT = 0
UNRESOLVED_CURRENT_SENTINEL_COUNT = 0

operations.USER_DATA_TIMESTAMP.authentication = PUBLIC
operations.HISTORICAL_CUTOFF.authentication = PUBLIC
public operation families = 2
authenticated operation families = 8

REV04_EXPECTED_CURRENT_DIFF_COUNT = 1
REV04_DIFF_0_PATH = $.market_result_contract.rendered_observation
REV04_DIFF_TRUNCATED = false
```

Current source identities recorded by the supplied run:

```text
https://docs.kalshi.com/openapi.yaml
raw_bytes = 324521
sha256 = 35a6b94f2154d100b22e400a5a5d5a36fd882877d5f30a495eba87d4cd3981ca

https://docs.kalshi.com/api-reference/portfolio/get-settlements.md
raw_bytes = 9701
sha256 = 560899acbc9e881307258f07da5a01d58b0663cca876b9bb13324f32f35d5311
```

No new official-source retrieval belongs in this specification handoff.

## 6. Revision-05 source-contract identity

Later implementation must bind exactly:

```text
schema_id = KALSHI_PRIMARY_DOMAIN_HISTORICAL_RESOLUTION_EXECUTION_MATERIAL_SOURCE_CONTRACT_REV5
normalization_revision = 4
canonical_json_bytes = 143864
canonical_json_sha256 = dc30bf877ce9ce7d8f65c97357fafe6891ce1af359bc7d2b4c9747278ad9a762
```

`normalization_revision` remains `4` because the normalization/serialization algorithm is unchanged. The `schema_id` changes from `...REV4` to `...REV5` solely to identify the corrected accepted contract coherently.

The supplied Provider-02J current candidate before that provenance relabel was:

```text
canonical_json_bytes = 143864
canonical_json_sha256 = 9616fcb6ce9d29c2e6ddf8747524f7d335d2f7ef13c69a91daf57ad53bfa94b9
schema_id = ...REV4
```

Do not use that pre-relabel hash as the accepted Revision-05 contract hash.

All ten per-operation canonical byte/hash identities remain unchanged from Revision 04 because no operation object changes.

## 7. Provider-02J boundary

Reviewed Provider package:

```text
KALSHI_DEMO_A3_OPENAPI_ABSENT_SECURITY_PUBLIC_CLASSIFICATION_CORRECTION_01_MARCO_REVIEW.zip
raw_bytes = 199363
sha256 = 2eaa9e5919fd4da8ebfe444b7d9f9e671c21f208f95432ab72e4a7711f7db543

provider_raw_bytes = 104479
provider_sha256 = 18c2b105743f4cae4fcc26db6f43e9785da89475e6a185a8a9e481e0fa02f1ce
```

Provider-02J semantic extraction is not the defect. Do not create another semantic extraction correction for `market_result`.

If a later external Provider/runner artifact contains a literal accepted-contract identity that must be mechanically rebound from Revision 04 to Revision 05, that is a separate provenance-binding task. It must be distinguished from source extraction semantics.

## 8. Smallest future implementation envelope

This handoff does not authorize implementation.

If a separate later implementation task is created, its smallest repository writable set should be exactly:

```text
src/arb/venues/kalshi/write_result_reconciliation.py
tests/test_kalshi_write_result_reconciliation.py
```

All other repository paths are readable protected dependencies at the exact base and remain unchanged unless the later task explicitly expands the path envelope.

The bounded implementation change is only:

```text
accepted rendered_observation value
Revision-05 schema_id / accepted canonical hash binding
comparator expected-baseline identity
focused tests for the accepted delta and preservation
```

Do not modify:

```text
request planner
request budgets
ten-operation surface
2-public / 8-auth split
response parser behavior
identity-binding theorem
zero-match theorem
economic reconciliation
historical partition
exchange_index semantics
persistent state
writer-proof state
credential/signing sequencing
Demo-only / GET-only envelope
A3 capability
```

## 9. Required later tests/evidence

No tests are executed by this handoff.

A later implementation must prove offline at minimum:

```text
1. rendered_observation accepts POSITIVELY_EXPOSED_AS_CHILD_IN_CURRENT_RENDERED_RESEARCH_INTERFACE
2. old NOT_POSITIVELY... value is no longer the accepted Revision-05 baseline
3. market_result classification remains NOT_CONFIRMED__NOT_EXECUTION_MATERIAL
4. a3_parse/a3_compare/a3_identity_use/a3_economic_use all remain false
5. absence_alone_malformed remains false
6. conflict_consequence remains exact
7. normalization_revision remains 4
8. schema_id is ...REV5
9. canonical projection is exactly 143864 bytes / dc30bf877ce9ce7d8f65c97357fafe6891ce1af359bc7d2b4c9747278ad9a762
10. all ten per-operation bytes/hashes remain unchanged
11. UDT remains PUBLIC
12. historical cutoff remains PUBLIC
13. exact 2-public / 8-auth split remains
14. responsibility/current-atom/SourceProof shape remains 1028/1028/1028 with zero missing/extra/unresolved
15. future source change away from the accepted rendered value halts before marker/credentials/Demo/A3
16. no request-generation, parser, identity, economics, result-taxonomy, persistence, or writer-proof change
```

Preserve inherited Revision-04 regression tests as required by the controlling specification.

Later review evidence must map:

```text
SPEC REQUIREMENT -> CODE LOCATION -> TEST/EVIDENCE -> STATUS
```

## 10. Comparator behavior

The later comparator must use the Revision-05 accepted value and remain globally fail-closed.

A future current-source change away from the accepted positive rendered observation is authoritative source drift and must produce the existing source-drift halt before any marker, credential, signing, Demo, production, or A3 boundary.

`market_result` remains non-consumed; positive visibility changes no request generation, response parsing, identity binding, economic reconciliation, or result classification.

Do not weaken other Revision-04 execution-material drift checks.

## 11. Current capability matrix

```text
canonical_repository_read_sync = PERMITTED_READ_ONLY
official_documentation_access = PROHIBITED__SUPPLIED_EVIDENCE_ONLY
general_internet = PROHIBITED
implementation = PROHIBITED
test_source_changes = PROHIBITED
test_execution = PROHIBITED
package_installation = PROHIBITED
credentials = PROHIBITED
private_keys = PROHIBITED
signing = PROHIBITED
Kalshi_Demo = PROHIBITED
Kalshi_production = PROHIBITED
CREATE = PROHIBITED
CANCEL = PROHIBITED
amend/decrease/replace = PROHIBITED
WebSocket = PROHIBITED
marker_access = PROHIBITED
evidence_state_access = PROHIBITED
A3_execution = PROHIBITED
staging = PROHIBITED
persistent_state_mutation = PROHIBITED
repository_modification = PROHIBITED
local_Git_write = PROHIBITED
remote_Git_write = PROHIBITED
```

## 12. Next external gate after a future implementation

A future implementation does not authorize A3.

After that implementation is independently reviewed, the next external gate remains a fresh closed **19-source public-docs-only preflight**. It must complete before any higher-risk phase. No credential use, marker access, Demo request, or A3 execution is implied by implementation acceptance.

## 13. Stop conditions

Stop rather than broaden scope on:

```text
CANONICAL_BASE_MISMATCH
CONTROLLING_SPEC04_IDENTITY_MISMATCH
CONTROLLING_HANDOFF04_IDENTITY_MISMATCH
EVIDENCE_IDENTITY_MISMATCH
MORE_THAN_ONE_CURRENT_MANIFEST_SEMANTIC_DIFF_FOUND
MARKET_RESULT_EXECUTION_MATERIALITY_REQUIRED
UNEXPLAINED_SOURCE_CONTRACT_IDENTITY_CONFLICT
OFFICIAL_SOURCE_CONFLICT
CURRENT_SOURCE_CONTRACT_UNRESOLVED
SCOPE_EXPANSION_REQUIRED
```

Also stop if the correction would require changing the request planner, budgets, identity/zero-match theorem, economics, persistence, writer proof, auth split, historical partition, shard semantics, parser behavior, `market_result` execution use, or Demo-only/GET-only envelope.

## 14. Handoff completion state

```text
specification_identity_bound = true
canonical_base_reverified = true
controlling_revision04_identities_verified = true
controlling_evidence_identities_verified = true
exact_current_manifest_diff_count = 1
market_result_rendered_observation_corrected = true
market_result_nonconsumption_preserved = true
A3_parse_compare_identity_economic_all_false = true
absence_alone_malformed_false = true
PUBLIC_UDT_preserved = true
PUBLIC_historical_cutoff_preserved = true
public_authenticated_split = 2/8
responsibility_shape = 1028/1028/1028
Revision05_source_contract_identity_fixed = true
Provider02J_semantic_extraction_reopened = false
request_planner_change_required = false
parser_change_required = false
economic_change_required = false
persistent_state_change_required = false
writer_proof_change_required = false
A3_capability_expansion = false
implementation_performed = false
test_execution = NONE
credential_activity = NONE
Kalshi_Demo_requests = 0
Kalshi_production_requests = 0
repository_mutation = NONE
Git_write_activity = NONE
```
