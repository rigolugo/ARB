# KALSHI DEMO PRIMARY-DOMAIN HISTORICAL INCIDENT RESOLUTION READ-ONLY — SPECIFICATION REVISION 05

```text
artifact_class = TECHNICAL_SPECIFICATION
task_class = SPEC_ONLY
technical_scope = REV04_MARKET_RESULT_RENDERED_OBSERVATION_SOURCE_CONTRACT_CORRECTION_ONLY
risk_tier = LOW
risk_posture = FAIL_CLOSED
repository = rigolugo/ARB
implementation_not_performed_by_this_artifact = true
```

## 1. Purpose and bounded correction

Revision 05 is one bounded same-scope correction to controlling Revision 04. Revision 04 remains controlling for every requirement not implicated by the exact current rendered `Settlement.market_result` observation or by the minimum revision/provenance metadata needed to identify the corrected source contract coherently.

### RA5-SCOPE-001 — exact correction

The only source-semantic correction is:

```text
path = $.market_result_contract.rendered_observation
Revision-04 accepted value = NOT_POSITIVELY_EXPOSED_AS_CHILD_IN_CURRENT_RENDERED_RESEARCH_INTERFACE
Revision-05 accepted value = POSITIVELY_EXPOSED_AS_CHILD_IN_CURRENT_RENDERED_RESEARCH_INTERFACE
```

The current rendered Get Settlements material positively exposes `market_result` as a child in the rendered 200 response example. Current OpenAPI also exposes `Settlement.market_result` and source-requiredness. This agreement is full-schema/source provenance only. It does not make `market_result` execution-material.

All of the following remain exact and unchanged:

```text
market_result = NOT_CONFIRMED__NOT_EXECUTION_MATERIAL
a3_parse = false
a3_compare = false
a3_identity_use = false
a3_economic_use = false
absence_alone_malformed = false
conflict_consequence = FULL_SCHEMA_PROVENANCE_ONLY__NO_A3_GATE_FAILURE_UNLESS_A_CONSUMED_SEMANTIC_CHANGES
```

No other source-contract semantic atom changes. No source-responsibility path is added or removed. No request planner, budget, parser, identity theorem, zero-match theorem, economic reconciliation, persistent state, writer-proof state, credential/signing sequence, historical partition, shard rule, or A3 execution behavior is reopened.

### RA5-SCOPE-002 — exact capability boundary

```text
canonical_repository_read_sync = PERMITTED_READ_ONLY
official_documentation_access = PROHIBITED__SUPPLIED_EVIDENCE_ONLY
general_internet = PROHIBITED
implementation = PROHIBITED
source_changes = PROHIBITED
test_source_changes = PROHIBITED
test_execution = PROHIBITED
package_installation = PROHIBITED
credentials = PROHIBITED
private_key_access = PROHIBITED
signing = PROHIBITED
Kalshi_account_access = PROHIBITED
Kalshi_Demo_API = PROHIBITED
Kalshi_production_API = PROHIBITED
venue_writes = PROHIBITED
CREATE = PROHIBITED
CANCEL = PROHIBITED
amend = PROHIBITED
decrease = PROHIBITED
replace = PROHIBITED
WebSocket = PROHIBITED
marker_access = PROHIBITED
evidence_state_access = PROHIBITED
A3_execution = PROHIBITED
staging = PROHIBITED
persistent_state_access = PROHIBITED
persistent_state_mutation = PROHIBITED
repository_modification = PROHIBITED
local_Git_write = PROHIBITED
remote_Git_write = PROHIBITED
branch_creation = PROHIBITED
commit = PROHIBITED
push = PROHIBITED
pull_request = PROHIBITED
merge = PROHIBITED
```

The only generated artifacts are this specification and its subordinate handoff.

## 2. Exact canonical repository and controlling identities

### RA5-BASE-001 — canonical repository

Required canonical state, reverified read-only against canonical `main`:

```text
repository = rigolugo/ARB
branch = main
canonical_main = 8787dd4b4ec5a8ba1fbb5b0e8c81ad2d8706cd39
canonical_tree = 6fa6e9ff940e0729c7dad27256e96e3c7fe4e3a5
canonical_parent = 28b295570bbd8a88a84fa1c589e4b7415f21c99e
verification = PASS
```

No canonical advancement, rebase, retarget, merge, branch creation, commit, or repository mutation is permitted by this SPEC_ONLY task.

### RA5-BASE-002 — exact controlling Revision 04

```text
specification = KALSHI_DEMO_PRIMARY_DOMAIN_HISTORICAL_INCIDENT_RESOLUTION_READ_ONLY_SPEC_04.md
raw_bytes = 583254
sha256 = 7973a871048ccccf80cd12307e1f5851ade9c26d8f5446f7cbecc61afead3d2b
verification = PASS

handoff = HANDOFF_KALSHI_DEMO_PRIMARY_DOMAIN_HISTORICAL_INCIDENT_RESOLUTION_READ_ONLY_SPEC_04.md
raw_bytes = 15871
sha256 = d5aaf0196542b1300113bd544b02dd592b627f00744c477ede6c4b13bfa60350
verification = PASS
```

Revision 04 controls every requirement not explicitly corrected in RA5-SCOPE-001 or in the Revision-05 provenance identity rules below.

### RA5-BASE-003 — current implementation surfaces at the required base

The future bounded implementation surface is the same two repository paths used by the installed source-contract implementation, but this specification does not authorize writes:

```text
src/arb/venues/kalshi/write_result_reconciliation.py
  observed_git_blob = be8ae2c4ded47b8686b3046e03f8ad2909b8ba28
  observed_raw_bytes = 186818

tests/test_kalshi_write_result_reconciliation.py
  observed_git_blob = 49a49e4865774d28b53db7e3cf7e70e2c5805b20
  observed_raw_bytes = 117411
```

These current-base identities supersede the older Revision-04 installed-file byte/blob observations for repository-startup provenance only. Their newer existence does not reopen execution semantics. All other repository paths are readable protected dependencies and are not writable under any later task unless that later task explicitly says otherwise.

### RA5-BASE-004 — controlling empirical evidence identities

```text
PROVIDER_02J_CURRENT_SOURCE_PREFLIGHT_OUTPUT_01.txt
raw_bytes = 10635
sha256 = ea6a60a97b2a03eec7501f87a5bb925c7dea607efd32507e245fd1fab472a399
verification = PASS

PROVIDER_02J_REV04_DRIFT_LOCALIZATION_OUTPUT_01.txt
raw_bytes = 13020
sha256 = dcfa97d0a6685df1de0a7494401b734f16ef3a24ec733bbbbbb3a9369252b36d
verification = PASS

CURRENT_RENDERED_GET_SETTLEMENTS_MARKET_RESULT_01.png
raw_bytes = 164839
sha256 = 22805c0b9064daaa24b1cc07a9f28f2cc04d9da75f2c09970d4720be983f0216
verification = PASS
```

The screenshot visibly shows `market_result` inside the current Get Settlements 200 response example and is corroborating rendered-interface evidence.

### RA5-BASE-005 — reviewed Provider-02J boundary

```text
review_package = KALSHI_DEMO_A3_OPENAPI_ABSENT_SECURITY_PUBLIC_CLASSIFICATION_CORRECTION_01_MARCO_REVIEW.zip
raw_bytes = 199363
sha256 = 2eaa9e5919fd4da8ebfe444b7d9f9e671c21f208f95432ab72e4a7711f7db543
verification = PASS

provider_raw_bytes = 104479
provider_sha256 = 18c2b105743f4cae4fcc26db6f43e9785da89475e6a185a8a9e481e0fa02f1ce
```

Provider-02J extraction is not the defect addressed by Revision 05. No new provider semantic-extraction correction is specified. A later implementation may require only mechanical binding to the new accepted Revision-05 source-contract identity.

## 3. Current supplied source evidence and authority classes

### RA5-SRC-001 — exact evidenced 19-source snapshot

No new official-source retrieval is authorized or performed by this specification task. The supplied preflight evidence records a complete current 19-source public-document snapshot:

```text
A2_BINDING = PASS
SOURCE_SNAPSHOT_BUILD = PASS
SOURCE_DOCS_GET_COUNT = 19
RESPONSIBILITY_COUNT = 1028
CANDIDATE_CURRENT_ATOM_COUNT = 1028
PROOF_COUNT = 1028
MISSING_CANDIDATE_ATOM_COUNT = 0
MISSING_PROOF_COUNT = 0
EXTRA_PROOF_COUNT = 0
UNRESOLVED_CURRENT_SENTINEL_COUNT = 0
```

Key current source identities from that supplied evidence are:

```text
https://docs.kalshi.com/openapi.yaml
raw_bytes = 324521
sha256 = 35a6b94f2154d100b22e400a5a5d5a36fd882877d5f30a495eba87d4cd3981ca

https://docs.kalshi.com/api-reference/portfolio/get-settlements.md
raw_bytes = 9701
sha256 = 560899acbc9e881307258f07da5a01d58b0663cca876b9bb13324f32f35d5311
```

The evidence also establishes the exact public/authentication split:

```text
operations.USER_DATA_TIMESTAMP.authentication = PUBLIC
operations.HISTORICAL_CUTOFF.authentication = PUBLIC
all other eight operation families = AUTHENTICATED
public operation families = 2
authenticated operation families = 8
```

### RA5-SRC-002 — exact one-difference theorem

The supplied localization evidence establishes:

```text
REV04_EXPECTED_CURRENT_DIFF_COUNT = 1
REV04_DIFF_0_PATH = $.market_result_contract.rendered_observation
REV04_DIFF_0_KIND = VALUE_MISMATCH
REV04_DIFF_0_EXPECTED = NOT_POSITIVELY_EXPOSED_AS_CHILD_IN_CURRENT_RENDERED_RESEARCH_INTERFACE
REV04_DIFF_0_CURRENT = POSITIVELY_EXPOSED_AS_CHILD_IN_CURRENT_RENDERED_RESEARCH_INTERFACE
REV04_DIFF_TRUNCATED = false
DIAGNOSTIC_RESULT = PASS__REV04_DRIFT_LOCALIZED
```

No second manifest semantic difference is accepted by this task. Discovery of one requires halt under RA5-STOP-001.

### RA5-SRC-003 — authority classes preserved

| Source class | Authority | Silence behavior |
| --- | --- | --- |
| Current OpenAPI schema | type, format, requiredness, nullability, enum, numeric range where exposed | missing required structural attribute => `CURRENT_SOURCE_CONTRACT_UNRESOLVED` |
| Rendered endpoint/reference | method, route, query surface, operation narrative, rendered examples | absence of child metadata does not negate positive OpenAPI metadata |
| Historical/environment guides | environment separation, recommended roots, live/historical partition semantics, retention exposure | no stronger theorem inferred |
| Changelog | dated behavioral changes and announced future changes | no execution capability inferred |

A rendered page's silence still does not override positive OpenAPI structural metadata. If two source classes make positive material claims and disagree, the inherited consequence remains `OFFICIAL_SOURCE_CONFLICT`. Revision 05 changes only the accepted empirical value for the rendered `market_result` child observation; it does not weaken the conflict rule.

### RA5-SRC-004 — market_result evidence classification

```text
OpenAPI observation = PROPERTY_PRESENT_AND_SOURCE_REQUIRED_IN_USER_SUPPLIED_CURRENT_OPENAPI_COPY
rendered observation = POSITIVELY_EXPOSED_AS_CHILD_IN_CURRENT_RENDERED_RESEARCH_INTERFACE
execution materiality = NOT_CONFIRMED__NOT_EXECUTION_MATERIAL
A3 parse = NO
A3 compare = NO
A3 identity use = NO
A3 economic use = NO
absence alone malformed = NO
```

Current OpenAPI/rendered positive agreement proves provenance about the field's source exposure. It does not prove that Route A should consume the field, and this specification prohibits deriving execution use from visibility alone.

## 4. Preserved Revision-03 corrections

### RA4-PRESERVE-001 — deterministic unsupported-query rule

Preserve exactly:

```text
unsupported_query_fields(H) =
SET(LIVE_PAIR.query_parameters)
MINUS
SET(HISTORICAL_PAIR.query_parameters)
```

with exact pairings:

```text
HISTORICAL_FILLS     <-> LIVE_FILLS
HISTORICAL_ORDERS    <-> LIVE_ORDERS
HISTORICAL_POSITIONS <-> LIVE_POSITIONS
```

and values:

```text
HISTORICAL_FILLS =
["exchange_index","min_ts","order_id","subaccount"]

HISTORICAL_ORDERS =
["event_ticker","exchange_index","min_ts","status","subaccount"]

HISTORICAL_POSITIONS =
["count_filter","exchange_index","subaccount"]
```

`client_order_id` is not restored to the historical-fill unsupported list.

### RA4-PRESERVE-002 — exact ten-operation surface

Exactly:

```text
USER_DATA_TIMESTAMP
HISTORICAL_CUTOFF
LIVE_ORDERS
HISTORICAL_ORDERS
EXACT_ORDER
LIVE_FILLS
HISTORICAL_FILLS
LIVE_POSITIONS
HISTORICAL_POSITIONS
SETTLEMENTS
```

No additional endpoint enters Route A.

### RA4-PRESERVE-003 — unchanged execution architecture

Preserve without weakening:

```text
zero matches do not prove CREATE never existed
no blind CREATE retry
no cancellation without exact authoritative order_id
writer proof remains HELD through A3
A3 read-only
persistent_state_accessed = false
persistent_state_mutated = false
Demo only
GET only
global GET maximum = 116
HTTP retries = 0
redirects = 0
master deadline = 180000 ms
per-request ceiling = 10000 ms
A3 cannot release writer proof
A3 cannot enter Gate D
```

### RA4-PRESERVE-004 — market_result remains non-consumed

Normative Route-A treatment remains:

```text
market_result = NOT_CONFIRMED__NOT_EXECUTION_MATERIAL
A3 parse = NO
A3 compare = NO
A3 identity use = NO
A3 economic use = NO
absence alone malformed = NO
```

Current OpenAPI positively contains `Settlement.market_result` and marks it source-required, and the supplied current rendered Get Settlements evidence positively exposes `market_result` as a child in the rendered 200 response example. Those agreeing source observations remain provenance only because current A2 and the accepted Route-A contract do not consume the field.

## 5. C01 central completeness theorem

### RA4-C01-001

Every source assumption load-bearing for current Route-A request generation, response acceptance, identity, temporal filtering, economic reconciliation, partition interpretation, pagination, scope/shard validation, or negative theorem MUST either:

1. appear explicitly in the Revision-05 accepted source projection, whose execution-material atom set is inherited unchanged from Revision 04; or
2. appear in the closed predecessor/exclusion audit with disposition `PROVEN_NON_CONSUMED` or `PROVEN_PROVENANCE_ONLY` and an exact reason.

Silent disappearance is prohibited.

### RA4-C01-002 — required execution-material categories

The projection uses these explicit categories:

```text
IDENTITY_FIELD
SCOPE_SHARD_FIELD
TEMPORAL_FIELD
ECONOMIC_FIELD
STATUS_OR_STATE_FIELD
PARTITION_SEMANTIC
PAGINATION_FIELD
SUPPORTING_EVIDENCE_FIELD
NEGATIVE_THEOREM_FIELD
REQUEST_SCOPE_FIELD
```

A field may occupy multiple categories.

## 6. Revision-02 predecessor field disposition audit

### RA4-AUDIT-001

The complete 7056-byte Revision-02 manifest was parsed as the inventory source. All 118 top-level/operation-level key-value families have exactly one closed disposition, and every list member inside those families is also individually classified so no predecessor field name or value can disappear through aggregation. The closed dispositions are:

```text
PRESERVED_EXECUTION_MATERIAL
RENAMED_EXECUTION_MATERIAL
SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT
UPDATED_CURRENT_SOURCE_VALUE
PROVEN_NON_CONSUMED
PROVEN_PROVENANCE_ONLY
SUPERSEDED_BY_EXPLICIT_REV03_RULE
```

Table A follows.

| REV02 FIELD PATH | REV02 VALUE | RUNTIME USE | REV03 DISPOSITION | REV04 DISPOSITION | REV04 FIELD PATH | EXECUTION-MATERIAL? | RATIONALE |
| --- | --- | --- | --- | --- | --- | --- | --- |
| environment.credentials_shared | false | ENVIRONMENT/SOURCE_GATE | OMITTED_BY_BLOCKED_REV03_PROJECTION | PRESERVED_EXECUTION_MATERIAL | environment.credentials_shared | YES | Demo/production separation and credential separation remain load-bearing |
| environment.demo_rest_root | https://external-api.demo.kalshi.co/trade-api/v2 | ENVIRONMENT/SOURCE_GATE | OMITTED_BY_BLOCKED_REV03_PROJECTION | PRESERVED_EXECUTION_MATERIAL | environment.demo_rest_root | YES | Demo/production separation and credential separation remain load-bearing |
| environment.production_rest_root | https://external-api.kalshi.com/trade-api/v2 | ENVIRONMENT/SOURCE_GATE | OMITTED_BY_BLOCKED_REV03_PROJECTION | PRESERVED_EXECUTION_MATERIAL | environment.production_rest_root | YES | Demo/production separation and credential separation remain load-bearing |
| historical_partition.cutoffs_move_forward | true | PARTITION/NEGATIVE_THEOREM/COMPLETENESS | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | historical_partition.cutoffs_move_forward | YES | historical partition/retention theorem remains load-bearing |
| historical_partition.positions_archived_per_whole_event | true | PARTITION/NEGATIVE_THEOREM/COMPLETENESS | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | historical_partition.positions_archived_per_whole_event | YES | historical partition/retention theorem remains load-bearing |
| historical_partition.retention_lower_bound | NOT_EXPOSED | PARTITION/NEGATIVE_THEOREM/COMPLETENESS | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | historical_partition.retention_lower_bound | YES | historical partition/retention theorem remains load-bearing |
| historical_partition.target_live_window | 3 months | PARTITION/NEGATIVE_THEOREM/COMPLETENESS | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | historical_partition.target_live_window | YES | historical partition/retention theorem remains load-bearing |
| manifest_id | KALSHI_PRIMARY_DOMAIN_HISTORICAL_RESOLUTION_CURRENT_OFFICIAL_SOURCE_BINDING_2026-08-19_REV2 | PROVENANCE_ONLY | OMITTED__PROVENANCE_NOT_IN_REV03_PROJECTION | PROVEN_PROVENANCE_ONLY | authoring_provenance.predecessor_manifest.manifest_id | NO | project/source provenance; not Route-A request or response semantics |
| observed_at_utc | 2026-08-19T23:42:00Z | PROVENANCE_ONLY | OMITTED__PROVENANCE_NOT_IN_REV03_PROJECTION | PROVEN_PROVENANCE_ONLY | authoring_provenance.predecessor_manifest.observed_at_utc | NO | project/source provenance; not Route-A request or response semantics |
| official_source_scope | docs.kalshi.com only | ENVIRONMENT/SOURCE_GATE | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | official_source_scope | YES | closed official-source host scope remains load-bearing |
| operations.EXACT_ORDER.authentication | AUTHENTICATED | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.EXACT_ORDER.authentication | YES | same load-bearing value retained and current-source checked |
| operations.EXACT_ORDER.documented_http_statuses | [200,401,404,500] | OPERATION_CONTRACT | OMITTED_BY_BLOCKED_REV03_PROJECTION | PRESERVED_EXECUTION_MATERIAL | operations.EXACT_ORDER.documented_http_statuses | YES | same load-bearing value retained and current-source checked |
| operations.EXACT_ORDER.documented_http_statuses[200] | 200 | NEGATIVE/RESPONSE_THEOREM | MEMBER_AUDITED_AGAINST_REV03 | PRESERVED_EXECUTION_MATERIAL | operations.EXACT_ORDER.documented_http_statuses | YES | status member preserved |
| operations.EXACT_ORDER.documented_http_statuses[401] | 401 | NEGATIVE/RESPONSE_THEOREM | MEMBER_AUDITED_AGAINST_REV03 | PRESERVED_EXECUTION_MATERIAL | operations.EXACT_ORDER.documented_http_statuses | YES | status member preserved |
| operations.EXACT_ORDER.documented_http_statuses[404] | 404 | NEGATIVE/RESPONSE_THEOREM | MEMBER_AUDITED_AGAINST_REV03 | PRESERVED_EXECUTION_MATERIAL | operations.EXACT_ORDER.documented_http_statuses | YES | status member preserved |
| operations.EXACT_ORDER.documented_http_statuses[500] | 500 | NEGATIVE/RESPONSE_THEOREM | MEMBER_AUDITED_AGAINST_REV03 | PRESERVED_EXECUTION_MATERIAL | operations.EXACT_ORDER.documented_http_statuses | YES | status member preserved |
| operations.EXACT_ORDER.http_404_nonexistence_theorem | NOT_EXPOSED | PARTITION/NEGATIVE_THEOREM/COMPLETENESS | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.EXACT_ORDER.http_404_nonexistence_theorem | YES | same load-bearing value retained and current-source checked |
| operations.EXACT_ORDER.method | GET | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.EXACT_ORDER.method | YES | same load-bearing value retained and current-source checked |
| operations.EXACT_ORDER.pagination | false | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.EXACT_ORDER.pagination | YES | same load-bearing value retained and current-source checked |
| operations.EXACT_ORDER.path | /trade-api/v2/portfolio/orders/{order_id} | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.EXACT_ORDER.path | YES | same load-bearing value retained and current-source checked |
| operations.EXACT_ORDER.path_parameters | ["order_id"] | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | PRESENT_SAME_KEY | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.EXACT_ORDER.path_parameters | YES | path field now carries exact structural and runtime parser metadata |
| operations.EXACT_ORDER.path_parameters["order_id"] | order_id | REQUEST_GENERATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.EXACT_ORDER.path_parameters[order_id] | YES | path parameter gains structural/runtime descriptor |
| operations.EXACT_ORDER.query_parameters | [] | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | PRESENT_AS_NORMALIZED_QUERY_NAME_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.EXACT_ORDER.query_parameter_names + operations.EXACT_ORDER.query_parameters | YES | name set preserved and each query field gains type/format/requiredness/nullability/range/request-use metadata |
| operations.EXACT_ORDER.response_identity_fields | ["order_id","client_order_id","ticker","subaccount_number","exchange_index"] | RESPONSE_ACCEPTANCE/IDENTITY/ECONOMIC/SUPPORTING_SOURCE_CONTRACT | PRESENT_SAME_FIELD_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.EXACT_ORDER.response_contract.fields | YES | field family split into per-field descriptors with source type/format/requiredness/nullability and ARB/runtime use |
| operations.EXACT_ORDER.response_identity_fields["client_order_id"] | client_order_id | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.EXACT_ORDER.response_contract.fields[client_order_id] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.EXACT_ORDER.response_identity_fields["exchange_index"] | exchange_index | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.EXACT_ORDER.response_contract.fields[exchange_index] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.EXACT_ORDER.response_identity_fields["order_id"] | order_id | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.EXACT_ORDER.response_contract.fields[order_id] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.EXACT_ORDER.response_identity_fields["subaccount_number"] | subaccount_number | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.EXACT_ORDER.response_contract.fields[subaccount_number] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.EXACT_ORDER.response_identity_fields["ticker"] | ticker | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.EXACT_ORDER.response_contract.fields[ticker] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.EXACT_ORDER.source_url | https://docs.kalshi.com/api-reference/orders/get-order | PROVENANCE_ONLY | PRESENT_SAME_KEY | PROVEN_PROVENANCE_ONLY | operations.EXACT_ORDER.source_refs.rendered_url | NO | source locator retained for provenance; operation semantics are separately frozen |
| operations.HISTORICAL_CUTOFF.authentication | PUBLIC | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_CUTOFF.authentication | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_CUTOFF.method | GET | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_CUTOFF.method | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_CUTOFF.negative_semantics | PARTITION_BOUNDARY_ONLY__NOT_RETENTION_LOWER_BOUND | PARTITION/NEGATIVE_THEOREM/COMPLETENESS | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_CUTOFF.negative_semantics | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_CUTOFF.pagination | false | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_CUTOFF.pagination | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_CUTOFF.path | /trade-api/v2/historical/cutoff | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_CUTOFF.path | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_CUTOFF.query_parameters | [] | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | PRESENT_AS_NORMALIZED_QUERY_NAME_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_CUTOFF.query_parameter_names + operations.HISTORICAL_CUTOFF.query_parameters | YES | name set preserved and each query field gains type/format/requiredness/nullability/range/request-use metadata |
| operations.HISTORICAL_CUTOFF.response_identity_fields | ["market_settled_ts","trades_created_ts","orders_updated_ts","market_positions_last_updated_ts"] | RESPONSE_ACCEPTANCE/IDENTITY/ECONOMIC/SUPPORTING_SOURCE_CONTRACT | PRESENT_SAME_FIELD_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_CUTOFF.response_contract.fields | YES | field family split into per-field descriptors with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_CUTOFF.response_identity_fields["market_positions_last_updated_ts"] | market_positions_last_updated_ts | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_CUTOFF.response_contract.fields[market_positions_last_updated_ts] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_CUTOFF.response_identity_fields["market_settled_ts"] | market_settled_ts | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_CUTOFF.response_contract.fields[market_settled_ts] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_CUTOFF.response_identity_fields["orders_updated_ts"] | orders_updated_ts | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_CUTOFF.response_contract.fields[orders_updated_ts] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_CUTOFF.response_identity_fields["trades_created_ts"] | trades_created_ts | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_CUTOFF.response_contract.fields[trades_created_ts] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_CUTOFF.source_url | https://docs.kalshi.com/api-reference/historical/get-historical-cutoff-timestamps | PROVENANCE_ONLY | PRESENT_SAME_KEY | PROVEN_PROVENANCE_ONLY | operations.HISTORICAL_CUTOFF.source_refs.rendered_url | NO | source locator retained for provenance; operation semantics are separately frozen |
| operations.HISTORICAL_FILLS.authentication | AUTHENTICATED | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_FILLS.authentication | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_FILLS.limit_range | [1,1000] | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_FILLS.limit_range | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_FILLS.method | GET | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_FILLS.method | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_FILLS.pagination | true | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_FILLS.pagination | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_FILLS.path | /trade-api/v2/historical/fills | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_FILLS.path | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_FILLS.query_parameters | ["ticker","max_ts","limit","cursor"] | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | PRESENT_AS_NORMALIZED_QUERY_NAME_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.query_parameter_names + operations.HISTORICAL_FILLS.query_parameters | YES | name set preserved and each query field gains type/format/requiredness/nullability/range/request-use metadata |
| operations.HISTORICAL_FILLS.query_parameters["cursor"] | cursor | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.query_parameters[cursor] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.HISTORICAL_FILLS.query_parameters["limit"] | limit | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.query_parameters[limit] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.HISTORICAL_FILLS.query_parameters["max_ts"] | max_ts | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.query_parameters[max_ts] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.HISTORICAL_FILLS.query_parameters["ticker"] | ticker | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.query_parameters[ticker] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.HISTORICAL_FILLS.response_economic_fields | ["count_fp","yes_price_dollars","no_price_dollars","fee_cost","is_taker"] | RESPONSE_ACCEPTANCE/IDENTITY/ECONOMIC/SUPPORTING_SOURCE_CONTRACT | PRESENT_SAME_FIELD_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.response_contract.fields | YES | field family split into per-field descriptors with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_FILLS.response_economic_fields["count_fp"] | count_fp | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.response_contract.fields[count_fp] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_FILLS.response_economic_fields["fee_cost"] | fee_cost | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.response_contract.fields[fee_cost] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_FILLS.response_economic_fields["is_taker"] | is_taker | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.response_contract.fields[is_taker] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_FILLS.response_economic_fields["no_price_dollars"] | no_price_dollars | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.response_contract.fields[no_price_dollars] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_FILLS.response_economic_fields["yes_price_dollars"] | yes_price_dollars | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.response_contract.fields[yes_price_dollars] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_FILLS.response_identity_fields | ["fill_id","trade_id","order_id","ticker","market_ticker","subaccount_number","exchange_index","ts","created_time"] | RESPONSE_ACCEPTANCE/IDENTITY/ECONOMIC/SUPPORTING_SOURCE_CONTRACT | PARTIAL_OR_RECLASSIFIED_FIELD_SET__C01_AUDIT_REQUIRED | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.response_contract.fields | YES | field family split into per-field descriptors with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_FILLS.response_identity_fields["created_time"] | created_time | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.response_contract.fields[created_time] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_FILLS.response_identity_fields["exchange_index"] | exchange_index | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.response_contract.fields[exchange_index] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_FILLS.response_identity_fields["fill_id"] | fill_id | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.response_contract.fields[fill_id] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_FILLS.response_identity_fields["market_ticker"] | market_ticker | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.response_contract.fields[market_ticker] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_FILLS.response_identity_fields["order_id"] | order_id | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.response_contract.fields[order_id] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_FILLS.response_identity_fields["subaccount_number"] | subaccount_number | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.response_contract.fields[subaccount_number] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_FILLS.response_identity_fields["ticker"] | ticker | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.response_contract.fields[ticker] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_FILLS.response_identity_fields["trade_id"] | trade_id | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.response_contract.fields[trade_id] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_FILLS.response_identity_fields["ts"] | ts | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_FILLS.response_contract.fields[ts] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_FILLS.retention_lower_bound | NOT_EXPOSED | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_FILLS.retention_lower_bound | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_FILLS.source_url | https://docs.kalshi.com/api-reference/historical/get-historical-fills | PROVENANCE_ONLY | PRESENT_SAME_KEY | PROVEN_PROVENANCE_ONLY | operations.HISTORICAL_FILLS.source_refs.rendered_url | NO | source locator retained for provenance; operation semantics are separately frozen |
| operations.HISTORICAL_FILLS.unsupported_query_fields | ["min_ts","order_id","subaccount","exchange_index","client_order_id"] | OPERATION_CONTRACT | CORRECTED_BY_REV03_MECHANICAL_SET_DIFFERENCE | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_FILLS.unsupported_query_fields | YES | old hand-maintained list replaced by accepted live-minus-historical mechanical derivation |
| operations.HISTORICAL_FILLS.unsupported_query_fields["client_order_id"] | client_order_id | SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_FILLS.unsupported_query_fields | YES | member belongs to predecessor hand-maintained unsupported list; Rev04 uses only the accepted mechanical live-minus-historical derivation; stale members such as client_order_id are not carried |
| operations.HISTORICAL_FILLS.unsupported_query_fields["exchange_index"] | exchange_index | SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_FILLS.unsupported_query_fields | YES | member belongs to predecessor hand-maintained unsupported list; Rev04 uses only the accepted mechanical live-minus-historical derivation; stale members such as client_order_id are not carried |
| operations.HISTORICAL_FILLS.unsupported_query_fields["min_ts"] | min_ts | SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_FILLS.unsupported_query_fields | YES | member belongs to predecessor hand-maintained unsupported list; Rev04 uses only the accepted mechanical live-minus-historical derivation; stale members such as client_order_id are not carried |
| operations.HISTORICAL_FILLS.unsupported_query_fields["order_id"] | order_id | SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_FILLS.unsupported_query_fields | YES | member belongs to predecessor hand-maintained unsupported list; Rev04 uses only the accepted mechanical live-minus-historical derivation; stale members such as client_order_id are not carried |
| operations.HISTORICAL_FILLS.unsupported_query_fields["subaccount"] | subaccount | SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_FILLS.unsupported_query_fields | YES | member belongs to predecessor hand-maintained unsupported list; Rev04 uses only the accepted mechanical live-minus-historical derivation; stale members such as client_order_id are not carried |
| operations.HISTORICAL_ORDERS.authentication | AUTHENTICATED | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_ORDERS.authentication | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_ORDERS.limit_range | [1,1000] | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_ORDERS.limit_range | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_ORDERS.method | GET | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_ORDERS.method | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_ORDERS.pagination | true | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_ORDERS.pagination | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_ORDERS.partition_semantics | canceled/executed orders older than orders_updated_ts | PARTITION/NEGATIVE_THEOREM/COMPLETENESS | OMITTED_BY_BLOCKED_REV03_PROJECTION | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_ORDERS.partition_semantics | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_ORDERS.path | /trade-api/v2/historical/orders | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_ORDERS.path | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_ORDERS.query_parameters | ["ticker","max_ts","limit","cursor"] | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | PRESENT_AS_NORMALIZED_QUERY_NAME_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_ORDERS.query_parameter_names + operations.HISTORICAL_ORDERS.query_parameters | YES | name set preserved and each query field gains type/format/requiredness/nullability/range/request-use metadata |
| operations.HISTORICAL_ORDERS.query_parameters["cursor"] | cursor | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_ORDERS.query_parameters[cursor] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.HISTORICAL_ORDERS.query_parameters["limit"] | limit | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_ORDERS.query_parameters[limit] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.HISTORICAL_ORDERS.query_parameters["max_ts"] | max_ts | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_ORDERS.query_parameters[max_ts] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.HISTORICAL_ORDERS.query_parameters["ticker"] | ticker | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_ORDERS.query_parameters[ticker] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.HISTORICAL_ORDERS.response_identity_fields | ["order_id","client_order_id","ticker","subaccount_number","exchange_index"] | RESPONSE_ACCEPTANCE/IDENTITY/ECONOMIC/SUPPORTING_SOURCE_CONTRACT | PRESENT_SAME_FIELD_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_ORDERS.response_contract.fields | YES | field family split into per-field descriptors with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_ORDERS.response_identity_fields["client_order_id"] | client_order_id | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_ORDERS.response_contract.fields[client_order_id] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_ORDERS.response_identity_fields["exchange_index"] | exchange_index | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_ORDERS.response_contract.fields[exchange_index] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_ORDERS.response_identity_fields["order_id"] | order_id | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_ORDERS.response_contract.fields[order_id] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_ORDERS.response_identity_fields["subaccount_number"] | subaccount_number | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_ORDERS.response_contract.fields[subaccount_number] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_ORDERS.response_identity_fields["ticker"] | ticker | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_ORDERS.response_contract.fields[ticker] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_ORDERS.retention_lower_bound | NOT_EXPOSED | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_ORDERS.retention_lower_bound | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_ORDERS.source_url | https://docs.kalshi.com/api-reference/historical/get-historical-orders | PROVENANCE_ONLY | PRESENT_SAME_KEY | PROVEN_PROVENANCE_ONLY | operations.HISTORICAL_ORDERS.source_refs.rendered_url | NO | source locator retained for provenance; operation semantics are separately frozen |
| operations.HISTORICAL_ORDERS.unsupported_query_fields | ["min_ts","status","subaccount","exchange_index","client_order_id"] | OPERATION_CONTRACT | CORRECTED_BY_REV03_MECHANICAL_SET_DIFFERENCE | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_ORDERS.unsupported_query_fields | YES | old hand-maintained list replaced by accepted live-minus-historical mechanical derivation |
| operations.HISTORICAL_ORDERS.unsupported_query_fields["client_order_id"] | client_order_id | SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_ORDERS.unsupported_query_fields | YES | member belongs to predecessor hand-maintained unsupported list; Rev04 uses only the accepted mechanical live-minus-historical derivation; stale members such as client_order_id are not carried |
| operations.HISTORICAL_ORDERS.unsupported_query_fields["exchange_index"] | exchange_index | SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_ORDERS.unsupported_query_fields | YES | member belongs to predecessor hand-maintained unsupported list; Rev04 uses only the accepted mechanical live-minus-historical derivation; stale members such as client_order_id are not carried |
| operations.HISTORICAL_ORDERS.unsupported_query_fields["min_ts"] | min_ts | SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_ORDERS.unsupported_query_fields | YES | member belongs to predecessor hand-maintained unsupported list; Rev04 uses only the accepted mechanical live-minus-historical derivation; stale members such as client_order_id are not carried |
| operations.HISTORICAL_ORDERS.unsupported_query_fields["status"] | status | SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_ORDERS.unsupported_query_fields | YES | member belongs to predecessor hand-maintained unsupported list; Rev04 uses only the accepted mechanical live-minus-historical derivation; stale members such as client_order_id are not carried |
| operations.HISTORICAL_ORDERS.unsupported_query_fields["subaccount"] | subaccount | SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_ORDERS.unsupported_query_fields | YES | member belongs to predecessor hand-maintained unsupported list; Rev04 uses only the accepted mechanical live-minus-historical derivation; stale members such as client_order_id are not carried |
| operations.HISTORICAL_POSITIONS.authentication | AUTHENTICATED | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_POSITIONS.authentication | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_POSITIONS.limit_range | [1,1000] | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_POSITIONS.limit_range | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_POSITIONS.market_position_fields | ["ticker","exchange_index","total_traded_dollars","position_fp","market_exposure_dollars","realized_pnl_dollars","fees_paid_dollars","last_updated_ts"] | RESPONSE_ACCEPTANCE/IDENTITY/ECONOMIC/SUPPORTING_SOURCE_CONTRACT | OMITTED_OR_RECLASSIFIED_BY_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_POSITIONS.response_contract.fields | YES | field family split into per-field descriptors with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_POSITIONS.market_position_fields["exchange_index"] | exchange_index | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_POSITIONS.response_contract.fields[exchange_index] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_POSITIONS.market_position_fields["fees_paid_dollars"] | fees_paid_dollars | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_POSITIONS.response_contract.fields[fees_paid_dollars] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_POSITIONS.market_position_fields["last_updated_ts"] | last_updated_ts | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_POSITIONS.response_contract.fields[last_updated_ts] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_POSITIONS.market_position_fields["market_exposure_dollars"] | market_exposure_dollars | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_POSITIONS.response_contract.fields[market_exposure_dollars] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_POSITIONS.market_position_fields["position_fp"] | position_fp | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_POSITIONS.response_contract.fields[position_fp] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_POSITIONS.market_position_fields["realized_pnl_dollars"] | realized_pnl_dollars | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_POSITIONS.response_contract.fields[realized_pnl_dollars] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_POSITIONS.market_position_fields["ticker"] | ticker | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_POSITIONS.response_contract.fields[ticker] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_POSITIONS.market_position_fields["total_traded_dollars"] | total_traded_dollars | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_POSITIONS.response_contract.fields[total_traded_dollars] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.HISTORICAL_POSITIONS.method | GET | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_POSITIONS.method | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_POSITIONS.pagination | true | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_POSITIONS.pagination | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_POSITIONS.partition_semantics | settled positions archived per whole event; never split across live/historical; cutoff field market_positions_last_updated_ts | PARTITION/NEGATIVE_THEOREM/COMPLETENESS | OMITTED_BY_BLOCKED_REV03_PROJECTION | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_POSITIONS.partition_semantics | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_POSITIONS.path | /trade-api/v2/historical/positions | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_POSITIONS.path | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_POSITIONS.query_parameters | ["ticker","event_ticker","limit","cursor"] | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | PRESENT_AS_NORMALIZED_QUERY_NAME_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_POSITIONS.query_parameter_names + operations.HISTORICAL_POSITIONS.query_parameters | YES | name set preserved and each query field gains type/format/requiredness/nullability/range/request-use metadata |
| operations.HISTORICAL_POSITIONS.query_parameters["cursor"] | cursor | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_POSITIONS.query_parameters[cursor] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.HISTORICAL_POSITIONS.query_parameters["event_ticker"] | event_ticker | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_POSITIONS.query_parameters[event_ticker] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.HISTORICAL_POSITIONS.query_parameters["limit"] | limit | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_POSITIONS.query_parameters[limit] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.HISTORICAL_POSITIONS.query_parameters["ticker"] | ticker | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.HISTORICAL_POSITIONS.query_parameters[ticker] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.HISTORICAL_POSITIONS.response_subaccount_field | NOT_EXPOSED | RESPONSE_ACCEPTANCE/IDENTITY/ECONOMIC/SUPPORTING_SOURCE_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_POSITIONS.response_subaccount_field | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_POSITIONS.retention_lower_bound | NOT_EXPOSED | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.HISTORICAL_POSITIONS.retention_lower_bound | YES | same load-bearing value retained and current-source checked |
| operations.HISTORICAL_POSITIONS.source_url | https://docs.kalshi.com/api-reference/historical/get-historical-positions | PROVENANCE_ONLY | PRESENT_SAME_KEY | PROVEN_PROVENANCE_ONLY | operations.HISTORICAL_POSITIONS.source_refs.rendered_url | NO | source locator retained for provenance; operation semantics are separately frozen |
| operations.HISTORICAL_POSITIONS.unsupported_query_fields | ["subaccount","exchange_index","min_ts","max_ts"] | OPERATION_CONTRACT | CORRECTED_BY_REV03_MECHANICAL_SET_DIFFERENCE | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_POSITIONS.unsupported_query_fields | YES | old hand-maintained list replaced by accepted live-minus-historical mechanical derivation |
| operations.HISTORICAL_POSITIONS.unsupported_query_fields["exchange_index"] | exchange_index | SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_POSITIONS.unsupported_query_fields | YES | member belongs to predecessor hand-maintained unsupported list; Rev04 uses only the accepted mechanical live-minus-historical derivation; stale members such as client_order_id are not carried |
| operations.HISTORICAL_POSITIONS.unsupported_query_fields["max_ts"] | max_ts | SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_POSITIONS.unsupported_query_fields | YES | member belongs to predecessor hand-maintained unsupported list; Rev04 uses only the accepted mechanical live-minus-historical derivation; stale members such as client_order_id are not carried |
| operations.HISTORICAL_POSITIONS.unsupported_query_fields["min_ts"] | min_ts | SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_POSITIONS.unsupported_query_fields | YES | member belongs to predecessor hand-maintained unsupported list; Rev04 uses only the accepted mechanical live-minus-historical derivation; stale members such as client_order_id are not carried |
| operations.HISTORICAL_POSITIONS.unsupported_query_fields["subaccount"] | subaccount | SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SUPERSEDED_BY_EXPLICIT_REV03_RULE | operations.HISTORICAL_POSITIONS.unsupported_query_fields | YES | member belongs to predecessor hand-maintained unsupported list; Rev04 uses only the accepted mechanical live-minus-historical derivation; stale members such as client_order_id are not carried |
| operations.LIVE_FILLS.authentication | AUTHENTICATED | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_FILLS.authentication | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_FILLS.limit_range | [1,1000] | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_FILLS.limit_range | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_FILLS.method | GET | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_FILLS.method | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_FILLS.pagination | true | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_FILLS.pagination | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_FILLS.partition_semantics | fills before trades_created_ts historical | PARTITION/NEGATIVE_THEOREM/COMPLETENESS | OMITTED_BY_BLOCKED_REV03_PROJECTION | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_FILLS.partition_semantics | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_FILLS.path | /trade-api/v2/portfolio/fills | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_FILLS.path | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_FILLS.query_parameters | ["ticker","order_id","min_ts","max_ts","limit","cursor","subaccount","exchange_index"] | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | PRESENT_AS_NORMALIZED_QUERY_NAME_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.query_parameter_names + operations.LIVE_FILLS.query_parameters | YES | name set preserved and each query field gains type/format/requiredness/nullability/range/request-use metadata |
| operations.LIVE_FILLS.query_parameters["cursor"] | cursor | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.query_parameters[cursor] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_FILLS.query_parameters["exchange_index"] | exchange_index | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.query_parameters[exchange_index] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_FILLS.query_parameters["limit"] | limit | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.query_parameters[limit] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_FILLS.query_parameters["max_ts"] | max_ts | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.query_parameters[max_ts] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_FILLS.query_parameters["min_ts"] | min_ts | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.query_parameters[min_ts] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_FILLS.query_parameters["order_id"] | order_id | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.query_parameters[order_id] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_FILLS.query_parameters["subaccount"] | subaccount | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.query_parameters[subaccount] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_FILLS.query_parameters["ticker"] | ticker | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.query_parameters[ticker] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_FILLS.response_economic_fields | ["count_fp","yes_price_dollars","no_price_dollars","fee_cost","is_taker"] | RESPONSE_ACCEPTANCE/IDENTITY/ECONOMIC/SUPPORTING_SOURCE_CONTRACT | PRESENT_SAME_FIELD_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.response_contract.fields | YES | field family split into per-field descriptors with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_FILLS.response_economic_fields["count_fp"] | count_fp | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.response_contract.fields[count_fp] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_FILLS.response_economic_fields["fee_cost"] | fee_cost | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.response_contract.fields[fee_cost] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_FILLS.response_economic_fields["is_taker"] | is_taker | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.response_contract.fields[is_taker] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_FILLS.response_economic_fields["no_price_dollars"] | no_price_dollars | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.response_contract.fields[no_price_dollars] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_FILLS.response_economic_fields["yes_price_dollars"] | yes_price_dollars | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.response_contract.fields[yes_price_dollars] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_FILLS.response_identity_fields | ["fill_id","trade_id","order_id","ticker","market_ticker","subaccount_number","exchange_index","ts","created_time"] | RESPONSE_ACCEPTANCE/IDENTITY/ECONOMIC/SUPPORTING_SOURCE_CONTRACT | PARTIAL_OR_RECLASSIFIED_FIELD_SET__C01_AUDIT_REQUIRED | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.response_contract.fields | YES | field family split into per-field descriptors with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_FILLS.response_identity_fields["created_time"] | created_time | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.response_contract.fields[created_time] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_FILLS.response_identity_fields["exchange_index"] | exchange_index | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.response_contract.fields[exchange_index] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_FILLS.response_identity_fields["fill_id"] | fill_id | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.response_contract.fields[fill_id] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_FILLS.response_identity_fields["market_ticker"] | market_ticker | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.response_contract.fields[market_ticker] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_FILLS.response_identity_fields["order_id"] | order_id | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.response_contract.fields[order_id] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_FILLS.response_identity_fields["subaccount_number"] | subaccount_number | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.response_contract.fields[subaccount_number] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_FILLS.response_identity_fields["ticker"] | ticker | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.response_contract.fields[ticker] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_FILLS.response_identity_fields["trade_id"] | trade_id | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.response_contract.fields[trade_id] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_FILLS.response_identity_fields["ts"] | ts | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_FILLS.response_contract.fields[ts] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_FILLS.source_url | https://docs.kalshi.com/api-reference/portfolio/get-fills | PROVENANCE_ONLY | PRESENT_SAME_KEY | PROVEN_PROVENANCE_ONLY | operations.LIVE_FILLS.source_refs.rendered_url | NO | source locator retained for provenance; operation semantics are separately frozen |
| operations.LIVE_ORDERS.authentication | AUTHENTICATED | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_ORDERS.authentication | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_ORDERS.limit_range | [1,1000] | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_ORDERS.limit_range | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_ORDERS.method | GET | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_ORDERS.method | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_ORDERS.pagination | true | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_ORDERS.pagination | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_ORDERS.partition_semantics | resting always live; canceled/fully executed before orders_updated_ts historical | PARTITION/NEGATIVE_THEOREM/COMPLETENESS | OMITTED_BY_BLOCKED_REV03_PROJECTION | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_ORDERS.partition_semantics | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_ORDERS.path | /trade-api/v2/portfolio/orders | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_ORDERS.path | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_ORDERS.query_parameters | ["ticker","event_ticker","min_ts","max_ts","status","limit","cursor","subaccount","exchange_index"] | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | PRESENT_AS_NORMALIZED_QUERY_NAME_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.query_parameter_names + operations.LIVE_ORDERS.query_parameters | YES | name set preserved and each query field gains type/format/requiredness/nullability/range/request-use metadata |
| operations.LIVE_ORDERS.query_parameters["cursor"] | cursor | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.query_parameters[cursor] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_ORDERS.query_parameters["event_ticker"] | event_ticker | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.query_parameters[event_ticker] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_ORDERS.query_parameters["exchange_index"] | exchange_index | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.query_parameters[exchange_index] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_ORDERS.query_parameters["limit"] | limit | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.query_parameters[limit] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_ORDERS.query_parameters["max_ts"] | max_ts | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.query_parameters[max_ts] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_ORDERS.query_parameters["min_ts"] | min_ts | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.query_parameters[min_ts] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_ORDERS.query_parameters["status"] | status | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.query_parameters[status] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_ORDERS.query_parameters["subaccount"] | subaccount | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.query_parameters[subaccount] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_ORDERS.query_parameters["ticker"] | ticker | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.query_parameters[ticker] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_ORDERS.response_economic_fields | ["yes_price_dollars","no_price_dollars","fill_count_fp","remaining_count_fp","initial_count_fp","taker_fill_cost_dollars","maker_fill_cost_dollars","taker_fees_dollars","maker_fees_dollars"] | RESPONSE_ACCEPTANCE/IDENTITY/ECONOMIC/SUPPORTING_SOURCE_CONTRACT | OMITTED_OR_RECLASSIFIED_BY_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.response_contract.fields | YES | field family split into per-field descriptors with source type/format/requiredness/nullability and ARB/runtime use; taker/maker cost/fee members are explicitly PROVEN_NON_CONSUMED rather than silently retained |
| operations.LIVE_ORDERS.response_economic_fields["fill_count_fp"] | fill_count_fp | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.response_contract.fields[fill_count_fp] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_ORDERS.response_economic_fields["initial_count_fp"] | initial_count_fp | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.response_contract.fields[initial_count_fp] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_ORDERS.response_economic_fields["maker_fees_dollars"] | maker_fees_dollars | PROVEN_NON_CONSUMED | MEMBER_AUDITED_AGAINST_REV03 | PROVEN_NON_CONSUMED | explicit_non_material_exclusions[LIVE_ORDERS.maker_fees_dollars] | NO | installed A2 neither parses nor consumes this source field; exclusion is explicit |
| operations.LIVE_ORDERS.response_economic_fields["maker_fill_cost_dollars"] | maker_fill_cost_dollars | PROVEN_NON_CONSUMED | MEMBER_AUDITED_AGAINST_REV03 | PROVEN_NON_CONSUMED | explicit_non_material_exclusions[LIVE_ORDERS.maker_fill_cost_dollars] | NO | installed A2 neither parses nor consumes this source field; exclusion is explicit |
| operations.LIVE_ORDERS.response_economic_fields["no_price_dollars"] | no_price_dollars | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.response_contract.fields[no_price_dollars] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_ORDERS.response_economic_fields["remaining_count_fp"] | remaining_count_fp | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.response_contract.fields[remaining_count_fp] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_ORDERS.response_economic_fields["taker_fees_dollars"] | taker_fees_dollars | PROVEN_NON_CONSUMED | MEMBER_AUDITED_AGAINST_REV03 | PROVEN_NON_CONSUMED | explicit_non_material_exclusions[LIVE_ORDERS.taker_fees_dollars] | NO | installed A2 neither parses nor consumes this source field; exclusion is explicit |
| operations.LIVE_ORDERS.response_economic_fields["taker_fill_cost_dollars"] | taker_fill_cost_dollars | PROVEN_NON_CONSUMED | MEMBER_AUDITED_AGAINST_REV03 | PROVEN_NON_CONSUMED | explicit_non_material_exclusions[LIVE_ORDERS.taker_fill_cost_dollars] | NO | installed A2 neither parses nor consumes this source field; exclusion is explicit |
| operations.LIVE_ORDERS.response_economic_fields["yes_price_dollars"] | yes_price_dollars | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.response_contract.fields[yes_price_dollars] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_ORDERS.response_identity_fields | ["order_id","client_order_id","ticker","subaccount_number","exchange_index"] | RESPONSE_ACCEPTANCE/IDENTITY/ECONOMIC/SUPPORTING_SOURCE_CONTRACT | PRESENT_SAME_FIELD_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.response_contract.fields | YES | field family split into per-field descriptors with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_ORDERS.response_identity_fields["client_order_id"] | client_order_id | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.response_contract.fields[client_order_id] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_ORDERS.response_identity_fields["exchange_index"] | exchange_index | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.response_contract.fields[exchange_index] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_ORDERS.response_identity_fields["order_id"] | order_id | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.response_contract.fields[order_id] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_ORDERS.response_identity_fields["subaccount_number"] | subaccount_number | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.response_contract.fields[subaccount_number] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_ORDERS.response_identity_fields["ticker"] | ticker | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_ORDERS.response_contract.fields[ticker] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_ORDERS.scope_request_fields | ["ticker","subaccount","exchange_index"] | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | PRESENT_SAME_KEY | RENAMED_EXECUTION_MATERIAL | operations.LIVE_ORDERS.request_scope_fields | YES | same scope fields, normalized key name |
| operations.LIVE_ORDERS.scope_request_fields["exchange_index"] | exchange_index | REQUEST_SCOPE | MEMBER_AUDITED_AGAINST_REV03 | RENAMED_EXECUTION_MATERIAL | operations.LIVE_ORDERS.request_scope_fields | YES | same request-scope member preserved |
| operations.LIVE_ORDERS.scope_request_fields["subaccount"] | subaccount | REQUEST_SCOPE | MEMBER_AUDITED_AGAINST_REV03 | RENAMED_EXECUTION_MATERIAL | operations.LIVE_ORDERS.request_scope_fields | YES | same request-scope member preserved |
| operations.LIVE_ORDERS.scope_request_fields["ticker"] | ticker | REQUEST_SCOPE | MEMBER_AUDITED_AGAINST_REV03 | RENAMED_EXECUTION_MATERIAL | operations.LIVE_ORDERS.request_scope_fields | YES | same request-scope member preserved |
| operations.LIVE_ORDERS.source_url | https://docs.kalshi.com/api-reference/orders/get-orders | PROVENANCE_ONLY | PRESENT_SAME_KEY | PROVEN_PROVENANCE_ONLY | operations.LIVE_ORDERS.source_refs.rendered_url | NO | source locator retained for provenance; operation semantics are separately frozen |
| operations.LIVE_POSITIONS.authentication | AUTHENTICATED | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_POSITIONS.authentication | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_POSITIONS.limit_range | [1,1000] | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_POSITIONS.limit_range | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_POSITIONS.market_position_fields | ["ticker","exchange_index","total_traded_dollars","position_fp","market_exposure_dollars","realized_pnl_dollars","fees_paid_dollars","last_updated_ts"] | RESPONSE_ACCEPTANCE/IDENTITY/ECONOMIC/SUPPORTING_SOURCE_CONTRACT | OMITTED_OR_RECLASSIFIED_BY_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.response_contract.fields | YES | field family split into per-field descriptors with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_POSITIONS.market_position_fields["exchange_index"] | exchange_index | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.response_contract.fields[exchange_index] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_POSITIONS.market_position_fields["fees_paid_dollars"] | fees_paid_dollars | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.response_contract.fields[fees_paid_dollars] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_POSITIONS.market_position_fields["last_updated_ts"] | last_updated_ts | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.response_contract.fields[last_updated_ts] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_POSITIONS.market_position_fields["market_exposure_dollars"] | market_exposure_dollars | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.response_contract.fields[market_exposure_dollars] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_POSITIONS.market_position_fields["position_fp"] | position_fp | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.response_contract.fields[position_fp] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_POSITIONS.market_position_fields["realized_pnl_dollars"] | realized_pnl_dollars | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.response_contract.fields[realized_pnl_dollars] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_POSITIONS.market_position_fields["ticker"] | ticker | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.response_contract.fields[ticker] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_POSITIONS.market_position_fields["total_traded_dollars"] | total_traded_dollars | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.response_contract.fields[total_traded_dollars] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.LIVE_POSITIONS.method | GET | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_POSITIONS.method | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_POSITIONS.pagination | true | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_POSITIONS.pagination | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_POSITIONS.partition_semantics | unsettled positions always live; settled positions may move by whole event to historical | PARTITION/NEGATIVE_THEOREM/COMPLETENESS | OMITTED_BY_BLOCKED_REV03_PROJECTION | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_POSITIONS.partition_semantics | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_POSITIONS.path | /trade-api/v2/portfolio/positions | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_POSITIONS.path | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_POSITIONS.query_parameters | ["cursor","limit","count_filter","ticker","event_ticker","subaccount","exchange_index"] | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | PRESENT_AS_NORMALIZED_QUERY_NAME_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.query_parameter_names + operations.LIVE_POSITIONS.query_parameters | YES | name set preserved and each query field gains type/format/requiredness/nullability/range/request-use metadata |
| operations.LIVE_POSITIONS.query_parameters["count_filter"] | count_filter | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.query_parameters[count_filter] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_POSITIONS.query_parameters["cursor"] | cursor | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.query_parameters[cursor] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_POSITIONS.query_parameters["event_ticker"] | event_ticker | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.query_parameters[event_ticker] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_POSITIONS.query_parameters["exchange_index"] | exchange_index | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.query_parameters[exchange_index] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_POSITIONS.query_parameters["limit"] | limit | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.query_parameters[limit] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_POSITIONS.query_parameters["subaccount"] | subaccount | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.query_parameters[subaccount] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_POSITIONS.query_parameters["ticker"] | ticker | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.LIVE_POSITIONS.query_parameters[ticker] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.LIVE_POSITIONS.response_subaccount_field | NOT_EXPOSED | RESPONSE_ACCEPTANCE/IDENTITY/ECONOMIC/SUPPORTING_SOURCE_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.LIVE_POSITIONS.response_subaccount_field | YES | same load-bearing value retained and current-source checked |
| operations.LIVE_POSITIONS.scope_request_fields | ["ticker","subaccount","exchange_index"] | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | OMITTED_BY_BLOCKED_REV03_PROJECTION | RENAMED_EXECUTION_MATERIAL | operations.LIVE_POSITIONS.request_scope_fields | YES | same scope fields, normalized key name |
| operations.LIVE_POSITIONS.scope_request_fields["exchange_index"] | exchange_index | REQUEST_SCOPE | MEMBER_AUDITED_AGAINST_REV03 | RENAMED_EXECUTION_MATERIAL | operations.LIVE_POSITIONS.request_scope_fields | YES | same request-scope member preserved |
| operations.LIVE_POSITIONS.scope_request_fields["subaccount"] | subaccount | REQUEST_SCOPE | MEMBER_AUDITED_AGAINST_REV03 | RENAMED_EXECUTION_MATERIAL | operations.LIVE_POSITIONS.request_scope_fields | YES | same request-scope member preserved |
| operations.LIVE_POSITIONS.scope_request_fields["ticker"] | ticker | REQUEST_SCOPE | MEMBER_AUDITED_AGAINST_REV03 | RENAMED_EXECUTION_MATERIAL | operations.LIVE_POSITIONS.request_scope_fields | YES | same request-scope member preserved |
| operations.LIVE_POSITIONS.source_url | https://docs.kalshi.com/api-reference/portfolio/get-positions | PROVENANCE_ONLY | PRESENT_SAME_KEY | PROVEN_PROVENANCE_ONLY | operations.LIVE_POSITIONS.source_refs.rendered_url | NO | source locator retained for provenance; operation semantics are separately frozen |
| operations.SETTLEMENTS.authentication | AUTHENTICATED | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.SETTLEMENTS.authentication | YES | same load-bearing value retained and current-source checked |
| operations.SETTLEMENTS.limit_range | [1,1000] | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.SETTLEMENTS.limit_range | YES | same load-bearing value retained and current-source checked |
| operations.SETTLEMENTS.method | GET | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.SETTLEMENTS.method | YES | same load-bearing value retained and current-source checked |
| operations.SETTLEMENTS.pagination | true | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.SETTLEMENTS.pagination | YES | same load-bearing value retained and current-source checked |
| operations.SETTLEMENTS.path | /trade-api/v2/portfolio/settlements | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.SETTLEMENTS.path | YES | same load-bearing value retained and current-source checked |
| operations.SETTLEMENTS.query_parameters | ["limit","cursor","ticker","event_ticker","min_ts","max_ts","subaccount"] | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | PRESENT_AS_NORMALIZED_QUERY_NAME_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.query_parameter_names + operations.SETTLEMENTS.query_parameters | YES | name set preserved and each query field gains type/format/requiredness/nullability/range/request-use metadata |
| operations.SETTLEMENTS.query_parameters["cursor"] | cursor | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.query_parameters[cursor] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.SETTLEMENTS.query_parameters["event_ticker"] | event_ticker | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.query_parameters[event_ticker] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.SETTLEMENTS.query_parameters["limit"] | limit | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.query_parameters[limit] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.SETTLEMENTS.query_parameters["max_ts"] | max_ts | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.query_parameters[max_ts] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.SETTLEMENTS.query_parameters["min_ts"] | min_ts | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.query_parameters[min_ts] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.SETTLEMENTS.query_parameters["subaccount"] | subaccount | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.query_parameters[subaccount] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.SETTLEMENTS.query_parameters["ticker"] | ticker | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.query_parameters[ticker] | YES | query name preserved in normalized name set and gains structural descriptor |
| operations.SETTLEMENTS.response_fields | ["ticker","exchange_index","event_ticker","yes_count_fp","yes_total_cost_dollars","no_count_fp","no_total_cost_dollars","revenue","settled_time","fee_cost","value"] | RESPONSE_ACCEPTANCE/IDENTITY/ECONOMIC/SUPPORTING_SOURCE_CONTRACT | OMITTED_OR_RECLASSIFIED_BY_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.response_contract.fields | YES | field family split into per-field descriptors with source type/format/requiredness/nullability and ARB/runtime use |
| operations.SETTLEMENTS.response_fields["event_ticker"] | event_ticker | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.response_contract.fields[event_ticker] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.SETTLEMENTS.response_fields["exchange_index"] | exchange_index | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.response_contract.fields[exchange_index] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.SETTLEMENTS.response_fields["fee_cost"] | fee_cost | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.response_contract.fields[fee_cost] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.SETTLEMENTS.response_fields["no_count_fp"] | no_count_fp | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.response_contract.fields[no_count_fp] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.SETTLEMENTS.response_fields["no_total_cost_dollars"] | no_total_cost_dollars | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.response_contract.fields[no_total_cost_dollars] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.SETTLEMENTS.response_fields["revenue"] | revenue | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.response_contract.fields[revenue] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.SETTLEMENTS.response_fields["settled_time"] | settled_time | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.response_contract.fields[settled_time] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.SETTLEMENTS.response_fields["ticker"] | ticker | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.response_contract.fields[ticker] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.SETTLEMENTS.response_fields["value"] | value | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.response_contract.fields[value] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.SETTLEMENTS.response_fields["yes_count_fp"] | yes_count_fp | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.response_contract.fields[yes_count_fp] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.SETTLEMENTS.response_fields["yes_total_cost_dollars"] | yes_total_cost_dollars | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.SETTLEMENTS.response_contract.fields[yes_total_cost_dollars] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.SETTLEMENTS.response_subaccount_field | NOT_EXPOSED | RESPONSE_ACCEPTANCE/IDENTITY/ECONOMIC/SUPPORTING_SOURCE_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.SETTLEMENTS.response_subaccount_field | YES | same load-bearing value retained and current-source checked |
| operations.SETTLEMENTS.role | SUPPORTING_ECONOMIC_CROSS_CHECK_ONLY__NOT_ORDER_IDENTITY | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.SETTLEMENTS.role | YES | same load-bearing value retained and current-source checked |
| operations.SETTLEMENTS.scope_request_fields | ["ticker","subaccount"] | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | OMITTED_BY_BLOCKED_REV03_PROJECTION | RENAMED_EXECUTION_MATERIAL | operations.SETTLEMENTS.request_scope_fields | YES | same scope fields, normalized key name |
| operations.SETTLEMENTS.scope_request_fields["subaccount"] | subaccount | REQUEST_SCOPE | MEMBER_AUDITED_AGAINST_REV03 | RENAMED_EXECUTION_MATERIAL | operations.SETTLEMENTS.request_scope_fields | YES | same request-scope member preserved |
| operations.SETTLEMENTS.scope_request_fields["ticker"] | ticker | REQUEST_SCOPE | MEMBER_AUDITED_AGAINST_REV03 | RENAMED_EXECUTION_MATERIAL | operations.SETTLEMENTS.request_scope_fields | YES | same request-scope member preserved |
| operations.SETTLEMENTS.source_url | https://docs.kalshi.com/api-reference/portfolio/get-settlements | PROVENANCE_ONLY | PRESENT_SAME_KEY | PROVEN_PROVENANCE_ONLY | operations.SETTLEMENTS.source_refs.rendered_url | NO | source locator retained for provenance; operation semantics are separately frozen |
| operations.USER_DATA_TIMESTAMP.authentication | PUBLIC | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.USER_DATA_TIMESTAMP.authentication | YES | same load-bearing value retained and current-source checked |
| operations.USER_DATA_TIMESTAMP.method | GET | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.USER_DATA_TIMESTAMP.method | YES | same load-bearing value retained and current-source checked |
| operations.USER_DATA_TIMESTAMP.negative_semantics | NOT_TRANSACTIONALLY_EXACT | PARTITION/NEGATIVE_THEOREM/COMPLETENESS | OMITTED_BY_BLOCKED_REV03_PROJECTION | PRESERVED_EXECUTION_MATERIAL | operations.USER_DATA_TIMESTAMP.negative_semantics | YES | same load-bearing value retained and current-source checked |
| operations.USER_DATA_TIMESTAMP.pagination | false | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.USER_DATA_TIMESTAMP.pagination | YES | same load-bearing value retained and current-source checked |
| operations.USER_DATA_TIMESTAMP.path | /trade-api/v2/exchange/user_data_timestamp | OPERATION_CONTRACT | PRESENT_SAME_KEY | PRESERVED_EXECUTION_MATERIAL | operations.USER_DATA_TIMESTAMP.path | YES | same load-bearing value retained and current-source checked |
| operations.USER_DATA_TIMESTAMP.query_parameters | [] | REQUEST_GENERATION_OR_SOURCE_PAIR_DERIVATION | PRESENT_AS_NORMALIZED_QUERY_NAME_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.USER_DATA_TIMESTAMP.query_parameter_names + operations.USER_DATA_TIMESTAMP.query_parameters | YES | name set preserved and each query field gains type/format/requiredness/nullability/range/request-use metadata |
| operations.USER_DATA_TIMESTAMP.response_identity_fields | ["as_of_time"] | RESPONSE_ACCEPTANCE/IDENTITY/ECONOMIC/SUPPORTING_SOURCE_CONTRACT | PRESENT_SAME_FIELD_SET | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.USER_DATA_TIMESTAMP.response_contract.fields | YES | field family split into per-field descriptors with source type/format/requiredness/nullability and ARB/runtime use |
| operations.USER_DATA_TIMESTAMP.response_identity_fields["as_of_time"] | as_of_time | RESPONSE_CONTRACT | MEMBER_AUDITED_AGAINST_REV03 | SPLIT_INTO_STRONGER_EXECUTION_MATERIAL_CONTRACT | operations.USER_DATA_TIMESTAMP.response_contract.fields[as_of_time] | YES | field restored/preserved as exact descriptor with source type/format/requiredness/nullability and ARB/runtime use |
| operations.USER_DATA_TIMESTAMP.semantic_notes | ["approximate indication of when GetBalance/GetOrder(s)/GetFills/GetPositions data was last validated","short reflection delay documented"] | PARTITION/NEGATIVE_THEOREM/COMPLETENESS | OMITTED_BY_BLOCKED_REV03_PROJECTION | PRESERVED_EXECUTION_MATERIAL | operations.USER_DATA_TIMESTAMP.semantic_notes | YES | same load-bearing value retained and current-source checked |
| operations.USER_DATA_TIMESTAMP.semantic_notes["approximate indication of when GetBalance/GetOrder(s)/GetFills/GetPositions data was last validated"] | approximate indication of when GetBalance/GetOrder(s)/GetFills/GetPositions data was last validated | NEGATIVE/COMPLETENESS | MEMBER_AUDITED_AGAINST_REV03 | PRESERVED_EXECUTION_MATERIAL | operations.USER_DATA_TIMESTAMP.semantic_notes | YES | semantic note remains part of approximate freshness interpretation |
| operations.USER_DATA_TIMESTAMP.semantic_notes["short reflection delay documented"] | short reflection delay documented | NEGATIVE/COMPLETENESS | MEMBER_AUDITED_AGAINST_REV03 | PRESERVED_EXECUTION_MATERIAL | operations.USER_DATA_TIMESTAMP.semantic_notes | YES | semantic note remains part of approximate freshness interpretation |
| operations.USER_DATA_TIMESTAMP.source_url | https://docs.kalshi.com/api-reference/exchange/get-user-data-timestamp | PROVENANCE_ONLY | PRESENT_SAME_KEY | PROVEN_PROVENANCE_ONLY | operations.USER_DATA_TIMESTAMP.source_refs.rendered_url | NO | source locator retained for provenance; operation semantics are separately frozen |
| raw_openapi.bytes | null | PROVENANCE_ONLY | OMITTED__PROVENANCE_NOT_IN_REV03_PROJECTION | UPDATED_CURRENT_SOURCE_VALUE | authoring_provenance.current_openapi_copy.bytes | NO | raw-source bookkeeping updated from current supplied OpenAPI copy; comparator baseline is field projection, not whole-file byte equality |
| raw_openapi.materialized | false | PROVENANCE_ONLY | OMITTED__PROVENANCE_NOT_IN_REV03_PROJECTION | UPDATED_CURRENT_SOURCE_VALUE | authoring_provenance.current_openapi_copy.materialized | NO | raw-source bookkeeping updated from current supplied OpenAPI copy; comparator baseline is field projection, not whole-file byte equality |
| raw_openapi.reason | available web retrieval permitted semantic inspection but raw bytes could not be materialized for independent hashing | PROVENANCE_ONLY | OMITTED__PROVENANCE_NOT_IN_REV03_PROJECTION | UPDATED_CURRENT_SOURCE_VALUE | authoring_provenance.current_openapi_copy.reason | NO | raw-source bookkeeping updated from current supplied OpenAPI copy; comparator baseline is field projection, not whole-file byte equality |
| raw_openapi.sha256 | null | PROVENANCE_ONLY | OMITTED__PROVENANCE_NOT_IN_REV03_PROJECTION | UPDATED_CURRENT_SOURCE_VALUE | authoring_provenance.current_openapi_copy.sha256 | NO | raw-source bookkeeping updated from current supplied OpenAPI copy; comparator baseline is field projection, not whole-file byte equality |

### RA4-AUDIT-002 — explicit predecessor non-consumption

The four Revision-02 `LIVE_ORDERS.response_economic_fields` members:

```text
taker_fill_cost_dollars
maker_fill_cost_dollars
taker_fees_dollars
maker_fees_dollars
```

are source-required in the current `Order` schema but are not parsed or consumed by installed A2. They are therefore explicit `PROVEN_NON_CONSUMED` exclusions, not silently removed. The consumed order economic members (`yes_price_dollars`, `no_price_dollars`, `fill_count_fp`, `remaining_count_fp`, `initial_count_fp`) remain in the stronger per-field projection.

## 7. Runtime-consumed response registry

### RA4-RUNTIME-001

Installed A2 is an independent input to the source projection. Table B records every runtime-consumed response field plus the Revision-03 shard fields and predecessor supporting schema anchors that must remain explicit.

| OPERATION | FIELD | CATEGORY | CURRENT A2 USE | EXPECTED SOURCE TYPE | SOURCE REQUIREDNESS | SOURCE NULLABILITY | ARB REQUIREDNESS | PARSER/NORMALIZATION | ABSENCE/INVALID RESULT | OFFICIAL SOURCE EVIDENCE | REV04 FIELD PATH |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| EXACT_ORDER | order | SUPPORTING_EVIDENCE_FIELD | PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER | object via #/components/schemas/Order | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | ORDER_OBJECT | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/GetOrderResponse/properties/order + https://docs.kalshi.com/api-reference/orders/get-order | operations.EXACT_ORDER.response_contract.container_fields[order] |
| EXACT_ORDER | book_side | STATUS_OR_STATE_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/BookSide enum=['bid', 'ask'] | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_OPAQUE_NONEMPTY_STRING | STORED_NONE / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/book_side + https://docs.kalshi.com/api-reference/orders/get-order | operations.EXACT_ORDER.response_contract.fields[book_side] |
| EXACT_ORDER | cancel_order_on_pause | STATUS_OR_STATE_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | boolean | SOURCE_OPTIONAL | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_EXACT_BOOL | STORED_NONE / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/cancel_order_on_pause + https://docs.kalshi.com/api-reference/orders/get-order | operations.EXACT_ORDER.response_contract.fields[cancel_order_on_pause] |
| EXACT_ORDER | client_order_id | IDENTITY_FIELD | PARSED_AS_REQUIRED_ORDER_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/client_order_id + https://docs.kalshi.com/api-reference/orders/get-order | operations.EXACT_ORDER.response_contract.fields[client_order_id] |
| EXACT_ORDER | exchange_index | SCOPE_SHARD_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | integer via #/components/schemas/ExchangeIndex | SOURCE_OPTIONAL | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2__NO_DEFAULT | IF_PRESENT_EXACT_BUILTIN_INT__BOOL_PROHIBITED | ACCEPTED_AS_NONE_CURRENT_A2__NO_DEFAULT_TO_ZERO / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/exchange_index + https://docs.kalshi.com/api-reference/orders/get-order | operations.EXACT_ORDER.response_contract.fields[exchange_index] |
| EXACT_ORDER | fill_count_fp | ECONOMIC_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/FixedPointCount | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL | NOT_EXPOSED_ECONOMIC_MATCH / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/fill_count_fp + https://docs.kalshi.com/api-reference/orders/get-order | operations.EXACT_ORDER.response_contract.fields[fill_count_fp] |
| EXACT_ORDER | initial_count_fp | ECONOMIC_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/FixedPointCount | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL | NOT_EXPOSED_ECONOMIC_MATCH / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/initial_count_fp + https://docs.kalshi.com/api-reference/orders/get-order | operations.EXACT_ORDER.response_contract.fields[initial_count_fp] |
| EXACT_ORDER | no_price_dollars | ECONOMIC_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL | STORED_NONE / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/no_price_dollars + https://docs.kalshi.com/api-reference/orders/get-order | operations.EXACT_ORDER.response_contract.fields[no_price_dollars] |
| EXACT_ORDER | order_id | IDENTITY_FIELD | PARSED_AS_REQUIRED_ORDER_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/order_id + https://docs.kalshi.com/api-reference/orders/get-order | operations.EXACT_ORDER.response_contract.fields[order_id] |
| EXACT_ORDER | outcome_side | STATUS_OR_STATE_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string enum=['yes', 'no'] | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_OPAQUE_NONEMPTY_STRING | STORED_NONE / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/outcome_side + https://docs.kalshi.com/api-reference/orders/get-order | operations.EXACT_ORDER.response_contract.fields[outcome_side] |
| EXACT_ORDER | remaining_count_fp | ECONOMIC_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/FixedPointCount | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL | NOT_EXPOSED_ECONOMIC_MATCH / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/remaining_count_fp + https://docs.kalshi.com/api-reference/orders/get-order | operations.EXACT_ORDER.response_contract.fields[remaining_count_fp] |
| EXACT_ORDER | status | STATUS_OR_STATE_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/OrderStatus enum=['resting', 'canceled', 'executed'] | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2__SOURCE_REQUIRED | IF_PRESENT_OPAQUE_STRING_AND_ENUM_RESTING_CANCELED_EXECUTED | MISSING_BECOMES_NONE_AND_IS_NOT_RESTING_CURRENT_A2 / AUTHORITATIVE_SOURCE_DRIFT_SPEC_REVISION_REQUIRED_FOR_UNKNOWN_ENUM__MALFORMED_FOR_INVALID_TYPE | #/components/schemas/Order/properties/status + https://docs.kalshi.com/api-reference/orders/get-order | operations.EXACT_ORDER.response_contract.fields[status] |
| EXACT_ORDER | subaccount_number | SCOPE_SHARD_FIELD | PARSED_AS_REQUIRED_ORDER_FIELD | integer | SOURCE_OPTIONAL | NULL_PERMITTED | ARB_REQUIRED | EXACT_BUILTIN_INT__BOOL_PROHIBITED | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/subaccount_number + https://docs.kalshi.com/api-reference/orders/get-order | operations.EXACT_ORDER.response_contract.fields[subaccount_number] |
| EXACT_ORDER | ticker | IDENTITY_FIELD+SCOPE_SHARD_FIELD | PARSED_AS_REQUIRED_ORDER_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/ticker + https://docs.kalshi.com/api-reference/orders/get-order | operations.EXACT_ORDER.response_contract.fields[ticker] |
| EXACT_ORDER | yes_price_dollars | ECONOMIC_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL | STORED_NONE / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/yes_price_dollars + https://docs.kalshi.com/api-reference/orders/get-order | operations.EXACT_ORDER.response_contract.fields[yes_price_dollars] |
| HISTORICAL_CUTOFF | market_positions_last_updated_ts | NEGATIVE_THEOREM_FIELD+PARTITION_SEMANTIC+TEMPORAL_FIELD | PARSED_AS_REQUIRED_UTC_RFC3339_CUTOFF_FIELD | string<date-time> | SOURCE_OPTIONAL | NULL_PROHIBITED | ARB_REQUIRED | UTC_RFC3339_ZERO_OFFSET_REQUIRED | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/GetHistoricalCutoffResponse/properties/market_positions_last_updated_ts + https://docs.kalshi.com/api-reference/historical/get-historical-cutoff-timestamps | operations.HISTORICAL_CUTOFF.response_contract.fields[market_positions_last_updated_ts] |
| HISTORICAL_CUTOFF | market_settled_ts | NEGATIVE_THEOREM_FIELD+PARTITION_SEMANTIC+TEMPORAL_FIELD | PARSED_AS_REQUIRED_UTC_RFC3339_CUTOFF_FIELD | string<date-time> | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | UTC_RFC3339_ZERO_OFFSET_REQUIRED | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/GetHistoricalCutoffResponse/properties/market_settled_ts + https://docs.kalshi.com/api-reference/historical/get-historical-cutoff-timestamps | operations.HISTORICAL_CUTOFF.response_contract.fields[market_settled_ts] |
| HISTORICAL_CUTOFF | orders_updated_ts | NEGATIVE_THEOREM_FIELD+PARTITION_SEMANTIC+TEMPORAL_FIELD | PARSED_AS_REQUIRED_UTC_RFC3339_CUTOFF_FIELD | string<date-time> | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | UTC_RFC3339_ZERO_OFFSET_REQUIRED | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/GetHistoricalCutoffResponse/properties/orders_updated_ts + https://docs.kalshi.com/api-reference/historical/get-historical-cutoff-timestamps | operations.HISTORICAL_CUTOFF.response_contract.fields[orders_updated_ts] |
| HISTORICAL_CUTOFF | trades_created_ts | NEGATIVE_THEOREM_FIELD+PARTITION_SEMANTIC+TEMPORAL_FIELD | PARSED_AS_REQUIRED_UTC_RFC3339_CUTOFF_FIELD | string<date-time> | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | UTC_RFC3339_ZERO_OFFSET_REQUIRED | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/GetHistoricalCutoffResponse/properties/trades_created_ts + https://docs.kalshi.com/api-reference/historical/get-historical-cutoff-timestamps | operations.HISTORICAL_CUTOFF.response_contract.fields[trades_created_ts] |
| HISTORICAL_FILLS | cursor | PAGINATION_FIELD | PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE | PAGINATION_CURSOR_MALFORMED / PAGINATION_CURSOR_MALFORMED | #/components/schemas/GetFillsResponse/properties/cursor + https://docs.kalshi.com/api-reference/historical/get-historical-fills | operations.HISTORICAL_FILLS.response_contract.container_fields[cursor] |
| HISTORICAL_FILLS | fills | SUPPORTING_EVIDENCE_FIELD | PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER | array | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | ARRAY_OF_FILL_OBJECTS | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/GetFillsResponse/properties/fills + https://docs.kalshi.com/api-reference/historical/get-historical-fills | operations.HISTORICAL_FILLS.response_contract.container_fields[fills] |
| HISTORICAL_FILLS | count_fp | ECONOMIC_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | string via #/components/schemas/FixedPointCount | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | FIXED_POINT_COUNT_2DP_TO_DECIMAL | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/count_fp + https://docs.kalshi.com/api-reference/historical/get-historical-fills | operations.HISTORICAL_FILLS.response_contract.fields[count_fp] |
| HISTORICAL_FILLS | created_time | TEMPORAL_FIELD | PARSED_IF_PRESENT__USED_BY_FILL_TEMPORAL_SELECTION_AS_FROZEN | string<date-time> | SOURCE_OPTIONAL | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_TIMEZONE_AWARE_RFC3339_STRING | NO_USABLE_TIME_FROM_THIS_FIELD / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/created_time + https://docs.kalshi.com/api-reference/historical/get-historical-fills | operations.HISTORICAL_FILLS.response_contract.fields[created_time] |
| HISTORICAL_FILLS | exchange_index | SCOPE_SHARD_FIELD | PARSED_IF_PRESENT_AND_SCOPE_CHECKED__REV03_REQUIRES_PRESENT | integer via #/components/schemas/ExchangeIndex | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED_BY_REV03 | EXACT_BUILTIN_INT__BOOL_PROHIBITED__GE_0 | AUTHORITATIVE_RESPONSE_MALFORMED_BY_REV03 / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/exchange_index + https://docs.kalshi.com/api-reference/historical/get-historical-fills | operations.HISTORICAL_FILLS.response_contract.fields[exchange_index] |
| HISTORICAL_FILLS | fee_cost | ECONOMIC_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/fee_cost + https://docs.kalshi.com/api-reference/historical/get-historical-fills | operations.HISTORICAL_FILLS.response_contract.fields[fee_cost] |
| HISTORICAL_FILLS | fill_id | IDENTITY_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/fill_id + https://docs.kalshi.com/api-reference/historical/get-historical-fills | operations.HISTORICAL_FILLS.response_contract.fields[fill_id] |
| HISTORICAL_FILLS | is_taker | ECONOMIC_FIELD+STATUS_OR_STATE_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | boolean | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | EXACT_BOOL | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/is_taker + https://docs.kalshi.com/api-reference/historical/get-historical-fills | operations.HISTORICAL_FILLS.response_contract.fields[is_taker] |
| HISTORICAL_FILLS | market_ticker | IDENTITY_FIELD+SCOPE_SHARD_FIELD | PARSED_IF_PRESENT_AND_SCOPE_CHECKED | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2__SOURCE_REQUIRED | IF_PRESENT_OPAQUE_NONEMPTY_STRING | STORED_NONE_CURRENT_A2 / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/market_ticker + https://docs.kalshi.com/api-reference/historical/get-historical-fills | operations.HISTORICAL_FILLS.response_contract.fields[market_ticker] |
| HISTORICAL_FILLS | no_price_dollars | ECONOMIC_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/no_price_dollars + https://docs.kalshi.com/api-reference/historical/get-historical-fills | operations.HISTORICAL_FILLS.response_contract.fields[no_price_dollars] |
| HISTORICAL_FILLS | order_id | IDENTITY_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/order_id + https://docs.kalshi.com/api-reference/historical/get-historical-fills | operations.HISTORICAL_FILLS.response_contract.fields[order_id] |
| HISTORICAL_FILLS | subaccount_number | SCOPE_SHARD_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | integer | SOURCE_OPTIONAL | NULL_PERMITTED | ARB_REQUIRED | EXACT_BUILTIN_INT__BOOL_PROHIBITED | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/subaccount_number + https://docs.kalshi.com/api-reference/historical/get-historical-fills | operations.HISTORICAL_FILLS.response_contract.fields[subaccount_number] |
| HISTORICAL_FILLS | ticker | IDENTITY_FIELD+SCOPE_SHARD_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/ticker + https://docs.kalshi.com/api-reference/historical/get-historical-fills | operations.HISTORICAL_FILLS.response_contract.fields[ticker] |
| HISTORICAL_FILLS | trade_id | IDENTITY_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/trade_id + https://docs.kalshi.com/api-reference/historical/get-historical-fills | operations.HISTORICAL_FILLS.response_contract.fields[trade_id] |
| HISTORICAL_FILLS | ts | TEMPORAL_FIELD | PARSED_IF_PRESENT__USED_BY_FILL_TEMPORAL_SELECTION_AS_FROZEN | integer<int64> | SOURCE_OPTIONAL | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | CURRENT_A2_ACCEPTS_EXACT_INT_OR_TIMEZONE_AWARE_RFC3339_STRING__SOURCE_BASELINE_IS_INT64 | NO_USABLE_TIME_FROM_THIS_FIELD / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/ts + https://docs.kalshi.com/api-reference/historical/get-historical-fills | operations.HISTORICAL_FILLS.response_contract.fields[ts] |
| HISTORICAL_FILLS | yes_price_dollars | ECONOMIC_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/yes_price_dollars + https://docs.kalshi.com/api-reference/historical/get-historical-fills | operations.HISTORICAL_FILLS.response_contract.fields[yes_price_dollars] |
| HISTORICAL_ORDERS | cursor | PAGINATION_FIELD | PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE | PAGINATION_CURSOR_MALFORMED / PAGINATION_CURSOR_MALFORMED | #/components/schemas/GetOrdersResponse/properties/cursor + https://docs.kalshi.com/api-reference/historical/get-historical-orders | operations.HISTORICAL_ORDERS.response_contract.container_fields[cursor] |
| HISTORICAL_ORDERS | orders | SUPPORTING_EVIDENCE_FIELD | PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER | array | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | ARRAY_OF_ORDER_OBJECTS | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/GetOrdersResponse/properties/orders + https://docs.kalshi.com/api-reference/historical/get-historical-orders | operations.HISTORICAL_ORDERS.response_contract.container_fields[orders] |
| HISTORICAL_ORDERS | book_side | STATUS_OR_STATE_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/BookSide enum=['bid', 'ask'] | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_OPAQUE_NONEMPTY_STRING | STORED_NONE / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/book_side + https://docs.kalshi.com/api-reference/historical/get-historical-orders | operations.HISTORICAL_ORDERS.response_contract.fields[book_side] |
| HISTORICAL_ORDERS | cancel_order_on_pause | STATUS_OR_STATE_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | boolean | SOURCE_OPTIONAL | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_EXACT_BOOL | STORED_NONE / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/cancel_order_on_pause + https://docs.kalshi.com/api-reference/historical/get-historical-orders | operations.HISTORICAL_ORDERS.response_contract.fields[cancel_order_on_pause] |
| HISTORICAL_ORDERS | client_order_id | IDENTITY_FIELD | PARSED_AS_REQUIRED_ORDER_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/client_order_id + https://docs.kalshi.com/api-reference/historical/get-historical-orders | operations.HISTORICAL_ORDERS.response_contract.fields[client_order_id] |
| HISTORICAL_ORDERS | exchange_index | SCOPE_SHARD_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | integer via #/components/schemas/ExchangeIndex | SOURCE_OPTIONAL | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2__NO_DEFAULT | IF_PRESENT_EXACT_BUILTIN_INT__BOOL_PROHIBITED | ACCEPTED_AS_NONE_CURRENT_A2__NO_DEFAULT_TO_ZERO / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/exchange_index + https://docs.kalshi.com/api-reference/historical/get-historical-orders | operations.HISTORICAL_ORDERS.response_contract.fields[exchange_index] |
| HISTORICAL_ORDERS | fill_count_fp | ECONOMIC_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/FixedPointCount | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL | NOT_EXPOSED_ECONOMIC_MATCH / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/fill_count_fp + https://docs.kalshi.com/api-reference/historical/get-historical-orders | operations.HISTORICAL_ORDERS.response_contract.fields[fill_count_fp] |
| HISTORICAL_ORDERS | initial_count_fp | ECONOMIC_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/FixedPointCount | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL | NOT_EXPOSED_ECONOMIC_MATCH / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/initial_count_fp + https://docs.kalshi.com/api-reference/historical/get-historical-orders | operations.HISTORICAL_ORDERS.response_contract.fields[initial_count_fp] |
| HISTORICAL_ORDERS | no_price_dollars | ECONOMIC_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL | STORED_NONE / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/no_price_dollars + https://docs.kalshi.com/api-reference/historical/get-historical-orders | operations.HISTORICAL_ORDERS.response_contract.fields[no_price_dollars] |
| HISTORICAL_ORDERS | order_id | IDENTITY_FIELD | PARSED_AS_REQUIRED_ORDER_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/order_id + https://docs.kalshi.com/api-reference/historical/get-historical-orders | operations.HISTORICAL_ORDERS.response_contract.fields[order_id] |
| HISTORICAL_ORDERS | outcome_side | STATUS_OR_STATE_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string enum=['yes', 'no'] | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_OPAQUE_NONEMPTY_STRING | STORED_NONE / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/outcome_side + https://docs.kalshi.com/api-reference/historical/get-historical-orders | operations.HISTORICAL_ORDERS.response_contract.fields[outcome_side] |
| HISTORICAL_ORDERS | remaining_count_fp | ECONOMIC_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/FixedPointCount | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL | NOT_EXPOSED_ECONOMIC_MATCH / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/remaining_count_fp + https://docs.kalshi.com/api-reference/historical/get-historical-orders | operations.HISTORICAL_ORDERS.response_contract.fields[remaining_count_fp] |
| HISTORICAL_ORDERS | status | STATUS_OR_STATE_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/OrderStatus enum=['resting', 'canceled', 'executed'] | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2__SOURCE_REQUIRED | IF_PRESENT_OPAQUE_STRING_AND_ENUM_RESTING_CANCELED_EXECUTED | MISSING_BECOMES_NONE_AND_IS_NOT_RESTING_CURRENT_A2 / AUTHORITATIVE_SOURCE_DRIFT_SPEC_REVISION_REQUIRED_FOR_UNKNOWN_ENUM__MALFORMED_FOR_INVALID_TYPE | #/components/schemas/Order/properties/status + https://docs.kalshi.com/api-reference/historical/get-historical-orders | operations.HISTORICAL_ORDERS.response_contract.fields[status] |
| HISTORICAL_ORDERS | subaccount_number | SCOPE_SHARD_FIELD | PARSED_AS_REQUIRED_ORDER_FIELD | integer | SOURCE_OPTIONAL | NULL_PERMITTED | ARB_REQUIRED | EXACT_BUILTIN_INT__BOOL_PROHIBITED | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/subaccount_number + https://docs.kalshi.com/api-reference/historical/get-historical-orders | operations.HISTORICAL_ORDERS.response_contract.fields[subaccount_number] |
| HISTORICAL_ORDERS | ticker | IDENTITY_FIELD+SCOPE_SHARD_FIELD | PARSED_AS_REQUIRED_ORDER_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/ticker + https://docs.kalshi.com/api-reference/historical/get-historical-orders | operations.HISTORICAL_ORDERS.response_contract.fields[ticker] |
| HISTORICAL_ORDERS | yes_price_dollars | ECONOMIC_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL | STORED_NONE / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/yes_price_dollars + https://docs.kalshi.com/api-reference/historical/get-historical-orders | operations.HISTORICAL_ORDERS.response_contract.fields[yes_price_dollars] |
| HISTORICAL_POSITIONS | cursor | PAGINATION_FIELD | PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER | string | SOURCE_OPTIONAL | NULL_PROHIBITED | ARB_REQUIRED | EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE | PAGINATION_CURSOR_MALFORMED / PAGINATION_CURSOR_MALFORMED | #/components/schemas/GetPositionsResponse/properties/cursor + https://docs.kalshi.com/api-reference/historical/get-historical-positions | operations.HISTORICAL_POSITIONS.response_contract.container_fields[cursor] |
| HISTORICAL_POSITIONS | market_positions | SUPPORTING_EVIDENCE_FIELD | PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER | array | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | ARRAY_OF_MARKET_POSITION_OBJECTS | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/GetPositionsResponse/properties/market_positions + https://docs.kalshi.com/api-reference/historical/get-historical-positions | operations.HISTORICAL_POSITIONS.response_contract.container_fields[market_positions] |
| HISTORICAL_POSITIONS | exchange_index | SCOPE_SHARD_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__REV03_REQUIRES_PRESERVE/VALIDATE | integer via #/components/schemas/ExchangeIndex | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED_BY_REV03 | REV03_REQUIRES_EXACT_BUILTIN_INT__BOOL_PROHIBITED__GE_0 | AUTHORITATIVE_RESPONSE_MALFORMED_BY_REV03 / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/MarketPosition/properties/exchange_index + https://docs.kalshi.com/api-reference/historical/get-historical-positions | operations.HISTORICAL_POSITIONS.response_contract.fields[exchange_index] |
| HISTORICAL_POSITIONS | fees_paid_dollars | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/MarketPosition/properties/fees_paid_dollars + https://docs.kalshi.com/api-reference/historical/get-historical-positions | operations.HISTORICAL_POSITIONS.response_contract.fields[fees_paid_dollars] |
| HISTORICAL_POSITIONS | last_updated_ts | SUPPORTING_EVIDENCE_FIELD+TEMPORAL_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string<date-time> | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_DATE_TIME_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/MarketPosition/properties/last_updated_ts + https://docs.kalshi.com/api-reference/historical/get-historical-positions | operations.HISTORICAL_POSITIONS.response_contract.fields[last_updated_ts] |
| HISTORICAL_POSITIONS | market_exposure_dollars | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/MarketPosition/properties/market_exposure_dollars + https://docs.kalshi.com/api-reference/historical/get-historical-positions | operations.HISTORICAL_POSITIONS.response_contract.fields[market_exposure_dollars] |
| HISTORICAL_POSITIONS | position_fp | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string via #/components/schemas/FixedPointCount | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_COUNT_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/MarketPosition/properties/position_fp + https://docs.kalshi.com/api-reference/historical/get-historical-positions | operations.HISTORICAL_POSITIONS.response_contract.fields[position_fp] |
| HISTORICAL_POSITIONS | realized_pnl_dollars | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/MarketPosition/properties/realized_pnl_dollars + https://docs.kalshi.com/api-reference/historical/get-historical-positions | operations.HISTORICAL_POSITIONS.response_contract.fields[realized_pnl_dollars] |
| HISTORICAL_POSITIONS | ticker | IDENTITY_FIELD+SCOPE_SHARD_FIELD+SUPPORTING_EVIDENCE_FIELD | RAW_FIELD_READ_FOR_TARGET_TICKER_FILTER | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED_FOR_TARGET_SUPPORTING_ROW | CURRENT_A2_READS_RAW_VALUE__EXACT_TARGET_TICKER_EQUALITY_IF_PRESENT | SOURCE_REQUIRES; CURRENT_A2 raw.get could treat absence as target-like; later correction should preserve source-required baseline / NON_STRING_OR_OTHER_TYPE_NOT_VALIDATED_CURRENT_A2 | #/components/schemas/MarketPosition/properties/ticker + https://docs.kalshi.com/api-reference/historical/get-historical-positions | operations.HISTORICAL_POSITIONS.response_contract.fields[ticker] |
| HISTORICAL_POSITIONS | total_traded_dollars | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/MarketPosition/properties/total_traded_dollars + https://docs.kalshi.com/api-reference/historical/get-historical-positions | operations.HISTORICAL_POSITIONS.response_contract.fields[total_traded_dollars] |
| LIVE_FILLS | cursor | PAGINATION_FIELD | PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE | PAGINATION_CURSOR_MALFORMED / PAGINATION_CURSOR_MALFORMED | #/components/schemas/GetFillsResponse/properties/cursor + https://docs.kalshi.com/api-reference/portfolio/get-fills | operations.LIVE_FILLS.response_contract.container_fields[cursor] |
| LIVE_FILLS | fills | SUPPORTING_EVIDENCE_FIELD | PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER | array | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | ARRAY_OF_FILL_OBJECTS | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/GetFillsResponse/properties/fills + https://docs.kalshi.com/api-reference/portfolio/get-fills | operations.LIVE_FILLS.response_contract.container_fields[fills] |
| LIVE_FILLS | count_fp | ECONOMIC_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | string via #/components/schemas/FixedPointCount | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | FIXED_POINT_COUNT_2DP_TO_DECIMAL | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/count_fp + https://docs.kalshi.com/api-reference/portfolio/get-fills | operations.LIVE_FILLS.response_contract.fields[count_fp] |
| LIVE_FILLS | created_time | TEMPORAL_FIELD | PARSED_IF_PRESENT__USED_BY_FILL_TEMPORAL_SELECTION_AS_FROZEN | string<date-time> | SOURCE_OPTIONAL | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_TIMEZONE_AWARE_RFC3339_STRING | NO_USABLE_TIME_FROM_THIS_FIELD / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/created_time + https://docs.kalshi.com/api-reference/portfolio/get-fills | operations.LIVE_FILLS.response_contract.fields[created_time] |
| LIVE_FILLS | exchange_index | SCOPE_SHARD_FIELD | PARSED_IF_PRESENT_AND_SCOPE_CHECKED__REV03_REQUIRES_PRESENT | integer via #/components/schemas/ExchangeIndex | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED_BY_REV03 | EXACT_BUILTIN_INT__BOOL_PROHIBITED__GE_0 | AUTHORITATIVE_RESPONSE_MALFORMED_BY_REV03 / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/exchange_index + https://docs.kalshi.com/api-reference/portfolio/get-fills | operations.LIVE_FILLS.response_contract.fields[exchange_index] |
| LIVE_FILLS | fee_cost | ECONOMIC_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/fee_cost + https://docs.kalshi.com/api-reference/portfolio/get-fills | operations.LIVE_FILLS.response_contract.fields[fee_cost] |
| LIVE_FILLS | fill_id | IDENTITY_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/fill_id + https://docs.kalshi.com/api-reference/portfolio/get-fills | operations.LIVE_FILLS.response_contract.fields[fill_id] |
| LIVE_FILLS | is_taker | ECONOMIC_FIELD+STATUS_OR_STATE_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | boolean | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | EXACT_BOOL | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/is_taker + https://docs.kalshi.com/api-reference/portfolio/get-fills | operations.LIVE_FILLS.response_contract.fields[is_taker] |
| LIVE_FILLS | market_ticker | IDENTITY_FIELD+SCOPE_SHARD_FIELD | PARSED_IF_PRESENT_AND_SCOPE_CHECKED | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2__SOURCE_REQUIRED | IF_PRESENT_OPAQUE_NONEMPTY_STRING | STORED_NONE_CURRENT_A2 / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/market_ticker + https://docs.kalshi.com/api-reference/portfolio/get-fills | operations.LIVE_FILLS.response_contract.fields[market_ticker] |
| LIVE_FILLS | no_price_dollars | ECONOMIC_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/no_price_dollars + https://docs.kalshi.com/api-reference/portfolio/get-fills | operations.LIVE_FILLS.response_contract.fields[no_price_dollars] |
| LIVE_FILLS | order_id | IDENTITY_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/order_id + https://docs.kalshi.com/api-reference/portfolio/get-fills | operations.LIVE_FILLS.response_contract.fields[order_id] |
| LIVE_FILLS | subaccount_number | SCOPE_SHARD_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | integer | SOURCE_OPTIONAL | NULL_PERMITTED | ARB_REQUIRED | EXACT_BUILTIN_INT__BOOL_PROHIBITED | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/subaccount_number + https://docs.kalshi.com/api-reference/portfolio/get-fills | operations.LIVE_FILLS.response_contract.fields[subaccount_number] |
| LIVE_FILLS | ticker | IDENTITY_FIELD+SCOPE_SHARD_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/ticker + https://docs.kalshi.com/api-reference/portfolio/get-fills | operations.LIVE_FILLS.response_contract.fields[ticker] |
| LIVE_FILLS | trade_id | IDENTITY_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/trade_id + https://docs.kalshi.com/api-reference/portfolio/get-fills | operations.LIVE_FILLS.response_contract.fields[trade_id] |
| LIVE_FILLS | ts | TEMPORAL_FIELD | PARSED_IF_PRESENT__USED_BY_FILL_TEMPORAL_SELECTION_AS_FROZEN | integer<int64> | SOURCE_OPTIONAL | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | CURRENT_A2_ACCEPTS_EXACT_INT_OR_TIMEZONE_AWARE_RFC3339_STRING__SOURCE_BASELINE_IS_INT64 | NO_USABLE_TIME_FROM_THIS_FIELD / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/ts + https://docs.kalshi.com/api-reference/portfolio/get-fills | operations.LIVE_FILLS.response_contract.fields[ts] |
| LIVE_FILLS | yes_price_dollars | ECONOMIC_FIELD | PARSED_AS_REQUIRED_FILL_FIELD | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Fill/properties/yes_price_dollars + https://docs.kalshi.com/api-reference/portfolio/get-fills | operations.LIVE_FILLS.response_contract.fields[yes_price_dollars] |
| LIVE_ORDERS | cursor | PAGINATION_FIELD | PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE | PAGINATION_CURSOR_MALFORMED / PAGINATION_CURSOR_MALFORMED | #/components/schemas/GetOrdersResponse/properties/cursor + https://docs.kalshi.com/api-reference/orders/get-orders | operations.LIVE_ORDERS.response_contract.container_fields[cursor] |
| LIVE_ORDERS | orders | SUPPORTING_EVIDENCE_FIELD | PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER | array | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | ARRAY_OF_ORDER_OBJECTS | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/GetOrdersResponse/properties/orders + https://docs.kalshi.com/api-reference/orders/get-orders | operations.LIVE_ORDERS.response_contract.container_fields[orders] |
| LIVE_ORDERS | book_side | STATUS_OR_STATE_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/BookSide enum=['bid', 'ask'] | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_OPAQUE_NONEMPTY_STRING | STORED_NONE / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/book_side + https://docs.kalshi.com/api-reference/orders/get-orders | operations.LIVE_ORDERS.response_contract.fields[book_side] |
| LIVE_ORDERS | cancel_order_on_pause | STATUS_OR_STATE_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | boolean | SOURCE_OPTIONAL | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_EXACT_BOOL | STORED_NONE / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/cancel_order_on_pause + https://docs.kalshi.com/api-reference/orders/get-orders | operations.LIVE_ORDERS.response_contract.fields[cancel_order_on_pause] |
| LIVE_ORDERS | client_order_id | IDENTITY_FIELD | PARSED_AS_REQUIRED_ORDER_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/client_order_id + https://docs.kalshi.com/api-reference/orders/get-orders | operations.LIVE_ORDERS.response_contract.fields[client_order_id] |
| LIVE_ORDERS | exchange_index | SCOPE_SHARD_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | integer via #/components/schemas/ExchangeIndex | SOURCE_OPTIONAL | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2__NO_DEFAULT | IF_PRESENT_EXACT_BUILTIN_INT__BOOL_PROHIBITED | ACCEPTED_AS_NONE_CURRENT_A2__NO_DEFAULT_TO_ZERO / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/exchange_index + https://docs.kalshi.com/api-reference/orders/get-orders | operations.LIVE_ORDERS.response_contract.fields[exchange_index] |
| LIVE_ORDERS | fill_count_fp | ECONOMIC_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/FixedPointCount | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL | NOT_EXPOSED_ECONOMIC_MATCH / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/fill_count_fp + https://docs.kalshi.com/api-reference/orders/get-orders | operations.LIVE_ORDERS.response_contract.fields[fill_count_fp] |
| LIVE_ORDERS | initial_count_fp | ECONOMIC_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/FixedPointCount | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL | NOT_EXPOSED_ECONOMIC_MATCH / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/initial_count_fp + https://docs.kalshi.com/api-reference/orders/get-orders | operations.LIVE_ORDERS.response_contract.fields[initial_count_fp] |
| LIVE_ORDERS | no_price_dollars | ECONOMIC_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL | STORED_NONE / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/no_price_dollars + https://docs.kalshi.com/api-reference/orders/get-orders | operations.LIVE_ORDERS.response_contract.fields[no_price_dollars] |
| LIVE_ORDERS | order_id | IDENTITY_FIELD | PARSED_AS_REQUIRED_ORDER_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/order_id + https://docs.kalshi.com/api-reference/orders/get-orders | operations.LIVE_ORDERS.response_contract.fields[order_id] |
| LIVE_ORDERS | outcome_side | STATUS_OR_STATE_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string enum=['yes', 'no'] | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_OPAQUE_NONEMPTY_STRING | STORED_NONE / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/outcome_side + https://docs.kalshi.com/api-reference/orders/get-orders | operations.LIVE_ORDERS.response_contract.fields[outcome_side] |
| LIVE_ORDERS | remaining_count_fp | ECONOMIC_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/FixedPointCount | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL | NOT_EXPOSED_ECONOMIC_MATCH / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/remaining_count_fp + https://docs.kalshi.com/api-reference/orders/get-orders | operations.LIVE_ORDERS.response_contract.fields[remaining_count_fp] |
| LIVE_ORDERS | status | STATUS_OR_STATE_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/OrderStatus enum=['resting', 'canceled', 'executed'] | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2__SOURCE_REQUIRED | IF_PRESENT_OPAQUE_STRING_AND_ENUM_RESTING_CANCELED_EXECUTED | MISSING_BECOMES_NONE_AND_IS_NOT_RESTING_CURRENT_A2 / AUTHORITATIVE_SOURCE_DRIFT_SPEC_REVISION_REQUIRED_FOR_UNKNOWN_ENUM__MALFORMED_FOR_INVALID_TYPE | #/components/schemas/Order/properties/status + https://docs.kalshi.com/api-reference/orders/get-orders | operations.LIVE_ORDERS.response_contract.fields[status] |
| LIVE_ORDERS | subaccount_number | SCOPE_SHARD_FIELD | PARSED_AS_REQUIRED_ORDER_FIELD | integer | SOURCE_OPTIONAL | NULL_PERMITTED | ARB_REQUIRED | EXACT_BUILTIN_INT__BOOL_PROHIBITED | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/subaccount_number + https://docs.kalshi.com/api-reference/orders/get-orders | operations.LIVE_ORDERS.response_contract.fields[subaccount_number] |
| LIVE_ORDERS | ticker | IDENTITY_FIELD+SCOPE_SHARD_FIELD | PARSED_AS_REQUIRED_ORDER_FIELD | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | OPAQUE_NONEMPTY_EXACT_STRING | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/ticker + https://docs.kalshi.com/api-reference/orders/get-orders | operations.LIVE_ORDERS.response_contract.fields[ticker] |
| LIVE_ORDERS | yes_price_dollars | ECONOMIC_FIELD | PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_OPTIONAL_CURRENT_A2 | IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL | STORED_NONE / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Order/properties/yes_price_dollars + https://docs.kalshi.com/api-reference/orders/get-orders | operations.LIVE_ORDERS.response_contract.fields[yes_price_dollars] |
| LIVE_POSITIONS | cursor | PAGINATION_FIELD | PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER | string | SOURCE_OPTIONAL | NULL_PROHIBITED | ARB_REQUIRED | EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE | PAGINATION_CURSOR_MALFORMED / PAGINATION_CURSOR_MALFORMED | #/components/schemas/GetPositionsResponse/properties/cursor + https://docs.kalshi.com/api-reference/portfolio/get-positions | operations.LIVE_POSITIONS.response_contract.container_fields[cursor] |
| LIVE_POSITIONS | market_positions | SUPPORTING_EVIDENCE_FIELD | PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER | array | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | ARRAY_OF_MARKET_POSITION_OBJECTS | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/GetPositionsResponse/properties/market_positions + https://docs.kalshi.com/api-reference/portfolio/get-positions | operations.LIVE_POSITIONS.response_contract.container_fields[market_positions] |
| LIVE_POSITIONS | exchange_index | SCOPE_SHARD_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__REV03_REQUIRES_PRESERVE/VALIDATE | integer via #/components/schemas/ExchangeIndex | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED_BY_REV03 | REV03_REQUIRES_EXACT_BUILTIN_INT__BOOL_PROHIBITED__GE_0 | AUTHORITATIVE_RESPONSE_MALFORMED_BY_REV03 / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/MarketPosition/properties/exchange_index + https://docs.kalshi.com/api-reference/portfolio/get-positions | operations.LIVE_POSITIONS.response_contract.fields[exchange_index] |
| LIVE_POSITIONS | fees_paid_dollars | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/MarketPosition/properties/fees_paid_dollars + https://docs.kalshi.com/api-reference/portfolio/get-positions | operations.LIVE_POSITIONS.response_contract.fields[fees_paid_dollars] |
| LIVE_POSITIONS | last_updated_ts | SUPPORTING_EVIDENCE_FIELD+TEMPORAL_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string<date-time> | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_DATE_TIME_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/MarketPosition/properties/last_updated_ts + https://docs.kalshi.com/api-reference/portfolio/get-positions | operations.LIVE_POSITIONS.response_contract.fields[last_updated_ts] |
| LIVE_POSITIONS | market_exposure_dollars | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/MarketPosition/properties/market_exposure_dollars + https://docs.kalshi.com/api-reference/portfolio/get-positions | operations.LIVE_POSITIONS.response_contract.fields[market_exposure_dollars] |
| LIVE_POSITIONS | position_fp | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string via #/components/schemas/FixedPointCount | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_COUNT_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/MarketPosition/properties/position_fp + https://docs.kalshi.com/api-reference/portfolio/get-positions | operations.LIVE_POSITIONS.response_contract.fields[position_fp] |
| LIVE_POSITIONS | realized_pnl_dollars | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/MarketPosition/properties/realized_pnl_dollars + https://docs.kalshi.com/api-reference/portfolio/get-positions | operations.LIVE_POSITIONS.response_contract.fields[realized_pnl_dollars] |
| LIVE_POSITIONS | ticker | IDENTITY_FIELD+SCOPE_SHARD_FIELD+SUPPORTING_EVIDENCE_FIELD | RAW_FIELD_READ_FOR_TARGET_TICKER_FILTER | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED_FOR_TARGET_SUPPORTING_ROW | CURRENT_A2_READS_RAW_VALUE__EXACT_TARGET_TICKER_EQUALITY_IF_PRESENT | SOURCE_REQUIRES; CURRENT_A2 raw.get could treat absence as target-like; later correction should preserve source-required baseline / NON_STRING_OR_OTHER_TYPE_NOT_VALIDATED_CURRENT_A2 | #/components/schemas/MarketPosition/properties/ticker + https://docs.kalshi.com/api-reference/portfolio/get-positions | operations.LIVE_POSITIONS.response_contract.fields[ticker] |
| LIVE_POSITIONS | total_traded_dollars | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/MarketPosition/properties/total_traded_dollars + https://docs.kalshi.com/api-reference/portfolio/get-positions | operations.LIVE_POSITIONS.response_contract.fields[total_traded_dollars] |
| SETTLEMENTS | cursor | PAGINATION_FIELD | PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER | string | SOURCE_OPTIONAL | NULL_PROHIBITED | ARB_REQUIRED | EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE | PAGINATION_CURSOR_MALFORMED / PAGINATION_CURSOR_MALFORMED | #/components/schemas/GetSettlementsResponse/properties/cursor + https://docs.kalshi.com/api-reference/portfolio/get-settlements | operations.SETTLEMENTS.response_contract.container_fields[cursor] |
| SETTLEMENTS | settlements | SUPPORTING_EVIDENCE_FIELD | PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER | array | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | ARRAY_OF_SETTLEMENT_OBJECTS | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/GetSettlementsResponse/properties/settlements + https://docs.kalshi.com/api-reference/portfolio/get-settlements | operations.SETTLEMENTS.response_contract.container_fields[settlements] |
| SETTLEMENTS | event_ticker | SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/Settlement/properties/event_ticker + https://docs.kalshi.com/api-reference/portfolio/get-settlements | operations.SETTLEMENTS.response_contract.fields[event_ticker] |
| SETTLEMENTS | exchange_index | SCOPE_SHARD_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__REV03_REQUIRES_PRESERVE/VALIDATE | integer via #/components/schemas/ExchangeIndex | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED_BY_REV03 | REV03_REQUIRES_EXACT_BUILTIN_INT__BOOL_PROHIBITED__GE_0 | AUTHORITATIVE_RESPONSE_MALFORMED_BY_REV03 / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/Settlement/properties/exchange_index + https://docs.kalshi.com/api-reference/portfolio/get-settlements | operations.SETTLEMENTS.response_contract.fields[exchange_index] |
| SETTLEMENTS | fee_cost | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/Settlement/properties/fee_cost + https://docs.kalshi.com/api-reference/portfolio/get-settlements | operations.SETTLEMENTS.response_contract.fields[fee_cost] |
| SETTLEMENTS | no_count_fp | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string via #/components/schemas/FixedPointCount | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_COUNT_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/Settlement/properties/no_count_fp + https://docs.kalshi.com/api-reference/portfolio/get-settlements | operations.SETTLEMENTS.response_contract.fields[no_count_fp] |
| SETTLEMENTS | no_total_cost_dollars | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/Settlement/properties/no_total_cost_dollars + https://docs.kalshi.com/api-reference/portfolio/get-settlements | operations.SETTLEMENTS.response_contract.fields[no_total_cost_dollars] |
| SETTLEMENTS | revenue | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | integer | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_INTEGER | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/Settlement/properties/revenue + https://docs.kalshi.com/api-reference/portfolio/get-settlements | operations.SETTLEMENTS.response_contract.fields[revenue] |
| SETTLEMENTS | settled_time | SUPPORTING_EVIDENCE_FIELD+TEMPORAL_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string<date-time> | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_DATE_TIME_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/Settlement/properties/settled_time + https://docs.kalshi.com/api-reference/portfolio/get-settlements | operations.SETTLEMENTS.response_contract.fields[settled_time] |
| SETTLEMENTS | ticker | IDENTITY_FIELD+SCOPE_SHARD_FIELD+SUPPORTING_EVIDENCE_FIELD | RAW_FIELD_READ_FOR_TARGET_TICKER_FILTER | string | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED_FOR_TARGET_SUPPORTING_ROW | CURRENT_A2_READS_RAW_VALUE__EXACT_TARGET_TICKER_EQUALITY_IF_PRESENT | SOURCE_REQUIRES; CURRENT_A2 raw.get could treat absence as target-like / NON_STRING_OR_OTHER_TYPE_NOT_VALIDATED_CURRENT_A2 | #/components/schemas/Settlement/properties/ticker + https://docs.kalshi.com/api-reference/portfolio/get-settlements | operations.SETTLEMENTS.response_contract.fields[ticker] |
| SETTLEMENTS | value | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | integer | SOURCE_OPTIONAL | NULL_PERMITTED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_NULLABLE_INTEGER | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/Settlement/properties/value + https://docs.kalshi.com/api-reference/portfolio/get-settlements | operations.SETTLEMENTS.response_contract.fields[value] |
| SETTLEMENTS | yes_count_fp | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string via #/components/schemas/FixedPointCount | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_COUNT_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/Settlement/properties/yes_count_fp + https://docs.kalshi.com/api-reference/portfolio/get-settlements | operations.SETTLEMENTS.response_contract.fields[yes_count_fp] |
| SETTLEMENTS | yes_total_cost_dollars | ECONOMIC_FIELD+SUPPORTING_EVIDENCE_FIELD | NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY | string via #/components/schemas/FixedPointDollars | SOURCE_REQUIRED | NULL_PROHIBITED | PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2 | NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING | NO_CURRENT_A2_INSTANCE_EFFECT / NO_CURRENT_A2_INSTANCE_EFFECT | #/components/schemas/Settlement/properties/yes_total_cost_dollars + https://docs.kalshi.com/api-reference/portfolio/get-settlements | operations.SETTLEMENTS.response_contract.fields[yes_total_cost_dollars] |
| USER_DATA_TIMESTAMP | as_of_time | NEGATIVE_THEOREM_FIELD+TEMPORAL_FIELD | PARSED_AS_REQUIRED_UTC_RFC3339_FRESHNESS_FIELD | string<date-time> | SOURCE_REQUIRED | NULL_PROHIBITED | ARB_REQUIRED | UTC_RFC3339_ZERO_OFFSET_REQUIRED | AUTHORITATIVE_RESPONSE_MALFORMED / AUTHORITATIVE_RESPONSE_MALFORMED | #/components/schemas/GetUserDataTimestampResponse/properties/as_of_time + https://docs.kalshi.com/api-reference/exchange/get-user-data-timestamp | operations.USER_DATA_TIMESTAMP.response_contract.fields[as_of_time] |

### RA4-RUNTIME-002 — current source requiredness is distinct from ARB requiredness

The projection distinguishes at least:

```text
SOURCE_REQUIRED_AND_ARB_REQUIRED
SOURCE_OPTIONAL_BUT_ARB_REQUIRED
SOURCE_REQUIRED_BUT_ARB_OPTIONAL
SOURCE_OPTIONAL_AND_ARB_OPTIONAL
SOURCE_REQUIRED_BUT_NON_CONSUMED
SOURCE_OPTIONAL_BUT_NON_CONSUMED
```

Examples that MUST remain distinct:

```text
Fill.exchange_index:
  source = REQUIRED
  ARB = REQUIRED_BY_REV03

Fill.subaccount_number:
  source = OPTIONAL + nullable
  ARB current A2 = REQUIRED exact int/non-null

GetHistoricalCutoffResponse.market_positions_last_updated_ts:
  source = OPTIONAL
  ARB current A2 = REQUIRED

GetPositionsResponse.cursor:
  source = OPTIONAL
  ARB current A2 = REQUIRED

GetSettlementsResponse.cursor:
  source = OPTIONAL
  ARB current A2 = REQUIRED

Order.exchange_index:
  source = OPTIONAL
  ARB current A2 = OPTIONAL if present; never defaulted to shard 0
```

Source optionality is never rewritten as source requiredness merely because ARB fails closed.

## 8. Exact fill temporal contract

### RA4-TEMP-001 — temporal fields are execution-material

Fill time is load-bearing because `_fill_in_local_scope` applies the incident/evaluation interval. Both predecessor fields are therefore explicit `TEMPORAL_FIELD` descriptors.

| Item | Exact rule |
| --- | --- |
| fields inspected | ts and created_time |
| source ts | OPTIONAL integer<int64>, null prohibited when present |
| source created_time | OPTIONAL string<date-time>, null prohibited when present |
| runtime ts parser | exact int (bool prohibited) OR timezone-aware RFC3339 string |
| runtime created_time parser | timezone-aware RFC3339 string only |
| precedence | valid RFC3339 string ts; else valid RFC3339 created_time; else no usable string timestamp |
| both present | no equality requirement; valid string ts wins |
| source-conforming integer ts | retained but not converted to datetime and not used by time filter |
| both absent / no usable string | fill is not temporally excluded; other scope/identity checks still apply |
| timezone | timezone-aware RFC3339; non-zero offsets accepted; not UTC-only |
| lower bound | inclusive |
| upper bound | inclusive |
| malformed present temporal field | AUTHORITATIVE_RESPONSE_MALFORMED |

### RA4-TEMP-002 — no invented timestamp precedence

The exact current A2 algorithm is frozen:

```text
fill_time = None

if ts is an exact string and valid timezone-aware RFC3339:
    fill_time = parse(ts)
elif created_time is an exact string and valid timezone-aware RFC3339:
    fill_time = parse(created_time)

if fill_time is None:
    treat the fill as not excluded by the time filter

otherwise:
    retain only if incident_lower_bound <= fill_time <= evaluation_upper_bound
```

The source contract differs from the runtime accepted-type set for `ts`: current OpenAPI says optional `integer<int64>`, while current A2 also accepts an RFC3339 string. Revision 04 records both facts instead of pretending they are identical.

### RA4-TEMP-003 — source-conforming integer ts

A source-conforming integer `ts` is parsed and retained by current A2 but is not converted to a datetime for the local incident-window filter. If `created_time` is a valid RFC3339 string, `created_time` becomes the selected filter time. If not, no temporal exclusion occurs.

This is a frozen observation of current behavior, not a new algorithm.

### RA4-TEMP-004 — temporal conflict determination

No material source/runtime contradiction requiring a separate revision was found:

- OpenAPI exposes `created_time` as a date-time string and `ts` as legacy int64.
- current A2 accepts both source-valid representations;
- current A2's conservative no-usable-string behavior does not infer nonexistence or release writer proof;
- no request planner, economic formula, result taxonomy, or identity theorem must change to represent the source contract.

Therefore:

```text
FILL_TEMPORAL_RUNTIME_CONTRACT_CONFLICT_REQUIRES_SEPARATE_REVISION = false
```

## 9. Shard-aware source contract

### RA4-SHARD-001

Preserve Revision-03 `exchange_index` conclusions:

```text
Fill.exchange_index:
  source-required, integer, non-null
  ARB Route A required by Revision 03
  exact built-in int semantics
  bool prohibited
  value >= 0 under ARB target-scope rule
  target incident shard = 0

MarketPosition.exchange_index:
  source-required, integer, non-null
  target supporting row must preserve/validate shard

Settlement.exchange_index:
  source-required, integer, non-null
  target supporting row must preserve/validate shard
```

Missing/malformed shard data never defaults to 0. Existing halt/result taxonomy remains controlling.

Order `exchange_index` remains source-optional under current OpenAPI and current A2 remains optional-if-present for orders; Revision 04 does not silently broaden the parser correction beyond the accepted Revision-03 fill/market-position/settlement scope.

## 10. Historical partition, environment, and negative theorem

### RA4-HIST-001 — environment

```text
credentials_shared = false
Demo recommended REST root = https://external-api.demo.kalshi.co/trade-api/v2
production recommended REST root = https://external-api.kalshi.com/trade-api/v2
```

No endpoint substitution or production capability is introduced.

### RA4-HIST-002 — partition/retention

```text
cutoffs_move_forward = true
target_live_window = 3 months
positions_archived_per_whole_event = true
retention_lower_bound = NOT_EXPOSED
```

Operation-specific partition semantics and operation-specific `NOT_EXPOSED` sentinels remain explicit in the projection.

### RA4-HIST-003 — exact-order 404

```text
documented_http_statuses = [200,401,404,500]
http_404_nonexistence_theorem = NOT_EXPOSED
HTTP 404 alone != CREATE_NEVER_EXISTED
```

## 11. Structural source comparator

### RA4-TYPE-001 — comparison baseline

The later source gate compares:

```text
CURRENT OFFICIAL SOURCE
vs
ACCEPTED REVISION-05 EXPECTED CONTRACT
```

It does not merely compare two current source classes to each other.

### RA4-TYPE-002 — per-field structural drift

For each consumed field descriptor:

```text
field removed -> SOURCE_DRIFT
source required -> optional -> SOURCE_DRIFT
source optional -> required -> SOURCE_DRIFT
type changes -> SOURCE_DRIFT
nullability changes -> SOURCE_DRIFT
execution-material format changes -> SOURCE_DRIFT
execution-material enum/range changes -> SOURCE_DRIFT or explicit specification review
temporal representation changes -> SOURCE_DRIFT
semantic category changes -> SOURCE_DRIFT
```

Current OpenAPI structural metadata is the authority for `type`, `format`, `requiredness`, `nullability`, enum, and numeric range where exposed.

### RA4-TYPE-003 — rendered-doc silence

Rendered reference absence is not evidence of OpenAPI absence. A conflict exists only when two current official source classes make positive material claims that disagree.

### RA4-TYPE-004 — unresolved metadata

If a required structural attribute cannot be established from any permitted current official source:

```text
CURRENT_SOURCE_CONTRACT_UNRESOLVED
```

No guess/default is permitted.

## 12. Deterministic coverage proof

### RA4-COVER-001 — exact set theorem

Define the exact atom sets reproduced in Appendix B:

```text
PREDECESSOR_EXECUTION_MATERIAL
REV03_ACCEPTED_EXECUTION_MATERIAL
RUNTIME_CONSUMED_SOURCE_CONTRACT
REV04_EXECUTION_MATERIAL_PROJECTION
EXPLICIT_NON_MATERIAL_EXCLUSIONS
```

Required theorem:

```text
(
  PREDECESSOR_EXECUTION_MATERIAL
  UNION
  REV03_ACCEPTED_EXECUTION_MATERIAL
  UNION
  RUNTIME_CONSUMED_SOURCE_CONTRACT
)
MINUS
EXPLICIT_NON_MATERIAL_EXCLUSIONS
SUBSET_OF
REV04_EXECUTION_MATERIAL_PROJECTION
```

The atom construction already removes members proven non-consumed/provenance-only; `EXPLICIT_NON_MATERIAL_EXCLUSIONS` remains separately listed in the canonical projection and Table A for auditability.

### RA4-COVER-002 — measured proof

| Set | Atom count | Canonical sorted-list bytes | SHA-256 |
| --- | --- | --- | --- |
| PREDECESSOR_EXECUTION_MATERIAL | 199 | 9468 | 559f6575fb71d50584cc6094f73e51b6859f0802b923a22aed6f80c1c3b63f2b |
| REV03_ACCEPTED_EXECUTION_MATERIAL | 71 | 3250 | 1d74776161ad1c8539783c26380ab53ba36603ca8b27847cafea069e0bd185df |
| RUNTIME_CONSUMED_SOURCE_CONTRACT | 174 | 8808 | d943cf97151a7ca2586c832fd198b061dcc22a86c7193652fc33f173d401a043 |
| REV04_EXECUTION_MATERIAL_PROJECTION | 298 | 14820 | c8d09262f9db8e73095b28ded702708e313d4e8224d070ba879cb7ea95b8ef1f |
| UNION_INPUT | 291 | 14431 | 15559b719b3deedf4025a2b38065df573bdefce747a47e62de88708cf9f4ed13 |
| MISSING_FROM_REV04_AFTER_EXCLUSIONS | 0 | 2 | 4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945 |

Measured result:

```text
missing_atoms = 0
coverage = PASS
```

### RA4-COVER-003 — closed exclusions

No request semantics, consumed response field, auth semantic, partition/retention semantic, identity, temporal field, economic field, scope/shard field, pagination field, or negative theorem may be added to the exclusion set merely because a current implementation does not directly parse a predecessor manifest key.

## 13. Functional impact classification

### RA4-IMPACT-001

| Change | Classification | Runtime consequence |
| --- | --- | --- |
| restore environment / partition / predecessor semantic fields | SOURCE_BINDING_ONLY | none |
| per-field type/format/source-requiredness/nullability/enum/range descriptors | SOURCE_COMPARATOR_ONLY | current-vs-accepted source gate becomes representable |
| fill exchange_index required; position/settlement shard preservation/validation | PARSER_COMPATIBILITY_ALREADY_REQUIRED_BY_REV03 | bounded A2 parser/supporting-row correction only |
| fill temporal source projection and exact current-A2 precedence/absence rules | NO_RUNTIME_CHANGE | freeze behavior; no new precedence or conversion |
| market_result OpenAPI + rendered source exposure observation | NO_RUNTIME_CHANGE | remains non-consumed |

The required conclusions are:

```text
request_planner_change_required = false
branch_request_budget_change_required = false
economic_semantic_change_required = false
result_taxonomy_change_required = false
identity_binding_theorem_change_required = false
zero_match_theorem_change_required = false
persistent_state_change_required = false
writer_proof_state_change_required = false
```

## 14. Canonical Revision-05 source projection

### RA5-MANIFEST-001 — serialization

Canonical projection bytes use exactly:

```text
UTF-8
JSON
sort_keys = true
separators = (",", ":")
ensure_ascii = false
no BOM
no trailing whitespace/newline in canonical bytes
all list ordering frozen by this specification
```

Exact identity:

```text
schema_id = KALSHI_PRIMARY_DOMAIN_HISTORICAL_RESOLUTION_EXECUTION_MATERIAL_SOURCE_CONTRACT_REV5
normalization_revision = 4
canonical_json_bytes = 143864
canonical_json_sha256 = dc30bf877ce9ce7d8f65c97357fafe6891ce1af359bc7d2b4c9747278ad9a762
```

Revision/provenance identity rules:

```text
schema_id change REV4 -> REV5 = REVISION_PROVENANCE_METADATA
normalization_revision = 4 = UNCHANGED_NORMALIZATION_ALGORITHM
canonical byte-count change 143868 -> 143864 = removal of stale NOT_ rendered-observation prefix only
operation-object identities = UNCHANGED
```

`normalization_revision` deliberately remains `4`: Revision 05 does not invent a new normalization algorithm. `schema_id` changes to `...REV5` so the accepted contract does not falsely claim to be the exact Revision-04 contract.

### RA5-MANIFEST-002 — per-operation identities

| Operation | Canonical bytes | SHA-256 |
| --- | --- | --- |
| EXACT_ORDER | 15224 | fb7e69cac3119dd396c7bf9b4f54f74f7f71cb5b76ce445895b58a53cc80bcfa |
| HISTORICAL_CUTOFF | 4595 | 96ba74f1233c91bcce529a5f59726ce44d166baf990352919e1af5e99855a794 |
| HISTORICAL_FILLS | 17130 | 56cd493d88b3bd4ca87a2eef7c597beb1a09f5c1626beefc997f1acf9b5fb87e |
| HISTORICAL_ORDERS | 17435 | ce76d532dacb2a7a059fd46d0c4a7d086e539f59e381d7bc97b41956f08bb53f |
| HISTORICAL_POSITIONS | 13001 | dbaa8f62f993110e23a14c8f84d894e52f0f32160693ccba0f10ae55930c6571 |
| LIVE_FILLS | 18689 | fdcc527dadeadd57d5512f70a6403876660d25e0f9e7cb21b230d52a52648a38 |
| LIVE_ORDERS | 19474 | c8ad464e4a7045b412ec70cec0e9f4e01035103da7aff6b6647624cd35bdf90c |
| LIVE_POSITIONS | 14165 | 0c0b8ff3d04102a3083f421ee6914dbbe3f2f37b0021ec44acde83230a35c2ce |
| SETTLEMENTS | 16810 | 7ec7b606ef4f5b0ba02eaad2cf6df1994e7e690e0c51b40140c9e20501147229 |
| USER_DATA_TIMESTAMP | 1630 | c13419329be995ee5fa72f0967cdc1063289e565eb472d92de36546694355e1c |

### RA5-MANIFEST-003 — complete projection content

The JSON object below is the complete projection. The canonical bytes are obtained by parsing this object and serializing with RA5-MANIFEST-001. For byte-for-byte recomputation, the exact minified canonical JSON is also reproduced immediately afterward.

#### Human-readable complete object

```json
{
  "environment": {
    "credentials_shared": false,
    "demo_rest_root": "https://external-api.demo.kalshi.co/trade-api/v2",
    "production_rest_root": "https://external-api.kalshi.com/trade-api/v2"
  },
  "explicit_non_material_exclusions": [
    {
      "disposition": "PROVEN_NON_CONSUMED",
      "path": "Fill.book_side",
      "reason": "current A2 fill parser/economics do not consume directional field"
    },
    {
      "disposition": "PROVEN_NON_CONSUMED",
      "path": "Fill.outcome_side",
      "reason": "current A2 fill parser/economics do not consume directional field"
    },
    {
      "disposition": "PROVEN_NON_CONSUMED",
      "path": "GetPositionsResponse.event_positions",
      "reason": "Route A collects market_positions only; event-position rows do not gain fabricated shard identity"
    },
    {
      "disposition": "PROVEN_NON_CONSUMED",
      "path": "Order.created_time",
      "reason": "order time is not used by Route-A incident-window logic"
    },
    {
      "disposition": "PROVEN_NON_CONSUMED",
      "path": "Order.maker_fees_dollars",
      "reason": "current A2 neither parses nor uses this source-required order field"
    },
    {
      "disposition": "PROVEN_NON_CONSUMED",
      "path": "Order.maker_fill_cost_dollars",
      "reason": "current A2 neither parses nor uses this source-required order field"
    },
    {
      "disposition": "PROVEN_NON_CONSUMED",
      "path": "Order.taker_fees_dollars",
      "reason": "current A2 neither parses nor uses this source-required order field"
    },
    {
      "disposition": "PROVEN_NON_CONSUMED",
      "path": "Order.taker_fill_cost_dollars",
      "reason": "current A2 neither parses nor uses this source-required order field"
    },
    {
      "disposition": "PROVEN_NON_CONSUMED",
      "path": "Order.type",
      "reason": "full-schema field not consumed by Route A"
    },
    {
      "disposition": "PROVEN_NON_CONSUMED",
      "path": "Order.user_id",
      "reason": "full-schema field not consumed by Route A"
    },
    {
      "disposition": "PROVEN_PROVENANCE_ONLY",
      "path": "REV02.manifest_id",
      "reason": "provenance identity; not request/response semantics"
    },
    {
      "disposition": "PROVEN_PROVENANCE_ONLY",
      "path": "REV02.observed_at_utc",
      "reason": "retrieval metadata; not current Route-A behavior"
    },
    {
      "disposition": "PROVEN_PROVENANCE_ONLY",
      "path": "REV02.raw_openapi.*",
      "reason": "raw retrieval bookkeeping is recorded separately from execution-material projection"
    },
    {
      "disposition": "PROVEN_NON_CONSUMED",
      "path": "Settlement.market_result",
      "reason": "Revision-03 non-consumption preserved; no identity/economic/parser use"
    }
  ],
  "fill_temporal_contract": {
    "contract_id": "FILL_TEMPORAL_CONTRACT_REV04",
    "current_a2_runtime_contract": {
      "both_absent_or_no_usable_string_behavior": "fill is not excluded by temporal filter; other identity/scope checks still apply",
      "both_present_conflict_behavior": "VALID_RFC3339_STRING_TS_WINS__NO_EQUALITY_COMPARISON",
      "both_present_equality_required": false,
      "created_time_parser": "if present: exact str + timezone-aware RFC3339; malformed => AUTHORITATIVE_RESPONSE_MALFORMED",
      "evaluation_upper_bound_comparison": "inclusive: fill_time <= evaluation snapshot",
      "incident_lower_bound_comparison": "inclusive: fill_time >= incident lower bound",
      "integer_ts_conversion_to_datetime": "NONE",
      "outside_interval_behavior": "fill excluded from incident-scope evidence",
      "selection_precedence": [
        "valid RFC3339 string ts",
        "valid RFC3339 string created_time",
        "NO_USABLE_STRING_TIMESTAMP"
      ],
      "source_conforming_integer_ts_behavior": "retained as authoritative parsed field but not selected as fill_time; created_time is fallback if valid string",
      "timezone_rule": "timezone-aware RFC3339; non-zero offsets accepted; not UTC-only",
      "ts_parser": "if present: exact int (bool prohibited) OR timezone-aware RFC3339 str; malformed => AUTHORITATIVE_RESPONSE_MALFORMED"
    },
    "fields_inspected": [
      "created_time",
      "ts"
    ],
    "functional_change": "NO_RUNTIME_CHANGE__FREEZE_CURRENT_A2_BEHAVIOR",
    "source_operations": [
      "HISTORICAL_FILLS",
      "LIVE_FILLS"
    ],
    "source_structural_contract": {
      "created_time": {
        "format": "date-time",
        "nullability": "NULL_PROHIBITED",
        "requiredness": "SOURCE_OPTIONAL",
        "source_pointer": "#/components/schemas/Fill/properties/created_time",
        "type": "string"
      },
      "ts": {
        "format": "int64",
        "nullability": "NULL_PROHIBITED",
        "requiredness": "SOURCE_OPTIONAL",
        "source_pointer": "#/components/schemas/Fill/properties/ts",
        "type": "integer"
      }
    }
  },
  "historical_partition": {
    "cutoffs_move_forward": true,
    "positions_archived_per_whole_event": true,
    "retention_lower_bound": "NOT_EXPOSED",
    "target_live_window": "3 months"
  },
  "market_result_contract": {
    "a3_compare": false,
    "a3_economic_use": false,
    "a3_identity_use": false,
    "a3_parse": false,
    "absence_alone_malformed": false,
    "classification": "NOT_CONFIRMED__NOT_EXECUTION_MATERIAL",
    "conflict_consequence": "FULL_SCHEMA_PROVENANCE_ONLY__NO_A3_GATE_FAILURE_UNLESS_A_CONSUMED_SEMANTIC_CHANGES",
    "openapi_copy_observation": "PROPERTY_PRESENT_AND_SOURCE_REQUIRED_IN_USER_SUPPLIED_CURRENT_OPENAPI_COPY",
    "rendered_observation": "POSITIVELY_EXPOSED_AS_CHILD_IN_CURRENT_RENDERED_RESEARCH_INTERFACE"
  },
  "normalization_revision": 4,
  "official_source_scope": "docs.kalshi.com only",
  "operations": {
    "EXACT_ORDER": {
      "authentication": "AUTHENTICATED",
      "documented_http_statuses": [
        200,
        401,
        404,
        500
      ],
      "http_404_nonexistence_theorem": "NOT_EXPOSED",
      "method": "GET",
      "pagination": false,
      "path": "/trade-api/v2/portfolio/orders/{order_id}",
      "path_parameters": [
        {
          "arb_request_use": "REQUIRED_PATH_SUBSTITUTION",
          "name": "order_id",
          "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_STRING__SLASH_QUESTION_HASH_PROHIBITED",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_REQUIRED",
          "source_type": "string"
        }
      ],
      "query_parameter_names": [],
      "query_parameters": [],
      "response_contract": {
        "container_fields": [
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER",
            "execution_categories": [
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "exact order wrapper",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "order",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "ORDER_OBJECT",
            "schema_ref": "#/components/schemas/Order",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetOrderResponse/properties/order",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "GetOrderResponse",
            "source_type": "object"
          }
        ],
        "fields": [
          {
            "absence_behavior": "STORED_NONE",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "STATUS_OR_STATE_FIELD"
            ],
            "execution_use": "duplicate/source compatibility only",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "book_side",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_OPAQUE_NONEMPTY_STRING",
            "schema_ref": "#/components/schemas/BookSide",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_enum": [
              "bid",
              "ask"
            ],
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/book_side",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "STORED_NONE",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "STATUS_OR_STATE_FIELD"
            ],
            "execution_use": "duplicate/source compatibility only",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "cancel_order_on_pause",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_AND_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_EXACT_BOOL",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/cancel_order_on_pause",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "Order",
            "source_type": "boolean"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_ORDER_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD"
            ],
            "execution_use": "immutable client-order identity match",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "client_order_id",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/client_order_id",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "ACCEPTED_AS_NONE_CURRENT_A2__NO_DEFAULT_TO_ZERO",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2__NO_DEFAULT",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "target shard scope if present",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "exchange_index",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_AND_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_EXACT_BUILTIN_INT__BOOL_PROHIBITED",
            "schema_ref": "#/components/schemas/ExchangeIndex",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/exchange_index",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "Order",
            "source_type": "integer"
          },
          {
            "absence_behavior": "NOT_EXPOSED_ECONOMIC_MATCH",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "order/fill quantity reconciliation when exposed",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "fill_count_fp",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointCount",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/fill_count_fp",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "NOT_EXPOSED_ECONOMIC_MATCH",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "order/fill quantity reconciliation when exposed",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "initial_count_fp",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointCount",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/initial_count_fp",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "STORED_NONE",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "duplicate/source compatibility only",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "no_price_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/no_price_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_ORDER_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD"
            ],
            "execution_use": "identity/dedup/binding",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "order_id",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/order_id",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "STORED_NONE",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "STATUS_OR_STATE_FIELD"
            ],
            "execution_use": "duplicate/source compatibility only",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "outcome_side",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_OPAQUE_NONEMPTY_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_enum": [
              "yes",
              "no"
            ],
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/outcome_side",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "NOT_EXPOSED_ECONOMIC_MATCH",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "order/fill quantity reconciliation when exposed",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "remaining_count_fp",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointCount",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/remaining_count_fp",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "MISSING_BECOMES_NONE_AND_IS_NOT_RESTING_CURRENT_A2",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2__SOURCE_REQUIRED",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "STATUS_OR_STATE_FIELD"
            ],
            "execution_use": "active-vs-terminal classification",
            "invalid_type_behavior": "AUTHORITATIVE_SOURCE_DRIFT_SPEC_REVISION_REQUIRED_FOR_UNKNOWN_ENUM__MALFORMED_FOR_INVALID_TYPE",
            "name": "status",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_OPAQUE_STRING_AND_ENUM_RESTING_CANCELED_EXECUTED",
            "schema_ref": "#/components/schemas/OrderStatus",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_enum": [
              "resting",
              "canceled",
              "executed"
            ],
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/status",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_ORDER_FIELD",
            "execution_categories": [
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "target subaccount scope",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "subaccount_number",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_BUT_ARB_REQUIRED",
            "runtime_parser_or_normalization": "EXACT_BUILTIN_INT__BOOL_PROHIBITED",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PERMITTED",
            "source_pointer": "#/components/schemas/Order/properties/subaccount_number",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "Order",
            "source_type": "integer"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_ORDER_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD",
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "target market scope",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "ticker",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/ticker",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "STORED_NONE",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "duplicate/source compatibility only",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "yes_price_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/yes_price_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          }
        ]
      },
      "source_refs": {
        "comparison_role": "PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION",
        "openapi_operation_pointer": "#/paths/~1portfolio~1orders~1{order_id}/get",
        "rendered_url": "https://docs.kalshi.com/api-reference/orders/get-order"
      }
    },
    "HISTORICAL_CUTOFF": {
      "authentication": "PUBLIC",
      "method": "GET",
      "negative_semantics": "PARTITION_BOUNDARY_ONLY__NOT_RETENTION_LOWER_BOUND",
      "pagination": false,
      "path": "/trade-api/v2/historical/cutoff",
      "query_parameter_names": [],
      "query_parameters": [],
      "response_contract": {
        "container_fields": [],
        "fields": [
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_UTC_RFC3339_CUTOFF_FIELD",
            "execution_categories": [
              "NEGATIVE_THEOREM_FIELD",
              "PARTITION_SEMANTIC",
              "TEMPORAL_FIELD"
            ],
            "execution_use": "pre/post partition boundary and moving-cutoff coverage theorem",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "market_positions_last_updated_ts",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_BUT_ARB_REQUIRED",
            "runtime_parser_or_normalization": "UTC_RFC3339_ZERO_OFFSET_REQUIRED",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "date-time",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetHistoricalCutoffResponse/properties/market_positions_last_updated_ts",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "GetHistoricalCutoffResponse",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_UTC_RFC3339_CUTOFF_FIELD",
            "execution_categories": [
              "NEGATIVE_THEOREM_FIELD",
              "PARTITION_SEMANTIC",
              "TEMPORAL_FIELD"
            ],
            "execution_use": "pre/post partition boundary and moving-cutoff coverage theorem",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "market_settled_ts",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "UTC_RFC3339_ZERO_OFFSET_REQUIRED",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "date-time",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetHistoricalCutoffResponse/properties/market_settled_ts",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "GetHistoricalCutoffResponse",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_UTC_RFC3339_CUTOFF_FIELD",
            "execution_categories": [
              "NEGATIVE_THEOREM_FIELD",
              "PARTITION_SEMANTIC",
              "TEMPORAL_FIELD"
            ],
            "execution_use": "pre/post partition boundary and moving-cutoff coverage theorem",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "orders_updated_ts",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "UTC_RFC3339_ZERO_OFFSET_REQUIRED",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "date-time",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetHistoricalCutoffResponse/properties/orders_updated_ts",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "GetHistoricalCutoffResponse",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_UTC_RFC3339_CUTOFF_FIELD",
            "execution_categories": [
              "NEGATIVE_THEOREM_FIELD",
              "PARTITION_SEMANTIC",
              "TEMPORAL_FIELD"
            ],
            "execution_use": "pre/post partition boundary and moving-cutoff coverage theorem",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "trades_created_ts",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "UTC_RFC3339_ZERO_OFFSET_REQUIRED",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "date-time",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetHistoricalCutoffResponse/properties/trades_created_ts",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "GetHistoricalCutoffResponse",
            "source_type": "string"
          }
        ]
      },
      "source_refs": {
        "comparison_role": "PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION",
        "openapi_operation_pointer": "#/paths/~1historical~1cutoff/get",
        "rendered_url": "https://docs.kalshi.com/api-reference/historical/get-historical-cutoff-timestamps"
      }
    },
    "HISTORICAL_FILLS": {
      "authentication": "AUTHENTICATED",
      "exchange_index_a3_contract": "REQUIRED_NON_NULL_EXACT_BUILTIN_INT_GE_0__TARGET_SCOPE_0",
      "fill_temporal_contract_ref": "FILL_TEMPORAL_CONTRACT_REV04",
      "limit_range": [
        1,
        1000
      ],
      "method": "GET",
      "pagination": true,
      "path": "/trade-api/v2/historical/fills",
      "query_parameter_names": [
        "cursor",
        "limit",
        "max_ts",
        "ticker"
      ],
      "query_parameters": [
        {
          "arb_request_use": "SENT_AFTER_FIRST_PAGE",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "cursor",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": 100,
          "maximum": 1000,
          "minimum": 1,
          "name": "limit",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int64",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "max_ts",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int64",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "ticker",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        }
      ],
      "response_contract": {
        "container_fields": [
          {
            "absence_behavior": "PAGINATION_CURSOR_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER",
            "execution_categories": [
              "PAGINATION_FIELD"
            ],
            "execution_use": "pagination continuation",
            "invalid_type_behavior": "PAGINATION_CURSOR_MALFORMED",
            "name": "cursor",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetFillsResponse/properties/cursor",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "GetFillsResponse",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER",
            "execution_categories": [
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "fill record stream",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "fills",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "ARRAY_OF_FILL_OBJECTS",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetFillsResponse/properties/fills",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "GetFillsResponse",
            "source_type": "array"
          }
        ],
        "fields": [
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "canonical fill quantity",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "count_fp",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "FIXED_POINT_COUNT_2DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointCount",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/count_fp",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_USABLE_TIME_FROM_THIS_FIELD",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT__USED_BY_FILL_TEMPORAL_SELECTION_AS_FROZEN",
            "execution_categories": [
              "TEMPORAL_FIELD"
            ],
            "execution_use": "fallback fill-time field after string ts",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "created_time",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_AND_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_TIMEZONE_AWARE_RFC3339_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "date-time",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/created_time",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "Fill",
            "source_type": "string",
            "temporal_precedence": "USED_ONLY_IF_TS_IS_NOT_A_VALID_RFC3339_STRING"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED_BY_REV03",
            "arb_requiredness": "ARB_REQUIRED_BY_REV03",
            "current_a2_use": "PARSED_IF_PRESENT_AND_SCOPE_CHECKED__REV03_REQUIRES_PRESENT",
            "execution_categories": [
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "target shard scope; duplicate compatibility",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "exchange_index",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "EXACT_BUILTIN_INT__BOOL_PROHIBITED__GE_0",
            "schema_ref": "#/components/schemas/ExchangeIndex",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_domain_rule": "INTEGER_GE_0_BY_ARB_REV03; OpenAPI ExchangeIndex has integer type without minimum",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/exchange_index",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "integer"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "canonical fee cost",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "fee_cost",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/fee_cost",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD"
            ],
            "execution_use": "dedupe primary identity",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "fill_id",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/fill_id",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "STATUS_OR_STATE_FIELD"
            ],
            "execution_use": "maker/taker economic invariant",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "is_taker",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "EXACT_BOOL",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/is_taker",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "boolean"
          },
          {
            "absence_behavior": "STORED_NONE_CURRENT_A2",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2__SOURCE_REQUIRED",
            "current_a2_use": "PARSED_IF_PRESENT_AND_SCOPE_CHECKED",
            "execution_categories": [
              "IDENTITY_FIELD",
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "secondary market-scope equality if present",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "market_ticker",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_OPAQUE_NONEMPTY_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/market_ticker",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "duplicate/source compatibility",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "no_price_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/no_price_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD"
            ],
            "execution_use": "candidate/bound-order identity",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "order_id",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/order_id",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "target subaccount scope",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "subaccount_number",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_BUT_ARB_REQUIRED",
            "runtime_parser_or_normalization": "EXACT_BUILTIN_INT__BOOL_PROHIBITED",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PERMITTED",
            "source_pointer": "#/components/schemas/Fill/properties/subaccount_number",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "Fill",
            "source_type": "integer"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD",
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "target market scope",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "ticker",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/ticker",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD"
            ],
            "execution_use": "identity/duplicate compatibility",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "trade_id",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/trade_id",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_USABLE_TIME_FROM_THIS_FIELD",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT__USED_BY_FILL_TEMPORAL_SELECTION_AS_FROZEN",
            "execution_categories": [
              "TEMPORAL_FIELD"
            ],
            "execution_use": "preferred fill-time only when runtime value is RFC3339 string; integer retained but not time-filtered",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "ts",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_AND_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "CURRENT_A2_ACCEPTS_EXACT_INT_OR_TIMEZONE_AWARE_RFC3339_STRING__SOURCE_BASELINE_IS_INT64",
            "runtime_source_type_divergence_note": "SOURCE_EXPECTS_INTEGER_INT64; CURRENT_A2 ALSO_ACCEPTS_RFC3339_STRING_FOR_BACKWARD_COMPATIBILITY",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "int64",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/ts",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "Fill",
            "source_type": "integer"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "filled principal and price bound",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "yes_price_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/yes_price_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          }
        ]
      },
      "retention_lower_bound": "NOT_EXPOSED",
      "source_refs": {
        "comparison_role": "PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION",
        "openapi_operation_pointer": "#/paths/~1historical~1fills/get",
        "rendered_url": "https://docs.kalshi.com/api-reference/historical/get-historical-fills"
      },
      "unsupported_query_fields": [
        "exchange_index",
        "min_ts",
        "order_id",
        "subaccount"
      ]
    },
    "HISTORICAL_ORDERS": {
      "authentication": "AUTHENTICATED",
      "limit_range": [
        1,
        1000
      ],
      "method": "GET",
      "pagination": true,
      "partition_semantics": "canceled/executed orders older than orders_updated_ts",
      "path": "/trade-api/v2/historical/orders",
      "query_parameter_names": [
        "cursor",
        "limit",
        "max_ts",
        "ticker"
      ],
      "query_parameters": [
        {
          "arb_request_use": "SENT_AFTER_FIRST_PAGE",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "cursor",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": 100,
          "maximum": 1000,
          "minimum": 1,
          "name": "limit",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int64",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "max_ts",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int64",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "ticker",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        }
      ],
      "response_contract": {
        "container_fields": [
          {
            "absence_behavior": "PAGINATION_CURSOR_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER",
            "execution_categories": [
              "PAGINATION_FIELD"
            ],
            "execution_use": "pagination continuation",
            "invalid_type_behavior": "PAGINATION_CURSOR_MALFORMED",
            "name": "cursor",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetOrdersResponse/properties/cursor",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "GetOrdersResponse",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER",
            "execution_categories": [
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "order record stream",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "orders",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "ARRAY_OF_ORDER_OBJECTS",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetOrdersResponse/properties/orders",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "GetOrdersResponse",
            "source_type": "array"
          }
        ],
        "fields": [
          {
            "absence_behavior": "STORED_NONE",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "STATUS_OR_STATE_FIELD"
            ],
            "execution_use": "duplicate/source compatibility only",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "book_side",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_OPAQUE_NONEMPTY_STRING",
            "schema_ref": "#/components/schemas/BookSide",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_enum": [
              "bid",
              "ask"
            ],
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/book_side",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "STORED_NONE",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "STATUS_OR_STATE_FIELD"
            ],
            "execution_use": "duplicate/source compatibility only",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "cancel_order_on_pause",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_AND_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_EXACT_BOOL",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/cancel_order_on_pause",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "Order",
            "source_type": "boolean"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_ORDER_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD"
            ],
            "execution_use": "immutable client-order identity match",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "client_order_id",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/client_order_id",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "ACCEPTED_AS_NONE_CURRENT_A2__NO_DEFAULT_TO_ZERO",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2__NO_DEFAULT",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "target shard scope if present",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "exchange_index",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_AND_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_EXACT_BUILTIN_INT__BOOL_PROHIBITED",
            "schema_ref": "#/components/schemas/ExchangeIndex",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/exchange_index",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "Order",
            "source_type": "integer"
          },
          {
            "absence_behavior": "NOT_EXPOSED_ECONOMIC_MATCH",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "order/fill quantity reconciliation when exposed",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "fill_count_fp",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointCount",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/fill_count_fp",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "NOT_EXPOSED_ECONOMIC_MATCH",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "order/fill quantity reconciliation when exposed",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "initial_count_fp",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointCount",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/initial_count_fp",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "STORED_NONE",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "duplicate/source compatibility only",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "no_price_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/no_price_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_ORDER_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD"
            ],
            "execution_use": "identity/dedup/binding",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "order_id",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/order_id",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "STORED_NONE",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "STATUS_OR_STATE_FIELD"
            ],
            "execution_use": "duplicate/source compatibility only",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "outcome_side",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_OPAQUE_NONEMPTY_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_enum": [
              "yes",
              "no"
            ],
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/outcome_side",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "NOT_EXPOSED_ECONOMIC_MATCH",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "order/fill quantity reconciliation when exposed",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "remaining_count_fp",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointCount",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/remaining_count_fp",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "MISSING_BECOMES_NONE_AND_IS_NOT_RESTING_CURRENT_A2",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2__SOURCE_REQUIRED",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "STATUS_OR_STATE_FIELD"
            ],
            "execution_use": "active-vs-terminal classification",
            "invalid_type_behavior": "AUTHORITATIVE_SOURCE_DRIFT_SPEC_REVISION_REQUIRED_FOR_UNKNOWN_ENUM__MALFORMED_FOR_INVALID_TYPE",
            "name": "status",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_OPAQUE_STRING_AND_ENUM_RESTING_CANCELED_EXECUTED",
            "schema_ref": "#/components/schemas/OrderStatus",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_enum": [
              "resting",
              "canceled",
              "executed"
            ],
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/status",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_ORDER_FIELD",
            "execution_categories": [
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "target subaccount scope",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "subaccount_number",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_BUT_ARB_REQUIRED",
            "runtime_parser_or_normalization": "EXACT_BUILTIN_INT__BOOL_PROHIBITED",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PERMITTED",
            "source_pointer": "#/components/schemas/Order/properties/subaccount_number",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "Order",
            "source_type": "integer"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_ORDER_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD",
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "target market scope",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "ticker",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/ticker",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "STORED_NONE",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "duplicate/source compatibility only",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "yes_price_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/yes_price_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          }
        ]
      },
      "retention_lower_bound": "NOT_EXPOSED",
      "source_refs": {
        "comparison_role": "PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION",
        "openapi_operation_pointer": "#/paths/~1historical~1orders/get",
        "rendered_url": "https://docs.kalshi.com/api-reference/historical/get-historical-orders"
      },
      "unsupported_query_fields": [
        "event_ticker",
        "exchange_index",
        "min_ts",
        "status",
        "subaccount"
      ]
    },
    "HISTORICAL_POSITIONS": {
      "authentication": "AUTHENTICATED",
      "exchange_index_a3_contract": "REQUIRED_NON_NULL_EXACT_BUILTIN_INT_GE_0__TARGET_SCOPE_0_FOR_TARGET_SUPPORTING_ROWS",
      "limit_range": [
        1,
        1000
      ],
      "method": "GET",
      "pagination": true,
      "partition_semantics": "settled positions archived per whole event; never split across live/historical; cutoff field market_positions_last_updated_ts",
      "path": "/trade-api/v2/historical/positions",
      "query_parameter_names": [
        "cursor",
        "event_ticker",
        "limit",
        "ticker"
      ],
      "query_parameters": [
        {
          "arb_request_use": "SENT_AFTER_FIRST_PAGE",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "cursor",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        },
        {
          "arb_request_use": "NOT_SENT__SOURCE_CONTRACT_OR_PAIR_DERIVATION_ONLY",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "event_ticker",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": 100,
          "maximum": 1000,
          "minimum": 1,
          "name": "limit",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int64",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "ticker",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        }
      ],
      "response_contract": {
        "container_fields": [
          {
            "absence_behavior": "PAGINATION_CURSOR_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER",
            "execution_categories": [
              "PAGINATION_FIELD"
            ],
            "execution_use": "pagination continuation",
            "invalid_type_behavior": "PAGINATION_CURSOR_MALFORMED",
            "name": "cursor",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_BUT_ARB_REQUIRED",
            "runtime_parser_or_normalization": "EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetPositionsResponse/properties/cursor",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "GetPositionsResponse",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER",
            "execution_categories": [
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "supporting market-position stream",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "market_positions",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "ARRAY_OF_MARKET_POSITION_OBJECTS",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetPositionsResponse/properties/market_positions",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "GetPositionsResponse",
            "source_type": "array"
          }
        ],
        "fields": [
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED_BY_REV03",
            "arb_requiredness": "ARB_REQUIRED_BY_REV03",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__REV03_REQUIRES_PRESERVE/VALIDATE",
            "execution_categories": [
              "SCOPE_SHARD_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "target shard scope for market_positions row",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "exchange_index",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "REV03_REQUIRES_EXACT_BUILTIN_INT__BOOL_PROHIBITED__GE_0",
            "schema_ref": "#/components/schemas/ExchangeIndex",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/MarketPosition/properties/exchange_index",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "MarketPosition",
            "source_type": "integer"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "fees_paid_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/MarketPosition/properties/fees_paid_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "MarketPosition",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "SUPPORTING_EVIDENCE_FIELD",
              "TEMPORAL_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "last_updated_ts",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_DATE_TIME_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "date-time",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/MarketPosition/properties/last_updated_ts",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "MarketPosition",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "market_exposure_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/MarketPosition/properties/market_exposure_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "MarketPosition",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "position_fp",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_COUNT_STRING",
            "schema_ref": "#/components/schemas/FixedPointCount",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/MarketPosition/properties/position_fp",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "MarketPosition",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "realized_pnl_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/MarketPosition/properties/realized_pnl_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "MarketPosition",
            "source_type": "string"
          },
          {
            "absence_behavior": "SOURCE_REQUIRES; CURRENT_A2 raw.get could treat absence as target-like; later correction should preserve source-required baseline",
            "arb_requiredness": "ARB_REQUIRED_FOR_TARGET_SUPPORTING_ROW",
            "current_a2_use": "RAW_FIELD_READ_FOR_TARGET_TICKER_FILTER",
            "execution_categories": [
              "IDENTITY_FIELD",
              "SCOPE_SHARD_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "target supporting-row selection",
            "invalid_type_behavior": "NON_STRING_OR_OTHER_TYPE_NOT_VALIDATED_CURRENT_A2",
            "name": "ticker",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "CURRENT_A2_READS_RAW_VALUE__EXACT_TARGET_TICKER_EQUALITY_IF_PRESENT",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/MarketPosition/properties/ticker",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "MarketPosition",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "total_traded_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/MarketPosition/properties/total_traded_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "MarketPosition",
            "source_type": "string"
          }
        ]
      },
      "response_subaccount_field": "NOT_EXPOSED",
      "retention_lower_bound": "NOT_EXPOSED",
      "source_refs": {
        "comparison_role": "PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION",
        "openapi_operation_pointer": "#/paths/~1historical~1positions/get",
        "rendered_url": "https://docs.kalshi.com/api-reference/historical/get-historical-positions"
      },
      "unsupported_query_fields": [
        "count_filter",
        "exchange_index",
        "subaccount"
      ]
    },
    "LIVE_FILLS": {
      "authentication": "AUTHENTICATED",
      "exchange_index_a3_contract": "REQUIRED_NON_NULL_EXACT_BUILTIN_INT_GE_0__TARGET_SCOPE_0",
      "fill_temporal_contract_ref": "FILL_TEMPORAL_CONTRACT_REV04",
      "limit_range": [
        1,
        1000
      ],
      "method": "GET",
      "pagination": true,
      "partition_semantics": "fills before trades_created_ts historical",
      "path": "/trade-api/v2/portfolio/fills",
      "query_parameter_names": [
        "cursor",
        "exchange_index",
        "limit",
        "max_ts",
        "min_ts",
        "order_id",
        "subaccount",
        "ticker"
      ],
      "query_parameters": [
        {
          "arb_request_use": "SENT_AFTER_FIRST_PAGE",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "cursor",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": 0,
          "name": "exchange_index",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int32",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": 100,
          "maximum": 1000,
          "minimum": 1,
          "name": "limit",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int64",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "max_ts",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int64",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "min_ts",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int64",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_IF_BOUND_ORDER",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "order_id",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "subaccount",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "ticker",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        }
      ],
      "response_contract": {
        "container_fields": [
          {
            "absence_behavior": "PAGINATION_CURSOR_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER",
            "execution_categories": [
              "PAGINATION_FIELD"
            ],
            "execution_use": "pagination continuation",
            "invalid_type_behavior": "PAGINATION_CURSOR_MALFORMED",
            "name": "cursor",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetFillsResponse/properties/cursor",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "GetFillsResponse",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER",
            "execution_categories": [
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "fill record stream",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "fills",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "ARRAY_OF_FILL_OBJECTS",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetFillsResponse/properties/fills",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "GetFillsResponse",
            "source_type": "array"
          }
        ],
        "fields": [
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "canonical fill quantity",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "count_fp",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "FIXED_POINT_COUNT_2DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointCount",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/count_fp",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_USABLE_TIME_FROM_THIS_FIELD",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT__USED_BY_FILL_TEMPORAL_SELECTION_AS_FROZEN",
            "execution_categories": [
              "TEMPORAL_FIELD"
            ],
            "execution_use": "fallback fill-time field after string ts",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "created_time",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_AND_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_TIMEZONE_AWARE_RFC3339_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "date-time",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/created_time",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "Fill",
            "source_type": "string",
            "temporal_precedence": "USED_ONLY_IF_TS_IS_NOT_A_VALID_RFC3339_STRING"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED_BY_REV03",
            "arb_requiredness": "ARB_REQUIRED_BY_REV03",
            "current_a2_use": "PARSED_IF_PRESENT_AND_SCOPE_CHECKED__REV03_REQUIRES_PRESENT",
            "execution_categories": [
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "target shard scope; duplicate compatibility",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "exchange_index",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "EXACT_BUILTIN_INT__BOOL_PROHIBITED__GE_0",
            "schema_ref": "#/components/schemas/ExchangeIndex",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_domain_rule": "INTEGER_GE_0_BY_ARB_REV03; OpenAPI ExchangeIndex has integer type without minimum",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/exchange_index",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "integer"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "canonical fee cost",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "fee_cost",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/fee_cost",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD"
            ],
            "execution_use": "dedupe primary identity",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "fill_id",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/fill_id",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "STATUS_OR_STATE_FIELD"
            ],
            "execution_use": "maker/taker economic invariant",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "is_taker",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "EXACT_BOOL",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/is_taker",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "boolean"
          },
          {
            "absence_behavior": "STORED_NONE_CURRENT_A2",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2__SOURCE_REQUIRED",
            "current_a2_use": "PARSED_IF_PRESENT_AND_SCOPE_CHECKED",
            "execution_categories": [
              "IDENTITY_FIELD",
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "secondary market-scope equality if present",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "market_ticker",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_OPAQUE_NONEMPTY_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/market_ticker",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "duplicate/source compatibility",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "no_price_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/no_price_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD"
            ],
            "execution_use": "candidate/bound-order identity",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "order_id",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/order_id",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "target subaccount scope",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "subaccount_number",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_BUT_ARB_REQUIRED",
            "runtime_parser_or_normalization": "EXACT_BUILTIN_INT__BOOL_PROHIBITED",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PERMITTED",
            "source_pointer": "#/components/schemas/Fill/properties/subaccount_number",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "Fill",
            "source_type": "integer"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD",
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "target market scope",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "ticker",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/ticker",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD"
            ],
            "execution_use": "identity/duplicate compatibility",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "trade_id",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/trade_id",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_USABLE_TIME_FROM_THIS_FIELD",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT__USED_BY_FILL_TEMPORAL_SELECTION_AS_FROZEN",
            "execution_categories": [
              "TEMPORAL_FIELD"
            ],
            "execution_use": "preferred fill-time only when runtime value is RFC3339 string; integer retained but not time-filtered",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "ts",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_AND_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "CURRENT_A2_ACCEPTS_EXACT_INT_OR_TIMEZONE_AWARE_RFC3339_STRING__SOURCE_BASELINE_IS_INT64",
            "runtime_source_type_divergence_note": "SOURCE_EXPECTS_INTEGER_INT64; CURRENT_A2 ALSO_ACCEPTS_RFC3339_STRING_FOR_BACKWARD_COMPATIBILITY",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "int64",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/ts",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "Fill",
            "source_type": "integer"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_FILL_FIELD",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "filled principal and price bound",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "yes_price_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Fill/properties/yes_price_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Fill",
            "source_type": "string"
          }
        ]
      },
      "source_refs": {
        "comparison_role": "PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION",
        "openapi_operation_pointer": "#/paths/~1portfolio~1fills/get",
        "rendered_url": "https://docs.kalshi.com/api-reference/portfolio/get-fills"
      }
    },
    "LIVE_ORDERS": {
      "authentication": "AUTHENTICATED",
      "limit_range": [
        1,
        1000
      ],
      "method": "GET",
      "pagination": true,
      "partition_semantics": "resting always live; canceled/fully executed before orders_updated_ts historical",
      "path": "/trade-api/v2/portfolio/orders",
      "query_parameter_names": [
        "cursor",
        "event_ticker",
        "exchange_index",
        "limit",
        "max_ts",
        "min_ts",
        "status",
        "subaccount",
        "ticker"
      ],
      "query_parameters": [
        {
          "arb_request_use": "SENT_AFTER_FIRST_PAGE",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "cursor",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        },
        {
          "arb_request_use": "NOT_SENT__SOURCE_CONTRACT_OR_PAIR_DERIVATION_ONLY",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "event_ticker",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": 0,
          "name": "exchange_index",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int32",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": 100,
          "maximum": 1000,
          "minimum": 1,
          "name": "limit",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int64",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "max_ts",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int64",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "min_ts",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int64",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "NOT_SENT__SOURCE_CONTRACT_OR_PAIR_DERIVATION_ONLY",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "status",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "subaccount",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "ticker",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        }
      ],
      "request_scope_fields": [
        "exchange_index",
        "subaccount",
        "ticker"
      ],
      "response_contract": {
        "container_fields": [
          {
            "absence_behavior": "PAGINATION_CURSOR_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER",
            "execution_categories": [
              "PAGINATION_FIELD"
            ],
            "execution_use": "pagination continuation",
            "invalid_type_behavior": "PAGINATION_CURSOR_MALFORMED",
            "name": "cursor",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetOrdersResponse/properties/cursor",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "GetOrdersResponse",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER",
            "execution_categories": [
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "order record stream",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "orders",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "ARRAY_OF_ORDER_OBJECTS",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetOrdersResponse/properties/orders",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "GetOrdersResponse",
            "source_type": "array"
          }
        ],
        "fields": [
          {
            "absence_behavior": "STORED_NONE",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "STATUS_OR_STATE_FIELD"
            ],
            "execution_use": "duplicate/source compatibility only",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "book_side",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_OPAQUE_NONEMPTY_STRING",
            "schema_ref": "#/components/schemas/BookSide",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_enum": [
              "bid",
              "ask"
            ],
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/book_side",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "STORED_NONE",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "STATUS_OR_STATE_FIELD"
            ],
            "execution_use": "duplicate/source compatibility only",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "cancel_order_on_pause",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_AND_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_EXACT_BOOL",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/cancel_order_on_pause",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "Order",
            "source_type": "boolean"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_ORDER_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD"
            ],
            "execution_use": "immutable client-order identity match",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "client_order_id",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/client_order_id",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "ACCEPTED_AS_NONE_CURRENT_A2__NO_DEFAULT_TO_ZERO",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2__NO_DEFAULT",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "target shard scope if present",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "exchange_index",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_AND_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_EXACT_BUILTIN_INT__BOOL_PROHIBITED",
            "schema_ref": "#/components/schemas/ExchangeIndex",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/exchange_index",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "Order",
            "source_type": "integer"
          },
          {
            "absence_behavior": "NOT_EXPOSED_ECONOMIC_MATCH",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "order/fill quantity reconciliation when exposed",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "fill_count_fp",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointCount",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/fill_count_fp",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "NOT_EXPOSED_ECONOMIC_MATCH",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "order/fill quantity reconciliation when exposed",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "initial_count_fp",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointCount",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/initial_count_fp",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "STORED_NONE",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "duplicate/source compatibility only",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "no_price_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/no_price_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_ORDER_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD"
            ],
            "execution_use": "identity/dedup/binding",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "order_id",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/order_id",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "STORED_NONE",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "STATUS_OR_STATE_FIELD"
            ],
            "execution_use": "duplicate/source compatibility only",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "outcome_side",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_OPAQUE_NONEMPTY_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_enum": [
              "yes",
              "no"
            ],
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/outcome_side",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "NOT_EXPOSED_ECONOMIC_MATCH",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "order/fill quantity reconciliation when exposed",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "remaining_count_fp",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointCount",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/remaining_count_fp",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "MISSING_BECOMES_NONE_AND_IS_NOT_RESTING_CURRENT_A2",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2__SOURCE_REQUIRED",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "STATUS_OR_STATE_FIELD"
            ],
            "execution_use": "active-vs-terminal classification",
            "invalid_type_behavior": "AUTHORITATIVE_SOURCE_DRIFT_SPEC_REVISION_REQUIRED_FOR_UNKNOWN_ENUM__MALFORMED_FOR_INVALID_TYPE",
            "name": "status",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_OPAQUE_STRING_AND_ENUM_RESTING_CANCELED_EXECUTED",
            "schema_ref": "#/components/schemas/OrderStatus",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_enum": [
              "resting",
              "canceled",
              "executed"
            ],
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/status",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_ORDER_FIELD",
            "execution_categories": [
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "target subaccount scope",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "subaccount_number",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_BUT_ARB_REQUIRED",
            "runtime_parser_or_normalization": "EXACT_BUILTIN_INT__BOOL_PROHIBITED",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PERMITTED",
            "source_pointer": "#/components/schemas/Order/properties/subaccount_number",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "Order",
            "source_type": "integer"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_ORDER_FIELD",
            "execution_categories": [
              "IDENTITY_FIELD",
              "SCOPE_SHARD_FIELD"
            ],
            "execution_use": "target market scope",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "ticker",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "OPAQUE_NONEMPTY_EXACT_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/ticker",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          },
          {
            "absence_behavior": "STORED_NONE",
            "arb_requiredness": "ARB_OPTIONAL_CURRENT_A2",
            "current_a2_use": "PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION",
            "execution_categories": [
              "ECONOMIC_FIELD"
            ],
            "execution_use": "duplicate/source compatibility only",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "yes_price_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_ARB_OPTIONAL",
            "runtime_parser_or_normalization": "IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Order/properties/yes_price_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Order",
            "source_type": "string"
          }
        ]
      },
      "source_refs": {
        "comparison_role": "PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION",
        "openapi_operation_pointer": "#/paths/~1portfolio~1orders/get",
        "rendered_url": "https://docs.kalshi.com/api-reference/orders/get-orders"
      }
    },
    "LIVE_POSITIONS": {
      "authentication": "AUTHENTICATED",
      "exchange_index_a3_contract": "REQUIRED_NON_NULL_EXACT_BUILTIN_INT_GE_0__TARGET_SCOPE_0_FOR_TARGET_SUPPORTING_ROWS",
      "limit_range": [
        1,
        1000
      ],
      "method": "GET",
      "pagination": true,
      "partition_semantics": "unsettled positions always live; settled positions may move by whole event to historical",
      "path": "/trade-api/v2/portfolio/positions",
      "query_parameter_names": [
        "count_filter",
        "cursor",
        "event_ticker",
        "exchange_index",
        "limit",
        "subaccount",
        "ticker"
      ],
      "query_parameters": [
        {
          "arb_request_use": "NOT_SENT__SOURCE_CONTRACT_OR_PAIR_DERIVATION_ONLY",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "count_filter",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        },
        {
          "arb_request_use": "SENT_AFTER_FIRST_PAGE",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "cursor",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        },
        {
          "arb_request_use": "NOT_SENT__SOURCE_CONTRACT_OR_PAIR_DERIVATION_ONLY",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "event_ticker",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": 0,
          "name": "exchange_index",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int32",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": 100,
          "maximum": 1000,
          "minimum": 1,
          "name": "limit",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int32",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "subaccount",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "ticker",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        }
      ],
      "request_scope_fields": [
        "exchange_index",
        "subaccount",
        "ticker"
      ],
      "response_contract": {
        "container_fields": [
          {
            "absence_behavior": "PAGINATION_CURSOR_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER",
            "execution_categories": [
              "PAGINATION_FIELD"
            ],
            "execution_use": "pagination continuation",
            "invalid_type_behavior": "PAGINATION_CURSOR_MALFORMED",
            "name": "cursor",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_BUT_ARB_REQUIRED",
            "runtime_parser_or_normalization": "EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetPositionsResponse/properties/cursor",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "GetPositionsResponse",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER",
            "execution_categories": [
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "supporting market-position stream",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "market_positions",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "ARRAY_OF_MARKET_POSITION_OBJECTS",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetPositionsResponse/properties/market_positions",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "GetPositionsResponse",
            "source_type": "array"
          }
        ],
        "fields": [
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED_BY_REV03",
            "arb_requiredness": "ARB_REQUIRED_BY_REV03",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__REV03_REQUIRES_PRESERVE/VALIDATE",
            "execution_categories": [
              "SCOPE_SHARD_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "target shard scope for market_positions row",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "exchange_index",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "REV03_REQUIRES_EXACT_BUILTIN_INT__BOOL_PROHIBITED__GE_0",
            "schema_ref": "#/components/schemas/ExchangeIndex",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/MarketPosition/properties/exchange_index",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "MarketPosition",
            "source_type": "integer"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "fees_paid_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/MarketPosition/properties/fees_paid_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "MarketPosition",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "SUPPORTING_EVIDENCE_FIELD",
              "TEMPORAL_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "last_updated_ts",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_DATE_TIME_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "date-time",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/MarketPosition/properties/last_updated_ts",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "MarketPosition",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "market_exposure_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/MarketPosition/properties/market_exposure_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "MarketPosition",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "position_fp",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_COUNT_STRING",
            "schema_ref": "#/components/schemas/FixedPointCount",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/MarketPosition/properties/position_fp",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "MarketPosition",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "realized_pnl_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/MarketPosition/properties/realized_pnl_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "MarketPosition",
            "source_type": "string"
          },
          {
            "absence_behavior": "SOURCE_REQUIRES; CURRENT_A2 raw.get could treat absence as target-like; later correction should preserve source-required baseline",
            "arb_requiredness": "ARB_REQUIRED_FOR_TARGET_SUPPORTING_ROW",
            "current_a2_use": "RAW_FIELD_READ_FOR_TARGET_TICKER_FILTER",
            "execution_categories": [
              "IDENTITY_FIELD",
              "SCOPE_SHARD_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "target supporting-row selection",
            "invalid_type_behavior": "NON_STRING_OR_OTHER_TYPE_NOT_VALIDATED_CURRENT_A2",
            "name": "ticker",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "CURRENT_A2_READS_RAW_VALUE__EXACT_TARGET_TICKER_EQUALITY_IF_PRESENT",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/MarketPosition/properties/ticker",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "MarketPosition",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "total_traded_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/MarketPosition/properties/total_traded_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "MarketPosition",
            "source_type": "string"
          }
        ]
      },
      "response_subaccount_field": "NOT_EXPOSED",
      "source_refs": {
        "comparison_role": "PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION",
        "openapi_operation_pointer": "#/paths/~1portfolio~1positions/get",
        "rendered_url": "https://docs.kalshi.com/api-reference/portfolio/get-positions"
      }
    },
    "SETTLEMENTS": {
      "authentication": "AUTHENTICATED",
      "exchange_index_a3_contract": "REQUIRED_NON_NULL_EXACT_BUILTIN_INT_GE_0__TARGET_SCOPE_0_FOR_TARGET_SUPPORTING_ROWS",
      "limit_range": [
        1,
        1000
      ],
      "method": "GET",
      "pagination": true,
      "path": "/trade-api/v2/portfolio/settlements",
      "query_parameter_names": [
        "cursor",
        "event_ticker",
        "limit",
        "max_ts",
        "min_ts",
        "subaccount",
        "ticker"
      ],
      "query_parameters": [
        {
          "arb_request_use": "SENT_AFTER_FIRST_PAGE",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "cursor",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        },
        {
          "arb_request_use": "NOT_SENT__SOURCE_CONTRACT_OR_PAIR_DERIVATION_ONLY",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "event_ticker",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": 100,
          "maximum": 1000,
          "minimum": 1,
          "name": "limit",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int64",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "max_ts",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int64",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "min_ts",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "int64",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "subaccount",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "integer"
        },
        {
          "arb_request_use": "SENT_REQUIRED",
          "default": null,
          "maximum": null,
          "minimum": null,
          "name": "ticker",
          "openapi_observability": "OBSERVED",
          "rendered_observability": "OBSERVED_QUERY_PARAMETER",
          "source_conflict_rule": "POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT",
          "source_format": "NONE",
          "source_nullability": "NULL_PROHIBITED",
          "source_requiredness": "SOURCE_OPTIONAL",
          "source_type": "string"
        }
      ],
      "request_scope_fields": [
        "subaccount",
        "ticker"
      ],
      "response_contract": {
        "container_fields": [
          {
            "absence_behavior": "PAGINATION_CURSOR_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER",
            "execution_categories": [
              "PAGINATION_FIELD"
            ],
            "execution_use": "pagination continuation",
            "invalid_type_behavior": "PAGINATION_CURSOR_MALFORMED",
            "name": "cursor",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_BUT_ARB_REQUIRED",
            "runtime_parser_or_normalization": "EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetSettlementsResponse/properties/cursor",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "GetSettlementsResponse",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER",
            "execution_categories": [
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "supporting settlement stream",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "settlements",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "ARRAY_OF_SETTLEMENT_OBJECTS",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetSettlementsResponse/properties/settlements",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "GetSettlementsResponse",
            "source_type": "array"
          }
        ],
        "fields": [
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "event_ticker",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Settlement/properties/event_ticker",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Settlement",
            "source_type": "string"
          },
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED_BY_REV03",
            "arb_requiredness": "ARB_REQUIRED_BY_REV03",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__REV03_REQUIRES_PRESERVE/VALIDATE",
            "execution_categories": [
              "SCOPE_SHARD_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "target shard scope for settlement row",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "exchange_index",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "REV03_REQUIRES_EXACT_BUILTIN_INT__BOOL_PROHIBITED__GE_0",
            "schema_ref": "#/components/schemas/ExchangeIndex",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Settlement/properties/exchange_index",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Settlement",
            "source_type": "integer"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "fee_cost",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Settlement/properties/fee_cost",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Settlement",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "no_count_fp",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_COUNT_STRING",
            "schema_ref": "#/components/schemas/FixedPointCount",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Settlement/properties/no_count_fp",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Settlement",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "no_total_cost_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Settlement/properties/no_total_cost_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Settlement",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "revenue",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_INTEGER",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Settlement/properties/revenue",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Settlement",
            "source_type": "integer"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "SUPPORTING_EVIDENCE_FIELD",
              "TEMPORAL_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "settled_time",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_DATE_TIME_STRING",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "date-time",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Settlement/properties/settled_time",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Settlement",
            "source_type": "string"
          },
          {
            "absence_behavior": "SOURCE_REQUIRES; CURRENT_A2 raw.get could treat absence as target-like",
            "arb_requiredness": "ARB_REQUIRED_FOR_TARGET_SUPPORTING_ROW",
            "current_a2_use": "RAW_FIELD_READ_FOR_TARGET_TICKER_FILTER",
            "execution_categories": [
              "IDENTITY_FIELD",
              "SCOPE_SHARD_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "target supporting-row selection",
            "invalid_type_behavior": "NON_STRING_OR_OTHER_TYPE_NOT_VALIDATED_CURRENT_A2",
            "name": "ticker",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "CURRENT_A2_READS_RAW_VALUE__EXACT_TARGET_TICKER_EQUALITY_IF_PRESENT",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Settlement/properties/ticker",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Settlement",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "value",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_OPTIONAL_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_NULLABLE_INTEGER",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PERMITTED",
            "source_pointer": "#/components/schemas/Settlement/properties/value",
            "source_requiredness": "SOURCE_OPTIONAL",
            "source_schema": "Settlement",
            "source_type": "integer"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "yes_count_fp",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_COUNT_STRING",
            "schema_ref": "#/components/schemas/FixedPointCount",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Settlement/properties/yes_count_fp",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Settlement",
            "source_type": "string"
          },
          {
            "absence_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "arb_requiredness": "PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2",
            "current_a2_use": "NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY",
            "execution_categories": [
              "ECONOMIC_FIELD",
              "SUPPORTING_EVIDENCE_FIELD"
            ],
            "execution_use": "Revision-02 supporting schema anchor",
            "invalid_type_behavior": "NO_CURRENT_A2_INSTANCE_EFFECT",
            "name": "yes_total_cost_dollars",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_EXAMPLE_OR_CHILD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_BUT_NON_CONSUMED",
            "runtime_parser_or_normalization": "NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING",
            "schema_ref": "#/components/schemas/FixedPointDollars",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "NONE",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/Settlement/properties/yes_total_cost_dollars",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "Settlement",
            "source_type": "string"
          }
        ]
      },
      "response_subaccount_field": "NOT_EXPOSED",
      "role": "SUPPORTING_ECONOMIC_CROSS_CHECK_ONLY__NOT_ORDER_IDENTITY",
      "source_refs": {
        "comparison_role": "PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION",
        "openapi_operation_pointer": "#/paths/~1portfolio~1settlements/get",
        "rendered_url": "https://docs.kalshi.com/api-reference/portfolio/get-settlements"
      }
    },
    "USER_DATA_TIMESTAMP": {
      "authentication": "PUBLIC",
      "method": "GET",
      "negative_semantics": "NOT_TRANSACTIONALLY_EXACT",
      "pagination": false,
      "path": "/trade-api/v2/exchange/user_data_timestamp",
      "query_parameter_names": [],
      "query_parameters": [],
      "response_contract": {
        "container_fields": [],
        "fields": [
          {
            "absence_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "arb_requiredness": "ARB_REQUIRED",
            "current_a2_use": "PARSED_AS_REQUIRED_UTC_RFC3339_FRESHNESS_FIELD",
            "execution_categories": [
              "NEGATIVE_THEOREM_FIELD",
              "TEMPORAL_FIELD"
            ],
            "execution_use": "approximate freshness ordering evidence only",
            "invalid_type_behavior": "AUTHORITATIVE_RESPONSE_MALFORMED",
            "name": "as_of_time",
            "openapi_observability": "OBSERVED",
            "rendered_observability": "RENDERED_FIELD_PRESENT",
            "requiredness_class": "SOURCE_REQUIRED_AND_ARB_REQUIRED",
            "runtime_parser_or_normalization": "UTC_RFC3339_ZERO_OFFSET_REQUIRED",
            "source_conflict_rule": "POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT",
            "source_format": "date-time",
            "source_nullability": "NULL_PROHIBITED",
            "source_pointer": "#/components/schemas/GetUserDataTimestampResponse/properties/as_of_time",
            "source_requiredness": "SOURCE_REQUIRED",
            "source_schema": "GetUserDataTimestampResponse",
            "source_type": "string"
          }
        ]
      },
      "semantic_notes": [
        "approximate indication of when GetBalance/GetOrder(s)/GetFills/GetPositions data was last validated",
        "short reflection delay documented"
      ],
      "source_refs": {
        "comparison_role": "PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION",
        "openapi_operation_pointer": "#/paths/~1exchange~1user_data_timestamp/get",
        "rendered_url": "https://docs.kalshi.com/api-reference/exchange/get-user-data-timestamp"
      }
    }
  },
  "schema_id": "KALSHI_PRIMARY_DOMAIN_HISTORICAL_RESOLUTION_EXECUTION_MATERIAL_SOURCE_CONTRACT_REV5",
  "source_responsibility": {
    "changelog": [
      "dated_behavioral_changes"
    ],
    "historical_environment_guides": [
      "environment_separation",
      "recommended_roots",
      "historical_partition_semantics",
      "retention_exposure"
    ],
    "openapi_schema_structural_metadata": [
      "type",
      "format",
      "requiredness",
      "nullability",
      "enum",
      "minimum",
      "maximum"
    ],
    "positive_claim_conflict_rule": "OFFICIAL_SOURCE_CONFLICT",
    "rendered_endpoint_reference": [
      "method",
      "path",
      "query_surface",
      "semantic_description",
      "operation_examples"
    ],
    "rendered_silence_rule": "SILENCE_DOES_NOT_OVERRIDE_POSITIVE_OPENAPI_STRUCTURAL_METADATA",
    "unexposed_required_attribute_rule": "CURRENT_SOURCE_CONTRACT_UNRESOLVED"
  }
}
```

#### Exact canonical JSON bytes as UTF-8 text

The exact canonical byte sequence is the UTF-8 encoding of the single JSON line between the following markers; the surrounding marker lines and newline characters are not part of the canonical bytes.

```text
BEGIN_REV05_CANONICAL_JSON
{"environment":{"credentials_shared":false,"demo_rest_root":"https://external-api.demo.kalshi.co/trade-api/v2","production_rest_root":"https://external-api.kalshi.com/trade-api/v2"},"explicit_non_material_exclusions":[{"disposition":"PROVEN_NON_CONSUMED","path":"Fill.book_side","reason":"current A2 fill parser/economics do not consume directional field"},{"disposition":"PROVEN_NON_CONSUMED","path":"Fill.outcome_side","reason":"current A2 fill parser/economics do not consume directional field"},{"disposition":"PROVEN_NON_CONSUMED","path":"GetPositionsResponse.event_positions","reason":"Route A collects market_positions only; event-position rows do not gain fabricated shard identity"},{"disposition":"PROVEN_NON_CONSUMED","path":"Order.created_time","reason":"order time is not used by Route-A incident-window logic"},{"disposition":"PROVEN_NON_CONSUMED","path":"Order.maker_fees_dollars","reason":"current A2 neither parses nor uses this source-required order field"},{"disposition":"PROVEN_NON_CONSUMED","path":"Order.maker_fill_cost_dollars","reason":"current A2 neither parses nor uses this source-required order field"},{"disposition":"PROVEN_NON_CONSUMED","path":"Order.taker_fees_dollars","reason":"current A2 neither parses nor uses this source-required order field"},{"disposition":"PROVEN_NON_CONSUMED","path":"Order.taker_fill_cost_dollars","reason":"current A2 neither parses nor uses this source-required order field"},{"disposition":"PROVEN_NON_CONSUMED","path":"Order.type","reason":"full-schema field not consumed by Route A"},{"disposition":"PROVEN_NON_CONSUMED","path":"Order.user_id","reason":"full-schema field not consumed by Route A"},{"disposition":"PROVEN_PROVENANCE_ONLY","path":"REV02.manifest_id","reason":"provenance identity; not request/response semantics"},{"disposition":"PROVEN_PROVENANCE_ONLY","path":"REV02.observed_at_utc","reason":"retrieval metadata; not current Route-A behavior"},{"disposition":"PROVEN_PROVENANCE_ONLY","path":"REV02.raw_openapi.*","reason":"raw retrieval bookkeeping is recorded separately from execution-material projection"},{"disposition":"PROVEN_NON_CONSUMED","path":"Settlement.market_result","reason":"Revision-03 non-consumption preserved; no identity/economic/parser use"}],"fill_temporal_contract":{"contract_id":"FILL_TEMPORAL_CONTRACT_REV04","current_a2_runtime_contract":{"both_absent_or_no_usable_string_behavior":"fill is not excluded by temporal filter; other identity/scope checks still apply","both_present_conflict_behavior":"VALID_RFC3339_STRING_TS_WINS__NO_EQUALITY_COMPARISON","both_present_equality_required":false,"created_time_parser":"if present: exact str + timezone-aware RFC3339; malformed => AUTHORITATIVE_RESPONSE_MALFORMED","evaluation_upper_bound_comparison":"inclusive: fill_time <= evaluation snapshot","incident_lower_bound_comparison":"inclusive: fill_time >= incident lower bound","integer_ts_conversion_to_datetime":"NONE","outside_interval_behavior":"fill excluded from incident-scope evidence","selection_precedence":["valid RFC3339 string ts","valid RFC3339 string created_time","NO_USABLE_STRING_TIMESTAMP"],"source_conforming_integer_ts_behavior":"retained as authoritative parsed field but not selected as fill_time; created_time is fallback if valid string","timezone_rule":"timezone-aware RFC3339; non-zero offsets accepted; not UTC-only","ts_parser":"if present: exact int (bool prohibited) OR timezone-aware RFC3339 str; malformed => AUTHORITATIVE_RESPONSE_MALFORMED"},"fields_inspected":["created_time","ts"],"functional_change":"NO_RUNTIME_CHANGE__FREEZE_CURRENT_A2_BEHAVIOR","source_operations":["HISTORICAL_FILLS","LIVE_FILLS"],"source_structural_contract":{"created_time":{"format":"date-time","nullability":"NULL_PROHIBITED","requiredness":"SOURCE_OPTIONAL","source_pointer":"#/components/schemas/Fill/properties/created_time","type":"string"},"ts":{"format":"int64","nullability":"NULL_PROHIBITED","requiredness":"SOURCE_OPTIONAL","source_pointer":"#/components/schemas/Fill/properties/ts","type":"integer"}}},"historical_partition":{"cutoffs_move_forward":true,"positions_archived_per_whole_event":true,"retention_lower_bound":"NOT_EXPOSED","target_live_window":"3 months"},"market_result_contract":{"a3_compare":false,"a3_economic_use":false,"a3_identity_use":false,"a3_parse":false,"absence_alone_malformed":false,"classification":"NOT_CONFIRMED__NOT_EXECUTION_MATERIAL","conflict_consequence":"FULL_SCHEMA_PROVENANCE_ONLY__NO_A3_GATE_FAILURE_UNLESS_A_CONSUMED_SEMANTIC_CHANGES","openapi_copy_observation":"PROPERTY_PRESENT_AND_SOURCE_REQUIRED_IN_USER_SUPPLIED_CURRENT_OPENAPI_COPY","rendered_observation":"POSITIVELY_EXPOSED_AS_CHILD_IN_CURRENT_RENDERED_RESEARCH_INTERFACE"},"normalization_revision":4,"official_source_scope":"docs.kalshi.com only","operations":{"EXACT_ORDER":{"authentication":"AUTHENTICATED","documented_http_statuses":[200,401,404,500],"http_404_nonexistence_theorem":"NOT_EXPOSED","method":"GET","pagination":false,"path":"/trade-api/v2/portfolio/orders/{order_id}","path_parameters":[{"arb_request_use":"REQUIRED_PATH_SUBSTITUTION","name":"order_id","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_STRING__SLASH_QUESTION_HASH_PROHIBITED","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_REQUIRED","source_type":"string"}],"query_parameter_names":[],"query_parameters":[],"response_contract":{"container_fields":[{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER","execution_categories":["SUPPORTING_EVIDENCE_FIELD"],"execution_use":"exact order wrapper","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"order","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"ORDER_OBJECT","schema_ref":"#/components/schemas/Order","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetOrderResponse/properties/order","source_requiredness":"SOURCE_REQUIRED","source_schema":"GetOrderResponse","source_type":"object"}],"fields":[{"absence_behavior":"STORED_NONE","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["STATUS_OR_STATE_FIELD"],"execution_use":"duplicate/source compatibility only","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"book_side","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_OPAQUE_NONEMPTY_STRING","schema_ref":"#/components/schemas/BookSide","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_enum":["bid","ask"],"source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/book_side","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"STORED_NONE","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["STATUS_OR_STATE_FIELD"],"execution_use":"duplicate/source compatibility only","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"cancel_order_on_pause","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_AND_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_EXACT_BOOL","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/cancel_order_on_pause","source_requiredness":"SOURCE_OPTIONAL","source_schema":"Order","source_type":"boolean"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_ORDER_FIELD","execution_categories":["IDENTITY_FIELD"],"execution_use":"immutable client-order identity match","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"client_order_id","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/client_order_id","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"ACCEPTED_AS_NONE_CURRENT_A2__NO_DEFAULT_TO_ZERO","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2__NO_DEFAULT","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["SCOPE_SHARD_FIELD"],"execution_use":"target shard scope if present","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"exchange_index","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_AND_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_EXACT_BUILTIN_INT__BOOL_PROHIBITED","schema_ref":"#/components/schemas/ExchangeIndex","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/exchange_index","source_requiredness":"SOURCE_OPTIONAL","source_schema":"Order","source_type":"integer"},{"absence_behavior":"NOT_EXPOSED_ECONOMIC_MATCH","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["ECONOMIC_FIELD"],"execution_use":"order/fill quantity reconciliation when exposed","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"fill_count_fp","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointCount","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/fill_count_fp","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"NOT_EXPOSED_ECONOMIC_MATCH","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["ECONOMIC_FIELD"],"execution_use":"order/fill quantity reconciliation when exposed","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"initial_count_fp","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointCount","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/initial_count_fp","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"STORED_NONE","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["ECONOMIC_FIELD"],"execution_use":"duplicate/source compatibility only","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"no_price_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/no_price_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_ORDER_FIELD","execution_categories":["IDENTITY_FIELD"],"execution_use":"identity/dedup/binding","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"order_id","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/order_id","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"STORED_NONE","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["STATUS_OR_STATE_FIELD"],"execution_use":"duplicate/source compatibility only","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"outcome_side","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_OPAQUE_NONEMPTY_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_enum":["yes","no"],"source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/outcome_side","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"NOT_EXPOSED_ECONOMIC_MATCH","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["ECONOMIC_FIELD"],"execution_use":"order/fill quantity reconciliation when exposed","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"remaining_count_fp","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointCount","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/remaining_count_fp","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"MISSING_BECOMES_NONE_AND_IS_NOT_RESTING_CURRENT_A2","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2__SOURCE_REQUIRED","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["STATUS_OR_STATE_FIELD"],"execution_use":"active-vs-terminal classification","invalid_type_behavior":"AUTHORITATIVE_SOURCE_DRIFT_SPEC_REVISION_REQUIRED_FOR_UNKNOWN_ENUM__MALFORMED_FOR_INVALID_TYPE","name":"status","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_OPAQUE_STRING_AND_ENUM_RESTING_CANCELED_EXECUTED","schema_ref":"#/components/schemas/OrderStatus","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_enum":["resting","canceled","executed"],"source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/status","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_ORDER_FIELD","execution_categories":["SCOPE_SHARD_FIELD"],"execution_use":"target subaccount scope","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"subaccount_number","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_BUT_ARB_REQUIRED","runtime_parser_or_normalization":"EXACT_BUILTIN_INT__BOOL_PROHIBITED","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PERMITTED","source_pointer":"#/components/schemas/Order/properties/subaccount_number","source_requiredness":"SOURCE_OPTIONAL","source_schema":"Order","source_type":"integer"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_ORDER_FIELD","execution_categories":["IDENTITY_FIELD","SCOPE_SHARD_FIELD"],"execution_use":"target market scope","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"ticker","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/ticker","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"STORED_NONE","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["ECONOMIC_FIELD"],"execution_use":"duplicate/source compatibility only","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"yes_price_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/yes_price_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"}]},"source_refs":{"comparison_role":"PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION","openapi_operation_pointer":"#/paths/~1portfolio~1orders~1{order_id}/get","rendered_url":"https://docs.kalshi.com/api-reference/orders/get-order"}},"HISTORICAL_CUTOFF":{"authentication":"PUBLIC","method":"GET","negative_semantics":"PARTITION_BOUNDARY_ONLY__NOT_RETENTION_LOWER_BOUND","pagination":false,"path":"/trade-api/v2/historical/cutoff","query_parameter_names":[],"query_parameters":[],"response_contract":{"container_fields":[],"fields":[{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_UTC_RFC3339_CUTOFF_FIELD","execution_categories":["NEGATIVE_THEOREM_FIELD","PARTITION_SEMANTIC","TEMPORAL_FIELD"],"execution_use":"pre/post partition boundary and moving-cutoff coverage theorem","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"market_positions_last_updated_ts","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_BUT_ARB_REQUIRED","runtime_parser_or_normalization":"UTC_RFC3339_ZERO_OFFSET_REQUIRED","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"date-time","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetHistoricalCutoffResponse/properties/market_positions_last_updated_ts","source_requiredness":"SOURCE_OPTIONAL","source_schema":"GetHistoricalCutoffResponse","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_UTC_RFC3339_CUTOFF_FIELD","execution_categories":["NEGATIVE_THEOREM_FIELD","PARTITION_SEMANTIC","TEMPORAL_FIELD"],"execution_use":"pre/post partition boundary and moving-cutoff coverage theorem","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"market_settled_ts","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"UTC_RFC3339_ZERO_OFFSET_REQUIRED","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"date-time","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetHistoricalCutoffResponse/properties/market_settled_ts","source_requiredness":"SOURCE_REQUIRED","source_schema":"GetHistoricalCutoffResponse","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_UTC_RFC3339_CUTOFF_FIELD","execution_categories":["NEGATIVE_THEOREM_FIELD","PARTITION_SEMANTIC","TEMPORAL_FIELD"],"execution_use":"pre/post partition boundary and moving-cutoff coverage theorem","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"orders_updated_ts","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"UTC_RFC3339_ZERO_OFFSET_REQUIRED","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"date-time","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetHistoricalCutoffResponse/properties/orders_updated_ts","source_requiredness":"SOURCE_REQUIRED","source_schema":"GetHistoricalCutoffResponse","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_UTC_RFC3339_CUTOFF_FIELD","execution_categories":["NEGATIVE_THEOREM_FIELD","PARTITION_SEMANTIC","TEMPORAL_FIELD"],"execution_use":"pre/post partition boundary and moving-cutoff coverage theorem","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"trades_created_ts","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"UTC_RFC3339_ZERO_OFFSET_REQUIRED","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"date-time","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetHistoricalCutoffResponse/properties/trades_created_ts","source_requiredness":"SOURCE_REQUIRED","source_schema":"GetHistoricalCutoffResponse","source_type":"string"}]},"source_refs":{"comparison_role":"PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION","openapi_operation_pointer":"#/paths/~1historical~1cutoff/get","rendered_url":"https://docs.kalshi.com/api-reference/historical/get-historical-cutoff-timestamps"}},"HISTORICAL_FILLS":{"authentication":"AUTHENTICATED","exchange_index_a3_contract":"REQUIRED_NON_NULL_EXACT_BUILTIN_INT_GE_0__TARGET_SCOPE_0","fill_temporal_contract_ref":"FILL_TEMPORAL_CONTRACT_REV04","limit_range":[1,1000],"method":"GET","pagination":true,"path":"/trade-api/v2/historical/fills","query_parameter_names":["cursor","limit","max_ts","ticker"],"query_parameters":[{"arb_request_use":"SENT_AFTER_FIRST_PAGE","default":null,"maximum":null,"minimum":null,"name":"cursor","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"},{"arb_request_use":"SENT_REQUIRED","default":100,"maximum":1000,"minimum":1,"name":"limit","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int64","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"max_ts","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int64","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"ticker","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"}],"response_contract":{"container_fields":[{"absence_behavior":"PAGINATION_CURSOR_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER","execution_categories":["PAGINATION_FIELD"],"execution_use":"pagination continuation","invalid_type_behavior":"PAGINATION_CURSOR_MALFORMED","name":"cursor","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetFillsResponse/properties/cursor","source_requiredness":"SOURCE_REQUIRED","source_schema":"GetFillsResponse","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER","execution_categories":["SUPPORTING_EVIDENCE_FIELD"],"execution_use":"fill record stream","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"fills","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"ARRAY_OF_FILL_OBJECTS","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetFillsResponse/properties/fills","source_requiredness":"SOURCE_REQUIRED","source_schema":"GetFillsResponse","source_type":"array"}],"fields":[{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["ECONOMIC_FIELD"],"execution_use":"canonical fill quantity","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"count_fp","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"FIXED_POINT_COUNT_2DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointCount","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/count_fp","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"},{"absence_behavior":"NO_USABLE_TIME_FROM_THIS_FIELD","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT__USED_BY_FILL_TEMPORAL_SELECTION_AS_FROZEN","execution_categories":["TEMPORAL_FIELD"],"execution_use":"fallback fill-time field after string ts","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"created_time","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_AND_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_TIMEZONE_AWARE_RFC3339_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"date-time","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/created_time","source_requiredness":"SOURCE_OPTIONAL","source_schema":"Fill","source_type":"string","temporal_precedence":"USED_ONLY_IF_TS_IS_NOT_A_VALID_RFC3339_STRING"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED_BY_REV03","arb_requiredness":"ARB_REQUIRED_BY_REV03","current_a2_use":"PARSED_IF_PRESENT_AND_SCOPE_CHECKED__REV03_REQUIRES_PRESENT","execution_categories":["SCOPE_SHARD_FIELD"],"execution_use":"target shard scope; duplicate compatibility","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"exchange_index","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"EXACT_BUILTIN_INT__BOOL_PROHIBITED__GE_0","schema_ref":"#/components/schemas/ExchangeIndex","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_domain_rule":"INTEGER_GE_0_BY_ARB_REV03; OpenAPI ExchangeIndex has integer type without minimum","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/exchange_index","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"integer"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["ECONOMIC_FIELD"],"execution_use":"canonical fee cost","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"fee_cost","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/fee_cost","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["IDENTITY_FIELD"],"execution_use":"dedupe primary identity","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"fill_id","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/fill_id","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["ECONOMIC_FIELD","STATUS_OR_STATE_FIELD"],"execution_use":"maker/taker economic invariant","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"is_taker","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"EXACT_BOOL","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/is_taker","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"boolean"},{"absence_behavior":"STORED_NONE_CURRENT_A2","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2__SOURCE_REQUIRED","current_a2_use":"PARSED_IF_PRESENT_AND_SCOPE_CHECKED","execution_categories":["IDENTITY_FIELD","SCOPE_SHARD_FIELD"],"execution_use":"secondary market-scope equality if present","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"market_ticker","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_OPAQUE_NONEMPTY_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/market_ticker","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["ECONOMIC_FIELD"],"execution_use":"duplicate/source compatibility","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"no_price_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/no_price_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["IDENTITY_FIELD"],"execution_use":"candidate/bound-order identity","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"order_id","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/order_id","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["SCOPE_SHARD_FIELD"],"execution_use":"target subaccount scope","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"subaccount_number","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_BUT_ARB_REQUIRED","runtime_parser_or_normalization":"EXACT_BUILTIN_INT__BOOL_PROHIBITED","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PERMITTED","source_pointer":"#/components/schemas/Fill/properties/subaccount_number","source_requiredness":"SOURCE_OPTIONAL","source_schema":"Fill","source_type":"integer"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["IDENTITY_FIELD","SCOPE_SHARD_FIELD"],"execution_use":"target market scope","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"ticker","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/ticker","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["IDENTITY_FIELD"],"execution_use":"identity/duplicate compatibility","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"trade_id","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/trade_id","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"},{"absence_behavior":"NO_USABLE_TIME_FROM_THIS_FIELD","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT__USED_BY_FILL_TEMPORAL_SELECTION_AS_FROZEN","execution_categories":["TEMPORAL_FIELD"],"execution_use":"preferred fill-time only when runtime value is RFC3339 string; integer retained but not time-filtered","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"ts","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_AND_ARB_OPTIONAL","runtime_parser_or_normalization":"CURRENT_A2_ACCEPTS_EXACT_INT_OR_TIMEZONE_AWARE_RFC3339_STRING__SOURCE_BASELINE_IS_INT64","runtime_source_type_divergence_note":"SOURCE_EXPECTS_INTEGER_INT64; CURRENT_A2 ALSO_ACCEPTS_RFC3339_STRING_FOR_BACKWARD_COMPATIBILITY","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"int64","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/ts","source_requiredness":"SOURCE_OPTIONAL","source_schema":"Fill","source_type":"integer"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["ECONOMIC_FIELD"],"execution_use":"filled principal and price bound","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"yes_price_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/yes_price_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"}]},"retention_lower_bound":"NOT_EXPOSED","source_refs":{"comparison_role":"PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION","openapi_operation_pointer":"#/paths/~1historical~1fills/get","rendered_url":"https://docs.kalshi.com/api-reference/historical/get-historical-fills"},"unsupported_query_fields":["exchange_index","min_ts","order_id","subaccount"]},"HISTORICAL_ORDERS":{"authentication":"AUTHENTICATED","limit_range":[1,1000],"method":"GET","pagination":true,"partition_semantics":"canceled/executed orders older than orders_updated_ts","path":"/trade-api/v2/historical/orders","query_parameter_names":["cursor","limit","max_ts","ticker"],"query_parameters":[{"arb_request_use":"SENT_AFTER_FIRST_PAGE","default":null,"maximum":null,"minimum":null,"name":"cursor","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"},{"arb_request_use":"SENT_REQUIRED","default":100,"maximum":1000,"minimum":1,"name":"limit","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int64","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"max_ts","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int64","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"ticker","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"}],"response_contract":{"container_fields":[{"absence_behavior":"PAGINATION_CURSOR_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER","execution_categories":["PAGINATION_FIELD"],"execution_use":"pagination continuation","invalid_type_behavior":"PAGINATION_CURSOR_MALFORMED","name":"cursor","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetOrdersResponse/properties/cursor","source_requiredness":"SOURCE_REQUIRED","source_schema":"GetOrdersResponse","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER","execution_categories":["SUPPORTING_EVIDENCE_FIELD"],"execution_use":"order record stream","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"orders","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"ARRAY_OF_ORDER_OBJECTS","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetOrdersResponse/properties/orders","source_requiredness":"SOURCE_REQUIRED","source_schema":"GetOrdersResponse","source_type":"array"}],"fields":[{"absence_behavior":"STORED_NONE","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["STATUS_OR_STATE_FIELD"],"execution_use":"duplicate/source compatibility only","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"book_side","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_OPAQUE_NONEMPTY_STRING","schema_ref":"#/components/schemas/BookSide","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_enum":["bid","ask"],"source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/book_side","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"STORED_NONE","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["STATUS_OR_STATE_FIELD"],"execution_use":"duplicate/source compatibility only","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"cancel_order_on_pause","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_AND_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_EXACT_BOOL","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/cancel_order_on_pause","source_requiredness":"SOURCE_OPTIONAL","source_schema":"Order","source_type":"boolean"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_ORDER_FIELD","execution_categories":["IDENTITY_FIELD"],"execution_use":"immutable client-order identity match","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"client_order_id","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/client_order_id","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"ACCEPTED_AS_NONE_CURRENT_A2__NO_DEFAULT_TO_ZERO","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2__NO_DEFAULT","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["SCOPE_SHARD_FIELD"],"execution_use":"target shard scope if present","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"exchange_index","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_AND_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_EXACT_BUILTIN_INT__BOOL_PROHIBITED","schema_ref":"#/components/schemas/ExchangeIndex","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/exchange_index","source_requiredness":"SOURCE_OPTIONAL","source_schema":"Order","source_type":"integer"},{"absence_behavior":"NOT_EXPOSED_ECONOMIC_MATCH","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["ECONOMIC_FIELD"],"execution_use":"order/fill quantity reconciliation when exposed","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"fill_count_fp","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointCount","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/fill_count_fp","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"NOT_EXPOSED_ECONOMIC_MATCH","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["ECONOMIC_FIELD"],"execution_use":"order/fill quantity reconciliation when exposed","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"initial_count_fp","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointCount","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/initial_count_fp","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"STORED_NONE","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["ECONOMIC_FIELD"],"execution_use":"duplicate/source compatibility only","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"no_price_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/no_price_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_ORDER_FIELD","execution_categories":["IDENTITY_FIELD"],"execution_use":"identity/dedup/binding","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"order_id","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/order_id","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"STORED_NONE","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["STATUS_OR_STATE_FIELD"],"execution_use":"duplicate/source compatibility only","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"outcome_side","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_OPAQUE_NONEMPTY_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_enum":["yes","no"],"source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/outcome_side","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"NOT_EXPOSED_ECONOMIC_MATCH","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["ECONOMIC_FIELD"],"execution_use":"order/fill quantity reconciliation when exposed","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"remaining_count_fp","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointCount","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/remaining_count_fp","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"MISSING_BECOMES_NONE_AND_IS_NOT_RESTING_CURRENT_A2","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2__SOURCE_REQUIRED","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["STATUS_OR_STATE_FIELD"],"execution_use":"active-vs-terminal classification","invalid_type_behavior":"AUTHORITATIVE_SOURCE_DRIFT_SPEC_REVISION_REQUIRED_FOR_UNKNOWN_ENUM__MALFORMED_FOR_INVALID_TYPE","name":"status","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_OPAQUE_STRING_AND_ENUM_RESTING_CANCELED_EXECUTED","schema_ref":"#/components/schemas/OrderStatus","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_enum":["resting","canceled","executed"],"source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/status","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_ORDER_FIELD","execution_categories":["SCOPE_SHARD_FIELD"],"execution_use":"target subaccount scope","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"subaccount_number","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_BUT_ARB_REQUIRED","runtime_parser_or_normalization":"EXACT_BUILTIN_INT__BOOL_PROHIBITED","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PERMITTED","source_pointer":"#/components/schemas/Order/properties/subaccount_number","source_requiredness":"SOURCE_OPTIONAL","source_schema":"Order","source_type":"integer"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_ORDER_FIELD","execution_categories":["IDENTITY_FIELD","SCOPE_SHARD_FIELD"],"execution_use":"target market scope","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"ticker","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/ticker","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"STORED_NONE","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["ECONOMIC_FIELD"],"execution_use":"duplicate/source compatibility only","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"yes_price_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/yes_price_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"}]},"retention_lower_bound":"NOT_EXPOSED","source_refs":{"comparison_role":"PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION","openapi_operation_pointer":"#/paths/~1historical~1orders/get","rendered_url":"https://docs.kalshi.com/api-reference/historical/get-historical-orders"},"unsupported_query_fields":["event_ticker","exchange_index","min_ts","status","subaccount"]},"HISTORICAL_POSITIONS":{"authentication":"AUTHENTICATED","exchange_index_a3_contract":"REQUIRED_NON_NULL_EXACT_BUILTIN_INT_GE_0__TARGET_SCOPE_0_FOR_TARGET_SUPPORTING_ROWS","limit_range":[1,1000],"method":"GET","pagination":true,"partition_semantics":"settled positions archived per whole event; never split across live/historical; cutoff field market_positions_last_updated_ts","path":"/trade-api/v2/historical/positions","query_parameter_names":["cursor","event_ticker","limit","ticker"],"query_parameters":[{"arb_request_use":"SENT_AFTER_FIRST_PAGE","default":null,"maximum":null,"minimum":null,"name":"cursor","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"},{"arb_request_use":"NOT_SENT__SOURCE_CONTRACT_OR_PAIR_DERIVATION_ONLY","default":null,"maximum":null,"minimum":null,"name":"event_ticker","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"},{"arb_request_use":"SENT_REQUIRED","default":100,"maximum":1000,"minimum":1,"name":"limit","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int64","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"ticker","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"}],"response_contract":{"container_fields":[{"absence_behavior":"PAGINATION_CURSOR_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER","execution_categories":["PAGINATION_FIELD"],"execution_use":"pagination continuation","invalid_type_behavior":"PAGINATION_CURSOR_MALFORMED","name":"cursor","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_BUT_ARB_REQUIRED","runtime_parser_or_normalization":"EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetPositionsResponse/properties/cursor","source_requiredness":"SOURCE_OPTIONAL","source_schema":"GetPositionsResponse","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER","execution_categories":["SUPPORTING_EVIDENCE_FIELD"],"execution_use":"supporting market-position stream","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"market_positions","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"ARRAY_OF_MARKET_POSITION_OBJECTS","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetPositionsResponse/properties/market_positions","source_requiredness":"SOURCE_REQUIRED","source_schema":"GetPositionsResponse","source_type":"array"}],"fields":[{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED_BY_REV03","arb_requiredness":"ARB_REQUIRED_BY_REV03","current_a2_use":"NOT_PARSED_CURRENT_A2__REV03_REQUIRES_PRESERVE/VALIDATE","execution_categories":["SCOPE_SHARD_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"target shard scope for market_positions row","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"exchange_index","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"REV03_REQUIRES_EXACT_BUILTIN_INT__BOOL_PROHIBITED__GE_0","schema_ref":"#/components/schemas/ExchangeIndex","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/MarketPosition/properties/exchange_index","source_requiredness":"SOURCE_REQUIRED","source_schema":"MarketPosition","source_type":"integer"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"fees_paid_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/MarketPosition/properties/fees_paid_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"MarketPosition","source_type":"string"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["SUPPORTING_EVIDENCE_FIELD","TEMPORAL_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"last_updated_ts","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_DATE_TIME_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"date-time","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/MarketPosition/properties/last_updated_ts","source_requiredness":"SOURCE_REQUIRED","source_schema":"MarketPosition","source_type":"string"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"market_exposure_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/MarketPosition/properties/market_exposure_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"MarketPosition","source_type":"string"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"position_fp","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_COUNT_STRING","schema_ref":"#/components/schemas/FixedPointCount","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/MarketPosition/properties/position_fp","source_requiredness":"SOURCE_REQUIRED","source_schema":"MarketPosition","source_type":"string"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"realized_pnl_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/MarketPosition/properties/realized_pnl_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"MarketPosition","source_type":"string"},{"absence_behavior":"SOURCE_REQUIRES; CURRENT_A2 raw.get could treat absence as target-like; later correction should preserve source-required baseline","arb_requiredness":"ARB_REQUIRED_FOR_TARGET_SUPPORTING_ROW","current_a2_use":"RAW_FIELD_READ_FOR_TARGET_TICKER_FILTER","execution_categories":["IDENTITY_FIELD","SCOPE_SHARD_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"target supporting-row selection","invalid_type_behavior":"NON_STRING_OR_OTHER_TYPE_NOT_VALIDATED_CURRENT_A2","name":"ticker","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"CURRENT_A2_READS_RAW_VALUE__EXACT_TARGET_TICKER_EQUALITY_IF_PRESENT","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/MarketPosition/properties/ticker","source_requiredness":"SOURCE_REQUIRED","source_schema":"MarketPosition","source_type":"string"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"total_traded_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/MarketPosition/properties/total_traded_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"MarketPosition","source_type":"string"}]},"response_subaccount_field":"NOT_EXPOSED","retention_lower_bound":"NOT_EXPOSED","source_refs":{"comparison_role":"PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION","openapi_operation_pointer":"#/paths/~1historical~1positions/get","rendered_url":"https://docs.kalshi.com/api-reference/historical/get-historical-positions"},"unsupported_query_fields":["count_filter","exchange_index","subaccount"]},"LIVE_FILLS":{"authentication":"AUTHENTICATED","exchange_index_a3_contract":"REQUIRED_NON_NULL_EXACT_BUILTIN_INT_GE_0__TARGET_SCOPE_0","fill_temporal_contract_ref":"FILL_TEMPORAL_CONTRACT_REV04","limit_range":[1,1000],"method":"GET","pagination":true,"partition_semantics":"fills before trades_created_ts historical","path":"/trade-api/v2/portfolio/fills","query_parameter_names":["cursor","exchange_index","limit","max_ts","min_ts","order_id","subaccount","ticker"],"query_parameters":[{"arb_request_use":"SENT_AFTER_FIRST_PAGE","default":null,"maximum":null,"minimum":null,"name":"cursor","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":0,"name":"exchange_index","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int32","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":100,"maximum":1000,"minimum":1,"name":"limit","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int64","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"max_ts","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int64","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"min_ts","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int64","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_IF_BOUND_ORDER","default":null,"maximum":null,"minimum":null,"name":"order_id","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"subaccount","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"ticker","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"}],"response_contract":{"container_fields":[{"absence_behavior":"PAGINATION_CURSOR_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER","execution_categories":["PAGINATION_FIELD"],"execution_use":"pagination continuation","invalid_type_behavior":"PAGINATION_CURSOR_MALFORMED","name":"cursor","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetFillsResponse/properties/cursor","source_requiredness":"SOURCE_REQUIRED","source_schema":"GetFillsResponse","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER","execution_categories":["SUPPORTING_EVIDENCE_FIELD"],"execution_use":"fill record stream","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"fills","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"ARRAY_OF_FILL_OBJECTS","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetFillsResponse/properties/fills","source_requiredness":"SOURCE_REQUIRED","source_schema":"GetFillsResponse","source_type":"array"}],"fields":[{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["ECONOMIC_FIELD"],"execution_use":"canonical fill quantity","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"count_fp","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"FIXED_POINT_COUNT_2DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointCount","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/count_fp","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"},{"absence_behavior":"NO_USABLE_TIME_FROM_THIS_FIELD","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT__USED_BY_FILL_TEMPORAL_SELECTION_AS_FROZEN","execution_categories":["TEMPORAL_FIELD"],"execution_use":"fallback fill-time field after string ts","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"created_time","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_AND_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_TIMEZONE_AWARE_RFC3339_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"date-time","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/created_time","source_requiredness":"SOURCE_OPTIONAL","source_schema":"Fill","source_type":"string","temporal_precedence":"USED_ONLY_IF_TS_IS_NOT_A_VALID_RFC3339_STRING"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED_BY_REV03","arb_requiredness":"ARB_REQUIRED_BY_REV03","current_a2_use":"PARSED_IF_PRESENT_AND_SCOPE_CHECKED__REV03_REQUIRES_PRESENT","execution_categories":["SCOPE_SHARD_FIELD"],"execution_use":"target shard scope; duplicate compatibility","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"exchange_index","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"EXACT_BUILTIN_INT__BOOL_PROHIBITED__GE_0","schema_ref":"#/components/schemas/ExchangeIndex","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_domain_rule":"INTEGER_GE_0_BY_ARB_REV03; OpenAPI ExchangeIndex has integer type without minimum","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/exchange_index","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"integer"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["ECONOMIC_FIELD"],"execution_use":"canonical fee cost","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"fee_cost","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/fee_cost","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["IDENTITY_FIELD"],"execution_use":"dedupe primary identity","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"fill_id","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/fill_id","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["ECONOMIC_FIELD","STATUS_OR_STATE_FIELD"],"execution_use":"maker/taker economic invariant","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"is_taker","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"EXACT_BOOL","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/is_taker","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"boolean"},{"absence_behavior":"STORED_NONE_CURRENT_A2","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2__SOURCE_REQUIRED","current_a2_use":"PARSED_IF_PRESENT_AND_SCOPE_CHECKED","execution_categories":["IDENTITY_FIELD","SCOPE_SHARD_FIELD"],"execution_use":"secondary market-scope equality if present","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"market_ticker","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_OPAQUE_NONEMPTY_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/market_ticker","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["ECONOMIC_FIELD"],"execution_use":"duplicate/source compatibility","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"no_price_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/no_price_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["IDENTITY_FIELD"],"execution_use":"candidate/bound-order identity","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"order_id","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/order_id","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["SCOPE_SHARD_FIELD"],"execution_use":"target subaccount scope","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"subaccount_number","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_BUT_ARB_REQUIRED","runtime_parser_or_normalization":"EXACT_BUILTIN_INT__BOOL_PROHIBITED","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PERMITTED","source_pointer":"#/components/schemas/Fill/properties/subaccount_number","source_requiredness":"SOURCE_OPTIONAL","source_schema":"Fill","source_type":"integer"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["IDENTITY_FIELD","SCOPE_SHARD_FIELD"],"execution_use":"target market scope","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"ticker","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/ticker","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["IDENTITY_FIELD"],"execution_use":"identity/duplicate compatibility","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"trade_id","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/trade_id","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"},{"absence_behavior":"NO_USABLE_TIME_FROM_THIS_FIELD","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT__USED_BY_FILL_TEMPORAL_SELECTION_AS_FROZEN","execution_categories":["TEMPORAL_FIELD"],"execution_use":"preferred fill-time only when runtime value is RFC3339 string; integer retained but not time-filtered","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"ts","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_AND_ARB_OPTIONAL","runtime_parser_or_normalization":"CURRENT_A2_ACCEPTS_EXACT_INT_OR_TIMEZONE_AWARE_RFC3339_STRING__SOURCE_BASELINE_IS_INT64","runtime_source_type_divergence_note":"SOURCE_EXPECTS_INTEGER_INT64; CURRENT_A2 ALSO_ACCEPTS_RFC3339_STRING_FOR_BACKWARD_COMPATIBILITY","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"int64","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/ts","source_requiredness":"SOURCE_OPTIONAL","source_schema":"Fill","source_type":"integer"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_FILL_FIELD","execution_categories":["ECONOMIC_FIELD"],"execution_use":"filled principal and price bound","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"yes_price_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"FIXED_POINT_DOLLARS_1_TO_6DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Fill/properties/yes_price_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"Fill","source_type":"string"}]},"source_refs":{"comparison_role":"PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION","openapi_operation_pointer":"#/paths/~1portfolio~1fills/get","rendered_url":"https://docs.kalshi.com/api-reference/portfolio/get-fills"}},"LIVE_ORDERS":{"authentication":"AUTHENTICATED","limit_range":[1,1000],"method":"GET","pagination":true,"partition_semantics":"resting always live; canceled/fully executed before orders_updated_ts historical","path":"/trade-api/v2/portfolio/orders","query_parameter_names":["cursor","event_ticker","exchange_index","limit","max_ts","min_ts","status","subaccount","ticker"],"query_parameters":[{"arb_request_use":"SENT_AFTER_FIRST_PAGE","default":null,"maximum":null,"minimum":null,"name":"cursor","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"},{"arb_request_use":"NOT_SENT__SOURCE_CONTRACT_OR_PAIR_DERIVATION_ONLY","default":null,"maximum":null,"minimum":null,"name":"event_ticker","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":0,"name":"exchange_index","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int32","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":100,"maximum":1000,"minimum":1,"name":"limit","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int64","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"max_ts","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int64","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"min_ts","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int64","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"NOT_SENT__SOURCE_CONTRACT_OR_PAIR_DERIVATION_ONLY","default":null,"maximum":null,"minimum":null,"name":"status","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"subaccount","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"ticker","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"}],"request_scope_fields":["exchange_index","subaccount","ticker"],"response_contract":{"container_fields":[{"absence_behavior":"PAGINATION_CURSOR_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER","execution_categories":["PAGINATION_FIELD"],"execution_use":"pagination continuation","invalid_type_behavior":"PAGINATION_CURSOR_MALFORMED","name":"cursor","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetOrdersResponse/properties/cursor","source_requiredness":"SOURCE_REQUIRED","source_schema":"GetOrdersResponse","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER","execution_categories":["SUPPORTING_EVIDENCE_FIELD"],"execution_use":"order record stream","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"orders","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"ARRAY_OF_ORDER_OBJECTS","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetOrdersResponse/properties/orders","source_requiredness":"SOURCE_REQUIRED","source_schema":"GetOrdersResponse","source_type":"array"}],"fields":[{"absence_behavior":"STORED_NONE","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["STATUS_OR_STATE_FIELD"],"execution_use":"duplicate/source compatibility only","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"book_side","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_OPAQUE_NONEMPTY_STRING","schema_ref":"#/components/schemas/BookSide","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_enum":["bid","ask"],"source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/book_side","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"STORED_NONE","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["STATUS_OR_STATE_FIELD"],"execution_use":"duplicate/source compatibility only","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"cancel_order_on_pause","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_AND_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_EXACT_BOOL","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/cancel_order_on_pause","source_requiredness":"SOURCE_OPTIONAL","source_schema":"Order","source_type":"boolean"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_ORDER_FIELD","execution_categories":["IDENTITY_FIELD"],"execution_use":"immutable client-order identity match","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"client_order_id","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/client_order_id","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"ACCEPTED_AS_NONE_CURRENT_A2__NO_DEFAULT_TO_ZERO","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2__NO_DEFAULT","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["SCOPE_SHARD_FIELD"],"execution_use":"target shard scope if present","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"exchange_index","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_AND_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_EXACT_BUILTIN_INT__BOOL_PROHIBITED","schema_ref":"#/components/schemas/ExchangeIndex","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/exchange_index","source_requiredness":"SOURCE_OPTIONAL","source_schema":"Order","source_type":"integer"},{"absence_behavior":"NOT_EXPOSED_ECONOMIC_MATCH","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["ECONOMIC_FIELD"],"execution_use":"order/fill quantity reconciliation when exposed","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"fill_count_fp","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointCount","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/fill_count_fp","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"NOT_EXPOSED_ECONOMIC_MATCH","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["ECONOMIC_FIELD"],"execution_use":"order/fill quantity reconciliation when exposed","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"initial_count_fp","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointCount","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/initial_count_fp","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"STORED_NONE","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["ECONOMIC_FIELD"],"execution_use":"duplicate/source compatibility only","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"no_price_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/no_price_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_ORDER_FIELD","execution_categories":["IDENTITY_FIELD"],"execution_use":"identity/dedup/binding","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"order_id","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/order_id","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"STORED_NONE","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["STATUS_OR_STATE_FIELD"],"execution_use":"duplicate/source compatibility only","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"outcome_side","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_OPAQUE_NONEMPTY_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_enum":["yes","no"],"source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/outcome_side","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"NOT_EXPOSED_ECONOMIC_MATCH","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["ECONOMIC_FIELD"],"execution_use":"order/fill quantity reconciliation when exposed","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"remaining_count_fp","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_FIXED_POINT_COUNT_2DP_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointCount","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/remaining_count_fp","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"MISSING_BECOMES_NONE_AND_IS_NOT_RESTING_CURRENT_A2","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2__SOURCE_REQUIRED","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["STATUS_OR_STATE_FIELD"],"execution_use":"active-vs-terminal classification","invalid_type_behavior":"AUTHORITATIVE_SOURCE_DRIFT_SPEC_REVISION_REQUIRED_FOR_UNKNOWN_ENUM__MALFORMED_FOR_INVALID_TYPE","name":"status","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_OPAQUE_STRING_AND_ENUM_RESTING_CANCELED_EXECUTED","schema_ref":"#/components/schemas/OrderStatus","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_enum":["resting","canceled","executed"],"source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/status","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_ORDER_FIELD","execution_categories":["SCOPE_SHARD_FIELD"],"execution_use":"target subaccount scope","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"subaccount_number","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_BUT_ARB_REQUIRED","runtime_parser_or_normalization":"EXACT_BUILTIN_INT__BOOL_PROHIBITED","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PERMITTED","source_pointer":"#/components/schemas/Order/properties/subaccount_number","source_requiredness":"SOURCE_OPTIONAL","source_schema":"Order","source_type":"integer"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_ORDER_FIELD","execution_categories":["IDENTITY_FIELD","SCOPE_SHARD_FIELD"],"execution_use":"target market scope","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"ticker","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"OPAQUE_NONEMPTY_EXACT_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/ticker","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"},{"absence_behavior":"STORED_NONE","arb_requiredness":"ARB_OPTIONAL_CURRENT_A2","current_a2_use":"PARSED_IF_PRESENT_AND_RETAINED_FOR_COMPATIBILITY/CLASSIFICATION","execution_categories":["ECONOMIC_FIELD"],"execution_use":"duplicate/source compatibility only","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"yes_price_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_ARB_OPTIONAL","runtime_parser_or_normalization":"IF_PRESENT_FIXED_POINT_DOLLARS_REGEX_TO_DECIMAL","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Order/properties/yes_price_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"Order","source_type":"string"}]},"source_refs":{"comparison_role":"PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION","openapi_operation_pointer":"#/paths/~1portfolio~1orders/get","rendered_url":"https://docs.kalshi.com/api-reference/orders/get-orders"}},"LIVE_POSITIONS":{"authentication":"AUTHENTICATED","exchange_index_a3_contract":"REQUIRED_NON_NULL_EXACT_BUILTIN_INT_GE_0__TARGET_SCOPE_0_FOR_TARGET_SUPPORTING_ROWS","limit_range":[1,1000],"method":"GET","pagination":true,"partition_semantics":"unsettled positions always live; settled positions may move by whole event to historical","path":"/trade-api/v2/portfolio/positions","query_parameter_names":["count_filter","cursor","event_ticker","exchange_index","limit","subaccount","ticker"],"query_parameters":[{"arb_request_use":"NOT_SENT__SOURCE_CONTRACT_OR_PAIR_DERIVATION_ONLY","default":null,"maximum":null,"minimum":null,"name":"count_filter","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"},{"arb_request_use":"SENT_AFTER_FIRST_PAGE","default":null,"maximum":null,"minimum":null,"name":"cursor","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"},{"arb_request_use":"NOT_SENT__SOURCE_CONTRACT_OR_PAIR_DERIVATION_ONLY","default":null,"maximum":null,"minimum":null,"name":"event_ticker","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":0,"name":"exchange_index","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int32","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":100,"maximum":1000,"minimum":1,"name":"limit","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int32","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"subaccount","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"ticker","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"}],"request_scope_fields":["exchange_index","subaccount","ticker"],"response_contract":{"container_fields":[{"absence_behavior":"PAGINATION_CURSOR_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER","execution_categories":["PAGINATION_FIELD"],"execution_use":"pagination continuation","invalid_type_behavior":"PAGINATION_CURSOR_MALFORMED","name":"cursor","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_BUT_ARB_REQUIRED","runtime_parser_or_normalization":"EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetPositionsResponse/properties/cursor","source_requiredness":"SOURCE_OPTIONAL","source_schema":"GetPositionsResponse","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER","execution_categories":["SUPPORTING_EVIDENCE_FIELD"],"execution_use":"supporting market-position stream","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"market_positions","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"ARRAY_OF_MARKET_POSITION_OBJECTS","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetPositionsResponse/properties/market_positions","source_requiredness":"SOURCE_REQUIRED","source_schema":"GetPositionsResponse","source_type":"array"}],"fields":[{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED_BY_REV03","arb_requiredness":"ARB_REQUIRED_BY_REV03","current_a2_use":"NOT_PARSED_CURRENT_A2__REV03_REQUIRES_PRESERVE/VALIDATE","execution_categories":["SCOPE_SHARD_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"target shard scope for market_positions row","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"exchange_index","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"REV03_REQUIRES_EXACT_BUILTIN_INT__BOOL_PROHIBITED__GE_0","schema_ref":"#/components/schemas/ExchangeIndex","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/MarketPosition/properties/exchange_index","source_requiredness":"SOURCE_REQUIRED","source_schema":"MarketPosition","source_type":"integer"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"fees_paid_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/MarketPosition/properties/fees_paid_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"MarketPosition","source_type":"string"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["SUPPORTING_EVIDENCE_FIELD","TEMPORAL_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"last_updated_ts","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_DATE_TIME_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"date-time","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/MarketPosition/properties/last_updated_ts","source_requiredness":"SOURCE_REQUIRED","source_schema":"MarketPosition","source_type":"string"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"market_exposure_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/MarketPosition/properties/market_exposure_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"MarketPosition","source_type":"string"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"position_fp","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_COUNT_STRING","schema_ref":"#/components/schemas/FixedPointCount","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/MarketPosition/properties/position_fp","source_requiredness":"SOURCE_REQUIRED","source_schema":"MarketPosition","source_type":"string"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"realized_pnl_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/MarketPosition/properties/realized_pnl_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"MarketPosition","source_type":"string"},{"absence_behavior":"SOURCE_REQUIRES; CURRENT_A2 raw.get could treat absence as target-like; later correction should preserve source-required baseline","arb_requiredness":"ARB_REQUIRED_FOR_TARGET_SUPPORTING_ROW","current_a2_use":"RAW_FIELD_READ_FOR_TARGET_TICKER_FILTER","execution_categories":["IDENTITY_FIELD","SCOPE_SHARD_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"target supporting-row selection","invalid_type_behavior":"NON_STRING_OR_OTHER_TYPE_NOT_VALIDATED_CURRENT_A2","name":"ticker","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"CURRENT_A2_READS_RAW_VALUE__EXACT_TARGET_TICKER_EQUALITY_IF_PRESENT","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/MarketPosition/properties/ticker","source_requiredness":"SOURCE_REQUIRED","source_schema":"MarketPosition","source_type":"string"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"total_traded_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/MarketPosition/properties/total_traded_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"MarketPosition","source_type":"string"}]},"response_subaccount_field":"NOT_EXPOSED","source_refs":{"comparison_role":"PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION","openapi_operation_pointer":"#/paths/~1portfolio~1positions/get","rendered_url":"https://docs.kalshi.com/api-reference/portfolio/get-positions"}},"SETTLEMENTS":{"authentication":"AUTHENTICATED","exchange_index_a3_contract":"REQUIRED_NON_NULL_EXACT_BUILTIN_INT_GE_0__TARGET_SCOPE_0_FOR_TARGET_SUPPORTING_ROWS","limit_range":[1,1000],"method":"GET","pagination":true,"path":"/trade-api/v2/portfolio/settlements","query_parameter_names":["cursor","event_ticker","limit","max_ts","min_ts","subaccount","ticker"],"query_parameters":[{"arb_request_use":"SENT_AFTER_FIRST_PAGE","default":null,"maximum":null,"minimum":null,"name":"cursor","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"},{"arb_request_use":"NOT_SENT__SOURCE_CONTRACT_OR_PAIR_DERIVATION_ONLY","default":null,"maximum":null,"minimum":null,"name":"event_ticker","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"},{"arb_request_use":"SENT_REQUIRED","default":100,"maximum":1000,"minimum":1,"name":"limit","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int64","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"max_ts","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int64","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"min_ts","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"int64","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"subaccount","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"integer"},{"arb_request_use":"SENT_REQUIRED","default":null,"maximum":null,"minimum":null,"name":"ticker","openapi_observability":"OBSERVED","rendered_observability":"OBSERVED_QUERY_PARAMETER","source_conflict_rule":"POSITIVE_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_requiredness":"SOURCE_OPTIONAL","source_type":"string"}],"request_scope_fields":["subaccount","ticker"],"response_contract":{"container_fields":[{"absence_behavior":"PAGINATION_CURSOR_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER","execution_categories":["PAGINATION_FIELD"],"execution_use":"pagination continuation","invalid_type_behavior":"PAGINATION_CURSOR_MALFORMED","name":"cursor","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_BUT_ARB_REQUIRED","runtime_parser_or_normalization":"EXACT_STRING__EMPTY_TERMINAL__NONEMPTY_OPAQUE","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetSettlementsResponse/properties/cursor","source_requiredness":"SOURCE_OPTIONAL","source_schema":"GetSettlementsResponse","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AND_REQUIRED_BY_GENERIC_RESPONSE/PAGINATION_LAYER","execution_categories":["SUPPORTING_EVIDENCE_FIELD"],"execution_use":"supporting settlement stream","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"settlements","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"ARRAY_OF_SETTLEMENT_OBJECTS","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetSettlementsResponse/properties/settlements","source_requiredness":"SOURCE_REQUIRED","source_schema":"GetSettlementsResponse","source_type":"array"}],"fields":[{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"event_ticker","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Settlement/properties/event_ticker","source_requiredness":"SOURCE_REQUIRED","source_schema":"Settlement","source_type":"string"},{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED_BY_REV03","arb_requiredness":"ARB_REQUIRED_BY_REV03","current_a2_use":"NOT_PARSED_CURRENT_A2__REV03_REQUIRES_PRESERVE/VALIDATE","execution_categories":["SCOPE_SHARD_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"target shard scope for settlement row","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"exchange_index","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"REV03_REQUIRES_EXACT_BUILTIN_INT__BOOL_PROHIBITED__GE_0","schema_ref":"#/components/schemas/ExchangeIndex","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Settlement/properties/exchange_index","source_requiredness":"SOURCE_REQUIRED","source_schema":"Settlement","source_type":"integer"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"fee_cost","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Settlement/properties/fee_cost","source_requiredness":"SOURCE_REQUIRED","source_schema":"Settlement","source_type":"string"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"no_count_fp","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_COUNT_STRING","schema_ref":"#/components/schemas/FixedPointCount","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Settlement/properties/no_count_fp","source_requiredness":"SOURCE_REQUIRED","source_schema":"Settlement","source_type":"string"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"no_total_cost_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Settlement/properties/no_total_cost_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"Settlement","source_type":"string"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"revenue","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_INTEGER","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Settlement/properties/revenue","source_requiredness":"SOURCE_REQUIRED","source_schema":"Settlement","source_type":"integer"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["SUPPORTING_EVIDENCE_FIELD","TEMPORAL_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"settled_time","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_DATE_TIME_STRING","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"date-time","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Settlement/properties/settled_time","source_requiredness":"SOURCE_REQUIRED","source_schema":"Settlement","source_type":"string"},{"absence_behavior":"SOURCE_REQUIRES; CURRENT_A2 raw.get could treat absence as target-like","arb_requiredness":"ARB_REQUIRED_FOR_TARGET_SUPPORTING_ROW","current_a2_use":"RAW_FIELD_READ_FOR_TARGET_TICKER_FILTER","execution_categories":["IDENTITY_FIELD","SCOPE_SHARD_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"target supporting-row selection","invalid_type_behavior":"NON_STRING_OR_OTHER_TYPE_NOT_VALIDATED_CURRENT_A2","name":"ticker","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"CURRENT_A2_READS_RAW_VALUE__EXACT_TARGET_TICKER_EQUALITY_IF_PRESENT","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Settlement/properties/ticker","source_requiredness":"SOURCE_REQUIRED","source_schema":"Settlement","source_type":"string"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"value","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_OPTIONAL_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_NULLABLE_INTEGER","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PERMITTED","source_pointer":"#/components/schemas/Settlement/properties/value","source_requiredness":"SOURCE_OPTIONAL","source_schema":"Settlement","source_type":"integer"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"yes_count_fp","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_COUNT_STRING","schema_ref":"#/components/schemas/FixedPointCount","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Settlement/properties/yes_count_fp","source_requiredness":"SOURCE_REQUIRED","source_schema":"Settlement","source_type":"string"},{"absence_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","arb_requiredness":"PRESERVED_SOURCE_BINDING__NOT_ARITHMETICALLY_CONSUMED_CURRENT_A2","current_a2_use":"NOT_PARSED_CURRENT_A2__PREDECESSOR_SOURCE_BINDING_ONLY","execution_categories":["ECONOMIC_FIELD","SUPPORTING_EVIDENCE_FIELD"],"execution_use":"Revision-02 supporting schema anchor","invalid_type_behavior":"NO_CURRENT_A2_INSTANCE_EFFECT","name":"yes_total_cost_dollars","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_EXAMPLE_OR_CHILD_PRESENT","requiredness_class":"SOURCE_REQUIRED_BUT_NON_CONSUMED","runtime_parser_or_normalization":"NOT_PARSED_CURRENT_A2__SOURCE_EXPECTS_FIXED_POINT_DOLLARS_STRING","schema_ref":"#/components/schemas/FixedPointDollars","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"NONE","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/Settlement/properties/yes_total_cost_dollars","source_requiredness":"SOURCE_REQUIRED","source_schema":"Settlement","source_type":"string"}]},"response_subaccount_field":"NOT_EXPOSED","role":"SUPPORTING_ECONOMIC_CROSS_CHECK_ONLY__NOT_ORDER_IDENTITY","source_refs":{"comparison_role":"PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION","openapi_operation_pointer":"#/paths/~1portfolio~1settlements/get","rendered_url":"https://docs.kalshi.com/api-reference/portfolio/get-settlements"}},"USER_DATA_TIMESTAMP":{"authentication":"PUBLIC","method":"GET","negative_semantics":"NOT_TRANSACTIONALLY_EXACT","pagination":false,"path":"/trade-api/v2/exchange/user_data_timestamp","query_parameter_names":[],"query_parameters":[],"response_contract":{"container_fields":[],"fields":[{"absence_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","arb_requiredness":"ARB_REQUIRED","current_a2_use":"PARSED_AS_REQUIRED_UTC_RFC3339_FRESHNESS_FIELD","execution_categories":["NEGATIVE_THEOREM_FIELD","TEMPORAL_FIELD"],"execution_use":"approximate freshness ordering evidence only","invalid_type_behavior":"AUTHORITATIVE_RESPONSE_MALFORMED","name":"as_of_time","openapi_observability":"OBSERVED","rendered_observability":"RENDERED_FIELD_PRESENT","requiredness_class":"SOURCE_REQUIRED_AND_ARB_REQUIRED","runtime_parser_or_normalization":"UTC_RFC3339_ZERO_OFFSET_REQUIRED","source_conflict_rule":"POSITIVE_MATERIAL_CLAIM_DISAGREEMENT__OFFICIAL_SOURCE_CONFLICT__RENDERED_SILENCE_NOT_CONFLICT","source_format":"date-time","source_nullability":"NULL_PROHIBITED","source_pointer":"#/components/schemas/GetUserDataTimestampResponse/properties/as_of_time","source_requiredness":"SOURCE_REQUIRED","source_schema":"GetUserDataTimestampResponse","source_type":"string"}]},"semantic_notes":["approximate indication of when GetBalance/GetOrder(s)/GetFills/GetPositions data was last validated","short reflection delay documented"],"source_refs":{"comparison_role":"PROVENANCE_AND_POSITIVE_SEMANTIC_CORROBORATION","openapi_operation_pointer":"#/paths/~1exchange~1user_data_timestamp/get","rendered_url":"https://docs.kalshi.com/api-reference/exchange/get-user-data-timestamp"}}},"schema_id":"KALSHI_PRIMARY_DOMAIN_HISTORICAL_RESOLUTION_EXECUTION_MATERIAL_SOURCE_CONTRACT_REV5","source_responsibility":{"changelog":["dated_behavioral_changes"],"historical_environment_guides":["environment_separation","recommended_roots","historical_partition_semantics","retention_exposure"],"openapi_schema_structural_metadata":["type","format","requiredness","nullability","enum","minimum","maximum"],"positive_claim_conflict_rule":"OFFICIAL_SOURCE_CONFLICT","rendered_endpoint_reference":["method","path","query_surface","semantic_description","operation_examples"],"rendered_silence_rule":"SILENCE_DOES_NOT_OVERRIDE_POSITIVE_OPENAPI_STRUCTURAL_METADATA","unexposed_required_attribute_rule":"CURRENT_SOURCE_CONTRACT_UNRESOLVED"}}
END_REV05_CANONICAL_JSON
```

## 15. Revision-03 preservation table

### RA4-PRESERVE-005

Table C proves preservation/correction classification for every named Revision-03 requirement.

| REV03 REQUIREMENT | STATUS IN REV04 | UNCHANGED / CORRECTED BY C01 | RATIONALE |
| --- | --- | --- | --- |
| RA3-BASE-001 — exact canonical repository | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-BASE-002 — exact controlling predecessor | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-BASE-003 — installed A2 reference identity | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-BASE-004 — failed A3 public-only evidence | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-CAP-001 — capabilities used by this specification task | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-PRESERVE-001 — unchanged safety theorem | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-PRESERVE-002 — exact ten operations remain closed | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-SRC-001 — two-layer source model | PRESERVED | CORRECTED BY C01 | Blocked Rev03 projection representation is replaced/expanded; underlying accepted behavior is preserved unless this requirement specifically described the blocked manifest. |
| RA3-SRC-002 — field registry and derivation rules | PRESERVED | CORRECTED BY C01 | Blocked Rev03 projection representation is replaced/expanded; underlying accepted behavior is preserved unless this requirement specifically described the blocked manifest. |
| RA3-SRC-003 — unsupported query fields | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-SRC-004 — query-parameter normalization | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-SRC-005 — current-source class agreement | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-COMP-001 — comparison matrix | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-COMP-002 — extra and removed fields | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-COMP-003 — `NOT_EXPOSED` | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-SHARD-001 — source finding | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-SHARD-002 — exact `exchange_index` value rule | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-SHARD-003 — fill identity/scope tuple | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-SHARD-004 — fill duplicate and scope behavior | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-SHARD-005 — position observations | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-SHARD-006 — settlement observations | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-SHARD-007 — live/historical consistency | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-SETTLE-001 — evidence distinction | PRESERVED | UNCHANGED; PROVENANCE ENRICHED | OpenAPI and current rendered Get Settlements evidence both positively expose market_result; non-consumption and no A3 gate consequence remain preserved. |
| RA3-SETTLE-002 — classification | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-SETTLE-003 — future source handling | PRESERVED | UNCHANGED; PROVENANCE ENRICHED | OpenAPI and current rendered Get Settlements evidence both positively expose market_result; non-consumption and no A3 gate consequence remain preserved. |
| RA3-HIST-001 — partition semantics remain exact | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-HIST-002 — retention lower bound | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-HIST-003 — exact-order 404 | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-MANIFEST-001 — canonical serialization | PRESERVED | CORRECTED BY C01 | Blocked Rev03 projection representation is replaced/expanded; underlying accepted behavior is preserved unless this requirement specifically described the blocked manifest. |
| RA3-MANIFEST-002 — per-operation binding identities | PRESERVED | CORRECTED BY C01 | Blocked Rev03 projection representation is replaced/expanded; underlying accepted behavior is preserved unless this requirement specifically described the blocked manifest. |
| RA3-MANIFEST-003 — canonical projection content | PRESERVED | CORRECTED BY C01 | Blocked Rev03 projection representation is replaced/expanded; underlying accepted behavior is preserved unless this requirement specifically described the blocked manifest. |
| RA3-IMPACT-001 — source-binding-only deltas | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-IMPACT-002 — bounded parser compatibility required | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| DISPATCH AUDIT LABEL RA3-A3-001 — failed attempt did not consume marker (no RA3-A3-001 heading exists in the verified blocked Revision 03 artifact) | BEHAVIOR PRESERVED | UNCHANGED | The requested audit label is not invented as a predecessor requirement ID. Its behavior is preserved by the actual Revision-03 pre-marker/A3-boundary requirements, including RA3-BASE-004 and RA3-PRESERVE-001. |
| DISPATCH AUDIT LABEL RA3-A3-002 — no automatic rerun (no RA3-A3-002 heading exists in the verified blocked Revision 03 artifact) | BEHAVIOR PRESERVED | UNCHANGED | The requested audit label is not invented as a predecessor requirement ID. The no-automatic-rerun behavior remains preserved by the actual Revision-03 A3 boundary and the Revision-04 execution prohibition. |
| RA3-FUTURE-001 — fill/shard identity | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-FUTURE-002 — target balance allocation | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-FUTURE-003 — August-27 routing change | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-FUTURE-004 — NFL combo fee exception | PRESERVED | UNCHANGED | Preserved without functional weakening; C01 does not alter this requirement. |
| RA3-TEST-001 — source derivation | PRESERVED | UNCHANGED + REV04 ADDITIVE TESTS | Rev03 test obligation remains; Revision 04 adds projection-coverage, temporal, and structural-metadata drift tests. |
| RA3-TEST-002 — dual source class | PRESERVED | UNCHANGED + REV04 ADDITIVE TESTS | Rev03 test obligation remains; Revision 04 adds projection-coverage, temporal, and structural-metadata drift tests. |
| RA3-TEST-003 — fill shard validation | PRESERVED | UNCHANGED + REV04 ADDITIVE TESTS | Rev03 test obligation remains; Revision 04 adds projection-coverage, temporal, and structural-metadata drift tests. |
| RA3-TEST-004 — position/settlement shard preservation | PRESERVED | UNCHANGED + REV04 ADDITIVE TESTS | Rev03 test obligation remains; Revision 04 adds projection-coverage, temporal, and structural-metadata drift tests. |
| RA3-TEST-005 — `market_result` and schema extras | PRESERVED | UNCHANGED + REV04 ADDITIVE TESTS | Rev03 test obligation remains; Revision 04 adds projection-coverage, temporal, and structural-metadata drift tests. |
| RA3-TEST-006 — `NOT_EXPOSED` and negative theorem | PRESERVED | UNCHANGED + REV04 ADDITIVE TESTS | Rev03 test obligation remains; Revision 04 adds projection-coverage, temporal, and structural-metadata drift tests. |
| RA3-TEST-007 — preserved regression invariants | PRESERVED | UNCHANGED + REV04 ADDITIVE TESTS | Rev03 test obligation remains; Revision 04 adds projection-coverage, temporal, and structural-metadata drift tests. |

## 16. Smallest future implementation envelope

### RA5-IMPL-001 — no implementation authorization

This Revision-05 artifact is SPEC_ONLY. It does not authorize source changes, test-source changes, test execution, staging, Git writes, credentials, venue access, or A3.

If a later implementation task is separately created, the smallest required writable path set is exactly:

```text
src/arb/venues/kalshi/write_result_reconciliation.py
tests/test_kalshi_write_result_reconciliation.py
```

All other paths at canonical base `8787dd4b4ec5a8ba1fbb5b0e8c81ad2d8706cd39` are readable protected dependencies and must remain unchanged unless that later task explicitly says otherwise.

### RA5-IMPL-002 — bounded later changes only

A later implementation must be limited to installing the accepted Revision-05 source contract:

```text
1. accepted market_result_contract.rendered_observation -> POSITIVELY_EXPOSED_AS_CHILD_IN_CURRENT_RENDERED_RESEARCH_INTERFACE
2. accepted schema_id -> KALSHI_PRIMARY_DOMAIN_HISTORICAL_RESOLUTION_EXECUTION_MATERIAL_SOURCE_CONTRACT_REV5
3. normalization_revision remains exactly 4
4. accepted canonical source-contract identity -> 143864 bytes / dc30bf877ce9ce7d8f65c97357fafe6891ce1af359bc7d2b4c9747278ad9a762
5. comparator expected-baseline identity updated mechanically to Revision 05
6. focused tests proving the one accepted value change and preservation of all non-consumed/A3-false semantics
```

No Provider-02J semantic extraction rewrite belongs in this correction. If Provider-02J or a runner contains an explicit accepted source-contract identity binding that mechanically names Revision 04, any change to that external artifact is a separate provenance-binding task, not part of the two repository writable paths above.

### RA5-IMPL-003 — prohibited future scope expansion

The bounded later implementation must not change:

```text
request planner
ten-operation surface
2-public / 8-auth split
request budgets
response parser semantics
identity-binding theorem
zero-match theorem
economic formulas/reconciliation
historical partition semantics
exchange_index semantics
result taxonomy
persistent state
writer-proof state
credential/signing sequencing
Demo-only / GET-only envelope
A3 capability
```

## 17. Revision-05 comparator contract and A3 boundary

### RA5-COMP-001 — accepted current observation

The accepted current value is exactly:

```text
market_result_contract.rendered_observation = POSITIVELY_EXPOSED_AS_CHILD_IN_CURRENT_RENDERED_RESEARCH_INTERFACE
```

The supplied Provider-02J current candidate, before Revision-05 provenance relabeling, canonicalized to:

```text
canonical_json_bytes = 143864
canonical_json_sha256 = 9616fcb6ce9d29c2e6ddf8747524f7d335d2f7ef13c69a91daf57ad53bfa94b9
schema_id = ...REV4
```

Revision 05 changes only the provenance `schema_id` to `...REV5`; the accepted Revision-05 canonical identity is therefore the RA5-MANIFEST-001 identity, not the pre-relabel Provider candidate hash.

### RA5-COMP-002 — future source drift behavior

For any future public-docs-only source preflight against the installed Revision-05 baseline:

1. the positive rendered observation above is the accepted value;
2. a current-source value different from the accepted value is `SOURCE_DRIFT_AUTHORITATIVE_SOURCE_DRIFT_SPEC_REVISION_REQUIRED`;
3. such drift halts before marker access, credential reference/value/file access, signing, Demo access, production access, or A3 execution;
4. all execution-material Revision-04 drift checks remain unchanged;
5. the global fail-closed source-drift gate is not weakened to accommodate this correction;
6. `market_result` remains non-consumed, so its positive visibility does not change request generation, response parsing, identity binding, economic reconciliation, or terminal result classification.

### RA5-COMP-003 — exact responsibility/proof shape

The accepted contract must preserve the current complete shape:

```text
responsibility paths = 1028
current atoms = 1028
SourceProofs = 1028
unresolved _CURRENT = 0
```

No source-responsibility path may be added or removed solely because rendered `market_result` is now positively visible.

### RA5-A3-001 — no automatic A3

No automatic A3 rerun follows this specification or a future implementation. After a future implementation is independently reviewed, the next external gate remains a fresh closed 19-source public-docs-only preflight. Only a later task may decide whether any higher-risk phase is permitted.

This specification does not authorize marker creation/access, credentials, signing, Demo requests, production requests, A3 execution, writer-proof release, or Gate D.

## 18. Required later tests — offline only

No tests are executed by this SPEC_ONLY task.

### RA5-TEST-001 — focused Revision-05 contract delta

A later implementation must prove, offline, all of the following:

```text
accepted rendered_observation = POSITIVELY_EXPOSED_AS_CHILD_IN_CURRENT_RENDERED_RESEARCH_INTERFACE
market_result classification unchanged = NOT_CONFIRMED__NOT_EXECUTION_MATERIAL
a3_parse = false
a3_compare = false
a3_identity_use = false
a3_economic_use = false
absence_alone_malformed = false
conflict_consequence unchanged
normalization_revision = 4
schema_id = ...REV5
canonical bytes/hash = 143864 / dc30bf877ce9ce7d8f65c97357fafe6891ce1af359bc7d2b4c9747278ad9a762
all ten per-operation bytes/hashes unchanged from Revision 04
PUBLIC UDT preserved
PUBLIC HISTORICAL_CUTOFF preserved
2-public / 8-auth split preserved
responsibility/proof counts remain 1028/1028/1028 with zero missing/extra/unresolved
no request-planner or A3 capability change
```

The inherited Revision-04 offline test obligations below remain regression obligations.

### RA4-TEST-001 — predecessor/projection coverage

Later tests must:

```text
reconstruct the exact 7056-byte Revision-02 manifest
classify every predecessor field family
fail on any unclassified predecessor field
prove every predecessor execution-material atom is represented
prove every Rev03 accepted source atom is represented
prove every runtime-consumed atom is represented
prove the exclusion set contains only explicit non-material/provenance items
prove missing_atoms = 0
```

### RA4-TEST-002 — fill temporal matrix

Require exact tests for:

```text
created_time valid RFC3339
created_time malformed
ts integer accepted but not converted/selected for fill_time
ts RFC3339 string accepted under current runtime compatibility
both present with string ts -> ts wins
both present with integer ts + valid created_time -> created_time selected
both absent -> no temporal exclusion
null present -> malformed
timezone-aware non-UTC offset accepted
naive timestamp rejected
lower bound exact equality retained
upper bound exact equality retained
below lower bound excluded
above upper bound excluded
no equality comparison between ts and created_time
```

### RA4-TEST-003 — structural drift matrix

Generate/table-drive every consumed descriptor for:

```text
field removal
type drift
required -> optional
optional -> required
nullability drift
material format drift
material enum/range drift
unexpected consumed-category addition
positive OpenAPI/rendered material disagreement
```

Every source drift must halt before marker, credential read, or Demo request in any later A3 gate.

### RA4-TEST-004 — predecessor semantic regression

Direct tests must cover at minimum:

```text
environment.demo_rest_root
environment.production_rest_root
environment.credentials_shared
LIVE_FILLS.partition_semantics
LIVE_ORDERS.partition_semantics
HISTORICAL_ORDERS.partition_semantics
LIVE_POSITIONS.partition_semantics
HISTORICAL_POSITIONS.partition_semantics
EXACT_ORDER.documented_http_statuses
EXACT_ORDER.path_parameters
EXACT_ORDER.http_404_nonexistence_theorem
USER_DATA_TIMESTAMP.negative_semantics
USER_DATA_TIMESTAMP.semantic_notes
operation-specific retention_lower_bound
scope/request fields
response_subaccount_field
```

### RA4-TEST-005 — preserve Revision-03 tests

Preserve all accepted Revision-03 tests for:

```text
mechanical unsupported_query_fields
ten normalized query sets
exchange_index fill validation
exchange_index position/settlement validation
market_result non-consumption
NOT_EXPOSED semantics
exact-order 404 theorem
zero-match theorem
ten-operation closure
Demo-only / GET-only
global request maximum 116
master deadline 180000 ms
per-request ceiling 10000 ms
zero retries
zero redirects
writer proof HELD
no persistent-state mutation
no automatic A3 rerun
```

## 19. Revision-05 traceability requirement

### RA5-TRACE-001

Every later implementation/review report must map:

```text
SPEC REQUIREMENT -> REV05 LOCATION -> EVIDENCE -> STATUS
```

Minimum Revision-05 traceability:

| SPEC REQUIREMENT | REV05 LOCATION | EVIDENCE | STATUS |
| --- | --- | --- | --- |
| positive rendered `market_result` observation | RA5-SCOPE-001; RA5-SRC-004; RA5-MANIFEST-003 | preflight output + localization output + screenshot; exact bundled identities | SATISFIED_BY_SPEC |
| `market_result` non-consumption | RA5-SCOPE-001; inherited RA4-PRESERVE-004 | classification remains `NOT_CONFIRMED__NOT_EXECUTION_MATERIAL` | SATISFIED_BY_SPEC |
| A3 parse/compare/identity/economic all false | RA5-SCOPE-001; RA5-SRC-004 | exact Boolean fields in Revision-05 projection | SATISFIED_BY_SPEC |
| absence alone malformed remains false | RA5-SCOPE-001; RA5-SRC-004 | exact Boolean field | SATISFIED_BY_SPEC |
| conflict consequence preserved | RA5-SCOPE-001; RA5-MANIFEST-003 | exact unchanged string | SATISFIED_BY_SPEC |
| PUBLIC UDT preserved | RA5-SRC-001; RA5-MANIFEST-003 | Provider-02J preflight records PUBLIC | SATISFIED_BY_SPEC |
| PUBLIC historical cutoff preserved | RA5-SRC-001; RA5-MANIFEST-003 | Provider-02J preflight records PUBLIC | SATISFIED_BY_SPEC |
| 2-public / 8-auth split preserved | RA5-SRC-001; RA5-IMPL-003 | exact ten-operation authentication classification | SATISFIED_BY_SPEC |
| 1028 responsibility paths preserved | RA5-SRC-001; RA5-COMP-003 | 1028 candidate atoms / proofs, zero missing/extra/unresolved | SATISFIED_BY_SPEC |
| all execution-material Rev04 semantics preserved | RA5-SCOPE-001; inherited Sections 4-13; RA5-IMPL-003 | one-difference localization proves no second current manifest difference | SATISFIED_BY_SPEC |
| Rev05 source-contract identity exact | RA5-MANIFEST-001..003 | 143864 bytes / dc30bf877ce9ce7d8f65c97357fafe6891ce1af359bc7d2b4c9747278ad9a762; schema_id REV5; normalization_revision 4 | SATISFIED_BY_SPEC |
| future comparator behavior exact | RA5-COMP-001..003 | accepted value + fail-closed future drift rule | SATISFIED_BY_SPEC |
| no A3 capability expansion | RA5-SCOPE-002; RA5-A3-001 | A3/marker/credential/Demo prohibited; fresh preflight remains next gate | SATISFIED_BY_SPEC |
| Provider-02J extraction not reopened | RA5-BASE-005; RA5-IMPL-002 | reviewed package/provider identities + one-difference localization | SATISFIED_BY_SPEC |

A later implementation report changes status to implementation/test evidence as appropriate without weakening these requirements.

## 20. Stop conditions

### RA5-STOP-001

Stop rather than broaden scope on any of:

```text
CANONICAL_BASE_MISMATCH
CONTROLLING_SPEC04_IDENTITY_MISMATCH
CONTROLLING_HANDOFF04_IDENTITY_MISMATCH
EVIDENCE_IDENTITY_MISMATCH
MORE_THAN_ONE_CURRENT_MANIFEST_SEMANTIC_DIFF_FOUND
MARKET_RESULT_EXECUTION_MATERIALITY_REQUIRED
UNEXPLAINED_SOURCE_CONTRACT_IDENTITY_CONFLICT
OFFICIAL_SOURCE_CONFLICT
CURRENT_SOURCE_CONTRACT_UNRESOLVED
ROUTE_A_FUNCTIONAL_CONTRACT_CONFLICT_REQUIRES_SEPARATE_REVISION
SCOPE_EXPANSION_REQUIRED
```

Also stop if evidence would require changing any of:

```text
A3 request planner
request budgets
identity theorem
zero-match theorem
economic reconciliation
persistent state
writer-proof state
credential/signing sequencing
2-public / 8-auth split
historical partition
exchange_index semantics
order/fill/position/settlement parser behavior
market_result execution use
Demo-only / GET-only envelope
```

No uncertainty may be resolved by weakening the source gate, inventing execution materiality, deleting a source field, or expanding capability.

## 21. Completion criteria

Revision 05 is technically complete only when all are true:

```text
canonical main/tree/parent reverified exactly
controlling Revision-04 spec identity verified
controlling Revision-04 handoff identity verified
Provider-02J preflight evidence identity verified
Revision-04 drift-localization evidence identity verified
rendered screenshot identity verified and visually corroborating
exactly one current manifest semantic difference accepted
accepted rendered_observation changed to POSITIVELY_EXPOSED_AS_CHILD_IN_CURRENT_RENDERED_RESEARCH_INTERFACE
market_result remains NOT_CONFIRMED__NOT_EXECUTION_MATERIAL
a3_parse/a3_compare/a3_identity_use/a3_economic_use remain false
absence_alone_malformed remains false
conflict consequence preserved
PUBLIC UDT preserved
PUBLIC historical cutoff preserved
2-public / 8-auth split preserved
responsibility/current-atom/SourceProof counts remain 1028/1028/1028
zero missing candidate atoms / missing proofs / extra proofs / unresolved current sentinels
Revision-05 schema_id fixed
normalization_revision remains 4
Revision-05 canonical projection fixed at 143864 bytes / dc30bf877ce9ce7d8f65c97357fafe6891ce1af359bc7d2b4c9747278ad9a762
all ten per-operation canonical identities preserved
no Provider semantic extraction correction specified
no request planner/parser/identity/economic/persistence/writer/A3 capability change
no implementation/test/credential/venue/persistent-state/repository/Git/A3 activity performed
```

---

# Appendix A — exact Revision-02 normalized manifest

The exact predecessor inventory object canonicalizes to 7056 bytes and SHA-256 `22f4b6a8022bfe862536ce03fc21b91520b084c6361bd6c84fa6c51ca749451f`.

```json
{
  "environment": {
    "credentials_shared": false,
    "demo_rest_root": "https://external-api.demo.kalshi.co/trade-api/v2",
    "production_rest_root": "https://external-api.kalshi.com/trade-api/v2"
  },
  "historical_partition": {
    "cutoffs_move_forward": true,
    "positions_archived_per_whole_event": true,
    "retention_lower_bound": "NOT_EXPOSED",
    "target_live_window": "3 months"
  },
  "manifest_id": "KALSHI_PRIMARY_DOMAIN_HISTORICAL_RESOLUTION_CURRENT_OFFICIAL_SOURCE_BINDING_2026-08-19_REV2",
  "observed_at_utc": "2026-08-19T23:42:00Z",
  "official_source_scope": "docs.kalshi.com only",
  "operations": {
    "EXACT_ORDER": {
      "authentication": "AUTHENTICATED",
      "documented_http_statuses": [
        200,
        401,
        404,
        500
      ],
      "http_404_nonexistence_theorem": "NOT_EXPOSED",
      "method": "GET",
      "pagination": false,
      "path": "/trade-api/v2/portfolio/orders/{order_id}",
      "path_parameters": [
        "order_id"
      ],
      "query_parameters": [],
      "response_identity_fields": [
        "order_id",
        "client_order_id",
        "ticker",
        "subaccount_number",
        "exchange_index"
      ],
      "source_url": "https://docs.kalshi.com/api-reference/orders/get-order"
    },
    "HISTORICAL_CUTOFF": {
      "authentication": "PUBLIC",
      "method": "GET",
      "negative_semantics": "PARTITION_BOUNDARY_ONLY__NOT_RETENTION_LOWER_BOUND",
      "pagination": false,
      "path": "/trade-api/v2/historical/cutoff",
      "query_parameters": [],
      "response_identity_fields": [
        "market_settled_ts",
        "trades_created_ts",
        "orders_updated_ts",
        "market_positions_last_updated_ts"
      ],
      "source_url": "https://docs.kalshi.com/api-reference/historical/get-historical-cutoff-timestamps"
    },
    "HISTORICAL_FILLS": {
      "authentication": "AUTHENTICATED",
      "limit_range": [
        1,
        1000
      ],
      "method": "GET",
      "pagination": true,
      "path": "/trade-api/v2/historical/fills",
      "query_parameters": [
        "ticker",
        "max_ts",
        "limit",
        "cursor"
      ],
      "response_economic_fields": [
        "count_fp",
        "yes_price_dollars",
        "no_price_dollars",
        "fee_cost",
        "is_taker"
      ],
      "response_identity_fields": [
        "fill_id",
        "trade_id",
        "order_id",
        "ticker",
        "market_ticker",
        "subaccount_number",
        "exchange_index",
        "ts",
        "created_time"
      ],
      "retention_lower_bound": "NOT_EXPOSED",
      "source_url": "https://docs.kalshi.com/api-reference/historical/get-historical-fills",
      "unsupported_query_fields": [
        "min_ts",
        "order_id",
        "subaccount",
        "exchange_index",
        "client_order_id"
      ]
    },
    "HISTORICAL_ORDERS": {
      "authentication": "AUTHENTICATED",
      "limit_range": [
        1,
        1000
      ],
      "method": "GET",
      "pagination": true,
      "partition_semantics": "canceled/executed orders older than orders_updated_ts",
      "path": "/trade-api/v2/historical/orders",
      "query_parameters": [
        "ticker",
        "max_ts",
        "limit",
        "cursor"
      ],
      "response_identity_fields": [
        "order_id",
        "client_order_id",
        "ticker",
        "subaccount_number",
        "exchange_index"
      ],
      "retention_lower_bound": "NOT_EXPOSED",
      "source_url": "https://docs.kalshi.com/api-reference/historical/get-historical-orders",
      "unsupported_query_fields": [
        "min_ts",
        "status",
        "subaccount",
        "exchange_index",
        "client_order_id"
      ]
    },
    "HISTORICAL_POSITIONS": {
      "authentication": "AUTHENTICATED",
      "limit_range": [
        1,
        1000
      ],
      "market_position_fields": [
        "ticker",
        "exchange_index",
        "total_traded_dollars",
        "position_fp",
        "market_exposure_dollars",
        "realized_pnl_dollars",
        "fees_paid_dollars",
        "last_updated_ts"
      ],
      "method": "GET",
      "pagination": true,
      "partition_semantics": "settled positions archived per whole event; never split across live/historical; cutoff field market_positions_last_updated_ts",
      "path": "/trade-api/v2/historical/positions",
      "query_parameters": [
        "ticker",
        "event_ticker",
        "limit",
        "cursor"
      ],
      "response_subaccount_field": "NOT_EXPOSED",
      "retention_lower_bound": "NOT_EXPOSED",
      "source_url": "https://docs.kalshi.com/api-reference/historical/get-historical-positions",
      "unsupported_query_fields": [
        "subaccount",
        "exchange_index",
        "min_ts",
        "max_ts"
      ]
    },
    "LIVE_FILLS": {
      "authentication": "AUTHENTICATED",
      "limit_range": [
        1,
        1000
      ],
      "method": "GET",
      "pagination": true,
      "partition_semantics": "fills before trades_created_ts historical",
      "path": "/trade-api/v2/portfolio/fills",
      "query_parameters": [
        "ticker",
        "order_id",
        "min_ts",
        "max_ts",
        "limit",
        "cursor",
        "subaccount",
        "exchange_index"
      ],
      "response_economic_fields": [
        "count_fp",
        "yes_price_dollars",
        "no_price_dollars",
        "fee_cost",
        "is_taker"
      ],
      "response_identity_fields": [
        "fill_id",
        "trade_id",
        "order_id",
        "ticker",
        "market_ticker",
        "subaccount_number",
        "exchange_index",
        "ts",
        "created_time"
      ],
      "source_url": "https://docs.kalshi.com/api-reference/portfolio/get-fills"
    },
    "LIVE_ORDERS": {
      "authentication": "AUTHENTICATED",
      "limit_range": [
        1,
        1000
      ],
      "method": "GET",
      "pagination": true,
      "partition_semantics": "resting always live; canceled/fully executed before orders_updated_ts historical",
      "path": "/trade-api/v2/portfolio/orders",
      "query_parameters": [
        "ticker",
        "event_ticker",
        "min_ts",
        "max_ts",
        "status",
        "limit",
        "cursor",
        "subaccount",
        "exchange_index"
      ],
      "response_economic_fields": [
        "yes_price_dollars",
        "no_price_dollars",
        "fill_count_fp",
        "remaining_count_fp",
        "initial_count_fp",
        "taker_fill_cost_dollars",
        "maker_fill_cost_dollars",
        "taker_fees_dollars",
        "maker_fees_dollars"
      ],
      "response_identity_fields": [
        "order_id",
        "client_order_id",
        "ticker",
        "subaccount_number",
        "exchange_index"
      ],
      "scope_request_fields": [
        "ticker",
        "subaccount",
        "exchange_index"
      ],
      "source_url": "https://docs.kalshi.com/api-reference/orders/get-orders"
    },
    "LIVE_POSITIONS": {
      "authentication": "AUTHENTICATED",
      "limit_range": [
        1,
        1000
      ],
      "market_position_fields": [
        "ticker",
        "exchange_index",
        "total_traded_dollars",
        "position_fp",
        "market_exposure_dollars",
        "realized_pnl_dollars",
        "fees_paid_dollars",
        "last_updated_ts"
      ],
      "method": "GET",
      "pagination": true,
      "partition_semantics": "unsettled positions always live; settled positions may move by whole event to historical",
      "path": "/trade-api/v2/portfolio/positions",
      "query_parameters": [
        "cursor",
        "limit",
        "count_filter",
        "ticker",
        "event_ticker",
        "subaccount",
        "exchange_index"
      ],
      "response_subaccount_field": "NOT_EXPOSED",
      "scope_request_fields": [
        "ticker",
        "subaccount",
        "exchange_index"
      ],
      "source_url": "https://docs.kalshi.com/api-reference/portfolio/get-positions"
    },
    "SETTLEMENTS": {
      "authentication": "AUTHENTICATED",
      "limit_range": [
        1,
        1000
      ],
      "method": "GET",
      "pagination": true,
      "path": "/trade-api/v2/portfolio/settlements",
      "query_parameters": [
        "limit",
        "cursor",
        "ticker",
        "event_ticker",
        "min_ts",
        "max_ts",
        "subaccount"
      ],
      "response_fields": [
        "ticker",
        "exchange_index",
        "event_ticker",
        "yes_count_fp",
        "yes_total_cost_dollars",
        "no_count_fp",
        "no_total_cost_dollars",
        "revenue",
        "settled_time",
        "fee_cost",
        "value"
      ],
      "response_subaccount_field": "NOT_EXPOSED",
      "role": "SUPPORTING_ECONOMIC_CROSS_CHECK_ONLY__NOT_ORDER_IDENTITY",
      "scope_request_fields": [
        "ticker",
        "subaccount"
      ],
      "source_url": "https://docs.kalshi.com/api-reference/portfolio/get-settlements"
    },
    "USER_DATA_TIMESTAMP": {
      "authentication": "PUBLIC",
      "method": "GET",
      "negative_semantics": "NOT_TRANSACTIONALLY_EXACT",
      "pagination": false,
      "path": "/trade-api/v2/exchange/user_data_timestamp",
      "query_parameters": [],
      "response_identity_fields": [
        "as_of_time"
      ],
      "semantic_notes": [
        "approximate indication of when GetBalance/GetOrder(s)/GetFills/GetPositions data was last validated",
        "short reflection delay documented"
      ],
      "source_url": "https://docs.kalshi.com/api-reference/exchange/get-user-data-timestamp"
    }
  },
  "raw_openapi": {
    "bytes": null,
    "materialized": false,
    "reason": "available web retrieval permitted semantic inspection but raw bytes could not be materialized for independent hashing",
    "sha256": null
  }
}
```

# Appendix B — coverage atom enumerations

#### PREDECESSOR_EXECUTION_MATERIAL

```json
[
  "environment.credentials_shared",
  "environment.demo_rest_root",
  "environment.production_rest_root",
  "historical_partition.cutoffs_move_forward",
  "historical_partition.positions_archived_per_whole_event",
  "historical_partition.retention_lower_bound",
  "historical_partition.target_live_window",
  "official_source_scope",
  "operations.EXACT_ORDER.authentication",
  "operations.EXACT_ORDER.documented_http_statuses",
  "operations.EXACT_ORDER.http_404_nonexistence_theorem",
  "operations.EXACT_ORDER.method",
  "operations.EXACT_ORDER.pagination",
  "operations.EXACT_ORDER.path",
  "operations.EXACT_ORDER.path_parameter.order_id",
  "operations.EXACT_ORDER.response_field.client_order_id",
  "operations.EXACT_ORDER.response_field.exchange_index",
  "operations.EXACT_ORDER.response_field.order_id",
  "operations.EXACT_ORDER.response_field.subaccount_number",
  "operations.EXACT_ORDER.response_field.ticker",
  "operations.HISTORICAL_CUTOFF.authentication",
  "operations.HISTORICAL_CUTOFF.method",
  "operations.HISTORICAL_CUTOFF.negative_semantics",
  "operations.HISTORICAL_CUTOFF.pagination",
  "operations.HISTORICAL_CUTOFF.path",
  "operations.HISTORICAL_CUTOFF.response_field.market_positions_last_updated_ts",
  "operations.HISTORICAL_CUTOFF.response_field.market_settled_ts",
  "operations.HISTORICAL_CUTOFF.response_field.orders_updated_ts",
  "operations.HISTORICAL_CUTOFF.response_field.trades_created_ts",
  "operations.HISTORICAL_FILLS.authentication",
  "operations.HISTORICAL_FILLS.limit_range",
  "operations.HISTORICAL_FILLS.method",
  "operations.HISTORICAL_FILLS.pagination",
  "operations.HISTORICAL_FILLS.path",
  "operations.HISTORICAL_FILLS.query.cursor",
  "operations.HISTORICAL_FILLS.query.limit",
  "operations.HISTORICAL_FILLS.query.max_ts",
  "operations.HISTORICAL_FILLS.query.ticker",
  "operations.HISTORICAL_FILLS.response_field.count_fp",
  "operations.HISTORICAL_FILLS.response_field.created_time",
  "operations.HISTORICAL_FILLS.response_field.exchange_index",
  "operations.HISTORICAL_FILLS.response_field.fee_cost",
  "operations.HISTORICAL_FILLS.response_field.fill_id",
  "operations.HISTORICAL_FILLS.response_field.is_taker",
  "operations.HISTORICAL_FILLS.response_field.market_ticker",
  "operations.HISTORICAL_FILLS.response_field.no_price_dollars",
  "operations.HISTORICAL_FILLS.response_field.order_id",
  "operations.HISTORICAL_FILLS.response_field.subaccount_number",
  "operations.HISTORICAL_FILLS.response_field.ticker",
  "operations.HISTORICAL_FILLS.response_field.trade_id",
  "operations.HISTORICAL_FILLS.response_field.ts",
  "operations.HISTORICAL_FILLS.response_field.yes_price_dollars",
  "operations.HISTORICAL_FILLS.retention_lower_bound",
  "operations.HISTORICAL_ORDERS.authentication",
  "operations.HISTORICAL_ORDERS.limit_range",
  "operations.HISTORICAL_ORDERS.method",
  "operations.HISTORICAL_ORDERS.pagination",
  "operations.HISTORICAL_ORDERS.partition_semantics",
  "operations.HISTORICAL_ORDERS.path",
  "operations.HISTORICAL_ORDERS.query.cursor",
  "operations.HISTORICAL_ORDERS.query.limit",
  "operations.HISTORICAL_ORDERS.query.max_ts",
  "operations.HISTORICAL_ORDERS.query.ticker",
  "operations.HISTORICAL_ORDERS.response_field.client_order_id",
  "operations.HISTORICAL_ORDERS.response_field.exchange_index",
  "operations.HISTORICAL_ORDERS.response_field.order_id",
  "operations.HISTORICAL_ORDERS.response_field.subaccount_number",
  "operations.HISTORICAL_ORDERS.response_field.ticker",
  "operations.HISTORICAL_ORDERS.retention_lower_bound",
  "operations.HISTORICAL_POSITIONS.authentication",
  "operations.HISTORICAL_POSITIONS.limit_range",
  "operations.HISTORICAL_POSITIONS.method",
  "operations.HISTORICAL_POSITIONS.pagination",
  "operations.HISTORICAL_POSITIONS.partition_semantics",
  "operations.HISTORICAL_POSITIONS.path",
  "operations.HISTORICAL_POSITIONS.query.cursor",
  "operations.HISTORICAL_POSITIONS.query.event_ticker",
  "operations.HISTORICAL_POSITIONS.query.limit",
  "operations.HISTORICAL_POSITIONS.query.ticker",
  "operations.HISTORICAL_POSITIONS.response_field.exchange_index",
  "operations.HISTORICAL_POSITIONS.response_field.fees_paid_dollars",
  "operations.HISTORICAL_POSITIONS.response_field.last_updated_ts",
  "operations.HISTORICAL_POSITIONS.response_field.market_exposure_dollars",
  "operations.HISTORICAL_POSITIONS.response_field.position_fp",
  "operations.HISTORICAL_POSITIONS.response_field.realized_pnl_dollars",
  "operations.HISTORICAL_POSITIONS.response_field.ticker",
  "operations.HISTORICAL_POSITIONS.response_field.total_traded_dollars",
  "operations.HISTORICAL_POSITIONS.response_subaccount_field",
  "operations.HISTORICAL_POSITIONS.retention_lower_bound",
  "operations.LIVE_FILLS.authentication",
  "operations.LIVE_FILLS.limit_range",
  "operations.LIVE_FILLS.method",
  "operations.LIVE_FILLS.pagination",
  "operations.LIVE_FILLS.partition_semantics",
  "operations.LIVE_FILLS.path",
  "operations.LIVE_FILLS.query.cursor",
  "operations.LIVE_FILLS.query.exchange_index",
  "operations.LIVE_FILLS.query.limit",
  "operations.LIVE_FILLS.query.max_ts",
  "operations.LIVE_FILLS.query.min_ts",
  "operations.LIVE_FILLS.query.order_id",
  "operations.LIVE_FILLS.query.subaccount",
  "operations.LIVE_FILLS.query.ticker",
  "operations.LIVE_FILLS.response_field.count_fp",
  "operations.LIVE_FILLS.response_field.created_time",
  "operations.LIVE_FILLS.response_field.exchange_index",
  "operations.LIVE_FILLS.response_field.fee_cost",
  "operations.LIVE_FILLS.response_field.fill_id",
  "operations.LIVE_FILLS.response_field.is_taker",
  "operations.LIVE_FILLS.response_field.market_ticker",
  "operations.LIVE_FILLS.response_field.no_price_dollars",
  "operations.LIVE_FILLS.response_field.order_id",
  "operations.LIVE_FILLS.response_field.subaccount_number",
  "operations.LIVE_FILLS.response_field.ticker",
  "operations.LIVE_FILLS.response_field.trade_id",
  "operations.LIVE_FILLS.response_field.ts",
  "operations.LIVE_FILLS.response_field.yes_price_dollars",
  "operations.LIVE_ORDERS.authentication",
  "operations.LIVE_ORDERS.limit_range",
  "operations.LIVE_ORDERS.method",
  "operations.LIVE_ORDERS.pagination",
  "operations.LIVE_ORDERS.partition_semantics",
  "operations.LIVE_ORDERS.path",
  "operations.LIVE_ORDERS.query.cursor",
  "operations.LIVE_ORDERS.query.event_ticker",
  "operations.LIVE_ORDERS.query.exchange_index",
  "operations.LIVE_ORDERS.query.limit",
  "operations.LIVE_ORDERS.query.max_ts",
  "operations.LIVE_ORDERS.query.min_ts",
  "operations.LIVE_ORDERS.query.status",
  "operations.LIVE_ORDERS.query.subaccount",
  "operations.LIVE_ORDERS.query.ticker",
  "operations.LIVE_ORDERS.request_scope_fields",
  "operations.LIVE_ORDERS.response_field.client_order_id",
  "operations.LIVE_ORDERS.response_field.exchange_index",
  "operations.LIVE_ORDERS.response_field.fill_count_fp",
  "operations.LIVE_ORDERS.response_field.initial_count_fp",
  "operations.LIVE_ORDERS.response_field.no_price_dollars",
  "operations.LIVE_ORDERS.response_field.order_id",
  "operations.LIVE_ORDERS.response_field.remaining_count_fp",
  "operations.LIVE_ORDERS.response_field.subaccount_number",
  "operations.LIVE_ORDERS.response_field.ticker",
  "operations.LIVE_ORDERS.response_field.yes_price_dollars",
  "operations.LIVE_POSITIONS.authentication",
  "operations.LIVE_POSITIONS.limit_range",
  "operations.LIVE_POSITIONS.method",
  "operations.LIVE_POSITIONS.pagination",
  "operations.LIVE_POSITIONS.partition_semantics",
  "operations.LIVE_POSITIONS.path",
  "operations.LIVE_POSITIONS.query.count_filter",
  "operations.LIVE_POSITIONS.query.cursor",
  "operations.LIVE_POSITIONS.query.event_ticker",
  "operations.LIVE_POSITIONS.query.exchange_index",
  "operations.LIVE_POSITIONS.query.limit",
  "operations.LIVE_POSITIONS.query.subaccount",
  "operations.LIVE_POSITIONS.query.ticker",
  "operations.LIVE_POSITIONS.request_scope_fields",
  "operations.LIVE_POSITIONS.response_field.exchange_index",
  "operations.LIVE_POSITIONS.response_field.fees_paid_dollars",
  "operations.LIVE_POSITIONS.response_field.last_updated_ts",
  "operations.LIVE_POSITIONS.response_field.market_exposure_dollars",
  "operations.LIVE_POSITIONS.response_field.position_fp",
  "operations.LIVE_POSITIONS.response_field.realized_pnl_dollars",
  "operations.LIVE_POSITIONS.response_field.ticker",
  "operations.LIVE_POSITIONS.response_field.total_traded_dollars",
  "operations.LIVE_POSITIONS.response_subaccount_field",
  "operations.SETTLEMENTS.authentication",
  "operations.SETTLEMENTS.limit_range",
  "operations.SETTLEMENTS.method",
  "operations.SETTLEMENTS.pagination",
  "operations.SETTLEMENTS.path",
  "operations.SETTLEMENTS.query.cursor",
  "operations.SETTLEMENTS.query.event_ticker",
  "operations.SETTLEMENTS.query.limit",
  "operations.SETTLEMENTS.query.max_ts",
  "operations.SETTLEMENTS.query.min_ts",
  "operations.SETTLEMENTS.query.subaccount",
  "operations.SETTLEMENTS.query.ticker",
  "operations.SETTLEMENTS.request_scope_fields",
  "operations.SETTLEMENTS.response_field.event_ticker",
  "operations.SETTLEMENTS.response_field.exchange_index",
  "operations.SETTLEMENTS.response_field.fee_cost",
  "operations.SETTLEMENTS.response_field.no_count_fp",
  "operations.SETTLEMENTS.response_field.no_total_cost_dollars",
  "operations.SETTLEMENTS.response_field.revenue",
  "operations.SETTLEMENTS.response_field.settled_time",
  "operations.SETTLEMENTS.response_field.ticker",
  "operations.SETTLEMENTS.response_field.value",
  "operations.SETTLEMENTS.response_field.yes_count_fp",
  "operations.SETTLEMENTS.response_field.yes_total_cost_dollars",
  "operations.SETTLEMENTS.response_subaccount_field",
  "operations.SETTLEMENTS.role",
  "operations.USER_DATA_TIMESTAMP.authentication",
  "operations.USER_DATA_TIMESTAMP.method",
  "operations.USER_DATA_TIMESTAMP.negative_semantics",
  "operations.USER_DATA_TIMESTAMP.pagination",
  "operations.USER_DATA_TIMESTAMP.path",
  "operations.USER_DATA_TIMESTAMP.response_field.as_of_time",
  "operations.USER_DATA_TIMESTAMP.semantic_notes"
]
```

#### REV03_ACCEPTED_EXECUTION_MATERIAL

```json
[
  "historical_partition.cutoffs_move_forward",
  "historical_partition.positions_archived_per_whole_event",
  "historical_partition.retention_lower_bound",
  "historical_partition.target_live_window",
  "market_result_contract.nonconsumption",
  "operations.EXACT_ORDER.http_404_nonexistence_theorem",
  "operations.HISTORICAL_FILLS.exchange_index_a3_contract",
  "operations.HISTORICAL_FILLS.query.cursor",
  "operations.HISTORICAL_FILLS.query.limit",
  "operations.HISTORICAL_FILLS.query.max_ts",
  "operations.HISTORICAL_FILLS.query.ticker",
  "operations.HISTORICAL_FILLS.unsupported.exchange_index",
  "operations.HISTORICAL_FILLS.unsupported.min_ts",
  "operations.HISTORICAL_FILLS.unsupported.order_id",
  "operations.HISTORICAL_FILLS.unsupported.subaccount",
  "operations.HISTORICAL_ORDERS.partition_semantics",
  "operations.HISTORICAL_ORDERS.query.cursor",
  "operations.HISTORICAL_ORDERS.query.limit",
  "operations.HISTORICAL_ORDERS.query.max_ts",
  "operations.HISTORICAL_ORDERS.query.ticker",
  "operations.HISTORICAL_ORDERS.unsupported.event_ticker",
  "operations.HISTORICAL_ORDERS.unsupported.exchange_index",
  "operations.HISTORICAL_ORDERS.unsupported.min_ts",
  "operations.HISTORICAL_ORDERS.unsupported.status",
  "operations.HISTORICAL_ORDERS.unsupported.subaccount",
  "operations.HISTORICAL_POSITIONS.exchange_index_a3_contract",
  "operations.HISTORICAL_POSITIONS.partition_semantics",
  "operations.HISTORICAL_POSITIONS.query.cursor",
  "operations.HISTORICAL_POSITIONS.query.event_ticker",
  "operations.HISTORICAL_POSITIONS.query.limit",
  "operations.HISTORICAL_POSITIONS.query.ticker",
  "operations.HISTORICAL_POSITIONS.unsupported.count_filter",
  "operations.HISTORICAL_POSITIONS.unsupported.exchange_index",
  "operations.HISTORICAL_POSITIONS.unsupported.subaccount",
  "operations.LIVE_FILLS.exchange_index_a3_contract",
  "operations.LIVE_FILLS.partition_semantics",
  "operations.LIVE_FILLS.query.cursor",
  "operations.LIVE_FILLS.query.exchange_index",
  "operations.LIVE_FILLS.query.limit",
  "operations.LIVE_FILLS.query.max_ts",
  "operations.LIVE_FILLS.query.min_ts",
  "operations.LIVE_FILLS.query.order_id",
  "operations.LIVE_FILLS.query.subaccount",
  "operations.LIVE_FILLS.query.ticker",
  "operations.LIVE_ORDERS.partition_semantics",
  "operations.LIVE_ORDERS.query.cursor",
  "operations.LIVE_ORDERS.query.event_ticker",
  "operations.LIVE_ORDERS.query.exchange_index",
  "operations.LIVE_ORDERS.query.limit",
  "operations.LIVE_ORDERS.query.max_ts",
  "operations.LIVE_ORDERS.query.min_ts",
  "operations.LIVE_ORDERS.query.status",
  "operations.LIVE_ORDERS.query.subaccount",
  "operations.LIVE_ORDERS.query.ticker",
  "operations.LIVE_POSITIONS.exchange_index_a3_contract",
  "operations.LIVE_POSITIONS.partition_semantics",
  "operations.LIVE_POSITIONS.query.count_filter",
  "operations.LIVE_POSITIONS.query.cursor",
  "operations.LIVE_POSITIONS.query.event_ticker",
  "operations.LIVE_POSITIONS.query.exchange_index",
  "operations.LIVE_POSITIONS.query.limit",
  "operations.LIVE_POSITIONS.query.subaccount",
  "operations.LIVE_POSITIONS.query.ticker",
  "operations.SETTLEMENTS.exchange_index_a3_contract",
  "operations.SETTLEMENTS.query.cursor",
  "operations.SETTLEMENTS.query.event_ticker",
  "operations.SETTLEMENTS.query.limit",
  "operations.SETTLEMENTS.query.max_ts",
  "operations.SETTLEMENTS.query.min_ts",
  "operations.SETTLEMENTS.query.subaccount",
  "operations.SETTLEMENTS.query.ticker"
]
```

#### RUNTIME_CONSUMED_SOURCE_CONTRACT

```json
[
  "fill_temporal_contract",
  "operations.EXACT_ORDER.authentication",
  "operations.EXACT_ORDER.http_404_nonexistence_theorem",
  "operations.EXACT_ORDER.method",
  "operations.EXACT_ORDER.pagination",
  "operations.EXACT_ORDER.path",
  "operations.EXACT_ORDER.path_parameter.order_id",
  "operations.EXACT_ORDER.response_field.book_side",
  "operations.EXACT_ORDER.response_field.cancel_order_on_pause",
  "operations.EXACT_ORDER.response_field.client_order_id",
  "operations.EXACT_ORDER.response_field.exchange_index",
  "operations.EXACT_ORDER.response_field.fill_count_fp",
  "operations.EXACT_ORDER.response_field.initial_count_fp",
  "operations.EXACT_ORDER.response_field.no_price_dollars",
  "operations.EXACT_ORDER.response_field.order_id",
  "operations.EXACT_ORDER.response_field.outcome_side",
  "operations.EXACT_ORDER.response_field.remaining_count_fp",
  "operations.EXACT_ORDER.response_field.status",
  "operations.EXACT_ORDER.response_field.subaccount_number",
  "operations.EXACT_ORDER.response_field.ticker",
  "operations.EXACT_ORDER.response_field.yes_price_dollars",
  "operations.HISTORICAL_CUTOFF.authentication",
  "operations.HISTORICAL_CUTOFF.method",
  "operations.HISTORICAL_CUTOFF.negative_semantics",
  "operations.HISTORICAL_CUTOFF.pagination",
  "operations.HISTORICAL_CUTOFF.path",
  "operations.HISTORICAL_CUTOFF.response_field.market_positions_last_updated_ts",
  "operations.HISTORICAL_CUTOFF.response_field.market_settled_ts",
  "operations.HISTORICAL_CUTOFF.response_field.orders_updated_ts",
  "operations.HISTORICAL_CUTOFF.response_field.trades_created_ts",
  "operations.HISTORICAL_FILLS.authentication",
  "operations.HISTORICAL_FILLS.method",
  "operations.HISTORICAL_FILLS.pagination",
  "operations.HISTORICAL_FILLS.path",
  "operations.HISTORICAL_FILLS.query_descriptor.cursor",
  "operations.HISTORICAL_FILLS.query_descriptor.limit",
  "operations.HISTORICAL_FILLS.query_descriptor.max_ts",
  "operations.HISTORICAL_FILLS.query_descriptor.ticker",
  "operations.HISTORICAL_FILLS.response_container.cursor",
  "operations.HISTORICAL_FILLS.response_container.fills",
  "operations.HISTORICAL_FILLS.response_field.count_fp",
  "operations.HISTORICAL_FILLS.response_field.created_time",
  "operations.HISTORICAL_FILLS.response_field.exchange_index",
  "operations.HISTORICAL_FILLS.response_field.fee_cost",
  "operations.HISTORICAL_FILLS.response_field.fill_id",
  "operations.HISTORICAL_FILLS.response_field.is_taker",
  "operations.HISTORICAL_FILLS.response_field.market_ticker",
  "operations.HISTORICAL_FILLS.response_field.no_price_dollars",
  "operations.HISTORICAL_FILLS.response_field.order_id",
  "operations.HISTORICAL_FILLS.response_field.subaccount_number",
  "operations.HISTORICAL_FILLS.response_field.ticker",
  "operations.HISTORICAL_FILLS.response_field.trade_id",
  "operations.HISTORICAL_FILLS.response_field.ts",
  "operations.HISTORICAL_FILLS.response_field.yes_price_dollars",
  "operations.HISTORICAL_ORDERS.authentication",
  "operations.HISTORICAL_ORDERS.method",
  "operations.HISTORICAL_ORDERS.pagination",
  "operations.HISTORICAL_ORDERS.path",
  "operations.HISTORICAL_ORDERS.query_descriptor.cursor",
  "operations.HISTORICAL_ORDERS.query_descriptor.limit",
  "operations.HISTORICAL_ORDERS.query_descriptor.max_ts",
  "operations.HISTORICAL_ORDERS.query_descriptor.ticker",
  "operations.HISTORICAL_ORDERS.response_container.cursor",
  "operations.HISTORICAL_ORDERS.response_container.orders",
  "operations.HISTORICAL_ORDERS.response_field.book_side",
  "operations.HISTORICAL_ORDERS.response_field.cancel_order_on_pause",
  "operations.HISTORICAL_ORDERS.response_field.client_order_id",
  "operations.HISTORICAL_ORDERS.response_field.exchange_index",
  "operations.HISTORICAL_ORDERS.response_field.fill_count_fp",
  "operations.HISTORICAL_ORDERS.response_field.initial_count_fp",
  "operations.HISTORICAL_ORDERS.response_field.no_price_dollars",
  "operations.HISTORICAL_ORDERS.response_field.order_id",
  "operations.HISTORICAL_ORDERS.response_field.outcome_side",
  "operations.HISTORICAL_ORDERS.response_field.remaining_count_fp",
  "operations.HISTORICAL_ORDERS.response_field.status",
  "operations.HISTORICAL_ORDERS.response_field.subaccount_number",
  "operations.HISTORICAL_ORDERS.response_field.ticker",
  "operations.HISTORICAL_ORDERS.response_field.yes_price_dollars",
  "operations.HISTORICAL_POSITIONS.authentication",
  "operations.HISTORICAL_POSITIONS.method",
  "operations.HISTORICAL_POSITIONS.pagination",
  "operations.HISTORICAL_POSITIONS.path",
  "operations.HISTORICAL_POSITIONS.query_descriptor.cursor",
  "operations.HISTORICAL_POSITIONS.query_descriptor.limit",
  "operations.HISTORICAL_POSITIONS.query_descriptor.ticker",
  "operations.HISTORICAL_POSITIONS.response_container.cursor",
  "operations.HISTORICAL_POSITIONS.response_container.market_positions",
  "operations.HISTORICAL_POSITIONS.response_field.ticker",
  "operations.LIVE_FILLS.authentication",
  "operations.LIVE_FILLS.method",
  "operations.LIVE_FILLS.pagination",
  "operations.LIVE_FILLS.path",
  "operations.LIVE_FILLS.query_descriptor.cursor",
  "operations.LIVE_FILLS.query_descriptor.exchange_index",
  "operations.LIVE_FILLS.query_descriptor.limit",
  "operations.LIVE_FILLS.query_descriptor.max_ts",
  "operations.LIVE_FILLS.query_descriptor.min_ts",
  "operations.LIVE_FILLS.query_descriptor.order_id",
  "operations.LIVE_FILLS.query_descriptor.subaccount",
  "operations.LIVE_FILLS.query_descriptor.ticker",
  "operations.LIVE_FILLS.response_container.cursor",
  "operations.LIVE_FILLS.response_container.fills",
  "operations.LIVE_FILLS.response_field.count_fp",
  "operations.LIVE_FILLS.response_field.created_time",
  "operations.LIVE_FILLS.response_field.exchange_index",
  "operations.LIVE_FILLS.response_field.fee_cost",
  "operations.LIVE_FILLS.response_field.fill_id",
  "operations.LIVE_FILLS.response_field.is_taker",
  "operations.LIVE_FILLS.response_field.market_ticker",
  "operations.LIVE_FILLS.response_field.no_price_dollars",
  "operations.LIVE_FILLS.response_field.order_id",
  "operations.LIVE_FILLS.response_field.subaccount_number",
  "operations.LIVE_FILLS.response_field.ticker",
  "operations.LIVE_FILLS.response_field.trade_id",
  "operations.LIVE_FILLS.response_field.ts",
  "operations.LIVE_FILLS.response_field.yes_price_dollars",
  "operations.LIVE_ORDERS.authentication",
  "operations.LIVE_ORDERS.method",
  "operations.LIVE_ORDERS.pagination",
  "operations.LIVE_ORDERS.path",
  "operations.LIVE_ORDERS.query_descriptor.cursor",
  "operations.LIVE_ORDERS.query_descriptor.exchange_index",
  "operations.LIVE_ORDERS.query_descriptor.limit",
  "operations.LIVE_ORDERS.query_descriptor.max_ts",
  "operations.LIVE_ORDERS.query_descriptor.min_ts",
  "operations.LIVE_ORDERS.query_descriptor.subaccount",
  "operations.LIVE_ORDERS.query_descriptor.ticker",
  "operations.LIVE_ORDERS.response_container.cursor",
  "operations.LIVE_ORDERS.response_container.orders",
  "operations.LIVE_ORDERS.response_field.book_side",
  "operations.LIVE_ORDERS.response_field.cancel_order_on_pause",
  "operations.LIVE_ORDERS.response_field.client_order_id",
  "operations.LIVE_ORDERS.response_field.exchange_index",
  "operations.LIVE_ORDERS.response_field.fill_count_fp",
  "operations.LIVE_ORDERS.response_field.initial_count_fp",
  "operations.LIVE_ORDERS.response_field.no_price_dollars",
  "operations.LIVE_ORDERS.response_field.order_id",
  "operations.LIVE_ORDERS.response_field.outcome_side",
  "operations.LIVE_ORDERS.response_field.remaining_count_fp",
  "operations.LIVE_ORDERS.response_field.status",
  "operations.LIVE_ORDERS.response_field.subaccount_number",
  "operations.LIVE_ORDERS.response_field.ticker",
  "operations.LIVE_ORDERS.response_field.yes_price_dollars",
  "operations.LIVE_POSITIONS.authentication",
  "operations.LIVE_POSITIONS.method",
  "operations.LIVE_POSITIONS.pagination",
  "operations.LIVE_POSITIONS.path",
  "operations.LIVE_POSITIONS.query_descriptor.cursor",
  "operations.LIVE_POSITIONS.query_descriptor.exchange_index",
  "operations.LIVE_POSITIONS.query_descriptor.limit",
  "operations.LIVE_POSITIONS.query_descriptor.subaccount",
  "operations.LIVE_POSITIONS.query_descriptor.ticker",
  "operations.LIVE_POSITIONS.response_container.cursor",
  "operations.LIVE_POSITIONS.response_container.market_positions",
  "operations.LIVE_POSITIONS.response_field.ticker",
  "operations.SETTLEMENTS.authentication",
  "operations.SETTLEMENTS.method",
  "operations.SETTLEMENTS.pagination",
  "operations.SETTLEMENTS.path",
  "operations.SETTLEMENTS.query_descriptor.cursor",
  "operations.SETTLEMENTS.query_descriptor.limit",
  "operations.SETTLEMENTS.query_descriptor.max_ts",
  "operations.SETTLEMENTS.query_descriptor.min_ts",
  "operations.SETTLEMENTS.query_descriptor.subaccount",
  "operations.SETTLEMENTS.query_descriptor.ticker",
  "operations.SETTLEMENTS.response_container.cursor",
  "operations.SETTLEMENTS.response_container.settlements",
  "operations.SETTLEMENTS.response_field.ticker",
  "operations.USER_DATA_TIMESTAMP.authentication",
  "operations.USER_DATA_TIMESTAMP.method",
  "operations.USER_DATA_TIMESTAMP.negative_semantics",
  "operations.USER_DATA_TIMESTAMP.pagination",
  "operations.USER_DATA_TIMESTAMP.path",
  "operations.USER_DATA_TIMESTAMP.response_field.as_of_time"
]
```

#### REV04_EXECUTION_MATERIAL_PROJECTION

```json
[
  "environment.credentials_shared",
  "environment.demo_rest_root",
  "environment.production_rest_root",
  "fill_temporal_contract",
  "historical_partition.cutoffs_move_forward",
  "historical_partition.positions_archived_per_whole_event",
  "historical_partition.retention_lower_bound",
  "historical_partition.target_live_window",
  "market_result_contract.nonconsumption",
  "official_source_scope",
  "operations.EXACT_ORDER.authentication",
  "operations.EXACT_ORDER.documented_http_statuses",
  "operations.EXACT_ORDER.http_404_nonexistence_theorem",
  "operations.EXACT_ORDER.method",
  "operations.EXACT_ORDER.pagination",
  "operations.EXACT_ORDER.path",
  "operations.EXACT_ORDER.path_parameter.order_id",
  "operations.EXACT_ORDER.response_container.order",
  "operations.EXACT_ORDER.response_field.book_side",
  "operations.EXACT_ORDER.response_field.cancel_order_on_pause",
  "operations.EXACT_ORDER.response_field.client_order_id",
  "operations.EXACT_ORDER.response_field.exchange_index",
  "operations.EXACT_ORDER.response_field.fill_count_fp",
  "operations.EXACT_ORDER.response_field.initial_count_fp",
  "operations.EXACT_ORDER.response_field.no_price_dollars",
  "operations.EXACT_ORDER.response_field.order_id",
  "operations.EXACT_ORDER.response_field.outcome_side",
  "operations.EXACT_ORDER.response_field.remaining_count_fp",
  "operations.EXACT_ORDER.response_field.status",
  "operations.EXACT_ORDER.response_field.subaccount_number",
  "operations.EXACT_ORDER.response_field.ticker",
  "operations.EXACT_ORDER.response_field.yes_price_dollars",
  "operations.HISTORICAL_CUTOFF.authentication",
  "operations.HISTORICAL_CUTOFF.method",
  "operations.HISTORICAL_CUTOFF.negative_semantics",
  "operations.HISTORICAL_CUTOFF.pagination",
  "operations.HISTORICAL_CUTOFF.path",
  "operations.HISTORICAL_CUTOFF.response_field.market_positions_last_updated_ts",
  "operations.HISTORICAL_CUTOFF.response_field.market_settled_ts",
  "operations.HISTORICAL_CUTOFF.response_field.orders_updated_ts",
  "operations.HISTORICAL_CUTOFF.response_field.trades_created_ts",
  "operations.HISTORICAL_FILLS.authentication",
  "operations.HISTORICAL_FILLS.exchange_index_a3_contract",
  "operations.HISTORICAL_FILLS.limit_range",
  "operations.HISTORICAL_FILLS.method",
  "operations.HISTORICAL_FILLS.pagination",
  "operations.HISTORICAL_FILLS.path",
  "operations.HISTORICAL_FILLS.query.cursor",
  "operations.HISTORICAL_FILLS.query.limit",
  "operations.HISTORICAL_FILLS.query.max_ts",
  "operations.HISTORICAL_FILLS.query.ticker",
  "operations.HISTORICAL_FILLS.query_descriptor.cursor",
  "operations.HISTORICAL_FILLS.query_descriptor.limit",
  "operations.HISTORICAL_FILLS.query_descriptor.max_ts",
  "operations.HISTORICAL_FILLS.query_descriptor.ticker",
  "operations.HISTORICAL_FILLS.response_container.cursor",
  "operations.HISTORICAL_FILLS.response_container.fills",
  "operations.HISTORICAL_FILLS.response_field.count_fp",
  "operations.HISTORICAL_FILLS.response_field.created_time",
  "operations.HISTORICAL_FILLS.response_field.exchange_index",
  "operations.HISTORICAL_FILLS.response_field.fee_cost",
  "operations.HISTORICAL_FILLS.response_field.fill_id",
  "operations.HISTORICAL_FILLS.response_field.is_taker",
  "operations.HISTORICAL_FILLS.response_field.market_ticker",
  "operations.HISTORICAL_FILLS.response_field.no_price_dollars",
  "operations.HISTORICAL_FILLS.response_field.order_id",
  "operations.HISTORICAL_FILLS.response_field.subaccount_number",
  "operations.HISTORICAL_FILLS.response_field.ticker",
  "operations.HISTORICAL_FILLS.response_field.trade_id",
  "operations.HISTORICAL_FILLS.response_field.ts",
  "operations.HISTORICAL_FILLS.response_field.yes_price_dollars",
  "operations.HISTORICAL_FILLS.retention_lower_bound",
  "operations.HISTORICAL_FILLS.unsupported.exchange_index",
  "operations.HISTORICAL_FILLS.unsupported.min_ts",
  "operations.HISTORICAL_FILLS.unsupported.order_id",
  "operations.HISTORICAL_FILLS.unsupported.subaccount",
  "operations.HISTORICAL_ORDERS.authentication",
  "operations.HISTORICAL_ORDERS.limit_range",
  "operations.HISTORICAL_ORDERS.method",
  "operations.HISTORICAL_ORDERS.pagination",
  "operations.HISTORICAL_ORDERS.partition_semantics",
  "operations.HISTORICAL_ORDERS.path",
  "operations.HISTORICAL_ORDERS.query.cursor",
  "operations.HISTORICAL_ORDERS.query.limit",
  "operations.HISTORICAL_ORDERS.query.max_ts",
  "operations.HISTORICAL_ORDERS.query.ticker",
  "operations.HISTORICAL_ORDERS.query_descriptor.cursor",
  "operations.HISTORICAL_ORDERS.query_descriptor.limit",
  "operations.HISTORICAL_ORDERS.query_descriptor.max_ts",
  "operations.HISTORICAL_ORDERS.query_descriptor.ticker",
  "operations.HISTORICAL_ORDERS.response_container.cursor",
  "operations.HISTORICAL_ORDERS.response_container.orders",
  "operations.HISTORICAL_ORDERS.response_field.book_side",
  "operations.HISTORICAL_ORDERS.response_field.cancel_order_on_pause",
  "operations.HISTORICAL_ORDERS.response_field.client_order_id",
  "operations.HISTORICAL_ORDERS.response_field.exchange_index",
  "operations.HISTORICAL_ORDERS.response_field.fill_count_fp",
  "operations.HISTORICAL_ORDERS.response_field.initial_count_fp",
  "operations.HISTORICAL_ORDERS.response_field.no_price_dollars",
  "operations.HISTORICAL_ORDERS.response_field.order_id",
  "operations.HISTORICAL_ORDERS.response_field.outcome_side",
  "operations.HISTORICAL_ORDERS.response_field.remaining_count_fp",
  "operations.HISTORICAL_ORDERS.response_field.status",
  "operations.HISTORICAL_ORDERS.response_field.subaccount_number",
  "operations.HISTORICAL_ORDERS.response_field.ticker",
  "operations.HISTORICAL_ORDERS.response_field.yes_price_dollars",
  "operations.HISTORICAL_ORDERS.retention_lower_bound",
  "operations.HISTORICAL_ORDERS.unsupported.event_ticker",
  "operations.HISTORICAL_ORDERS.unsupported.exchange_index",
  "operations.HISTORICAL_ORDERS.unsupported.min_ts",
  "operations.HISTORICAL_ORDERS.unsupported.status",
  "operations.HISTORICAL_ORDERS.unsupported.subaccount",
  "operations.HISTORICAL_POSITIONS.authentication",
  "operations.HISTORICAL_POSITIONS.exchange_index_a3_contract",
  "operations.HISTORICAL_POSITIONS.limit_range",
  "operations.HISTORICAL_POSITIONS.method",
  "operations.HISTORICAL_POSITIONS.pagination",
  "operations.HISTORICAL_POSITIONS.partition_semantics",
  "operations.HISTORICAL_POSITIONS.path",
  "operations.HISTORICAL_POSITIONS.query.cursor",
  "operations.HISTORICAL_POSITIONS.query.event_ticker",
  "operations.HISTORICAL_POSITIONS.query.limit",
  "operations.HISTORICAL_POSITIONS.query.ticker",
  "operations.HISTORICAL_POSITIONS.query_descriptor.cursor",
  "operations.HISTORICAL_POSITIONS.query_descriptor.event_ticker",
  "operations.HISTORICAL_POSITIONS.query_descriptor.limit",
  "operations.HISTORICAL_POSITIONS.query_descriptor.ticker",
  "operations.HISTORICAL_POSITIONS.response_container.cursor",
  "operations.HISTORICAL_POSITIONS.response_container.market_positions",
  "operations.HISTORICAL_POSITIONS.response_field.exchange_index",
  "operations.HISTORICAL_POSITIONS.response_field.fees_paid_dollars",
  "operations.HISTORICAL_POSITIONS.response_field.last_updated_ts",
  "operations.HISTORICAL_POSITIONS.response_field.market_exposure_dollars",
  "operations.HISTORICAL_POSITIONS.response_field.position_fp",
  "operations.HISTORICAL_POSITIONS.response_field.realized_pnl_dollars",
  "operations.HISTORICAL_POSITIONS.response_field.ticker",
  "operations.HISTORICAL_POSITIONS.response_field.total_traded_dollars",
  "operations.HISTORICAL_POSITIONS.response_subaccount_field",
  "operations.HISTORICAL_POSITIONS.retention_lower_bound",
  "operations.HISTORICAL_POSITIONS.unsupported.count_filter",
  "operations.HISTORICAL_POSITIONS.unsupported.exchange_index",
  "operations.HISTORICAL_POSITIONS.unsupported.subaccount",
  "operations.LIVE_FILLS.authentication",
  "operations.LIVE_FILLS.exchange_index_a3_contract",
  "operations.LIVE_FILLS.limit_range",
  "operations.LIVE_FILLS.method",
  "operations.LIVE_FILLS.pagination",
  "operations.LIVE_FILLS.partition_semantics",
  "operations.LIVE_FILLS.path",
  "operations.LIVE_FILLS.query.cursor",
  "operations.LIVE_FILLS.query.exchange_index",
  "operations.LIVE_FILLS.query.limit",
  "operations.LIVE_FILLS.query.max_ts",
  "operations.LIVE_FILLS.query.min_ts",
  "operations.LIVE_FILLS.query.order_id",
  "operations.LIVE_FILLS.query.subaccount",
  "operations.LIVE_FILLS.query.ticker",
  "operations.LIVE_FILLS.query_descriptor.cursor",
  "operations.LIVE_FILLS.query_descriptor.exchange_index",
  "operations.LIVE_FILLS.query_descriptor.limit",
  "operations.LIVE_FILLS.query_descriptor.max_ts",
  "operations.LIVE_FILLS.query_descriptor.min_ts",
  "operations.LIVE_FILLS.query_descriptor.order_id",
  "operations.LIVE_FILLS.query_descriptor.subaccount",
  "operations.LIVE_FILLS.query_descriptor.ticker",
  "operations.LIVE_FILLS.response_container.cursor",
  "operations.LIVE_FILLS.response_container.fills",
  "operations.LIVE_FILLS.response_field.count_fp",
  "operations.LIVE_FILLS.response_field.created_time",
  "operations.LIVE_FILLS.response_field.exchange_index",
  "operations.LIVE_FILLS.response_field.fee_cost",
  "operations.LIVE_FILLS.response_field.fill_id",
  "operations.LIVE_FILLS.response_field.is_taker",
  "operations.LIVE_FILLS.response_field.market_ticker",
  "operations.LIVE_FILLS.response_field.no_price_dollars",
  "operations.LIVE_FILLS.response_field.order_id",
  "operations.LIVE_FILLS.response_field.subaccount_number",
  "operations.LIVE_FILLS.response_field.ticker",
  "operations.LIVE_FILLS.response_field.trade_id",
  "operations.LIVE_FILLS.response_field.ts",
  "operations.LIVE_FILLS.response_field.yes_price_dollars",
  "operations.LIVE_ORDERS.authentication",
  "operations.LIVE_ORDERS.limit_range",
  "operations.LIVE_ORDERS.method",
  "operations.LIVE_ORDERS.pagination",
  "operations.LIVE_ORDERS.partition_semantics",
  "operations.LIVE_ORDERS.path",
  "operations.LIVE_ORDERS.query.cursor",
  "operations.LIVE_ORDERS.query.event_ticker",
  "operations.LIVE_ORDERS.query.exchange_index",
  "operations.LIVE_ORDERS.query.limit",
  "operations.LIVE_ORDERS.query.max_ts",
  "operations.LIVE_ORDERS.query.min_ts",
  "operations.LIVE_ORDERS.query.status",
  "operations.LIVE_ORDERS.query.subaccount",
  "operations.LIVE_ORDERS.query.ticker",
  "operations.LIVE_ORDERS.query_descriptor.cursor",
  "operations.LIVE_ORDERS.query_descriptor.event_ticker",
  "operations.LIVE_ORDERS.query_descriptor.exchange_index",
  "operations.LIVE_ORDERS.query_descriptor.limit",
  "operations.LIVE_ORDERS.query_descriptor.max_ts",
  "operations.LIVE_ORDERS.query_descriptor.min_ts",
  "operations.LIVE_ORDERS.query_descriptor.status",
  "operations.LIVE_ORDERS.query_descriptor.subaccount",
  "operations.LIVE_ORDERS.query_descriptor.ticker",
  "operations.LIVE_ORDERS.request_scope_fields",
  "operations.LIVE_ORDERS.response_container.cursor",
  "operations.LIVE_ORDERS.response_container.orders",
  "operations.LIVE_ORDERS.response_field.book_side",
  "operations.LIVE_ORDERS.response_field.cancel_order_on_pause",
  "operations.LIVE_ORDERS.response_field.client_order_id",
  "operations.LIVE_ORDERS.response_field.exchange_index",
  "operations.LIVE_ORDERS.response_field.fill_count_fp",
  "operations.LIVE_ORDERS.response_field.initial_count_fp",
  "operations.LIVE_ORDERS.response_field.no_price_dollars",
  "operations.LIVE_ORDERS.response_field.order_id",
  "operations.LIVE_ORDERS.response_field.outcome_side",
  "operations.LIVE_ORDERS.response_field.remaining_count_fp",
  "operations.LIVE_ORDERS.response_field.status",
  "operations.LIVE_ORDERS.response_field.subaccount_number",
  "operations.LIVE_ORDERS.response_field.ticker",
  "operations.LIVE_ORDERS.response_field.yes_price_dollars",
  "operations.LIVE_POSITIONS.authentication",
  "operations.LIVE_POSITIONS.exchange_index_a3_contract",
  "operations.LIVE_POSITIONS.limit_range",
  "operations.LIVE_POSITIONS.method",
  "operations.LIVE_POSITIONS.pagination",
  "operations.LIVE_POSITIONS.partition_semantics",
  "operations.LIVE_POSITIONS.path",
  "operations.LIVE_POSITIONS.query.count_filter",
  "operations.LIVE_POSITIONS.query.cursor",
  "operations.LIVE_POSITIONS.query.event_ticker",
  "operations.LIVE_POSITIONS.query.exchange_index",
  "operations.LIVE_POSITIONS.query.limit",
  "operations.LIVE_POSITIONS.query.subaccount",
  "operations.LIVE_POSITIONS.query.ticker",
  "operations.LIVE_POSITIONS.query_descriptor.count_filter",
  "operations.LIVE_POSITIONS.query_descriptor.cursor",
  "operations.LIVE_POSITIONS.query_descriptor.event_ticker",
  "operations.LIVE_POSITIONS.query_descriptor.exchange_index",
  "operations.LIVE_POSITIONS.query_descriptor.limit",
  "operations.LIVE_POSITIONS.query_descriptor.subaccount",
  "operations.LIVE_POSITIONS.query_descriptor.ticker",
  "operations.LIVE_POSITIONS.request_scope_fields",
  "operations.LIVE_POSITIONS.response_container.cursor",
  "operations.LIVE_POSITIONS.response_container.market_positions",
  "operations.LIVE_POSITIONS.response_field.exchange_index",
  "operations.LIVE_POSITIONS.response_field.fees_paid_dollars",
  "operations.LIVE_POSITIONS.response_field.last_updated_ts",
  "operations.LIVE_POSITIONS.response_field.market_exposure_dollars",
  "operations.LIVE_POSITIONS.response_field.position_fp",
  "operations.LIVE_POSITIONS.response_field.realized_pnl_dollars",
  "operations.LIVE_POSITIONS.response_field.ticker",
  "operations.LIVE_POSITIONS.response_field.total_traded_dollars",
  "operations.LIVE_POSITIONS.response_subaccount_field",
  "operations.SETTLEMENTS.authentication",
  "operations.SETTLEMENTS.exchange_index_a3_contract",
  "operations.SETTLEMENTS.limit_range",
  "operations.SETTLEMENTS.method",
  "operations.SETTLEMENTS.pagination",
  "operations.SETTLEMENTS.path",
  "operations.SETTLEMENTS.query.cursor",
  "operations.SETTLEMENTS.query.event_ticker",
  "operations.SETTLEMENTS.query.limit",
  "operations.SETTLEMENTS.query.max_ts",
  "operations.SETTLEMENTS.query.min_ts",
  "operations.SETTLEMENTS.query.subaccount",
  "operations.SETTLEMENTS.query.ticker",
  "operations.SETTLEMENTS.query_descriptor.cursor",
  "operations.SETTLEMENTS.query_descriptor.event_ticker",
  "operations.SETTLEMENTS.query_descriptor.limit",
  "operations.SETTLEMENTS.query_descriptor.max_ts",
  "operations.SETTLEMENTS.query_descriptor.min_ts",
  "operations.SETTLEMENTS.query_descriptor.subaccount",
  "operations.SETTLEMENTS.query_descriptor.ticker",
  "operations.SETTLEMENTS.request_scope_fields",
  "operations.SETTLEMENTS.response_container.cursor",
  "operations.SETTLEMENTS.response_container.settlements",
  "operations.SETTLEMENTS.response_field.event_ticker",
  "operations.SETTLEMENTS.response_field.exchange_index",
  "operations.SETTLEMENTS.response_field.fee_cost",
  "operations.SETTLEMENTS.response_field.no_count_fp",
  "operations.SETTLEMENTS.response_field.no_total_cost_dollars",
  "operations.SETTLEMENTS.response_field.revenue",
  "operations.SETTLEMENTS.response_field.settled_time",
  "operations.SETTLEMENTS.response_field.ticker",
  "operations.SETTLEMENTS.response_field.value",
  "operations.SETTLEMENTS.response_field.yes_count_fp",
  "operations.SETTLEMENTS.response_field.yes_total_cost_dollars",
  "operations.SETTLEMENTS.response_subaccount_field",
  "operations.SETTLEMENTS.role",
  "operations.USER_DATA_TIMESTAMP.authentication",
  "operations.USER_DATA_TIMESTAMP.method",
  "operations.USER_DATA_TIMESTAMP.negative_semantics",
  "operations.USER_DATA_TIMESTAMP.pagination",
  "operations.USER_DATA_TIMESTAMP.path",
  "operations.USER_DATA_TIMESTAMP.response_field.as_of_time",
  "operations.USER_DATA_TIMESTAMP.semantic_notes"
]
```

# Appendix C — exact current-source/functional delta summary

Relative to blocked Revision 03, Revision 04 restores/adds:

- `environment.demo_rest_root`
- `environment.production_rest_root`
- `environment.credentials_shared`
- `LIVE_FILLS/HISTORICAL_FILLS response temporal descriptors: created_time, ts`
- `LIVE_FILLS.partition_semantics`
- `LIVE_ORDERS/HISTORICAL_ORDERS partition semantics`
- `LIVE_POSITIONS/HISTORICAL_POSITIONS partition semantics`
- `LIVE_ORDERS source response economic family with explicit consumed/non-consumed member classification`
- `LIVE_ORDERS/LIVE_POSITIONS/SETTLEMENTS request-scope fields`
- `EXACT_ORDER documented_http_statuses, path parameter structural contract, http_404_nonexistence_theorem`
- `USER_DATA_TIMESTAMP negative_semantics and semantic_notes`
- `operation-specific retention_lower_bound and response_subaccount_field sentinels`
- `all response container/cursor requiredness contracts`
- `all consumed response field type/format/source-requiredness/nullability descriptors`
- `all normalized query parameter type/format/requiredness/nullability/range descriptors`
- `explicit TEMPORAL_FIELD category and FILL_TEMPORAL_CONTRACT_REV04`
- `closed predecessor disposition table and explicit non-material exclusion set`

No current official-source conflict remains for a Route-A consumed field.

The later implementation remains bounded to the A2 source and A2 test paths stated in RA4-IMPL-001.
