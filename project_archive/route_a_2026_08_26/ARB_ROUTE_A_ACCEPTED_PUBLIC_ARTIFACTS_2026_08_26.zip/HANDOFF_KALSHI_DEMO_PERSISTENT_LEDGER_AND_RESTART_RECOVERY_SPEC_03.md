# HANDOFF — KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_03

## 1. Controlling specification

This handoff is subordinate implementation context for the exact specification:

```text
KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_03.md
raw_bytes = 141566
sha256 = 98592d719db2dcb59bb5ade6f18700b9acf4ae1049480f409b60f228f1518ead
```

If this handoff and the specification differ, the exact Revision-03 specification bytes/SHA-256 above control.

Artifact boundary:

```text
artifact_class = HANDOFF_FOR_TECHNICAL_SPECIFICATION
task_class = SPEC_ONLY
technical_scope = PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_ONLY
risk_tier = LOW
implementation_performed = false
test_execution_performed = false
actual_legacy_import_performed = false
venue_activity = NONE
credential_activity = NONE
repository_write_activity = NONE
local_git_write_activity = NONE
remote_git_activity = NONE
```

---

## 2. Frozen canonical repository gate

Canonical repository:

```text
rigolugo/ARB
```

Exact reviewed state:

```text
main = 5a65ccadb05b29d6e8692a108bcf46347ec0d214
tree = c4bce88221c7ea30f0bd381ba26851f05ac83b6b
parent = 7681676edb86e0f8fda52d5cebd46a5f52356401
```

A later implementation must reverify these exact predicates and must not silently advance or rebase this specification onto a newer canonical commit.

Exact blocked predecessor:

```text
KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_02.md
bytes = 118356
sha256 = ac699aa98d4813b54e63c3eb91fa84ead4653963ea32729d83f1935578a87476

HANDOFF_KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_02.md
bytes = 22149
sha256 = ef6f170efd0d510aa1a2ddadf446575df65dce08da7d02d110503603088d7e62
```

Revision-01/original-dispatch provenance remains exactly as bound in PL-BASE-005 of the controlling specification.

Non-controlling research input remains:

```text
HANDOFF_PERSISTENT_LEDGER_RESTART_BOUNDARY_INTEGRITY_EXTERNAL_FINDINGS_01.md
bytes = 20887
sha256 = 6b21c223cd394ef6750ec84442ba86f9c1eeed47282fb349593c6f5d13f2ecb4
status = NON_CONTROLLING_TECHNICAL_RESEARCH_INPUT
```

No new external research or venue-source refresh is required.

---

## 3. Scope of Revision-03 correction

Revision 03 preserves the accepted Revision-02 architecture and corrects only the legacy-import bootstrap/atomicity defect.

The two coupled manifestations are closed as follows:

| Blocked Revision-02 manifestation | Revision-03 closure |
|---|---|
| normal writer acquisition requires complete pre-ledger history, leaving no exact safe lock/acquisition path for the required first import | `PL-LEGACY-015..017` define a distinct `LEGACY_IMPORT_ONLY` acquisition/handle using the same authority-first/ledger-second validation and locks, but exposing no normal writer/send/credential/venue surface |
| Revision 02 could be read to require zero import events after an authority failure even though the exact two-event ledger transaction had already committed | `PL-LEGACY-018..022` separate ledger-batch atomicity from authority advancement, preserve a committed complete ledger-ahead import batch, and define deterministic reopen recognition/catch-up without duplicate import |

Normal writer acquisition remains blocked before import and remains write/send-ineligible after import because the imported unresolved write keeps writer proof `HELD`.

---

## 4. Preserved Revision-02 architecture

Do not reopen these accepted decisions:

```text
persistence =
    Python standard-library sqlite3

durability_domains =
    trusted authority/anchor SQLite database
    append-only execution-ledger SQLite database

journal_mode = DELETE
synchronous = EXTRA
synchronous_readback = 3
foreign_keys = ON
foreign_keys_readback = 1
busy_timeout = 0
locking_mode = EXCLUSIVE
implicit_python_transactions = disabled

lock_order =
    authority first
    authoritative ledger second

authority_model =
    one deployment-bound authority namespace
    one exact conflict-domain -> authoritative ledger instance/path binding
    monotonic trusted sequence/event_hash
    ledger-ahead forward catch-up only
    no backward movement
    no automatic recreate/rebind/repair

write_gate =
    ledger WRITE_SEND_BOUNDARY_ENTERED commit
    -> trusted authority advancement/verified readback
    -> only then transport may begin

automatic_resend = PROHIBITED
preledger_mode = LEGACY_IMPORT_REQUIRED
event_history = append-only
encoding = canonical JSON + exact Decimal; binary float prohibited
integrity = contiguous sequence + payload SHA-256 + previous hash + event hash
restart_venue_io = 0
restart_credential_io = 0
```

The Revision-03 import correction does not add a third persistence domain, dependency, venue operation, runtime lock file, snapshot layer, migration system, or repair mechanism.

---

## 5. Future repository path envelope

The exact first future implementation path envelope remains unchanged.

```text
NEW:
src/arb/execution_ledger.py
src/arb/venues/kalshi/ledger_binding.py
tests/test_execution_ledger.py
tests/test_kalshi_ledger_binding.py

MODIFIED EXISTING:
none
```

Readable protected dependencies remain the exact canonical lifecycle/reconciliation/model/validation/error modules and directly relevant existing tests named by the controlling specification.

The runtime authority and execution-ledger SQLite files are local operational state outside the canonical repository; they are not additional repository paths.

---

## 6. Exact acquisition modes

The local acquisition enum is:

```text
NORMAL_WRITER
LEGACY_IMPORT_ONLY
```

`NORMAL_WRITER` retains the accepted PL-LOCK-002 path and cannot be exposed while legacy history is incomplete.

`LEGACY_IMPORT_ONLY` is a distinct restricted acquisition surface. It is not a Boolean mode on an ordinary writer object.

Required acquisition order:

```text
1. validate accepted AuthorityNamespaceBinding
2. no-create open established authority store
3. verify authority DELETE + EXTRA and all required readbacks
4. acquire authority BEGIN EXCLUSIVE, timeout 0, no retry
5. validate authority schema/meta/integrity/identity/conflict-domain binding
6. obtain authoritative ledger path only from authority row
7. no-create open that ledger
8. verify ledger DELETE + EXTRA and all required readbacks
9. acquire ledger BEGIN EXCLUSIVE, timeout 0, no retry
10. validate ledger schema/meta/integrity/hash/path/cross-binding
11. resolve authority/ledger tail relation under PL-AUTH-007
12. catch authority forward only for a completely valid suffix; any legacy-import
    material additionally must satisfy PL-LEGACY-022 Case B
13. replay complete authoritative history
14. if import is already complete, return the idempotent completed/caught-up
    result with no mutation handle; otherwise prove the sole normal-writer
    blocker is the expected incomplete LEGACY_IMPORT_REQUIRED state
15. expose only the restricted LEGACY_IMPORT_ONLY handle
```

No identity, schema, corruption, path, authority, split-brain, or duplicate check is bypassed for import.

---

## 7. Restricted `LEGACY_IMPORT_ONLY` surface

The restricted handle may conceptually expose only:

```text
inspect_validated_projection()
validate_legacy_evidence(...)
commit_exact_legacy_import(...)
close()
```

It must not expose:

```text
ordinary arbitrary append
EXECUTION_INTENT_RECORDED for future execution
REQUEST_PREPARED
WRITE_SEND_BOUNDARY_ENTERED
READ_SEND_BOUNDARY_ENTERED
transport/network
credential/private-key access
signing
CREATE/CANCEL/amend/decrease/replace
reconciliation/fill-discovery venue requests
normal writer-proof construction
WRITER_PROOF_RELEASED
normal writer-session acquisition
```

The import-only acquisition itself appends no `WRITER_SESSION_STARTED`, `WRITER_SESSION_ABANDONED`, or `WRITER_SESSION_ENDED`.

---

## 8. Exact legacy ledger batch

One import transaction contains exactly, in order:

```text
LEGACY_INCIDENT_IMPORTED
WRITER_PROOF_HELD
```

The ledger transaction is all-or-nothing.

The import event remains the authoritative representation of pre-ledger history. Do not synthesize retroactive:

```text
EXECUTION_INTENT_RECORDED
REQUEST_PREPARED
WRITE_SEND_BOUNDARY_ENTERED
HTTP_RESPONSE_CLASSIFIED
TRANSPORT_UNKNOWN_AFTER_SEND
```

Both import event envelopes use:

```text
writer_session_id = null
incident_id = KALSHI_DEMO_ONE_ORDER_LIFECYCLE_EXECUTION_01
execution_attempt_id = null
```

The historical `legacy_writer_session_id` stays inside the legacy payload as evidence provenance.

`LEGACY_INCIDENT_IMPORTED.event_id` remains deterministic:

```text
legacy_<sha256(canonical legacy import payload bytes)>
```

The paired hold event retains the normal event-ID rule from the accepted event model.

---

## 9. Two-store import atomicity

### Before ledger COMMIT

Any validation/construction/transaction failure before a successful ledger COMMIT, or a definite ledger-COMMIT failure, yields:

```text
ledger_import_events_committed = 0
authority_tail = unchanged
import_status = NOT_COMMITTED
transport_invocation_count = 0
normal_writer_handle = unavailable
```

### Ledger COMMIT success

The execution ledger contains both required events, never one.

It may now be temporarily ahead of authority.

### Authority success

The import is complete only after:

```text
authority COMMIT succeeds
authority readback == exact new ledger tail
ledger readback at that sequence == same hash
replay proves exactly one import
```

Result:

```text
legacy_import_status = FULLY_AUTHORITY_ANCHORED
history = COMPLETE_WITH_PROTECTED_UNRESOLVED_LEGACY_WRITE
restart = RESTART_UNRESOLVED_WRITE_HELD
writer_proof_state = HELD
writer_proof_release_eligible = false
```

### Authority definite failure after ledger COMMIT

Preserve the complete ledger batch.

```text
ledger = AHEAD_OF_AUTHORITY_WITH_COMPLETE_IMPORT_BATCH
authority = OLD_TRUSTED_TAIL
delete/rewrite/retry import = PROHIBITED
transport = 0
normal writer = unavailable
close/reopen = REQUIRED
```

### Authority unknown after ledger COMMIT

Preserve the complete batch, do not retry import or append a second batch, and require close/reopen. Reopen determines whether authority already equals the imported tail or whether valid forward catch-up is required.

A ledger-COMMIT result that is itself unknown also requires reopen; it is not blindly treated as `NOT_COMMITTED` and the import transaction is not blindly retried.

---

## 10. Reopen after interrupted import

### Case A — authority already equals imported ledger tail

If the exact two-event import validates and replay proves exactly one representation:

```text
append_new_import_events = 0
authority_mutation = 0
import_status = ALREADY_COMPLETED_AND_ANCHORED
restart = RESTART_UNRESOLVED_WRITE_HELD
writer_proof = HELD
```

### Case B — ledger ahead with exact complete import in suffix

If the anchored prefix and complete suffix validate and the suffix contains the exact complete import representation:

```text
append_new_import_events = 0
authority = monotonically catch forward to exact ledger tail
on verified success:
    import_status = ALREADY_COMMITTED_CATCHUP_COMPLETED
    restart = RESTART_UNRESOLVED_WRITE_HELD
    writer_proof = HELD
```

No second import is appended.

### Case C — partial/malformed/conflicting import suffix

Examples:

```text
only one import-batch event
conflicting imported incident content
conflicting WRITER_PROOF_HELD content
invalid batch/order/parent semantics
duplicate non-identical import
invalid evidence identity/content
multiple protected legacy representations for the incident
```

Result:

```text
LEGACY_INCIDENT_IMPORT_CONFLICT
authority catch-up = PROHIBITED
import retry = PROHIBITED
writer capability = PROHIBITED
automatic repair = PROHIBITED
```

---

## 11. Normal writer state before and after import

Before a completed exact import:

```text
history = INCOMPLETE
restart = RESTART_LEGACY_HISTORY_INCOMPLETE
NORMAL_WRITER = blocked
LEGACY_IMPORT_ONLY = conditionally eligible under exact restricted predicates
```

After exact import completion or idempotent authority catch-up:

```text
history = COMPLETE_WITH_PROTECTED_UNRESOLVED_LEGACY_WRITE
restart = RESTART_UNRESOLVED_WRITE_HELD
normal write/send capability = unavailable
```

Import completion does not make the incident safe for another CREATE.

---

## 12. Immutable current incident result

Every successful import completion/recognition/catch-up must replay:

```text
incident_id =
KALSHI_DEMO_ONE_ORDER_LIFECYCLE_EXECUTION_01

disposition =
WRITE_UNRESOLVED_ZERO_MATCH

bound_order_id =
null

created_order_upper_bound =
1

active_order_upper_bound =
1

unknown_result =
true

writer_proof_state =
HELD

writer_proof_release_eligible =
false

protected_unresolved_legacy_write_count =
1

restart_classification =
RESTART_UNRESOLVED_WRITE_HELD
```

Prohibited inferences remain:

```text
CREATE_NEVER_EXISTED
CREATE_DEFINITELY_FAILED
SAFE_TO_RETRY_CREATE
SAFE_TO_CANCEL
WRITER_PROOF_RELEASED
INCIDENT_CLOSED
```

---

## 13. Future offline test additions

Preserve every Revision-02 required offline test.

The Revision-03 correction additionally requires:

```text
NORMAL_WRITER before import -> RESTART_LEGACY_HISTORY_INCOMPLETE
same valid state + LEGACY_IMPORT_ONLY -> restricted handle succeeds
restricted handle has no transport/send/ordinary append/credential/signing/
    writer-proof-release surface

evidence validation failure -> zero import events
ledger transaction failure -> zero import events
ledger COMMIT definite failure -> zero import events
successful ledger import -> exactly two required events, never one

authority definite failure after ledger import ->
    complete two-event ledger-ahead suffix remains
    transport count 0
    no normal writer
    no automatic import retry

authority unknown after ledger import ->
    complete batch remains
    reopen required
    no duplicate import

reopen authority-equal exact import ->
    append zero
    RESTART_UNRESOLVED_WRITE_HELD

reopen valid ledger-ahead exact import ->
    authority catches forward
    append zero
    RESTART_UNRESOLVED_WRITE_HELD

partial/malformed suffix ->
    fail closed
    no catch-up
    no retry

conflicting import ->
    LEGACY_INCIDENT_IMPORT_CONFLICT

current incident exact fields/proof/count remain unchanged
```

All import mechanics use synthetic fixtures only.

No future offline test may perform the real accepted legacy import.

Required zero-side-effect evidence across import tests:

```text
real credential reads = 0
Kalshi Demo requests = 0
Kalshi production requests = 0
orders = 0
cancellations = 0
amend/decrease/replace = 0
WebSockets = 0
funding/trading = 0
package installation = 0
```

---

## 14. Review traceability

| SPEC REQUIREMENT | SPEC LOCATION | FUTURE TEST / EVIDENCE | STATUS |
|---|---|---|---|
| `LEGACY_IMPORT_ONLY` restricted acquisition | `PL-LEGACY-015..017`, Section 19 | normal-writer-blocked/import-only-permitted + restricted-surface tests | `CLOSED_IN_SPEC_03` |
| legacy import ledger-batch atomicity | `PL-LEGACY-010`, `PL-LEGACY-018`, Section 19 | zero-before-commit / exactly-two-after-commit tests | `CLOSED_IN_SPEC_03` |
| authority failure/unknown after committed batch | `PL-LEGACY-019..021`, Section 19 | complete ledger-ahead suffix retained, no retry, transport zero | `CLOSED_IN_SPEC_03` |
| reopen/catch-up without duplicate import | `PL-LEGACY-014`, `PL-LEGACY-022`, Section 19 | authority-equal + ledger-ahead reopen, append-zero assertions | `CLOSED_IN_SPEC_03` |
| current unresolved incident | `PL-LEGACY-001`, `PL-LEGACY-024`, `PL-PROOF-005` | exact disposition/upper bounds/unknown/proof/count | `PRESERVED_UNRESOLVED` |
| no automatic resend | `PL-WRITE-004`, `PL-LEGACY-017..023` | transport zero on import paths; unresolved state blocks send | `PRESERVED` |

---

## 15. Static review hazards

A future implementation review should explicitly reject any implementation that:

```text
reuses a NORMAL_WRITER object with a boolean import flag
skips any authority/ledger validation for import-only
opens either established store with create-if-missing behavior
reverses authority/ledger lock order
allows arbitrary event append through import-only
appends writer-session events solely to bootstrap import
fabricates a historical WRITE_SEND_BOUNDARY_ENTERED
deletes a committed import batch because authority update failed
retries the import transaction after an unknown commit result without reopen
appends a second import when the exact import already exists
authority-catches-up a partial/malformed import suffix
constructs normal writer proof after import despite the unresolved write
performs venue/credential activity during acquisition, replay, import, or tests
```

---

## 16. Capability boundary

This handoff and its controlling specification provide no execution capability.

```text
canonical_repository_read_sync = future task dependent
repository_code_changes = NOT_PERFORMED_BY_THIS_ARTIFACT
test_source_changes = NOT_PERFORMED_BY_THIS_ARTIFACT
test_execution = NOT_PERFORMED
package_installation = NOT_PERFORMED

general_internet = NOT_USED
official_documentation_access = NOT_USED
venue_network = PROHIBITED_BY_THIS_TASK
credentials_signing = PROHIBITED_BY_THIS_TASK
account_access = PROHIBITED_BY_THIS_TASK
CREATE_CANCEL_AMEND_DECREASE_REPLACE = PROHIBITED_BY_THIS_TASK
WebSocket = PROHIBITED_BY_THIS_TASK
funding_trading = PROHIBITED_BY_THIS_TASK

local_git_write = NOT_PERFORMED
remote_git_write = NOT_PERFORMED
```

Repository inspection for this specification was read-only.

---

## 17. Completion boundary

Deliverables for this bounded correction are only:

```text
KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_03.md
HANDOFF_KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_03.md
```

No implementation, tests, real legacy import, credentials, venue activity, repository modification, branch, commit, push, PR, or merge is part of this handoff.

`STOP_AFTER_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_03_AND_HANDOFF_DELIVERY`
