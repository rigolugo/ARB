# KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_03

**Artifact class:** `TECHNICAL_SPECIFICATION`  
**Task class:** `SPEC_ONLY`  
**Technical scope:** `PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_ONLY`  
**Risk tier:** `LOW`  
**Risk posture:** fail closed  
**Canonical repository:** `rigolugo/ARB`  
**Exact reviewed canonical `main`:** `5a65ccadb05b29d6e8692a108bcf46347ec0d214`  
**Exact reviewed canonical tree:** `c4bce88221c7ea30f0bd381ba26851f05ac83b6b`  
**Exact reviewed parent:** `7681676edb86e0f8fda52d5cebd46a5f52356401`  
**Ledger schema revision:** `1`  
**Persistence mechanism:** Python standard-library `sqlite3` / SQLite rollback journal  
**Implementation performed by this artifact:** `false`  
**Venue execution performed or authorized by this artifact:** `false`  
**Completion boundary:** `STOP_AFTER_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_03_AND_HANDOFF_DELIVERY`

---

## 1. Purpose

This specification defines the smallest durable local execution-safety ledger that can later make the accepted ARB execution spine crash-safe and restart-safe without changing venue semantics or granting venue capability.

The ledger is an **append-only authoritative local safety history** plus a deterministic replay projection. It records write intent, the durable network-send ambiguity boundary, transport/result classifications, order/fill identities and observations, reconciliation dispositions, writer continuity, and halt/terminal facts.

It is not:

- a strategy database;
- a market-data warehouse;
- a profitability or P&L store;
- a general event platform;
- an account database;
- a source of venue authorization;
- a source of credential material;
- a venue truth oracle;
- a mechanism that retroactively resolves missing venue truth.

The accepted unresolved incident remains unresolved after this specification. The ledger can preserve/import that state, but cannot manufacture a venue result that the accepted evidence did not establish.

---

## 2. Controlling repository and source identities

### PL-BASE-001 — canonical base

Any future implementation of this specification MUST begin from exactly:

```text
repository = rigolugo/ARB
default_branch = main
required_main = 5a65ccadb05b29d6e8692a108bcf46347ec0d214
required_tree = c4bce88221c7ea30f0bd381ba26851f05ac83b6b
required_parent = 7681676edb86e0f8fda52d5cebd46a5f52356401
```

An unexplained commit mismatch MUST halt `CANONICAL_BASE_MISMATCH`.  
An unexplained tree mismatch MUST halt `CANONICAL_TREE_MISMATCH`.

A later implementation task MUST NOT silently rebase this contract onto a newer `main`.

### PL-BASE-002 — exact canonical technical inputs

The following exact canonical identities are controlling implementation inputs:

| Path | Raw bytes | SHA-256 | Git blob |
|---|---:|---|---|
| `project_context/PROJECT_STATE.md` | `35872` | `4c959b2cdd7158903cdc380c491ecc4d9936c05e4ab5dfc7ea61b61c834d94eb` | `693ed806ad3e98b4bee100d757d5d9e3bc861ef6` |
| `project_context/ARTIFACT_INDEX.md` | `30901` | `9802cdc2065a783ea400433c06af73729ca08a8f519154e5564c1c49af2b9ea7` | `ff49e8f1ee38efd4e4f730e00311135ef34e66d7` |
| `src/arb/venues/kalshi/order_lifecycle.py` | `181815` | `7ea14d6c4e90f1447eb33ee0df1b04cdb598723f06928eb6077d8449bbf1d133` | `0d36a116458469d1436ceed55018c90c9e876a02` |
| `tests/test_kalshi_one_order_lifecycle.py` | `250999` | `31be69106ec6aa4dc31493580d259dba608e011de6afb17fda1bc3e3ec031558` | `f17ed92eef3460f023a9d5d4eccdf05c933f37dc` |
| `src/arb/venues/kalshi/write_result_reconciliation.py` | `189881` | `a30d4eb9a43f4e1e75022384621a61defaec581c5062ba7ed5610edee7c1db8a` | `101c1e7d5566b8a4b604ef60f92211e33888c2bb` |
| `tests/test_kalshi_write_result_reconciliation.py` | `97543` | `05e05c84d0c265d611b42905f98e94a2249da21aeab4c31a1dcb187af203f6df` | `8edc70a0b8fc8dcac4f50061fa338b27c3b8c45c` |

A mismatch in a required input identity MUST halt `CONTROLLING_ARTIFACT_IDENTITY_MISMATCH`.

### PL-BASE-003 — accepted external predecessor identities

The following external artifacts are controlling technical inputs:

| Artifact | Raw bytes | SHA-256 |
|---|---:|---|
| `execution_evidence.json` | `10746` | `2cb1677d06d3c88a3dd6f5b41190fa6de237bae24f02457fee37b2e0d04eefac` |
| `KALSHI_DEMO_ONE_ORDER_LIFECYCLE_SPEC_06.md` | `101724` | `bb8355ad0022cda0d5ce936ed84993a381028187f207ae4b402f8017c9fbd101` |
| `HANDOFF_KALSHI_DEMO_ONE_ORDER_LIFECYCLE_SPEC_06.md` | `13667` | `a7cecc181001c0ef646da8a0c53bcbcb53e2cf4c8a2bb2a8b43386b4805e75d5` |
| `KALSHI_DEMO_POST_HALT_EXACT_WRITE_RESULT_RECONCILIATION_SPEC_01.md` | `69923` | `61fd39b87d8b837e1a16b2b21cd133614f2607a3c21130682b53ace6ac4715e7` |
| `HANDOFF_KALSHI_DEMO_POST_HALT_EXACT_WRITE_RESULT_RECONCILIATION_SPEC_01.md` | `17704` | `ce6d3ef37339d118a0a390c69432833b50cedb3820017dbc66ef443934724a5e` |
| `KALSHI_DEMO_POST_HALT_EXACT_WRITE_RESULT_RECONCILIATION_EVIDENCE_01.json` | `10541` | `a10eb4a6d7490755bbe055056cbe4960d075fd73048967d7e3d1c846c7be34fe` |
| `KALSHI_DEMO_POST_HALT_FILL_DISCOVERY_BINDING_FALLBACK_SPEC_01.md` | `62219` | `361f7bbc172c1a2ecd7f2278f0371966288e4ef63a41a018820f0a7a1d893c0b` |
| `HANDOFF_KALSHI_DEMO_POST_HALT_FILL_DISCOVERY_BINDING_FALLBACK_SPEC_01.md` | `12699` | `f81a99e0b3aec7a831065c6da622c6a029cb3d137e2cb4708b8b940445799924` |
| `KALSHI_DEMO_POST_HALT_FILL_DISCOVERY_BINDING_FALLBACK_EXECUTION_EVIDENCE_01.json` | `10882` | `5e9cb2690854309f5684fa1b31cc4d837e301152a8466732382acb913dd73aa2` |

The external execution artifacts are evidence records. They establish the project evidence state recorded in those exact bytes; this specification does not claim to have re-observed the historical venue transaction.

### PL-BASE-004 — no venue-source refresh

This ledger design adds no Kalshi REST operation and makes no new claim about current Kalshi API behavior.

A future implementation of this ledger layer MUST NOT require a Kalshi documentation/OpenAPI refresh. If implementation discovers that a new venue operation or a new current-API claim is necessary, it MUST halt `NEW_VENUE_SOURCE_OR_OPERATION_SCOPE_REQUIRED`.


### PL-BASE-005 — Revision-03 correction provenance

Revision 03 is one bounded same-scope correction of the exact blocked Revision-02 predecessor. The predecessor identities are provenance controls; they do not grant implementation or venue capability.

```text
blocked_revision_02_specification =
KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_02.md
bytes = 118356
sha256 = ac699aa98d4813b54e63c3eb91fa84ead4653963ea32729d83f1935578a87476

blocked_revision_02_handoff =
HANDOFF_KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_02.md
bytes = 22149
sha256 = ef6f170efd0d510aa1a2ddadf446575df65dce08da7d02d110503603088d7e62
```

Revision-01 provenance remains unchanged:

```text
blocked_revision_01_specification =
KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_01.md
bytes = 80622
sha256 = ce55ead634937af93c2aa445dc5f197f21c7e6ff71c3db2ec0e3c2f716c57ac3

blocked_revision_01_handoff =
HANDOFF_KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_01.md
bytes = 15708
sha256 = c56f8da188fa0d65f6aadf2e8c8cbfef1d2033c9058e35cbbef6cbc31636070a

initial_dispatch =
BRUNO_DISPATCH_KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_01.md
bytes = 31948
sha256 = 4ace6b5983e7cdee2b39b6b961dce648b35242a86594b617b3601f29f3f0cdb0

initial_inputs_package =
KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_01_INPUTS.zip
bytes = 77969
sha256 = e50a3822953d4c326698334a2246d5fcc51305e41b2d3518a9047d3b7b30785d

initial_inputs_manifest =
KALSHI_DEMO_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_01_INPUTS_MANIFEST.json
bytes = 1442
sha256 = acdd7d5ff765c25facec151ce8b0e89aa34936d3caca0caa99ed7af193cf2e14
```

The following remains non-controlling technical research/design input only:

```text
HANDOFF_PERSISTENT_LEDGER_RESTART_BOUNDARY_INTEGRITY_EXTERNAL_FINDINGS_01.md
bytes = 20887
sha256 = 6b21c223cd394ef6750ec84442ba86f9c1eeed47282fb349593c6f5d13f2ecb4
status = NON_CONTROLLING_TECHNICAL_RESEARCH_INPUT
```

Revision 03 corrects one bootstrap defect with two coupled manifestations and does not reopen the accepted Revision-02 architecture:

1. the legacy import needs an exact restricted acquisition path even though normal writer acquisition is blocked by incomplete pre-ledger history;
2. the two-store import contract must preserve a successfully committed two-event ledger batch when later authority advancement fails or is indeterminate, then deterministically recognize/catch up that batch on reopen without duplicate import.

All unimplicated Revision-02 requirements are preserved in the complete Revision-03 text below. Revision 03 is self-contained and controls any later implementation of this scope; blocked predecessors remain provenance, not additional contracts an implementer must reconcile.

---

## 3. Immutable carried-forward incident

### PL-LEGACY-001 — exact unresolved state

The following state is immutable input to this specification:

```text
incident_id =
KALSHI_DEMO_ONE_ORDER_LIFECYCLE_EXECUTION_01

environment =
KALSHI_DEMO

account_scope_ref =
ARB_KALSHI_DEMO_PRIMARY_ACCOUNT

subaccount =
0

ticker =
KXFEDDECISION-26SEP-H0

client_order_id =
2e64d452-2cc2-43fa-a976-e8f996192252

legacy_writer_session_id =
KALSHI_DEMO_ONE_ORDER_LIFECYCLE_EXECUTION_01_LOCAL_RUNNER

writer_proof_id =
KALSHI_DEMO_ONE_ORDER_LIFECYCLE_EXECUTION_01_WRITER_PROOF

one_order_lifecycle_authorization =
CONSUMED

exact_reconciliation_authorization =
CONSUMED

fill_discovery_fallback_authorization =
CONSUMED

final_accepted_disposition =
WRITE_UNRESOLVED_ZERO_MATCH

bound_order_id =
null

created_order_upper_bound =
1

active_order_upper_bound =
1

unknown_result =
true

writer_proof_state =
HELD

writer_proof_release_eligible =
false
```

The ledger MUST NOT reinterpret this state as any of:

```text
CREATE_NEVER_EXISTED
CREATE_DEFINITELY_FAILED
SAFE_TO_RETRY_CREATE
SAFE_TO_CANCEL
WRITER_PROOF_RELEASED
INCIDENT_CLOSED
```

Zero order evidence plus zero fill evidence remains insufficient negative proof.

### PL-LEGACY-002 — protected conflict domain

For this first ledger contract the logical conflict domain is intentionally account/subaccount-wide, not ticker-local:

```text
conflict_domain_ref =
KALSHI|KALSHI_DEMO|ARB_KALSHI_DEMO_PRIMARY_ACCOUNT|SUBACCOUNT=0
```

This is conservative: a prior unresolved protected write in this conflict domain blocks ledger-backed no-unresolved-prior-write proof for a later write unless and until that prior write is authoritatively closed under an accepted contract.

Ticker and incident remain narrower event attributes; they do not narrow the persistent writer lock.

---

## 4. Architecture boundary

### PL-ARCH-001 — generic ledger layer

The generic persistence layer owns only:

- SQLite initialization/opening for both the trusted authority store and execution ledger;
- local authority namespace/path validation;
- logical conflict-domain -> authoritative ledger binding;
- trusted sequence/event-hash anchor advancement and restart comparison;
- ledger instance identity;
- schema revision enforcement;
- append-only event storage;
- canonical event encoding;
- sequence allocation;
- hash-chain construction and validation;
- process-exclusive writer locking;
- writer-session recording;
- atomic event batches;
- deterministic replay mechanics;
- generic unresolved-write tracking;
- integrity/corruption classification;
- deterministic secret-safe review export.

It MUST NOT know Kalshi request/response schemas beyond generic opaque, already-validated adapter payloads.

### PL-ARCH-002 — Kalshi binding layer

The Kalshi binding layer owns:

- validation/canonicalization of Kalshi-specific prepared request facts;
- validation/canonicalization of order observations;
- validation/canonicalization of fill observations;
- validation of client-order/order/fill identity relationships;
- mapping accepted lifecycle/reconciliation result semantics into generic closure classifications;
- one-time validation/import of the exact legacy incident;
- construction of future ledger-backed writer-proof input only after fully validated replay and a separately accepted integration contract.

The Kalshi binding MUST preserve the accepted identity chain:

```text
client_order_id
    -> venue order_id when exactly bound
    -> fill_id[]
```

It MUST NOT create a universal cross-venue order schema that discards venue-specific meaning.

### PL-ARCH-003 — authoritative versus derived data

Four data classes are distinct:

```text
TRUSTED_AUTHORITY_STATE
    = mutable conflict-domain -> ledger binding plus monotonic trusted sequence/hash
      in the separate authority SQLite store

AUTHORITATIVE_DURABLE_EVENTS
    = append-only rows in ledger_events

DERIVED_REPLAY_PROJECTION
    = deterministic in-memory state recomputed from verified authoritative events

DIAGNOSTIC_METADATA
    = non-authoritative local log/debug material, never used to prove safety
```

Trusted authority state identifies the authoritative ledger and anchors its trusted prefix/tail; it does not replace event history. A derived projection MUST never overwrite authoritative events. Diagnostic metadata MUST never satisfy a safety precondition.

---

## 5. Exact future implementation surface

### PL-SURFACE-001 — first implementation writable path envelope

The exact proposed writable path envelope for the first separately authorized implementation of this specification is four repository paths only:

```text
NEW:
src/arb/execution_ledger.py
src/arb/venues/kalshi/ledger_binding.py
tests/test_execution_ledger.py
tests/test_kalshi_ledger_binding.py

MODIFIED EXISTING PATHS:
none
```

No migration CLI or repository runner is part of Revision 03.

The one-time legacy import entry point belongs in `src/arb/venues/kalshi/ledger_binding.py`; an actual import runner, if later needed for a real local ledger, remains task-local/outside the repository unless separately specified.

### PL-SURFACE-002 — readable protected dependencies

The future implementation may read/import, but MUST NOT modify under this first envelope:

```text
src/arb/venues/kalshi/order_lifecycle.py
src/arb/venues/kalshi/write_result_reconciliation.py
src/arb/venues/kalshi/models.py
src/arb/venues/kalshi/validation.py
src/arb/venues/kalshi/errors.py
tests/test_kalshi_one_order_lifecycle.py
tests/test_kalshi_write_result_reconciliation.py
```

The exact canonical versions at the reviewed base are used; fabricated stand-ins are not acceptable when the real canonical dependency is available.

### PL-SURFACE-003 — later integration boundary

A later, separately specified integration may need to add ledger hooks to the accepted lifecycle/reconciliation modules and their tests. That integration is **not** part of the first implementation path envelope and MUST NOT be inferred from this specification-only task.

The reason the first implementation can remain in new modules is that the accepted lifecycle and reconciliation implementations already expose caller-controlled orchestration/transport boundaries and validated order/fill semantics; the ledger layer can be implemented and tested independently before wiring those boundaries.

---

## 6. Persistence mechanism, two-store durability, and fault model

### PL-SQL-001 — required mechanisms

Revision 03 MUST use Python standard-library `sqlite3` for both load-bearing persistence stores:

```text
1. execution ledger SQLite database
2. trusted authority/anchor SQLite database
```

No third-party package may be introduced for persistence, locking, serialization, hashing, migration, or authority state.

The two databases are separate durability domains. No cross-database atomic transaction is assumed or claimed.

### PL-SQL-002 — execution-ledger database model

One logical ledger instance equals one SQLite database file. The database contains execution-safety history for exactly one:

```text
ledger_instance_id
environment_classification
conflict_domain_ref
ledger_schema_revision = 1
authority_instance_id
authority_namespace_id
```

A ledger instance MUST NOT be reused for another environment, conflict domain, or authority namespace.

### PL-SQL-003 — exact SQLite settings for both stores

Both the execution ledger database and the trusted authority/anchor database MUST use the same load-bearing SQLite posture.

Initialization MUST set `PRAGMA journal_mode=DELETE` before the first authoritative schema transaction. Normal open of an existing store MUST observe `journal_mode == "delete"`; it MUST fail closed rather than silently convert another journal mode.

Every load-bearing connection MUST use exact equivalent behavior to:

```text
sqlite3.connect(
    database_path,
    timeout=0.0,
    isolation_level=None,
)

PRAGMA synchronous=EXTRA;
PRAGMA foreign_keys=ON;
PRAGMA busy_timeout=0;
PRAGMA locking_mode=EXCLUSIVE;
```

Readback MUST verify exactly:

```text
journal_mode == "delete"
synchronous == 3          # SQLite EXTRA
foreign_keys == 1
busy_timeout == 0
locking_mode == "exclusive"
```

Failure to set or verify any required value MUST halt:

```text
LEDGER_DURABILITY_CONFIGURATION_FAILURE
```

for the ledger store, or:

```text
AUTHORITY_DURABILITY_CONFIGURATION_FAILURE
```

for the authority store.

`WAL`, `MEMORY`, `OFF`, `NORMAL`, `FULL`, or implementation-default synchronous behavior is not accepted for a load-bearing writer connection under Revision 03.

### PL-SQL-004 — transaction modes

Python implicit transactions MUST remain disabled.

Execution-ledger authoritative mutation uses:

```text
BEGIN IMMEDIATE;
... validate expected ledger tail / insert authoritative event or batch ...
COMMIT;
```

Trusted-authority anchor advancement uses:

```text
BEGIN IMMEDIATE;
... validate expected authority row / advance trusted sequence + hash ...
COMMIT;
```

Initialization of either database uses `BEGIN EXCLUSIVE` for its schema/meta transaction.

Writer acquisition uses the exact authority-first lock order in PL-LOCK-002 and begins with `BEGIN EXCLUSIVE` on the authority database, then `BEGIN EXCLUSIVE` on the bound ledger database. After the acquisition transactions commit, both connections remain open in `locking_mode=EXCLUSIVE` for the active writer session.

### PL-SQL-005 — ledger-only commit definition

A ledger event/batch is **ledger-committed** when all of the following are true:

1. the ledger connection passed PL-SQL-003 readback;
2. the complete event/batch was inserted under one explicit transaction;
3. all SQLite and application invariants passed;
4. ledger `COMMIT` returned success;
5. no commit exception or indeterminate result occurred.

A ledger-only commit is not sufficient for caller reliance on an authoritative append under Revision 03.

If ledger `COMMIT` fails definitively, return `LEDGER_COMMIT_FAILURE`. If its result is unknown/indeterminate, return `LEDGER_COMMIT_RESULT_UNKNOWN`; halt and require reopen/replay before any network-capable action.

### PL-SQL-006 — authoritative append durability definition

Except for the special first-time binding sequence in PL-AUTH-005, an authoritative append is **fully committed for caller reliance** only after both durability domains succeed in order:

```text
1. ledger event/event-batch COMMIT succeeds;
2. trusted authority row is advanced to that exact ledger tail sequence/hash;
3. authority COMMIT succeeds;
4. authority row is read back and equals the intended sequence/hash;
5. ledger tail is rechecked to equal the same sequence/hash before a send gate is exposed.
```

If step 1 succeeds but steps 2-5 fail, return an authority-anchor failure/unknown classification and halt locally. The ledger suffix remains immutable and is reconciled on the next open under PL-AUTH-007. It MUST NOT be deleted, rewritten, or automatically rolled back to the older trusted anchor.

### PL-SQL-007 — software durability boundary and conditional physical durability

Revision 03 distinguishes two claims.

```text
LOGICAL_PROCESS_CRASH_GUARANTEE
```

means the ordering, replay, lock, and fail-closed rules in this specification must hold across normal exceptions, abrupt process termination, and restart when the committed SQLite state is preserved by the operating environment.

```text
OS_FILESYSTEM_STORAGE_POWER_LOSS_DURABILITY
```

is conditional.

A successful SQLite commit under the required `DELETE + EXTRA` configuration is the **software durability boundary assumed by this design**. Physical power-loss durability is conditional on the operating system, filesystem, virtualization layer, storage controller, and storage hardware honoring the synchronization semantics on which SQLite relies.

Revision 03 MUST NOT claim that `DELETE + EXTRA` defeats an environment that violates those synchronization semantics.

Ordinary unit tests, injected exceptions, process-kill tests, and restart tests validate the logical crash theorem. They MUST NOT be labeled physical sudden-power-loss qualification.

### PL-SQL-008 — integrity checks

Before authoritative replay, each existing SQLite store MUST pass:

```text
PRAGMA integrity_check;
    exactly one row whose exact text is "ok"

PRAGMA foreign_key_check;
    exactly zero rows
```

Ledger failure classifies `LEDGER_INTEGRITY_CHECK_FAILURE`.
Authority failure classifies `AUTHORITY_INTEGRITY_CHECK_FAILURE`.

`quick_check` is insufficient for authoritative startup.

### PL-SQL-009 — schema versions

Execution ledger:

```text
PRAGMA user_version == 1
ledger_meta.ledger_schema_revision == 1
```

Trusted authority store:

```text
PRAGMA user_version == 1
authority_meta.authority_schema_revision == 1
```

Mismatch between a store's `user_version` and immutable meta value is a schema identity failure. Newer or older unsupported revisions fail closed. Revision 03 performs no automatic migration and no repair-in-place.

### PL-SQL-010 — clean shutdown

A clean writer shutdown MUST execute exactly:

```text
1. append WRITER_SESSION_ENDED to the ledger;
2. durably advance the authority anchor to that committed end event;
3. verify both stores agree on the terminal sequence/hash;
4. close the ledger connection;
5. close the authority connection, releasing logical authority ownership.
```

Failure after the event is ledger-committed but before authority advancement leaves a ledger-ahead-of-anchor state for deterministic restart handling. Clean shutdown NEVER releases writer proof by itself.

## 7. Trusted authority/anchor, logical conflict-domain binding, and path safety

### PL-AUTH-001 — one deployment-bound authority namespace

Revision 03 selects one exact authority mechanism: a deployment-bound standard-library SQLite authority store that owns the logical conflict-domain binding and trusted ledger tail anchor.

A future accepted integration MUST bind one `AuthorityNamespaceBinding` before any writer-capable operation:

```text
authority_namespace_id:       non-empty canonical str
authority_namespace_root:     exact absolute resolved local directory
authority_store_filename:     arb_execution_authority_v1.sqlite3
authority_store_resolved_path:
    <authority_namespace_root>/arb_execution_authority_v1.sqlite3
authority_store_path_identity_sha256: exact path identity hash
authority_schema_revision:    exact int 1
```

The namespace root is deployment configuration, not a per-call option. Low-level append/open APIs MUST NOT accept an arbitrary alternate authority root that can silently establish a second writer universe.

For the first implementation, the authority store uses one fixed filename for the namespace. Conflict domains are keyed by their exact canonical `conflict_domain_ref` text inside that store, not by a hashed filename. Therefore two distinct canonical conflict-domain strings cannot alias through a filename hash.

The authority root/store is local operational state outside the public canonical repository.

### PL-AUTH-002 — canonical path identity

For any load-bearing local path, compute:

```text
resolved_path = Path(path).resolve(strict=True)        # existing object
native_normalized_path = os.path.normcase(os.path.normpath(str(resolved_path)))
path_identity_sha256 = lowercase_hex(
    SHA256(
        b"ARB_PATH_IDENTITY_V1\x00" +
        UTF8(native_normalized_path)
    )
)
```

For a path that does not yet exist during explicit initialization, resolve the existing parent strictly and append the exact leaf filename before applying `normpath`/`normcase`.

The exact normalized path text is stored in trusted authority state. Deterministic evidence export uses only the SHA-256 path identity unless a separately authorized diagnostic explicitly requires the local path text.

### PL-AUTH-003 — authority namespace initialization

Authority-store creation is an explicit operation distinct from normal open.

Initialization preconditions:

```text
authority namespace root exists and resolves outside canonical repository
authority store path does not exist
authority store path is not a symlink/junction/reparse redirect
authority schema revision == 1
authority namespace id is explicitly bound by deployment configuration
```

Initialization creates:

```text
authority_instance_id = lowercase UUID4 text
authority_schema_revision = 1
authority_namespace_id
authority_store_resolved_path
authority_store_path_identity_sha256
created_at_utc
```

using the exact SQLite posture in Section 6.

Normal `open_authority_namespace(...)` MUST use existing-file semantics and MUST NOT create the file. If an established authority store is missing, normal open MUST halt `AUTHORITY_STORE_MISSING`. It MUST NOT silently call initialization.

If initialization creates any partial filesystem/database object and does not fully commit valid authority metadata, the path remains blocked for diagnosis; automatic delete/recreate is prohibited.

### PL-AUTH-004 — authority store identity and replacement handling

Every normal open MUST validate:

```text
authority_schema_revision == 1
authority_namespace_id == exact accepted deployment binding
authority_store_resolved_path == accepted resolved path
authority_store_path_identity_sha256 == recomputed exact identity
authority_instance_id is valid immutable UUID4 text
required authority schema/triggers exist
integrity_check == ok
foreign_key_check == []
```

An authority store with a different instance/namespace/path identity is `AUTHORITY_IDENTITY_MISMATCH`.

An empty/new replacement store at an established namespace cannot become authoritative for an existing ledger because the exact conflict-domain binding row and ledger cross-binding are required. Missing established binding is `AUTHORITY_CONFLICT_DOMAIN_BINDING_MISSING`; no automatic recreation/adoption is allowed.

A trusted authority store is the external local root of trust for ledger truncation detection. Revision 03 does not claim protection against an actor capable of replacing both a ledger and all trusted authority state with a mutually consistent forged/older pair; that is outside this local accidental-corruption/crash threat model.

### PL-AUTH-005 — exact conflict-domain authority row and first binding

For each conflict domain, the authority store owns exactly one mutable high-watermark row:

```text
conflict_domain_ref
environment_classification
ledger_instance_id
ledger_resolved_path
ledger_path_identity_sha256
trusted_sequence
trusted_event_hash
updated_at_utc
```

The exact `conflict_domain_ref` is the primary key. One row may bind to only one ledger instance/path. A second ledger file cannot claim the same conflict domain while that row exists.

First ledger binding is a special two-store initialization sequence:

```text
1. acquire authority exclusive ownership;
2. prove no authority row exists for conflict_domain_ref;
3. create/initialize the new ledger with LEGACY_IMPORT_REQUIRED;
4. ledger COMMIT sequence 1 LEDGER_INITIALIZED;
5. insert the authority row bound to that exact ledger instance/path and
   trusted_sequence = 1 / trusted_event_hash = ledger sequence-1 event_hash;
6. authority COMMIT;
7. read back the authority row and recheck ledger sequence/hash;
8. only then report initialization success.
```

If ledger initialization commits and the authority binding commit fails **definitively**, the ledger is an **unbound orphan**. It has no writer authority and MUST NOT be automatically adopted, rebound, deleted, or used for proof. Classification is `AUTHORITY_LEDGER_INITIALIZATION_PARTIAL_FAILURE` pending explicit diagnosis outside this first contract.

If the authority binding commit result is unknown/indeterminate, initialization MUST halt and close/reopen. On reopen:

```text
exact authority row exists and matches the ledger sequence-1 identity/hash
    -> treat first binding as completed and continue normal validation

authority row absent
    -> ledger is an unbound orphan; no automatic adoption

row exists but any binding/hash differs
    -> authority/ledger identity or integrity failure
```

The same initialization call MUST NOT blindly retry the authority INSERT after an indeterminate result.

### PL-AUTH-006 — uniform authority advancement

After first binding, every authoritative ledger append/batch MUST use:

```text
ledger old fully-anchored tail = (S, H)
    -> ledger append/batch COMMIT -> new tail (S2, H2)
    -> authority transaction verifies current row == (S, H)
    -> authority row updates only trusted_sequence/trusted_event_hash/updated_at
       to (S2, H2)
    -> authority COMMIT
    -> authority readback == (S2, H2)
    -> ledger readback at S2 == H2
    -> append is fully committed for caller reliance
```

Authority advancement MUST be monotonic:

```text
new trusted_sequence > old trusted_sequence
```

except an idempotent verification of an already-equal exact pair. The authority row MUST never move backward.

Authority commit definite failure -> `AUTHORITY_ANCHOR_COMMIT_FAILURE`.
Authority commit unknown/indeterminate or unverifiable readback -> `AUTHORITY_ANCHOR_COMMIT_RESULT_UNKNOWN`.

Either case halts the active operation. No transport send may begin for a write whose send-boundary authority advancement has not been positively verified.

### PL-AUTH-007 — exact two-store restart relations

After authority and ledger identity/integrity validation, exactly one relation applies.

**A. authority equal to ledger**

```text
authority.trusted_sequence == ledger.last_sequence
authority.trusted_event_hash == ledger.terminal_event_hash
```

Proceed to deterministic replay.

**B. ledger ahead of authority**

```text
ledger.last_sequence > authority.trusted_sequence
```

Required handling:

1. event hash at `authority.trusted_sequence` MUST equal `authority.trusted_event_hash`;
2. validate every event from sequence `1` through the ledger tail, including canonical encoding, sequence continuity, payload hash, previous-event hash, event hash, parent/session/incident semantics, duplicates, and closed event schema;
3. replay the complete validated suffix; any send boundary in that suffix is treated conservatively as `WRITE_MAY_HAVE_BEEN_SENT` unless a later validated closure event closes it;
4. while the authority lock remains held, advance the authority row monotonically to the validated ledger tail using PL-AUTH-006 semantics;
5. if catch-up commit is not definitely successful and verified, halt `AUTHORITY_ANCHOR_CATCHUP_FAILURE` with no writer capability;
6. never delete the suffix, rewrite the ledger, or move the authority backward.

A fully validated ledger-ahead suffix may be adopted only by **advancing** the trusted authority to that exact suffix tail. This deterministic catch-up is not repair of ledger history; it is completion of a prior two-store partial transition.

For any suffix containing `LEGACY_INCIDENT_IMPORTED` or a `WRITER_PROOF_HELD` event whose held reason is `PROTECTED_UNRESOLVED_LEGACY_WRITE`, PL-AUTH-007 catch-up additionally requires PL-LEGACY-022 Case B. A partial, malformed, or conflicting legacy-import representation is not a valid catch-up suffix and MUST NOT be authority-anchored.

**C. authority ahead of ledger**

```text
authority.trusted_sequence > ledger.last_sequence
```

Classify `AUTHORITY_AHEAD_OF_LEDGER_ROLLBACK_OR_REPLACEMENT`; writer capability is prohibited. Do not recreate or rewrite either store.

**D. hash mismatch at trusted sequence**

If the ledger has the trusted sequence but its event hash differs from the authority hash, classify `AUTHORITY_LEDGER_ANCHOR_HASH_MISMATCH`; writer capability is prohibited.

**E. identity mismatch**

Wrong environment, conflict domain, ledger instance, ledger resolved path/path identity, authority namespace, or authority instance is an authority/ledger identity failure; writer capability is prohibited.

**F. missing/corrupt store**

Missing established authority -> `AUTHORITY_STORE_MISSING`.
Missing bound ledger -> `LEDGER_FILE_MISSING`.
Corrupt authority -> `AUTHORITY_INTEGRITY_CHECK_FAILURE`.
Corrupt ledger -> `LEDGER_INTEGRITY_CHECK_FAILURE`.

No normal open path recreates either store.

### PL-AUTH-008 — alternate namespace is not writer authority

A ledger/proof bound to one authority namespace is invalid under any different authority namespace root/path/namespace identity.

A future accepted venue integration MUST bind one exact authority namespace for the deployment. A caller MUST NOT obtain writer eligibility by pointing the same conflict-domain string at another authority root.

For the first implementation, a proof object MUST include the authority namespace/path identities so a proof produced under namespace A is rejected under namespace B.

### PL-PATH-001 — local non-repository paths

Both authority namespace root/store and execution-ledger file are local operational state and MUST be outside the resolved canonical repository root.

The authoritative ledger path is not selected by `open_existing_ledger(...)`; normal writer open obtains it from the trusted conflict-domain authority row. An optional caller expected path may only be compared for equality and MUST NOT override the authority binding.

A path resolving to the repository root or a descendant MUST halt `LEDGER_PATH_INSIDE_CANONICAL_REPOSITORY` or `AUTHORITY_PATH_INSIDE_CANONICAL_REPOSITORY` as applicable.

### PL-PATH-002 — link/reparse safety

Existing authority and ledger file paths MUST reject a final filesystem entry that is a symbolic link. On CPython 3.12+ Windows they MUST also reject a final entry for which `Path.is_junction()` is true. Resolved parents and final resolved locations MUST be rechecked against the canonical repository root.

### PL-PATH-003 — no silent creation on normal open

Normal authority and ledger open MUST use existing-file semantics. Missing files are failures, not empty history.

The implementation MUST NOT call SQLite in a normal-open mode that silently creates a new database.

### PL-PATH-004 — explicit ledger initialization

Ledger creation is permitted only through the first-binding flow PL-AUTH-005.

Initialization input MUST NOT contain a caller-selectable pre-ledger-empty mode. The only supported first-persistence mode in this contract is:

```text
preledger_history_mode = LEGACY_IMPORT_REQUIRED
```

If a ledger file already exists at the intended new path, initialization halts `LEDGER_ALREADY_EXISTS`.

### PL-PATH-005 — ledger instance identity

`ledger_instance_id` is generated once at initialization as lowercase RFC 4122 UUID version 4 text and is immutable for the life of the ledger.

### PL-PATH-006 — immutable ledger metadata

The single `ledger_meta` row MUST contain:

```text
ledger_instance_id:               uuid4 str
ledger_schema_revision:           exact int 1
created_at_utc:                   canonical UTC timestamp
environment_classification:      exact non-empty value
conflict_domain_ref:              exact canonical str
preledger_history_mode:           exact literal LEGACY_IMPORT_REQUIRED
authority_instance_id:            exact bound UUID4 str
authority_namespace_id:           exact bound canonical str
authority_store_path_identity_sha256: lowercase 64-hex
ledger_path_identity_sha256:      lowercase 64-hex
```

No supported Revision-03 state permits `PRELEDGER_HISTORY_PROVEN_EMPTY`.

### PL-PATH-007 — caller-asserted emptiness is prohibited

Until a future separate specification defines and identity-binds a complete pre-ledger-empty proof mechanism, none of the following establishes pre-ledger emptiness:

```text
absence of ledger rows
new SQLite database
new ledger_instance_id
new conflict-domain string
caller assertion
configuration flag
lack of observed orders
lack of observed fills
```

The token/value `PRELEDGER_HISTORY_PROVEN_EMPTY` MUST be rejected wherever a caller-controlled value could present it.

For the current conflict domain:

```text
before exact legacy import:
    history_completeness = INCOMPLETE
    restart = RESTART_LEGACY_HISTORY_INCOMPLETE

after exact legacy import:
    history_completeness = COMPLETE_WITH_PROTECTED_UNRESOLVED_LEGACY_WRITE
    restart = RESTART_UNRESOLVED_WRITE_HELD
```

A genuinely new conflict-domain pre-ledger-empty proof is future work under a separate accepted specification/integration contract.

### PL-PATH-008 — no external per-append expectation object

Revision 03 removes the Revision-01 caller-retained mutable `LedgerOpenExpectation` as the load-bearing tail authority.

The trusted authority store itself is the durable tail owner. Append/restart code MUST use PL-AUTH-006/007. A caller-returned sequence/hash may be exposed for diagnostics, but it cannot replace the trusted authority row or satisfy writer-proof predicates.

## 8. Exact SQLite schemas

### PL-SCHEMA-001 — execution-ledger `ledger_meta`

Revision 03 MUST create:

```sql
CREATE TABLE ledger_meta (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    ledger_instance_id TEXT NOT NULL UNIQUE,
    ledger_schema_revision INTEGER NOT NULL CHECK (ledger_schema_revision = 1),
    created_at_utc TEXT NOT NULL,
    environment_classification TEXT NOT NULL,
    conflict_domain_ref TEXT NOT NULL,
    preledger_history_mode TEXT NOT NULL
        CHECK (preledger_history_mode = 'LEGACY_IMPORT_REQUIRED'),
    authority_instance_id TEXT NOT NULL,
    authority_namespace_id TEXT NOT NULL,
    authority_store_path_identity_sha256 TEXT NOT NULL,
    ledger_path_identity_sha256 TEXT NOT NULL
);
```

Exactly one row is permitted.

### PL-SCHEMA-002 — execution-ledger `ledger_events`

Revision 03 MUST preserve the Revision-01 event table fields exactly:

```sql
CREATE TABLE ledger_events (
    sequence INTEGER PRIMARY KEY CHECK (sequence >= 1),
    event_id TEXT NOT NULL UNIQUE,
    ledger_instance_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    event_schema_revision INTEGER NOT NULL CHECK (event_schema_revision = 1),
    writer_session_id TEXT,
    incident_id TEXT,
    execution_attempt_id TEXT,
    recorded_at_utc TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    payload_sha256 TEXT NOT NULL,
    previous_event_hash TEXT NOT NULL,
    event_hash TEXT NOT NULL UNIQUE,
    FOREIGN KEY (ledger_instance_id)
        REFERENCES ledger_meta(ledger_instance_id)
);
```

The implementation MAY add non-authoritative indexes only when they do not change event semantics.

### PL-SCHEMA-003 — ledger immutability triggers

After initialization, triggers MUST reject:

```text
UPDATE ledger_events
DELETE FROM ledger_events
UPDATE ledger_meta
DELETE FROM ledger_meta
INSERT a second ledger_meta row
```

Required trigger names/behaviors remain:

```text
trg_ledger_events_no_update
trg_ledger_events_no_delete
trg_ledger_meta_no_update
trg_ledger_meta_no_delete
```

Normal open MUST verify the required tables, columns, constraints, foreign key, and triggers using `sqlite_schema`, `PRAGMA table_info`, and `PRAGMA foreign_key_list`.

### PL-SCHEMA-004 — ledger sequence

The first ledger event sequence is exactly `1`; each next sequence is exactly prior tail + 1. `AUTOINCREMENT` is not the safety source. Gap, duplicate, non-1 genesis, or out-of-order sequence is `LEDGER_SEQUENCE_INTEGRITY_FAILURE`.

### PL-SCHEMA-005 — authority `authority_meta`

The trusted authority database MUST create:

```sql
CREATE TABLE authority_meta (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    authority_instance_id TEXT NOT NULL UNIQUE,
    authority_schema_revision INTEGER NOT NULL CHECK (authority_schema_revision = 1),
    authority_namespace_id TEXT NOT NULL,
    authority_store_resolved_path TEXT NOT NULL,
    authority_store_path_identity_sha256 TEXT NOT NULL,
    created_at_utc TEXT NOT NULL
);
```

Exactly one row is permitted. `authority_meta` is immutable after initialization.

### PL-SCHEMA-006 — authority `conflict_domain_authority`

The trusted authority database MUST create:

```sql
CREATE TABLE conflict_domain_authority (
    conflict_domain_ref TEXT PRIMARY KEY,
    environment_classification TEXT NOT NULL,
    ledger_instance_id TEXT NOT NULL UNIQUE,
    ledger_resolved_path TEXT NOT NULL UNIQUE,
    ledger_path_identity_sha256 TEXT NOT NULL UNIQUE,
    trusted_sequence INTEGER NOT NULL CHECK (trusted_sequence >= 1),
    trusted_event_hash TEXT NOT NULL,
    updated_at_utc TEXT NOT NULL
);
```

`trusted_event_hash` MUST be exact lowercase 64-hex SHA-256. `ledger_resolved_path` is the exact canonical normalized resolved path under PL-AUTH-002.

### PL-SCHEMA-007 — authority immutability and monotonic-update triggers

Required authority trigger names and behavior are exactly:

```text
trg_authority_meta_no_update
    BEFORE UPDATE ON authority_meta
    -> RAISE(ABORT, "IMMUTABLE_AUTHORITY_META")

trg_authority_meta_no_delete
    BEFORE DELETE ON authority_meta
    -> RAISE(ABORT, "IMMUTABLE_AUTHORITY_META")

trg_conflict_authority_no_delete
    BEFORE DELETE ON conflict_domain_authority
    -> RAISE(ABORT, "IMMUTABLE_CONFLICT_DOMAIN_BINDING")

trg_conflict_authority_immutable_fields
    BEFORE UPDATE ON conflict_domain_authority
    when any of conflict_domain_ref, environment_classification, ledger_instance_id,
    ledger_resolved_path, ledger_path_identity_sha256 changes
    -> RAISE(ABORT, "IMMUTABLE_CONFLICT_DOMAIN_BINDING")

trg_conflict_authority_monotonic_tail
    BEFORE UPDATE ON conflict_domain_authority
    when NEW.trusted_sequence <= OLD.trusted_sequence
    -> RAISE(ABORT, "NON_MONOTONIC_AUTHORITY_TAIL")
```

Normal advancement therefore always increases the trusted sequence. Exact equality is handled as an application-level idempotent verification with **no UPDATE statement** and requires the exact same trusted event hash. A same-sequence/different-hash request is `AUTHORITY_LEDGER_ANCHOR_HASH_MISMATCH`.

Open-time schema validation MUST verify the required trigger names, definitions, and behavior.

### PL-SCHEMA-008 — no normal schema mutation

Schema DDL changes are prohibited during normal open/replay/append for both stores. No automatic migration, drop/recreate, VACUUM-as-repair, or authority-row replacement is permitted. A future schema migration requires a separate specification.

## 9. Canonical encoding

### PL-CANON-001 — canonical JSON

Canonical JSON bytes are exactly:

```python
json.dumps(
    canonical_value,
    sort_keys=True,
    separators=(",", ":"),
    ensure_ascii=True,
    allow_nan=False,
).encode("utf-8")
```

with:

```text
no BOM
no trailing newline
no insignificant whitespace
```

The stored `payload_json` text MUST round-trip to exactly the same canonical UTF-8 bytes.

### PL-CANON-002 — allowed JSON-domain values

Canonical payload input permits only:

```text
dict with exact built-in str keys
list
exact built-in str
null / None
exact built-in bool
exact built-in int in signed 64-bit range
decimal.Decimal through the tagged encoding below
```

Prohibited:

```text
float
bytes/bytearray
tuple/set
NaN/Infinity
custom numeric classes
bool where an integer schema field is required
dict keys that are not exact built-in str
```

### PL-CANON-003 — Unicode

Every string and key MUST already be Unicode NFC normalized.

The implementation MUST reject, not silently normalize, a non-NFC string with `NONCANONICAL_UNICODE`.

### PL-CANON-004 — Decimal tag

Binary floating point is prohibited for monetary values and exact quantities.

A `decimal.Decimal` is serialized only as:

```json
{"$decimal":"<canonical-decimal-text>"}
```

Caller-supplied dictionaries containing reserved keys beginning with `$` are prohibited; only the canonicalizer may create the `$decimal` tag.

Canonical Decimal text MUST satisfy:

```text
finite only
no exponent notation
no leading "+"
no unnecessary leading zeros
no trailing fractional zeros
no trailing decimal point
negative zero canonicalizes to "0"
integer zero canonicalizes to "0"
```

Examples:

```text
Decimal("1.00")     -> "1"
Decimal("0.0100")   -> "0.01"
Decimal("0.000001") -> "0.000001"
Decimal("-0.00")    -> "0"
```

On replay, a malformed/noncanonical Decimal tag MUST halt `LEDGER_DECIMAL_CANONICALIZATION_FAILURE`.

Venue-specific source text MAY be preserved separately as a validated string when lexical provenance is required; it MUST NOT substitute for the Decimal value used in arithmetic.

### PL-CANON-005 — duplicate JSON keys

Any canonical JSON parsed from stored text MUST reject duplicate object keys before conversion to a dictionary.

A duplicate key is `LEDGER_CANONICAL_ENCODING_FAILURE`.

---

## 10. Event identity and hash chain

### PL-EVENT-001 — event envelope

Every authoritative event has this complete canonical identity model:

```text
ledger_instance_id
sequence
event_id
event_type
event_schema_revision
writer_session_id
incident_id
execution_attempt_id
recorded_at_utc
payload
payload_sha256
previous_event_hash
event_hash
```

### PL-EVENT-002 — event ID

Normal event IDs MUST be generated as:

```text
evt_<32 lowercase UUID4 hex characters>
```

The legacy import event ID is deterministic:

```text
legacy_<64 lowercase hex SHA-256 of canonical legacy import payload bytes>
```

`event_id` MUST be unique within the ledger.

An existing identical `event_id` may be recognized as an idempotent duplicate only when the complete canonical event identity/content, excluding no field, is byte-identical to the already stored event.

Same `event_id` with any different canonical content MUST halt `EVENT_ID_CONTENT_CONFLICT`.

### PL-EVENT-003 — timestamp

`recorded_at_utc` MUST be canonical UTC RFC3339 with exactly six fractional digits and `Z`:

```text
YYYY-MM-DDTHH:MM:SS.ffffffZ
```

It MUST parse as timezone-aware UTC and reserialize to the exact same text.

Wall-clock time is provenance only. It MUST NOT define event order, lock ownership, or stale-session safety. Sequence/hash chain define authoritative order.

### PL-EVENT-004 — payload hash

```text
payload_bytes =
    canonical_json(payload)

payload_sha256 =
    lowercase_hex(SHA256(payload_bytes))
```

### PL-EVENT-005 — previous hash

For sequence `1`:

```text
previous_event_hash =
0000000000000000000000000000000000000000000000000000000000000000
```

For sequence `n > 1`:

```text
previous_event_hash =
event_hash of sequence n - 1
```

### PL-EVENT-006 — event hash

Define the canonical event core:

```json
{
  "event_id": "...",
  "event_schema_revision": 1,
  "event_type": "...",
  "execution_attempt_id": null,
  "incident_id": null,
  "ledger_instance_id": "...",
  "payload": {},
  "payload_sha256": "...",
  "previous_event_hash": "...",
  "recorded_at_utc": "...",
  "sequence": 1,
  "writer_session_id": null
}
```

Then:

```text
event_hash =
lowercase_hex(
    SHA256(
        UTF8("ARB_LEDGER_EVENT_V1") +
        byte(0x00) +
        canonical_json(event_core)
    )
)
```

`event_hash` is not embedded inside `event_core` to avoid a circular hash.

### PL-EVENT-007 — replay validation

Before an event affects replay, the implementation MUST verify:

1. exact supported event type;
2. exact event schema revision `1`;
3. canonical timestamp;
4. canonical payload bytes;
5. payload hash;
6. previous-event hash;
7. recomputed event hash;
8. event-id uniqueness/content consistency;
9. required parent/session/incident references;
10. exact type constraints.

Any failure is an integrity failure; replay MUST NOT skip a bad event and continue.

---

## 11. Closed revision-3 event set

### PL-EVENT-010 — allowed types

Revision 3 event types are exactly:

```text
LEDGER_INITIALIZED
WRITER_SESSION_STARTED
WRITER_SESSION_ABANDONED
EXECUTION_INTENT_RECORDED
REQUEST_PREPARED
WRITE_SEND_BOUNDARY_ENTERED
READ_SEND_BOUNDARY_ENTERED
HTTP_RESPONSE_CLASSIFIED
TRANSPORT_UNKNOWN_AFTER_SEND
ORDER_IDENTITY_BOUND
ORDER_OBSERVED
FILL_OBSERVED
RECONCILIATION_RECORDED
EXECUTION_HALTED
EXECUTION_TERMINAL
WRITER_PROOF_HELD
WRITER_PROOF_RELEASED
WRITER_SESSION_ENDED
LEGACY_INCIDENT_IMPORTED
```

An unknown event type MUST classify `LEDGER_SCHEMA_UNSUPPORTED_EVENT_TYPE`; it MUST NOT be ignored.

### PL-EVENT-011 — initialization event

Sequence `1` MUST be `LEDGER_INITIALIZED` and MUST mirror immutable metadata:

```text
ledger_instance_id
ledger_schema_revision = 1
environment_classification
conflict_domain_ref
preledger_history_mode = LEGACY_IMPORT_REQUIRED
authority_instance_id
authority_namespace_id
authority_store_path_identity_sha256
ledger_path_identity_sha256
created_at_utc
```

A mismatch between the initialization event and `ledger_meta` is `LEDGER_META_EVENT_MISMATCH`.

### PL-EVENT-012 — writer session events

`WRITER_SESSION_STARTED` payload:

```text
writer_session_id
session_schema_revision = 1
lock_model = AUTHORITY_THEN_LEDGER_SQLITE_EXCLUSIVE_V1
prior_session_state = NONE | CLEAN | ABNORMAL
```

`WRITER_SESSION_ABANDONED` payload:

```text
abandoned_writer_session_id
reason = PREVIOUS_SESSION_NO_LONGER_HOLDS_REQUIRED_AUTHORITY_AND_LEDGER_LOCKS
```

Abandonment records process/session continuity only. It cannot close an unresolved write or release writer proof.

### PL-EVENT-013 — execution intent

`EXECUTION_INTENT_RECORDED` payload MUST include non-secret, exact safety identity only:

```text
execution_attempt_id
venue
environment
conflict_domain_ref
incident_id
operation_family
client_order_id if applicable
capability_reference_id if applicable, as non-secret metadata only
intent_payload_schema_id
intent_payload
```

The event does not grant the named capability.

### PL-EVENT-014 — request prepared

`REQUEST_PREPARED` payload MUST include:

```text
request_id
operation_class = READ | WRITE
venue
environment
operation_name
method
path_without_query
canonical_query
canonical_query_sha256
canonical_body | null
canonical_body_sha256 | null
prepared_request_sha256
client_order_id | null
venue_order_id | null
idempotency_key | null
adapter_payload_schema_id
```

`canonical_query` and `canonical_body` are the complete secret-free prepared request identity after venue-specific validation. They MUST use PL-CANON encoding and MUST exclude authentication/signing headers and values. Their hashes are recomputed from those canonical values on replay.

It MUST NOT contain:

```text
Authorization header
authentication headers
signature
signature hash/fingerprint
private key
API secret
session token
```

The adapter MUST compute `prepared_request_sha256` from a secret-free canonical request-identity object; auth material is explicitly excluded.

### PL-EVENT-015 — send boundaries

`WRITE_SEND_BOUNDARY_ENTERED` payload:

```text
request_id
operation_name
prepared_request_sha256
write_ambiguity_rule = WRITE_MAY_HAVE_BEEN_SENT_AFTER_THIS_COMMIT
```

`READ_SEND_BOUNDARY_ENTERED` has the same identity fields but no write-ambiguity rule.

There MUST be at most one send-boundary event for a request ID.

### PL-EVENT-016 — transport/result classification

`HTTP_RESPONSE_CLASSIFIED` payload MUST contain only validated, secret-safe summary fields:

```text
request_id
http_status
response_media_type
response_byte_length
response_sha256
adapter_result_class
write_closure_class
validated_identity_fields
```

Allowed `write_closure_class`:

```text
NOT_APPLICABLE
UNRESOLVED
NO_SEND_PROVEN
AUTHORITATIVE_RESULT_CLOSED
```

For a write request, the generic ledger MUST NOT infer closure from HTTP status alone. The Kalshi adapter supplies the closure class only under an accepted venue-specific contract.

`TRANSPORT_UNKNOWN_AFTER_SEND` payload:

```text
request_id
unknown_class =
TRANSPORT_RESULT_UNKNOWN_AFTER_SEND
write_closure_class =
UNRESOLVED
```

Raw exception strings MUST NOT be persisted because they may carry headers or secrets.

### PL-EVENT-017 — order identity binding

`ORDER_IDENTITY_BOUND` MUST contain:

```text
client_order_id
venue_order_id
venue
environment
incident_id
binding_basis_event_ids[]
```

Within an incident:

- exact replay of the same mapping is idempotent;
- one `client_order_id` mapping to a different `venue_order_id` is `ORDER_IDENTITY_BINDING_CONFLICT`;
- one accepted incident binding MUST NOT be silently overwritten.

### PL-EVENT-018 — order observations

`ORDER_OBSERVED` MUST contain:

```text
venue_order_id
client_order_id | null
source_request_id
source_operation
venue_payload_schema_id
canonical_venue_payload
canonical_venue_payload_sha256
observation_semantic_class
```

Changing valid order state is represented by a new observation event. Older observations remain immutable.

A later different observation for the same `venue_order_id` is not automatically a duplicate conflict; the Kalshi adapter MUST validate whether the state transition/observation is compatible with its accepted contract.

### PL-EVENT-019 — fill observations

`FILL_OBSERVED` MUST contain:

```text
venue_fill_id
venue_order_id
client_order_id | null
source_request_id
source_operation
venue_payload_schema_id
canonical_venue_payload
canonical_venue_payload_sha256
```

The accepted venue `fill_id` is the deduplication identity.

For a given `venue_fill_id`:

```text
same complete canonical venue payload
    -> idempotent duplicate observation; contributes once

different complete canonical venue payload
    -> DUPLICATE_FILL_CONFLICT; halt
```

Actual fill price MUST come from the validated venue fill payload. Submitted limit price MUST NOT be substituted for actual fill price.

Monetary and quantity values in the canonical payload use Decimal/fixed-point semantics from PL-CANON-004.

### PL-EVENT-020 — reconciliation

`RECONCILIATION_RECORDED` payload MUST contain:

```text
incident_id
disposition
write_closure_class
bound_order_id | null
created_order_upper_bound
active_order_upper_bound
unknown_result
writer_proof_release_eligible
basis_event_ids[]
adapter_reconciliation_schema_id
```

A generic ledger MUST NOT manufacture a venue reconciliation disposition. It stores a disposition only after the venue binding validates it.

### PL-EVENT-021 — halt and terminal

`EXECUTION_HALTED` records an exact fail-closed reason and non-secret state projection reference.

`EXECUTION_TERMINAL` records a venue-binding terminal result.

Neither event closes an unresolved write merely because its event name is "terminal".

### PL-EVENT-022 — writer proof events

`WRITER_PROOF_HELD` payload:

```text
writer_proof_id
conflict_domain_ref
held_reason
protected_unresolved_write_event_ids[]
```

`WRITER_PROOF_RELEASED` payload:

```text
writer_proof_id
conflict_domain_ref
release_basis_event_ids[]
release_contract_id
```

`WRITER_PROOF_RELEASED` is appendable only when PL-PROOF-004 is satisfied.

---

## 12. Authoritative append, anchor advancement, and idempotency

### PL-APPEND-001 — append precondition

Before every ledger append:

```text
trusted authority exclusive ownership is held
authoritative ledger exclusive ownership is held
authority row exactly binds conflict domain/environment/ledger instance/path
schema/integrity validation is current
current fully anchored sequence/hash match the in-memory validated projection
ledger tail equals that fully anchored pair before a new append starts
event schema is supported
payload is canonical and secret-safe
```

If a prior operation left the ledger ahead of authority, normal append is prohibited until a reopen has completed PL-AUTH-007 catch-up.

### PL-APPEND-002 — atomic ledger event batch

The ledger MUST preserve Revision-01 ordered batch semantics:

1. assign contiguous sequences;
2. compute each previous hash from the prior event, including the prior batch member;
3. validate all rows;
4. insert all rows;
5. ledger COMMIT once.

Any ledger transaction failure rolls back the complete ledger batch.

### PL-APPEND-003 — authority advancement after ledger batch

After the ledger batch COMMIT succeeds, the same high-level append operation MUST advance the trusted authority to the exact new ledger tail under PL-AUTH-006.

The high-level append returns success only when authority COMMIT and readback are positively verified.

This rule applies to:

```text
EXECUTION_INTENT_RECORDED
REQUEST_PREPARED
WRITE_SEND_BOUNDARY_ENTERED
result/identity/reconciliation batches
writer-proof events
writer-session events
legacy-import batch
all other authoritative events
```

### PL-APPEND-004 — duplicate API behavior

If an append request presents an `event_id` already present in a fully validated ledger:

```text
complete canonical event is identical
    -> IDEMPOTENT_DUPLICATE, no new row, no sequence consumed

any canonical field differs
    -> EVENT_ID_CONTENT_CONFLICT
```

If the identical event exists only in a validated ledger-ahead-of-authority suffix, the process MUST first complete PL-AUTH-007 reopen/catch-up. An active operation MUST NOT silently convert an authority-unknown append into a success without reopen.

The implementation MUST NOT upsert or replace old ledger events.

## 13. Critical write/send ordering

### PL-WRITE-001 — mandatory authority-anchored order

For every future separately authorized venue write, the integration MUST execute exactly:

```text
1. validate all non-ledger and ledger pre-send predicates;

2. ledger-COMMIT EXECUTION_INTENT_RECORDED if not already present;
3. durably advance + verify trusted authority to the exact intent tail;

4. ledger-COMMIT REQUEST_PREPARED with exact secret-free request identity;
5. durably advance + verify trusted authority to the exact prepared tail;

6. ledger-COMMIT WRITE_SEND_BOUNDARY_ENTERED;
7. durably advance + verify trusted authority so trusted_sequence/hash are
   exactly the committed boundary sequence/event_hash;
8. recheck ledger boundary sequence/hash equals the verified authority anchor;

9. ONLY AFTER step 8 succeeds may transport/network send begin;

10. classify transport/response using the venue-specific accepted contract;
11. ledger-COMMIT the complete result/identity/reconciliation event batch;
12. durably advance + verify trusted authority to that exact result tail;
13. only after step 12 succeeds may the caller treat that result as safely
    persisted terminal/recoverable state.
```

The authority-anchored send boundary is a permission gate, not asynchronous logging.

### PL-WRITE-002 — pre-send ledger or authority failure

If the ledger commit or authority advancement for intent, prepared request, or send boundary:

```text
fails definitively
returns unknown/indeterminate
cannot be read back
cannot be verified
uses wrong identity
encounters unavailable/corrupt authority state
```

then:

```text
NETWORK SEND MUST NOT BEGIN
transport invocation count = 0
local halt = true
automatic retry/resend = false
```

If the ledger boundary commit succeeded but authority advancement did not become definitely successful and verified, the immutable ledger boundary remains. After restart it is conservatively `WRITE_MAY_HAVE_BEEN_SENT` even if the prior process never reached transport.

### PL-WRITE-003 — deliberate over-approximation

Once `WRITE_SEND_BOUNDARY_ENTERED` is ledger-committed, replay MUST place that request in the unresolved set until a later valid durable closure exists.

Therefore both:

```text
crash after ledger boundary commit but before authority commit
crash after authority commit but before actual socket write
```

may replay as:

```text
WRITE_MAY_HAVE_BEEN_SENT
```

The false positive is permitted. A false `NOT_SENT` after a potentially sent write is prohibited.

### PL-WRITE-004 — no automatic resend

After any ledger-committed write-send boundary that is not authoritatively closed:

```text
automatic resend = PROHIBITED
same client request automatic replay = PROHIBITED
replacement write = PROHIBITED
new write inferred from restart = PROHIBITED
```

A restart may return a recovery plan as data only; it MUST NOT execute it.

### PL-WRITE-005 — closure

A protected write leaves the unresolved set only after a later fully authoritative append (ledger commit plus authority advancement) proves one of:

```text
NO_SEND_PROVEN
AUTHORITATIVE_RESULT_CLOSED
```

under the exact accepted venue/integration contract.

A generic HTTP code, process exit, clean session end, elapsed time, stale lock observation, or empty venue read is not closure.

## 14. Crash/fault matrix

### PL-CRASH-001 — required restart interpretation

`L` = ledger commit result. `A` = trusted authority/anchor commit result. `T` = transport invocation count for the affected write.

| Case | Fault point | L | A | T | Restart interpretation | `unknown_write` | Writer proof | Venue recovery required to close affected write? | Automatic resend |
|---|---|---|---|---:|---|---|---|---|---|
| **A** | before durable intent | none | unchanged | `0` | no new event; prior state controls | unchanged; `false` for this attempt | prior state | no for this attempt | **PROHIBITED automatically** |
| **B** | after fully authoritative intent/prepared state, before send-boundary ledger commit | success through latest pre-boundary event | success through same pre-boundary tail | `0` | prepared but no boundary; no write inferred from this attempt | `false` for this attempt | prior/`HELD` as applicable | no for this attempt | **PROHIBITED automatically** |
| **C** | after ledger boundary + authority anchor succeed, before transport | success | success through boundary | `0` | `WRITE_MAY_HAVE_BEEN_SENT` | `true` | `HELD` | yes unless later accepted evidence proves closure/no-send | **PROHIBITED** |
| **D** | during/after transport, before response | success through boundary | success through boundary | `1` | `WRITE_RESULT_UNKNOWN` | `true` | `HELD` | yes | **PROHIBITED** |
| **E** | response received, before fully authoritative result batch | boundary success; result absent or ledger-only | boundary trusted; result anchor absent/unknown | `1` | unresolved unless a validated ledger-ahead result suffix is caught up and authoritatively closes it | `true` until exact closure | `HELD` until closure | yes while unresolved | **PROHIBITED** |
| **F** | after fully authoritative result batch | success | success through result tail | `1` | exact committed closure class controls | `false` only for `NO_SEND_PROVEN` or `AUTHORITATIVE_RESULT_CLOSED`; otherwise `true` | per replay; clean exit alone never releases | only if committed result remains unresolved | **PROHIBITED automatically** |
| **G** | during order/fill/reconciliation ledger batch or authority advancement | SQLite yields full prior ledger tail or full new ledger batch; authority may lag | prior or new exact tail | prior send state | replay full ledger; handle two-store relation under PL-AUTH-007; never accept partial ledger batch | conservative; `true` when prior boundary unclosed | `HELD` while unresolved | yes when unresolved | **PROHIBITED** |
| **H** | during clean writer-session shutdown | end event absent, ledger-only, or fully anchored | prior or end tail | unchanged | clean/abnormal session does not change write truth | from replayed protected writes | from replay; clean end does not release | according to unresolved set | **PROHIBITED** |
| **I** | send-boundary ledger commit fails | failure | not advanced | `0` | no committed boundary from this attempt | `false` for this attempt | prior state | no for this attempt | **PROHIBITED automatically** |
| **J** | boundary ledger commits; crash/failure before authority commit | success | old trusted tail | `0` | ledger ahead; validate anchored prefix + complete suffix; catch authority forward only; boundary remains conservative | `true` | `HELD` | yes unless a separate accepted no-send/closure proof later exists | **PROHIBITED** |
| **K** | boundary ledger commits; authority commit returns definite failure | success | definite failure / old trusted tail | `0` | local halt; restart via PL-AUTH-007 ledger-ahead handling | `true` | `HELD` | yes unless later accepted closure/no-send evidence exists | **PROHIBITED** |
| **L** | boundary ledger commits; authority commit result unknown/indeterminate | success | unknown | `0` | close/reopen required; resolve equal vs ledger-ahead relation; no send occurred in failed gate process | `true` conservatively | `HELD` | yes unless later accepted closure/no-send evidence exists | **PROHIBITED** |
| **M** | boundary + authority succeed; crash before transport | success | success | `0` | `WRITE_MAY_HAVE_BEEN_SENT` | `true` | `HELD` | yes unless later accepted closure/no-send evidence exists | **PROHIBITED** |
| **N** | boundary + authority succeed; transport begins; crash before fully authoritative result | success | success through boundary | `1` | `WRITE_MAY_HAVE_BEEN_SENT` / `WRITE_RESULT_UNKNOWN` | `true` | `HELD` | yes | **PROHIBITED** |
| **O** | trusted authority sequence newer than observed ledger | ledger behind | authority ahead | `0` on restart | `RESTART_AUTHORITY_LEDGER_ROLLBACK_FAILURE` | unavailable / cannot safely classify from damaged relation | unavailable / `HELD` | no venue recovery may run until local identity/integrity issue is resolved under a separate task | **PROHIBITED** |
| **P** | ledger hash at trusted sequence differs | n/a | trusted pair present | `0` on restart | `RESTART_LEDGER_INTEGRITY_FAILURE` | unavailable | unavailable / `HELD` | no venue recovery may run from untrusted local history | **PROHIBITED** |
| **Q** | established authority store missing/corrupt | n/a | unavailable | `0` on restart | `RESTART_AUTHORITY_INTEGRITY_FAILURE`; no recreation | unavailable | unavailable / `HELD` | no venue recovery may run from missing/corrupt authority state | **PROHIBITED** |
| **R** | second distinct ledger file claims same conflict domain | ledger B may be internally valid | authority row already binds ledger A | `0` for ledger B | ledger B logical writer authority rejected | `false` for B; authoritative ledger A state separately controls | no proof for B | no for B; B is not authoritative | **PROHIBITED** |

A future fault-injection battery MUST cover every row A-R.

For J/K/L, transport invocation is exactly zero because transport is structurally after verified authority advancement. Nevertheless, once the boundary row exists in the immutable ledger, restart remains conservative and never classifies that request as automatically resendable.

## 15. Logical conflict-domain writer exclusivity and restart takeover

### PL-LOCK-001 — authority store is the logical writer mutex

SQLite exclusivity on one execution-ledger file is insufficient because two distinct ledger files could otherwise claim the same conflict domain.

Revision 03 therefore requires both:

```text
trusted authority store exclusive ownership
AND
authoritative execution-ledger exclusive ownership
```

for an active writer session.

The trusted authority row determines which ledger instance/path is authoritative. A locally valid SQLite ledger that is not the authority-bound ledger has no writer authority and cannot construct writer proof.

### PL-LOCK-002 — exact lock acquisition order

The following is the `NORMAL_WRITER` acquisition path. It remains blocked when legacy/pre-ledger history is incomplete. The restricted `LEGACY_IMPORT_ONLY` acquisition path in PL-LEGACY-015 uses the same authority-first/ledger-second locks and every identity/integrity predicate, but stops before ordinary writer-session/send capability is exposed.

Writer acquisition order is frozen:

```text
1. resolve and validate the accepted AuthorityNamespaceBinding;
2. open existing authority store with no-create semantics;
3. apply/read back DELETE + EXTRA / FK / busy_timeout / EXCLUSIVE settings;
4. acquire authority ownership with BEGIN EXCLUSIVE, timeout=0, no retry;
5. validate authority meta, schema, integrity, and exact conflict-domain row;
6. obtain authoritative ledger path/instance only from that row;
7. open that existing ledger with no-create semantics;
8. apply/read back ledger DELETE + EXTRA / FK / busy_timeout / EXCLUSIVE settings;
9. acquire ledger ownership with BEGIN EXCLUSIVE, timeout=0, no retry;
10. validate ledger meta cross-binding, integrity, hash chain, anchor relation,
    complete suffix, replay, legacy completeness, duplicate identities,
    unresolved-write state, and writer-proof predicates;
11. complete authority catch-up if and only if PL-AUTH-007 allows it;
12. append + authority-anchor WRITER_SESSION_ABANDONED if required;
13. append + authority-anchor WRITER_SESSION_STARTED;
14. only then expose a local writer handle.
```

Implementations MUST NOT acquire these two database locks in the opposite order.

The authority connection remains open in exclusive locking mode for the entire active writer session; the ledger connection also remains open in exclusive locking mode.

A lock acquisition failure (`SQLITE_BUSY`, `SQLITE_LOCKED`, or equivalent) has no retry loop and classifies `RESTART_CONCURRENT_WRITER_BLOCKED`.

Revision 03 conservatively serializes active writers within one authority namespace because the authority SQLite store is held exclusively. Finer-grained multi-domain concurrency is out of scope.

### PL-LOCK-003 — two-ledger split-brain rejection

Given:

```text
same accepted authority namespace
same conflict_domain_ref
ledger_A.sqlite
ledger_B.sqlite
```

if the authority row binds ledger A, ledger B MUST fail before any writer session can start. Acquiring an independent SQLite lock on ledger B is irrelevant.

Required result:

```text
ledger_B logical writer authority = false
ledger_B writer proof = unavailable
ledger_B send capability = false
```

No automatic rebinding from A to B is permitted.

### PL-LOCK-004 — writer session identity

A writer session ID remains:

```text
ws_<32 lowercase UUID4 hex characters>
```

It is unrelated to PID, host clock, thread ID, or credential identity. The fully authority-anchored `WRITER_SESSION_STARTED` event must exist before any execution event from that session.

### PL-LOCK-005 — abnormal predecessor

If replay finds a most-recent `WRITER_SESSION_STARTED` without a matching `WRITER_SESSION_ENDED`, successful acquisition of both required locks permits the new writer to append and authority-anchor `WRITER_SESSION_ABANDONED`, followed by its own session start.

This proves only that the previous process no longer owns the required live locks. It does not prove prior writes resolved, transport did not occur, or writer proof released.

### PL-LOCK-006 — prohibited stale-lock heuristics

None of the following alone may establish ownership, prior-write closure, or safe takeover:

```text
PID missing or reused
process start time
wall-clock age
heartbeat timeout
deleted lock file
missing sidecar lock
host reboot
session end timestamp
clean process exit
```

The authority binding, both live SQLite locks, fully validated two-store restart relation, and deterministic replay control writer safety.

## 16. Replay projection

### PL-REPLAY-001 — replay is from durable authoritative events only

Replay MUST start from ledger sequence `1`, validate every event, and derive state only from authoritative ledger events after the authority/ledger relation has passed PL-AUTH-007.

The trusted authority store does not replace event history; it binds which ledger is authoritative and the minimum trusted terminal prefix/tail. A cached projection is never authoritative.

### PL-REPLAY-002 — minimum projection

The deterministic in-memory `SafetyProjection` MUST include at least:

```text
authority_schema_revision
authority_instance_id
authority_namespace_id
authority_store_path_identity_sha256
trusted_sequence
trusted_event_hash

ledger_instance_id
ledger_schema_revision
ledger_path_identity_sha256
environment_classification
conflict_domain_ref
history_completeness
last_sequence
terminal_event_hash

writer_sessions
active_writer_session_id | null
abnormal_prior_session_ids[]

incident_ids[]
execution_attempt_ids[]

prepared_requests by request_id
write_send_boundaries by request_id
write_closure_by_request_id
unresolved_write_request_ids[]

client_order_to_venue_order map
order_observation_history by venue_order_id
canonical_fills_by_fill_id
fill_conflicts

reconciliation_disposition_by_incident
writer_proof_state_by_proof_id
writer_proof_release_eligible_by_proof_id

restart_classification
```

### PL-REPLAY-003 — pre-ledger history states

Revision 03 supports no caller-asserted empty-history state.

For the current contract the replayed history state is:

```text
LEGACY_IMPORT_REQUIRED with no exact completed import
    -> INCOMPLETE

exact accepted legacy import present
    -> COMPLETE_WITH_PROTECTED_UNRESOLVED_LEGACY_WRITE
```

If a future accepted closure later resolves the protected legacy write while preserving complete imported history, the projection may classify history coverage `COMPLETE`; this specification does not create that closure.

### PL-REPLAY-004 — generic unresolved write rule

On replay of `WRITE_SEND_BOUNDARY_ENTERED`:

```text
add request_id to unresolved_write_request_ids
```

It remains there until a later valid fully authoritative classification closes it under PL-WRITE-005. `EXECUTION_HALTED`, `EXECUTION_TERMINAL`, `WRITER_SESSION_ENDED`, authority catch-up, process exit, or lock release MUST NOT remove it.

### PL-REPLAY-005 — order/fill persistence

Order observations remain append-only history.

Fills are deduplicated by accepted venue `fill_id` exactly as Revision 01 required. Conflicting canonical content for one `fill_id` prevents a safe projection. Actual fill price is never inferred from submitted limit price.

### PL-REPLAY-006 — deterministic equality

Replaying the same validated authoritative event history with the same trusted authority binding MUST produce byte-identical canonical review export bytes.

System clock, PID, dictionary insertion order, thread scheduling, filesystem enumeration order, and caller-selected alternate paths MUST NOT change replay output.

## 17. Closed restart classification

### PL-RESTART-001 — enum

Revision 03 restart classification is exactly one of:

```text
RESTART_SAFE_NO_WRITE_CAPABILITY
RESTART_UNRESOLVED_WRITE_HELD
RESTART_AUTHORITY_INTEGRITY_FAILURE
RESTART_AUTHORITY_LEDGER_ROLLBACK_FAILURE
RESTART_LEDGER_INTEGRITY_FAILURE
RESTART_SCHEMA_UNSUPPORTED
RESTART_CONCURRENT_WRITER_BLOCKED
RESTART_LEGACY_HISTORY_INCOMPLETE
RESTART_LEDGER_IDENTITY_FAILURE
RESTART_STORAGE_UNAVAILABLE
```

### PL-RESTART-002 — required verification theorem and precedence

Ledger-based writer eligibility may be considered only after all of these pass:

```text
trusted authority namespace identity
trusted authority store identity
logical conflict-domain binding
authoritative ledger path/instance binding
both SQLite configuration readbacks
both schema versions/support
both integrity_check results
both foreign_key_check results
sequence continuity
canonical encoding validation
payload hashes
previous-event hash chain
event hashes
trusted anchored sequence/hash match
complete validated ledger suffix after trusted anchor
successful authority catch-up when ledger was ahead
legacy/preledger history completeness
duplicate-identity checks
unresolved-write checks
writer-proof rules
```

Any uncertainty in authority store, authority binding, ledger identity/path, anchor, history completeness, hash chain, schema, duplicate identity, or protected unresolved write keeps writer capability unavailable.

Classification precedence:

```text
1. authority store missing/unopenable/corrupt, authority namespace/instance/path
   identity mismatch, missing established conflict-domain binding, or authority
   anchor catch-up not definitely committed+verified
    -> RESTART_AUTHORITY_INTEGRITY_FAILURE

2. authority logical lock unavailable or authoritative ledger logical lock unavailable
    -> RESTART_CONCURRENT_WRITER_BLOCKED

3. authority row expects a trusted sequence newer than the observed ledger
    -> RESTART_AUTHORITY_LEDGER_ROLLBACK_FAILURE

4. authoritative ledger missing, wrong instance/environment/conflict-domain/path,
   wrong authority cross-binding, or wrong path identity
    -> RESTART_LEDGER_IDENTITY_FAILURE

5. unsupported authority/ledger/event schema revision or event type
    -> RESTART_SCHEMA_UNSUPPORTED

6. authority anchored hash mismatch at the trusted sequence; ledger SQLite/FK,
   canonical encoding, sequence, payload hash, previous-event hash, event hash,
   duplicate-content, required-parent, or semantic replay integrity failure
    -> RESTART_LEDGER_INTEGRITY_FAILURE

7. exact legacy import required and incomplete
    -> RESTART_LEGACY_HISTORY_INCOMPLETE
    -> NORMAL_WRITER remains unavailable
    -> only the separately requested restricted LEGACY_IMPORT_ONLY acquisition
       may be considered, and only under PL-LEGACY-015/016

8. any protected unresolved write, including the current imported legacy write,
   or proof held because of unresolved history
    -> RESTART_UNRESOLVED_WRITE_HELD

9. fully validated, fully authority-anchored replay with complete history and no
   protected unresolved write
    -> RESTART_SAFE_NO_WRITE_CAPABILITY
```

When the ledger is ahead of the trusted authority but the anchored prefix and complete suffix validate, PL-AUTH-007 requires monotonic authority catch-up before the final classification above can be returned for writer consideration. Catch-up never removes an unresolved boundary.

### PL-RESTART-003 — restart is local only

Restart/open/replay/authority catch-up MUST perform:

```text
Kalshi requests = 0
credential reads = 0
private-key reads = 0
signing operations = 0
CREATE = 0
CANCEL = 0
amend/decrease/replace = 0
WebSocket = 0
funding/trading = 0
```

A restart classification MAY return a secret-free `RecoveryPlan` as data only. It MUST NOT execute a transport, read credentials, sign, or send a request.

### PL-RESTART-004 — safe remains non-authorizing

`RESTART_SAFE_NO_WRITE_CAPABILITY` means only that local authority/ledger/history predicates do not themselves identify a blocking unresolved protected prior write.

It grants no:

```text
network
credential use
signing
CREATE
CANCEL
production
venue request
execution task
```

## 18. Ledger-backed writer-proof continuity

### PL-PROOF-001 — accepted predecessor semantics remain controlling history

The accepted `WriterExclusivityPriorWriteProof` contract from the one-order lifecycle remains the historical controlling proof semantics for that lifecycle.

Revision 03 does not modify the accepted lifecycle implementation and does not retroactively replace its proof.

### PL-PROOF-002 — ledger safety state versus external capability

The ledger/authority subsystem maintains local safety state only. No ledger event, authority row, restart classification, lock acquisition, or proof object grants venue, credential, account, write, cancellation, funding, or production capability.

### PL-PROOF-003 — exact future ledger-backed proof binding

A future separately accepted integration MAY construct a ledger-backed prior-write proof only after the complete PL-RESTART-002 theorem passes and every protected prior write is authoritatively closed.

The proof MUST bind exactly:

```text
authority_schema_revision
authority_instance_id
authority_namespace_id
authority_store_resolved_path
authority_store_path_identity_sha256
conflict_domain_ref
environment_classification

authoritative_ledger_instance_id
authoritative_ledger_resolved_path
authoritative_ledger_path_identity_sha256

trusted_terminal_sequence
trusted_terminal_event_hash
fully_replayed_ledger_terminal_sequence
fully_replayed_ledger_terminal_event_hash
```

For a proof-eligible history, trusted and fully replayed terminal sequence/hash MUST be exact equals before proof construction.

A proof MUST NOT be constructed from:

```text
an arbitrary valid SQLite file
an arbitrary caller-supplied ledger path
an arbitrary alternate authority namespace
PID
heartbeat
wall-clock age
file existence alone
clean process exit alone
```

### PL-PROOF-004 — release

A `WRITER_PROOF_RELEASED` event may be appended only when:

```text
unresolved protected write count == 0
history completeness is complete under an accepted history contract
both-store integrity == PASS
schema support == PASS
authority/ledger identity + path binding == PASS
trusted terminal == fully replayed terminal
venue-specific accepted closure rules == PASS
the separately accepted integration contract declares release eligible
```

The release event itself must then be ledger-committed and authority-anchored before it can be relied upon.

Any unresolved send boundary, unresolved legacy write, integrity failure, missing history, unsupported schema, ambiguous import, authority uncertainty, ledger/authority mismatch, or unverified suffix keeps proof `HELD`.

### PL-PROOF-005 — current incident remains held

For the current Kalshi Demo conflict domain:

```text
before exact legacy import:
    restart = RESTART_LEGACY_HISTORY_INCOMPLETE
    writer proof = HELD / unavailable

after exact legacy import:
    restart = RESTART_UNRESOLVED_WRITE_HELD
    writer proof = HELD
    release eligible = false
```

Initialization or authority binding alone can never prove that pre-ledger history was empty.

## 19. Legacy incident import and bootstrap acquisition

### PL-LEGACY-010 — one exact two-event ledger import batch

The current unresolved incident MUST be represented by one exact ledger transaction containing exactly these two authoritative history events in this order:

```text
1. LEGACY_INCIDENT_IMPORTED
2. WRITER_PROOF_HELD
```

The transaction MUST be all-or-nothing **within the execution-ledger SQLite durability domain**. A committed import representation therefore contains both events; it MUST never contain exactly one.

The import MUST NOT fabricate retroactive normal events such as:

```text
EXECUTION_INTENT_RECORDED
REQUEST_PREPARED
WRITE_SEND_BOUNDARY_ENTERED
HTTP_RESPONSE_CLASSIFIED
TRANSPORT_UNKNOWN_AFTER_SEND
```

The `LEGACY_INCIDENT_IMPORTED` event is the authoritative representation of the pre-ledger history. Replay of the exact two-event batch MUST seed exactly one protected unresolved legacy write.

The two-store high-level import is complete only after the committed ledger batch is authority-anchored under PL-LEGACY-019. Ledger COMMIT and authority advancement remain distinct durability domains.

### PL-LEGACY-011 — evidence identity binding

Before constructing the import batch, the Kalshi binding MUST independently compute raw byte length and SHA-256 of all three execution-evidence inputs:

```text
execution_evidence.json
bytes = 10746
sha256 = 2cb1677d06d3c88a3dd6f5b41190fa6de237bae24f02457fee37b2e0d04eefac

KALSHI_DEMO_POST_HALT_EXACT_WRITE_RESULT_RECONCILIATION_EVIDENCE_01.json
bytes = 10541
sha256 = a10eb4a6d7490755bbe055056cbe4960d075fd73048967d7e3d1c846c7be34fe

KALSHI_DEMO_POST_HALT_FILL_DISCOVERY_BINDING_FALLBACK_EXECUTION_EVIDENCE_01.json
bytes = 10882
sha256 = 5e9cb2690854309f5684fa1b31cc4d837e301152a8466732382acb913dd73aa2
```

Any wrong byte length or SHA-256 MUST reject the complete import before a ledger transaction begins.

The production identities above are static contract data. Future tests MUST use synthetic evidence bytes for import mechanics and MUST NOT perform the real accepted import.

### PL-LEGACY-012 — evidence content cross-check

Identity match alone is insufficient. The importer MUST parse all three JSON artifacts using duplicate-key rejection and cross-check all material incident fields against PL-LEGACY-001.

At minimum it MUST prove consistent:

```text
incident/task identity
environment
account_scope_ref
subaccount
ticker
client_order_id
writer_proof_id
authorization-consumed facts
final disposition
bound_order_id
created_order_upper_bound
active_order_upper_bound
unknown_result
writer-proof continuity state
writer-proof release eligibility
```

It MUST also prove the evidence chain does not claim a later positive order/fill binding inconsistent with `WRITE_UNRESOLVED_ZERO_MATCH`.

Any mismatch is `LEGACY_INCIDENT_CONTENT_MISMATCH` and occurs before a ledger import transaction begins.

### PL-LEGACY-013 — exact import payload

The canonical `LEGACY_INCIDENT_IMPORTED` payload MUST include:

```text
legacy_import_schema_revision = 1
provenance_status = PROJECT_EVIDENCE_RECORDED

incident_id
environment
account_scope_ref
subaccount
ticker
client_order_id
legacy_writer_session_id
writer_proof_id

authorization_states = {
  one_order_lifecycle: CONSUMED,
  exact_reconciliation: CONSUMED,
  fill_discovery_fallback: CONSUMED
}

final_disposition = WRITE_UNRESOLVED_ZERO_MATCH
bound_order_id = null
created_order_upper_bound = 1
active_order_upper_bound = 1
unknown_result = true
writer_proof_state = HELD
writer_proof_release_eligible = false
legacy_write_may_have_been_sent = true

evidence_artifacts = [
  {name, bytes, sha256},
  {name, bytes, sha256},
  {name, bytes, sha256}
]
```

The corresponding `WRITER_PROOF_HELD` event MUST bind the same `writer_proof_id` and `conflict_domain_ref`, with:

```text
held_reason = PROTECTED_UNRESOLVED_LEGACY_WRITE
protected_unresolved_write_event_ids = [
  <LEGACY_INCIDENT_IMPORTED.event_id>
]
```

For both import events, the event envelope MUST use:

```text
writer_session_id = null
incident_id = KALSHI_DEMO_ONE_ORDER_LIFECYCLE_EXECUTION_01
execution_attempt_id = null
```

The immutable historical `legacy_writer_session_id` remains inside the `LEGACY_INCIDENT_IMPORTED` payload as evidence provenance. No current `WRITER_SESSION_STARTED` reference is fabricated. The paired `WRITER_PROOF_HELD.event_id` remains a normal `evt_<UUID4>` under PL-EVENT-002; Revision 03 does not redesign event-ID rules.

### PL-LEGACY-014 — deterministic import identity and duplicate conflict

`LEGACY_INCIDENT_IMPORTED.event_id` MUST remain:

```text
legacy_<sha256(canonical legacy import payload bytes)>
```

That deterministic legacy event ID, the exact incident ID, and the required immediately paired `WRITER_PROOF_HELD` semantic content define the one-time import representation. The hold event's normal UUID event ID is not used to decide whether the incident was already imported.

Duplicate rules:

```text
same complete two-event batch already fully authority-anchored
    -> ALREADY_IMPORTED
    -> append zero events

same complete two-event batch present in a validated ledger-ahead suffix
    -> append zero events
    -> catch authority forward under PL-LEGACY-022 Case B

same deterministic import event_id with any different canonical event content
    -> LEGACY_INCIDENT_IMPORT_CONFLICT

same incident represented by a second non-identical legacy import
    -> LEGACY_INCIDENT_IMPORT_CONFLICT
```

No retry/idempotency path may create a second protected unresolved legacy-write representation.

### PL-LEGACY-015 — closed acquisition mode enum

Local acquisition mode for this first persistence contract is exactly:

```text
NORMAL_WRITER
LEGACY_IMPORT_ONLY
```

`LEGACY_IMPORT_ONLY` is a restricted local bootstrap capability. It is not:

```text
NORMAL_WRITER
NORMAL_EXECUTION
SEND_CAPABLE
VENUE_CAPABLE
```

It exists only when the otherwise fully valid authority-bound ledger is blocked from normal writer eligibility solely by:

```text
preledger_history_mode = LEGACY_IMPORT_REQUIRED
AND
no completed valid legacy import is present
```

The acquisition mode is selected by the calling API as a closed enum value, but the requested mode cannot override predicates. Asking for `LEGACY_IMPORT_ONLY` when its exact bootstrap predicates do not hold MUST fail closed.

A Boolean flag on an ordinary writer object is prohibited. The implementation surface MUST return a distinct restricted handle/type whose public methods cannot invoke ordinary append/send/credential/venue paths.

### PL-LEGACY-016 — exact `LEGACY_IMPORT_ONLY` acquisition sequence

`LEGACY_IMPORT_ONLY` MUST execute exactly this authority-first lock/validation sequence:

```text
1. resolve and validate the accepted AuthorityNamespaceBinding;
2. open the existing authority store with no-create semantics;
3. verify authority DELETE + EXTRA and every PL-SQL-003 readback;
4. acquire authority exclusive ownership with BEGIN EXCLUSIVE, timeout=0,
   no retry;
5. validate authority meta/schema/integrity/identity and the exact
   conflict-domain binding;
6. obtain authoritative ledger path/instance only from the authority row;
7. open that existing ledger with no-create semantics;
8. verify ledger DELETE + EXTRA and every PL-SQL-003 readback;
9. acquire ledger exclusive ownership with BEGIN EXCLUSIVE, timeout=0,
   no retry;
10. validate ledger meta/schema/integrity/hash chain/path/authority
    cross-binding;
11. resolve the exact authority/ledger tail relation under PL-AUTH-007;
12. when and only when PL-AUTH-007 permits a completely validated
    ledger-ahead suffix, and any legacy-import material in that suffix also
    satisfies PL-LEGACY-022 Case B, perform the required monotonic authority
    catch-up;
13. replay the complete authoritative history;
14. if replay now proves an exact completed legacy import, return the
    idempotent PL-LEGACY-022 completed/caught-up result and expose no import
    mutation handle; otherwise prove that the only history-completeness
    condition preventing normal writer eligibility is the expected,
    not-yet-completed LEGACY_IMPORT_REQUIRED bootstrap state;
15. only in that not-yet-completed case expose the restricted
    LEGACY_IMPORT_ONLY handle.
```

Steps 1-14 MUST NOT be weakened, bypassed, reordered, or replaced with caller assertions.

`LEGACY_IMPORT_ONLY` acquisition MUST reject at minimum:

```text
authority store missing/unopenable/corrupt
authority schema/identity/namespace mismatch
authoritative ledger missing/unopenable/corrupt
authority/ledger identity mismatch
authority ahead of ledger
trusted anchor hash mismatch
invalid ledger-ahead suffix
unsupported authority/ledger/event schema or event type
wrong environment
wrong conflict domain
wrong authority namespace
second/non-authoritative ledger path
event-chain/canonical/hash/sequence/parent integrity failure
duplicate event/fill/order identity conflict
conflicting legacy import
a partial/malformed legacy import suffix
any unsafe condition other than the expected incomplete legacy-history bootstrap
```

Lock acquisition failures keep classification `RESTART_CONCURRENT_WRITER_BLOCKED`. No automatic retry loop is permitted.

The authority and ledger locks remain held until the import-only operation reaches one of its specified completion/halt close points.

### PL-LEGACY-017 — structurally restricted import-only handle

The `LEGACY_IMPORT_ONLY` handle MUST expose exactly these conceptual operations:

```text
inspect_validated_projection()
validate_legacy_evidence(...)
commit_exact_legacy_import(...)
close()
```

Names may follow repository naming conventions, but the type surface MUST be equally closed.

It MUST NOT expose or internally delegate to public methods that can perform:

```text
ordinary arbitrary event append
EXECUTION_INTENT_RECORDED for future execution
REQUEST_PREPARED for a future venue request
WRITE_SEND_BOUNDARY_ENTERED
READ_SEND_BOUNDARY_ENTERED
transport
network
credential/private-key access
signing
CREATE
CANCEL
amend
decrease
replace
venue reconciliation requests
fill-discovery requests
normal ledger-backed writer proof construction
WRITER_PROOF_RELEASED
normal writer-session acquisition
```

Its only permitted economic/history mutation is the exact two-event ledger batch in PL-LEGACY-010 followed by trusted authority advancement.

No `WRITER_SESSION_STARTED`, `WRITER_SESSION_ABANDONED`, or `WRITER_SESSION_ENDED` event is appended merely to acquire or close `LEGACY_IMPORT_ONLY`. The two import event envelopes use `writer_session_id = null`; the payload's `legacy_writer_session_id` is the immutable historical execution-session provenance from PL-LEGACY-001. This avoids creating a normal current writer session or extra authoritative history outside the exact import batch.

### PL-LEGACY-018 — exact pre-ledger-COMMIT failure semantics

Before the ledger COMMIT returns success, all import preparation and both event rows belong to one explicit SQLite ledger transaction.

If any of the following occurs:

```text
evidence identity validation fails
evidence content cross-check fails
duplicate-key parsing fails
current incident facts mismatch
import precondition fails
canonicalization fails
event construction/hash calculation fails
ledger transaction fails before COMMIT
ledger COMMIT returns a definite failure
```

then the required result is exactly:

```text
ledger_import_events_committed = 0
authority_tail = unchanged
import_status = NOT_COMMITTED
transport_invocation_count = 0
normal_writer_handle = unavailable
automatic_import_retry = false
```

The transaction MUST be rolled back when SQLite reports a definite pre-COMMIT failure. No authority advancement is attempted when the ledger batch did not commit.

If the **ledger COMMIT result itself is unknown/indeterminate rather than definitely failed**, the operation MUST NOT blindly retry the import transaction. It MUST close/reopen and determine whether the exact complete batch exists using PL-LEGACY-022. An unknown ledger COMMIT result is therefore not equivalent to `NOT_COMMITTED`.

### PL-LEGACY-019 — successful ledger COMMIT and authority-anchored completion

A successful ledger transaction commits exactly the two PL-LEGACY-010 events. After successful ledger COMMIT, the ledger is allowed to be ahead of the trusted authority until the authority mutation completes.

The high-level import becomes `FULLY_AUTHORITY_ANCHORED` only when all are true:

```text
1. complete two-event ledger batch COMMIT succeeded;
2. authority transaction verified the prior trusted pair;
3. authority advancement COMMIT succeeded;
4. authority readback equals the exact new ledger terminal sequence/event_hash;
5. ledger readback at that sequence equals the same event_hash;
6. replay validates exactly one completed legacy import representation.
```

Then and only then:

```text
legacy_import_status =
FULLY_AUTHORITY_ANCHORED

history_completeness =
COMPLETE_WITH_PROTECTED_UNRESOLVED_LEGACY_WRITE

restart_classification =
RESTART_UNRESOLVED_WRITE_HELD

writer_proof_state =
HELD

writer_proof_release_eligible =
false
```

No normal write/send capability follows because the protected unresolved legacy write remains.

### PL-LEGACY-020 — authority definite failure after committed import batch

If the complete two-event ledger import batch COMMIT succeeds and authority advancement then returns a **definite failure**:

```text
preserve committed ledger batch = true
delete committed import events = PROHIBITED
rewrite committed import events = PROHIBITED
retry ledger import batch in same operation = PROHIBITED
move ledger backward = PROHIBITED
authority remains at prior trusted tail
transport_invocation_count = 0
normal_writer_handle = unavailable
writer_proof construction/release = unavailable
```

The operation MUST halt locally, close both stores, and require reopen.

The persisted two-store relation is:

```text
ledger_state =
AHEAD_OF_AUTHORITY_WITH_COMPLETE_IMPORT_BATCH

authority_state =
OLD_TRUSTED_TAIL

normal_writer_reliance =
PROHIBITED
```

This state is not corruption merely because the ledger is ahead. On reopen it is interpreted only through PL-AUTH-007 plus the import-specific Case B rules in PL-LEGACY-022.

### PL-LEGACY-021 — authority unknown/indeterminate after committed import batch

If the complete ledger import batch committed but authority advancement returns unknown, indeterminate, or unverifiable:

```text
retry import = PROHIBITED
append another import batch = PROHIBITED
blind retry of authority mutation in same operation = PROHIBITED
transport_invocation_count = 0
close/reopen = REQUIRED
```

The committed ledger batch MUST be preserved.

Reopen determines whether:

```text
authority == imported ledger tail
OR
ledger ahead of authority with exact complete import batch suffix
OR
a fail-closed contradiction exists
```

using PL-AUTH-007 and PL-LEGACY-022. No success is inferred from an unknown commit result before reopen/readback.

### PL-LEGACY-022 — exact reopen/idempotent catch-up after interrupted import

After lock/identity/integrity validation under PL-LEGACY-016, reopen MUST classify the import relation by these cases in order.

**Case A — authority already equals the complete imported ledger tail**

Required predicates:

```text
authority trusted pair == ledger terminal pair
exact canonical two-event import batch validates
exact incident/evidence identities validate
replay proves exactly one completed legacy import
no conflicting import representation exists
```

Result:

```text
append_new_import_events = 0
authority_mutation = 0
import_status = ALREADY_COMPLETED_AND_ANCHORED
history = COMPLETE_WITH_PROTECTED_UNRESOLVED_LEGACY_WRITE
restart = RESTART_UNRESOLVED_WRITE_HELD
writer_proof_state = HELD
writer_proof_release_eligible = false
```

**Case B — ledger ahead and the complete exact import batch is in the validated suffix**

Required predicates:

```text
anchored prefix matches authority exactly
complete suffix validates under PL-AUTH-007
suffix contains the exact complete two-event import batch whose LEGACY_INCIDENT_IMPORTED event has the deterministic PL-LEGACY-014 identity
no conflicting import exists
replay yields exactly one protected unresolved legacy write
```

Required action/result:

```text
append_new_import_events = 0
advance authority monotonically to exact ledger tail
verify authority and ledger readback equality
on success:
    import_status = ALREADY_COMMITTED_CATCHUP_COMPLETED
    history = COMPLETE_WITH_PROTECTED_UNRESOLVED_LEGACY_WRITE
    restart = RESTART_UNRESOLVED_WRITE_HELD
    writer_proof_state = HELD
    writer_proof_release_eligible = false
```

If the catch-up commit is not definitely successful and verified, halt `AUTHORITY_ANCHOR_CATCHUP_FAILURE`; do not append another import batch.

**Case C — malformed, partial, or conflicting import suffix**

If replay finds any of:

```text
only one member of the required two-event batch
conflicting LEGACY_INCIDENT_IMPORTED content
conflicting WRITER_PROOF_HELD content
invalid event ordering/parent/batch semantics
duplicate non-identical import
invalid evidence identity/content
more than one protected unresolved legacy-write representation for this incident
```

then:

```text
classification = LEGACY_INCIDENT_IMPORT_CONFLICT
authority_catchup = PROHIBITED
normal_writer_capability = PROHIBITED
legacy_import_retry = PROHIBITED
automatic_repair = PROHIBITED
```

The ledger is not mutated to remove or complete the malformed representation.

### PL-LEGACY-023 — normal writer acquisition remains blocked before and after current import

Before an exact completed, authority-anchored import:

```text
history_completeness = INCOMPLETE
normal_writer_acquisition = BLOCKED
restart_classification = RESTART_LEGACY_HISTORY_INCOMPLETE
LEGACY_IMPORT_ONLY = potentially eligible only under PL-LEGACY-015/016
```

This special acquisition mode does not change the normal restart classification; it is a restricted bootstrap operation available only after the full local safety validation in PL-LEGACY-016.

After exact completion or successful Case-B catch-up:

```text
history_completeness =
COMPLETE_WITH_PROTECTED_UNRESOLVED_LEGACY_WRITE

restart_classification =
RESTART_UNRESOLVED_WRITE_HELD

normal_write_send_capability =
UNAVAILABLE
```

The current imported unresolved write itself blocks ordinary writer proof/write-send eligibility. Import completion never means the historical CREATE is safe to repeat.

### PL-LEGACY-024 — current imported state remains exactly unresolved

After successful import completion or idempotent reopen/catch-up, replay MUST yield exactly:

```text
incident_id =
KALSHI_DEMO_ONE_ORDER_LIFECYCLE_EXECUTION_01

disposition =
WRITE_UNRESOLVED_ZERO_MATCH

bound_order_id =
null

created_order_upper_bound =
1

active_order_upper_bound =
1

unknown_result =
true

writer_proof_state =
HELD

writer_proof_release_eligible =
false

protected_unresolved_legacy_write_count =
1

restart_classification =
RESTART_UNRESOLVED_WRITE_HELD
```

No import path may infer:

```text
CREATE_NEVER_EXISTED
CREATE_DEFINITELY_FAILED
SAFE_TO_RETRY_CREATE
SAFE_TO_CANCEL
WRITER_PROOF_RELEASED
INCIDENT_CLOSED
```

The import implementation/execution is not authorized by this specification-only artifact.

---

## 20. Order/fill identity persistence rules

### PL-ID-001 — client order identity

`client_order_id` is persisted exactly as validated by the venue binding.

For an incident, a bound `client_order_id -> venue_order_id` relationship is append-only.

A later conflicting mapping is a hard integrity/semantic halt.

### PL-ID-002 — order observations do not overwrite

Every authoritative order observation remains an event.

The projection may expose the latest valid observation, but it MUST retain/replay the complete observation sequence and MUST NOT update an old row to represent new state.

### PL-ID-003 — fill identity

Kalshi `fill_id` is the canonical venue fill identity.

Exact duplicate fill payload contributes once. Conflicting content for the same `fill_id` MUST halt `DUPLICATE_FILL_CONFLICT`.

### PL-ID-004 — economic semantics

No fill principal, fee, price, or quantity uses binary float.

No actual fill price is inferred from:

```text
submitted limit price
order book price
average price not accepted by the controlling fill contract
```

The exact validated venue fill value controls.

### PL-ID-005 — provenance

Every order/fill observation MUST retain sufficient secret-safe provenance to identify:

```text
source request ID
source operation
venue payload schema ID
canonical payload hash
recorded event ID/sequence
```

This distinguishes a legitimate later state observation from an accidental duplicate/conflict.

---

## 21. Corruption and failure classifications

### PL-FAIL-001 — closed failure codes

Revision 03 MUST expose deterministic closed failure/result codes including:

```text
AUTHORITY_STORE_MISSING
AUTHORITY_PATH_INSIDE_CANONICAL_REPOSITORY
AUTHORITY_STORAGE_OPEN_FAILURE
AUTHORITY_DURABILITY_CONFIGURATION_FAILURE
AUTHORITY_SCHEMA_IDENTITY_MISMATCH
AUTHORITY_SCHEMA_UNSUPPORTED_NEWER
AUTHORITY_SCHEMA_UNSUPPORTED_OLDER
AUTHORITY_INTEGRITY_CHECK_FAILURE
AUTHORITY_IDENTITY_MISMATCH
AUTHORITY_CONFLICT_DOMAIN_BINDING_MISSING
AUTHORITY_CONFLICT_DOMAIN_ALREADY_BOUND
AUTHORITY_LEDGER_INITIALIZATION_PARTIAL_FAILURE
AUTHORITY_ANCHOR_COMMIT_FAILURE
AUTHORITY_ANCHOR_COMMIT_RESULT_UNKNOWN
AUTHORITY_ANCHOR_CATCHUP_FAILURE
AUTHORITY_AHEAD_OF_LEDGER_ROLLBACK_OR_REPLACEMENT
AUTHORITY_LEDGER_ANCHOR_HASH_MISMATCH
AUTHORITY_ALTERNATE_NAMESPACE_REJECTED

LEDGER_FILE_MISSING
LEDGER_ALREADY_EXISTS
LEDGER_PATH_INSIDE_CANONICAL_REPOSITORY
LEDGER_STORAGE_OPEN_FAILURE
LEDGER_DURABILITY_CONFIGURATION_FAILURE
LEDGER_SCHEMA_IDENTITY_MISMATCH
LEDGER_SCHEMA_UNSUPPORTED_NEWER
LEDGER_SCHEMA_UNSUPPORTED_OLDER
LEDGER_SCHEMA_UNSUPPORTED_EVENT_TYPE
LEDGER_INTEGRITY_CHECK_FAILURE
LEDGER_SEQUENCE_INTEGRITY_FAILURE
LEDGER_HASH_CHAIN_FAILURE
LEDGER_CANONICAL_ENCODING_FAILURE
LEDGER_DECIMAL_CANONICALIZATION_FAILURE
NONCANONICAL_UNICODE
LEDGER_INSTANCE_ID_MISMATCH
LEDGER_ENVIRONMENT_MISMATCH
LEDGER_CONFLICT_DOMAIN_MISMATCH
LEDGER_AUTHORITY_BINDING_MISMATCH
LEDGER_CONCURRENT_WRITER
LEDGER_COMMIT_FAILURE
LEDGER_COMMIT_RESULT_UNKNOWN

PRELEDGER_EMPTY_ASSERTION_UNSUPPORTED
EVENT_ID_CONTENT_CONFLICT
EVENT_REQUIRED_PARENT_MISSING
WRITER_SESSION_REFERENCE_INVALID
REQUEST_PARENT_INVALID
ORDER_IDENTITY_BINDING_CONFLICT
DUPLICATE_FILL_CONFLICT
LEGACY_INCIDENT_EVIDENCE_IDENTITY_MISMATCH
LEGACY_INCIDENT_CONTENT_MISMATCH
LEGACY_INCIDENT_IMPORT_CONFLICT
LEGACY_INCIDENT_IMPORT_INCOMPLETE
LEGACY_IMPORT_ONLY_ACQUISITION_REJECTED
SECRET_FIELD_PROHIBITED
SECRET_PATTERN_PROHIBITED
```

Typed exceptions may be used internally, but caller-visible classification MUST be deterministic.

### PL-FAIL-002 — no automatic repair/rebind/recreate

On corruption, identity failure, rollback, missing established authority state, or two-store contradiction, Revision 03 MUST NOT:

```text
DELETE bad ledger rows
UPDATE old ledger rows
renumber ledger sequences
rebuild ledger hashes
drop/recreate tables
VACUUM into replacement as repair
salvage a suffix while ignoring a prefix
create a fresh empty ledger in place
recreate a missing established authority store
rebind a conflict domain from one ledger to another
decrease the trusted authority sequence
rewrite the ledger to match an older authority anchor
```

The only permitted automatic two-store convergence is PL-AUTH-007 monotonic authority catch-up to a completely validated ledger-ahead suffix.

### PL-FAIL-003 — disk/full/short-write/commit failure

Any SQLite `FULL`, `IOERR`, `CORRUPT`, `NOTADB`, commit I/O error, or equivalent storage failure in either store causes a local halt.

Before verified authority anchoring of a future write-send boundary, transport count MUST remain zero.

After a ledger-committed boundary exists, any later storage uncertainty keeps the write unresolved until a valid reopen/replay proves exact closure. No automatic resend is permitted.

## 22. Secret safety

### PL-SECRET-001 — prohibited material

Authoritative events, database metadata, deterministic export, and diagnostic material produced by the ledger MUST NOT contain:

```text
private-key PEM
private-key bytes
API secret/private credential value
raw request signature
signature hash
signature fingerprint
Authorization header
authentication-header map
session token
bearer token
access token
wallet secret
password
```

### PL-SECRET-002 — allowed credential provenance

Only non-secret credential reference metadata may be recorded, for example:

```text
credential_reference_class
credential_reference_name
credential_environment_classification
```

A reference name MUST NOT contain the underlying credential value.

### PL-SECRET-003 — denylisted keys

Before event commit and before export serialization, recursively reject object keys whose lowercase normalized form is any of:

```text
authorization
authorization_header
auth_header
headers
raw_headers
signature
signature_hash
signature_fingerprint
private_key
private_key_pem
api_secret
secret
password
session_token
bearer_token
access_token
wallet_secret
```

Also reject keys ending `_secret` or `_token` unless the exact field is a documented non-secret `credential_reference_name`/`credential_reference_class`.

### PL-SECRET-004 — denylisted content patterns

Recursively scan all string values and reject at minimum:

```text
-----BEGIN PRIVATE KEY-----
-----BEGIN RSA PRIVATE KEY-----
-----BEGIN EC PRIVATE KEY-----
Authorization:
Bearer 
KALSHI-ACCESS-SIGNATURE:
```

This is a safety backstop, not a substitute for typed schemas.

### PL-SECRET-005 — local/test storage

Test databases MUST use temporary local paths and synthetic material only.

No test database may be placed inside the repository worktree.

No real credential/environment secret may be read by the ledger tests.

---

## 23. Deterministic review export

### PL-EXPORT-001 — export object

After full authority validation, ledger integrity validation, authority catch-up if required, and deterministic replay, Revision 03 MUST be able to produce one secret-safe canonical JSON review export containing at least:

```text
export_schema_revision = 1

authority_schema_revision
authority_instance_id
authority_namespace_id
authority_store_path_identity_sha256
trusted_sequence
trusted_event_hash

ledger_instance_id
ledger_schema_revision
ledger_path_identity_sha256
environment_classification
conflict_domain_ref

event_count
first_sequence
last_sequence
terminal_event_hash

writer_session_state
last_writer_session_id
abnormal_prior_session_count

incident_ids
unresolved_write_count
unresolved_write_request_ids or stable legacy identifiers

client_order_to_venue_order_relationships

deduplicated_fill_ids
deduplicated_fill_count

reconciliation_dispositions
writer_proof_states
restart_classification
integrity_validation_result
authority_ledger_relation
```

Lists/mappings MUST be sorted by explicit stable keys before canonical serialization.

### PL-EXPORT-002 — export bytes/hash

Export bytes use PL-CANON-001 with no trailing newline. Export SHA-256 is computed outside the JSON object:

```text
export_sha256 = lowercase_hex(SHA256(export_bytes))
```

No circular self-hash is embedded.

### PL-EXPORT-003 — no database dump required

A normal review MUST NOT require exporting either mutable SQLite database file. The deterministic export plus raw byte length/SHA-256 is the ordinary evidence surface.

### PL-EXPORT-004 — no absolute local path disclosure

The deterministic export MUST NOT contain absolute authority/ledger filesystem paths, PID, process start time, or other machine-local mutable identifiers. It uses the path-identity SHA-256 values instead.

This export rule does not weaken the internal writer-proof requirement to bind the exact resolved local paths.

## 24. Future integration contract

### PL-INTEG-001 — deployment authority binding precedes writer use

Before a future venue-capable integration can consume ledger-based writer eligibility, that integration MUST bind exactly one authority namespace/root for the deployment and MUST reject per-call alternate authority roots.

The first implementation modules may expose generic configuration/binding types, but no venue capability exists until a later integration contract fixes the deployment binding.

### PL-INTEG-002 — lifecycle pre-send hook

A future integration with `order_lifecycle.py` MUST place the full authority-anchored send gate immediately before the caller-supplied transport is allowed to send a write:

```text
ledger WRITE_SEND_BOUNDARY_ENTERED commit
    -> trusted authority advancement commit + verified readback
    -> exact ledger/authority boundary equality
    -> only then transport may begin
```

It MUST NOT merely log after transport or rely on a ledger commit whose authority advancement is pending/unknown.

### PL-INTEG-003 — result hook

A future integration must convert accepted lifecycle transport/result classifications into the exact ledger result event batch and then advance the trusted authority before returning the result as safely persisted.

If result ledger commit or authority advancement fails after send, the integration returns a fail-closed unresolved/needs-reopen state. It MUST NOT silently return a safely persisted result.

### PL-INTEG-004 — reconciliation/fill hook

A future integration with accepted reconciliation/fill-discovery semantics must append and authority-anchor validated order/fill/reconciliation observations without weakening:

```text
zero-match is not negative proof
client_order_id -> order_id binding
fill_id deduplication
conflicting fill halt
Decimal/fixed-point values
writer proof HELD while unresolved
```

### PL-INTEG-005 — no automatic startup recovery I/O

No integration may make a Kalshi request merely because restart replay returns `RESTART_UNRESOLVED_WRITE_HELD` or any other restart classification. A later recovery request requires separate explicit execution capability and the accepted operation/source contract.

## 25. Load-bearing behavior templates

### PL-BEHAVIOR-001 — initialize authority namespace

```text
INPUT
    accepted deployment AuthorityNamespaceBinding
    canonical repository root

PRECONDITION
    authority root exists and is outside repository
    deterministic authority store path absent
    schema revision 1

DURABLE TRANSITION
    create authority schema/meta under DELETE + EXTRA

OUTPUT
    validated authority_instance_id + namespace/path identities

FAIL-CLOSED RESULT
    partial/failed store remains blocked; no silent recreate
```

### PL-BEHAVIOR-002 — initialize ledger/conflict-domain binding

```text
INPUT
    held validated authority namespace
    conflict_domain_ref
    environment_classification
    new ledger path

PRECONDITION
    authority conflict-domain row absent
    ledger path absent/outside repository
    preledger mode fixed to LEGACY_IMPORT_REQUIRED

DURABLE TRANSITION
    ledger sequence-1 LEDGER_INITIALIZED commit
    then authority binding row commit to exact sequence/hash

OUTPUT
    one authority-bound ledger instance

FAIL-CLOSED RESULT
    any two-store partial initialization has no writer authority and no auto-adoption
```

### PL-BEHAVIOR-003 — open/restart for writer consideration

```text
INPUT
    accepted AuthorityNamespaceBinding
    conflict_domain_ref
    canonical repository root

PRECONDITION
    established authority store exists
    authority row exists

DURABLE/LOCK TRANSITION
    acquire authority exclusive lock
    validate authority
    open authority-bound ledger path only
    acquire ledger exclusive lock
    validate both stores + anchored prefix + complete suffix
    if ledger ahead and suffix valid, advance authority monotonically
    replay history
    append+anchor abandoned/start session events when applicable

OUTPUT
    SafetyProjection
    RestartClassification
    writer handle only if all local eligibility predicates pass

FAIL-CLOSED RESULT
    authority/storage/identity/concurrent-writer/schema/integrity/
    legacy-incomplete/unresolved classification; no venue activity
```

### PL-BEHAVIOR-004 — prepare future write

```text
INPUT
    already validated venue-specific execution intent and secret-free prepared request

PRECONDITION
    authority + ledger locks held
    full replay and authority relation valid
    exact legacy/history completeness valid
    external execution capability separately valid
    no protected unresolved prior write
    venue-specific pre-send predicates pass

DURABLE TRANSITION
    ledger COMMIT EXECUTION_INTENT_RECORDED
    authority advance+verify
    ledger COMMIT REQUEST_PREPARED
    authority advance+verify
    ledger COMMIT WRITE_SEND_BOUNDARY_ENTERED
    authority advance+verify exact boundary sequence/hash

OUTPUT
    local send gate state = AUTHORITY_ANCHORED_SEND_BOUNDARY
    exact request_id + boundary sequence/hash

FAIL-CLOSED RESULT
    no network send; any ledger-only boundary remains conservative on restart
```

### PL-BEHAVIOR-005 — persist future write result

```text
INPUT
    transport/result facts validated by venue adapter

PRECONDITION
    matching fully authority-anchored write boundary exists
    request identity matches
    both locks held

DURABLE TRANSITION
    one atomic ledger result/identity/observation/reconciliation batch
    then authority advancement to exact batch tail

OUTPUT
    updated projection + trusted terminal anchor
    exact closure/unresolved classification

FAIL-CLOSED RESULT
    if ledger/result or authority advancement is not definitely complete,
    caller cannot treat result as safely persisted; reopen required
```

### PL-BEHAVIOR-006 — acquire `LEGACY_IMPORT_ONLY`

```text
INPUT
    accepted AuthorityNamespaceBinding
    conflict_domain_ref
    canonical repository root
    acquisition_mode = LEGACY_IMPORT_ONLY

PRECONDITION
    established authority store exists
    authority row exists and binds one authoritative existing ledger
    all authority/ledger settings, identities, integrity, hash chain,
    anchor relation, and replay checks pass
    the only normal-writer blocking history condition is:
        LEGACY_IMPORT_REQUIRED with no completed valid import

DURABLE/LOCK TRANSITION
    acquire authority exclusive ownership first
    validate authority and authoritative ledger binding
    acquire authoritative ledger exclusive ownership second
    resolve/catch up only a completely validated ledger-ahead suffix
    replay complete history
    append no writer-session event

OUTPUT
    restricted LEGACY_IMPORT_ONLY handle only

FAIL-CLOSED RESULT
    any other unsafe/blocking condition -> no import-only handle,
    no normal writer, no venue/network/credential capability
```

### PL-BEHAVIOR-007 — commit exact legacy import

```text
INPUT
    restricted LEGACY_IMPORT_ONLY handle
    exact three evidence files

PRECONDITION
    PL-LEGACY-016 acquisition remains valid and both locks are held
    evidence identities/content validate
    no completed/conflicting import representation exists

DURABLE TRANSITION
    one ledger transaction commits exactly:
        LEGACY_INCIDENT_IMPORTED
        WRITER_PROOF_HELD
    then authority advances to exact new ledger tail

OUTPUT ON FULL SUCCESS
    import = FULLY_AUTHORITY_ANCHORED
    history = COMPLETE_WITH_PROTECTED_UNRESOLVED_LEGACY_WRITE
    restart = RESTART_UNRESOLVED_WRITE_HELD
    writer proof = HELD

FAIL-CLOSED RESULT
    before ledger COMMIT -> zero import events
    ledger COMMIT success + authority definite failure ->
        preserve complete ledger-ahead two-event batch; close/reopen
    ledger COMMIT success + authority unknown ->
        preserve complete batch; close/reopen
    no duplicate import; no transport; no normal writer handle
```

### PL-BEHAVIOR-008 — reopen interrupted legacy import

```text
INPUT
    acquisition_mode = LEGACY_IMPORT_ONLY
    accepted authority namespace/conflict domain

PRECONDITION
    PL-LEGACY-016 lock/identity/integrity checks pass

DURABLE/LOCK TRANSITION
    authority equal + exact complete import:
        append nothing; recognize ALREADY_COMPLETED_AND_ANCHORED
    ledger ahead + exact complete import suffix:
        append nothing; authority catch-up only
    malformed/partial/conflicting import suffix:
        mutate nothing; fail closed

OUTPUT
    successful recognized/caught-up import ->
        RESTART_UNRESOLVED_WRITE_HELD
        writer proof HELD
        protected unresolved legacy write count 1

FAIL-CLOSED RESULT
    conflict/integrity/catch-up failure -> no import retry,
    no writer/send capability, no automatic repair
```


## 26. Future offline test contract

No tests are executed by this specification-only task.

A future implementation MUST provide deterministic offline tests using standard-library temporary files, mocks/fakes, synthetic material, and fake/in-memory transport objects only.

Every Revision-01 test intent not mechanically superseded by the preserved Revision-02 corrections remains required.

### PL-TEST-001 — persistence/replay

Required cases:

1. explicit authority namespace initialization;
2. explicit ledger/conflict-domain initialization;
3. normal append + authority advancement + replay equivalence;
4. clean shutdown/restart;
5. abnormal shutdown/restart;
6. deterministic export bytes/SHA stable;
7. binary float anywhere in authoritative payload rejected;
8. Decimal canonicalization examples/edge cases;
9. Unicode non-NFC rejection;
10. duplicate JSON-key rejection;
11. authority/ledger exact terminal equality after ordinary successful append.

### PL-TEST-002 — SQLite configuration

Tests MUST prove for **both** SQLite stores:

```text
journal_mode = DELETE
synchronous = EXTRA
synchronous readback == 3
foreign_keys = ON / readback == 1
busy_timeout = 0
locking_mode = EXCLUSIVE / readback == "exclusive"
user_version = 1
integrity_check == "ok"
foreign_key_check == []
```

`synchronous != 3` MUST fail closed. `FULL` readback `2` is insufficient under Revision 03.

### PL-TEST-003 — crash/fault injection A-R

Inject failure at every PL-CRASH-001 point A-R.

Mandatory assertions include:

```text
boundary ledger commit failure -> authority not advanced -> transport count 0
boundary ledger commit success + authority failure -> transport count 0
boundary ledger commit success + authority unknown -> transport count 0 + reopen required
transport impossible before verified authority success
crash after authority success before transport -> WRITE_MAY_HAVE_BEEN_SENT
crash after transport before durable result -> WRITE_MAY_HAVE_BEEN_SENT
ledger ahead of authority -> anchored prefix + complete suffix validation
anchor ahead of ledger -> rollback failure
hash mismatch at trusted sequence -> integrity failure
missing established authority -> no recreation
unresolved boundary -> writer proof HELD
no automatic resend in every unresolved case
ledger event batch remains all-or-nothing
```

### PL-TEST-004 — idempotency/integrity

Preserve all Revision-01 cases:

```text
exact duplicate event_id/content -> idempotent
same event_id/different content -> conflict
sequence gap -> integrity failure
broken previous hash -> integrity failure
wrong payload hash -> integrity failure
wrong event hash -> integrity failure
mutated canonical payload -> integrity failure
unknown event type -> schema unsupported
newer event schema -> schema unsupported
truncated/corrupt ledger -> integrity/storage failure
unknown required parent/session/incident -> integrity failure
```

Add authority mutation tests proving trusted sequence cannot decrease and immutable authority binding fields cannot change.

### PL-TEST-005 — order/fill identity

Preserve all Revision-01 cases:

```text
client_order_id -> one order_id binds
same exact binding repeats idempotently
different order_id for same client_order_id -> conflict
same fill_id + same complete canonical fill -> contributes once
same fill_id + changed canonical field -> DUPLICATE_FILL_CONFLICT
changing order observation is append-only, never overwrite
actual fill price comes from fill payload, not limit price
Decimal-only quantity/principal arithmetic
```

### PL-TEST-006 — logical writer authority / locking

Required real local multi-process or isolated-process tests:

```text
first writer acquires authority then ledger locks
second writer against same authority store is rejected immediately
clean end then takeover succeeds
abnormal session then takeover records abandoned session
PID reuse/stale timestamp cannot make second writer safe
unresolved prior write remains unresolved after takeover

same conflict_domain_ref
same accepted authority namespace
ledger_A.sqlite becomes authoritative
ledger_B.sqlite attempts writer acquisition
-> ledger_B rejected
-> no writer proof for B
-> no send capability for B

opposite lock ordering is not exposed/supported
```

At least one real local multi-process SQLite lock test is required on each supported deployment OS before deployment use; mocks alone are insufficient for lock behavior.

### PL-TEST-007 — legacy import bootstrap, atomicity, and idempotency

Implementation tests remain synthetic. They MUST use fixture-only evidence bytes and MUST prove every prior import semantic plus these exact Revision-03 cases:

```text
1. NORMAL_WRITER acquisition before import
   -> RESTART_LEGACY_HISTORY_INCOMPLETE
   -> no normal writer handle

2. same otherwise-valid local state with acquisition_mode=LEGACY_IMPORT_ONLY
   -> restricted import-only handle succeeds

3. restricted handle exposes no:
   transport
   send gate
   arbitrary/ordinary execution append
   credential/private-key/signing hook
   venue request hook
   writer-proof release
   normal writer proof construction

4. evidence validation failure before ledger transaction
   -> zero import events
   -> authority unchanged

5. ledger transaction failure before COMMIT
   -> zero import events

6. ledger COMMIT definite failure
   -> zero import events

7. successful ledger import transaction
   -> exactly two required events, ordered:
      LEGACY_INCIDENT_IMPORTED
      WRITER_PROOF_HELD
   -> never exactly one

8. authority definite failure after successful ledger import COMMIT
   -> complete two-event ledger-ahead suffix remains
   -> transport count 0
   -> no normal writer handle
   -> no automatic import retry

9. authority unknown after successful ledger import COMMIT
   -> complete batch remains
   -> reopen required
   -> no duplicate import

10. reopen with authority already equal to exact imported ledger tail
    -> append zero import events
    -> ALREADY_COMPLETED_AND_ANCHORED
    -> RESTART_UNRESOLVED_WRITE_HELD

11. reopen with valid ledger-ahead exact complete import suffix
    -> append zero import events
    -> authority catches forward only
    -> RESTART_UNRESOLVED_WRITE_HELD

12. partial/malformed import suffix
    -> fail closed
    -> no authority catch-up
    -> no import retry
    -> no automatic repair

13. conflicting deterministic duplicate import
    -> LEGACY_INCIDENT_IMPORT_CONFLICT

14. current incident after every successful completion/recognition/catch-up:
    disposition = WRITE_UNRESOLVED_ZERO_MATCH
    bound_order_id = null
    created_order_upper_bound = 1
    active_order_upper_bound = 1
    unknown_result = true
    writer_proof_state = HELD
    writer_proof_release_eligible = false
    protected_unresolved_legacy_write_count = 1
    restart = RESTART_UNRESOLVED_WRITE_HELD

15. across all import tests:
    transport/network calls = 0
    credential/private-key reads = 0
    signing operations = 0
    Kalshi Demo requests = 0
    Kalshi production requests = 0
```

Additional preserved pre-ledger assertions:

```text
caller assertion PRELEDGER_HISTORY_PROVEN_EMPTY rejected
configuration value PRELEDGER_HISTORY_PROVEN_EMPTY rejected
new empty ledger does not infer complete pre-ledger history
```

Static assertions MUST bind the production/current three accepted evidence byte/SHA identities exactly. No test may perform the real accepted legacy import or copy the real accepted evidence bytes into a test database.

### PL-TEST-008 — secret safety

Preserve Revision-01 secret tests: PEM, private key, authorization/header maps, signatures, signature hashes/fingerprints, tokens/secrets are rejected; non-secret credential reference class/name may be accepted; export passes the same secret scan.

Both authority and ledger synthetic stores must contain no real secret material.

### PL-TEST-009 — authority/path/replacement safety

Required cases:

```text
relative authority root rejected
path inside repository rejected
resolved symlink/junction into repository rejected where supported
missing established authority store rejected and not recreated
authority schema mismatch
authority instance/namespace/path identity mismatch
authority conflict-domain binding missing
authority conflict-domain binding collision
wrong ledger instance/environment/conflict domain/path rejected
ledger ahead of anchor with valid suffix catches authority forward
ledger ahead with invalid suffix fails closed
anchor ahead of ledger fails closed
hash mismatch at trusted sequence fails closed
alternate unbound authority namespace rejected for an existing proof/ledger binding
no automatic authority or ledger replacement/rebind
```

### PL-TEST-010 — zero capability side effects

Complete future test evidence MUST prove:

```text
real credential reads = 0
Kalshi Demo requests = 0
Kalshi production requests = 0
orders = 0
cancellations = 0
amend/decrease/replace = 0
WebSockets = 0
funding/trading = 0
package installation = 0
```

### PL-TEST-011 — expected commands

For the current Windows/Conda project environment, future implementation evidence should include at least:

```cmd
python -m unittest tests.test_execution_ledger tests.test_kalshi_ledger_binding
```

and a full regression battery equivalent to:

```cmd
python -m unittest discover -s tests -p "test_*.py"
```

A later implementation dispatch may narrow/add exact commands but MUST NOT weaken these test semantics.

### PL-TEST-012 — trusted authority/anchor partial transitions

Dedicated deterministic tests MUST cover:

```text
authority exact initialization
missing-established-store failure
authority rollback / ledger-ahead relation
authority hash mismatch
anchor-ahead-of-ledger relation
boundary ledger commit failure
anchor commit definite failure after boundary
anchor commit unknown after boundary
crash after anchor success before transport
two distinct ledgers / same conflict-domain rejection
alternate authority namespace rejection
```

For every test, record separately:

```text
ledger_commit_outcome
authority_commit_outcome
transport_invocation_count
restart_classification
writer_proof_state
automatic_resend
```

The same test module MUST additionally record legacy-import two-store partial transitions without changing PL-CRASH A-R:

```text
import_ledger_batch_outcome
import_authority_advancement_outcome
import_events_appended_on_reopen
import_status
legacy_import_retry_performed
```

Required results are those in PL-LEGACY-018..022: a successful import ledger COMMIT is never erased merely because later authority advancement fails or is indeterminate.

### PL-TEST-013 — fault-model evidence labeling

Implementation evidence MUST distinguish:

```text
logical_process_crash_tests
physical_power_loss_qualification
```

Ordinary unit, exception-injection, and process-kill tests MUST report:

```text
physical_power_loss_qualification = NOT_PERFORMED
```

unless a separately authorized environment-validation task actually performs such qualification. No ordinary offline test result may be described as proof of sudden-power-loss persistence.

## 27. Capability matrix for this specification task

The current specification-authoring task has this closed capability envelope:

| Capability | State |
|---|---|
| canonical `rigolugo/ARB` read-only synchronization/inspection | `PERMITTED` |
| official Kalshi documentation access | `PROHIBITED` |
| general internet/network | `PROHIBITED` except canonical repository synchronization |
| Kalshi Demo network | `PROHIBITED` |
| Kalshi production network | `PROHIBITED` |
| credential/private-key access | `PROHIBITED` |
| signing | `PROHIBITED` |
| account access | `PROHIBITED` |
| CREATE/CANCEL/amend/decrease/replace | `PROHIBITED` |
| WebSocket | `PROHIBITED` |
| funding/trading | `PROHIBITED` |
| package installation | `PROHIBITED` |
| production implementation code changes | `PROHIBITED` |
| test-source changes/test execution | `PROHIBITED` |
| canonical repository modification | `PROHIBITED` |
| local Git branch/commit | `PROHIBITED` |
| remote Git branch/push/PR/merge | `PROHIBITED` |
| external authoring of this specification and subordinate handoff | `PERMITTED` |

Anything omitted is prohibited for this task.

---

## 28. Acceptance / review evidence contract for a future implementation

### PL-EVID-001 — required implementation evidence

A future implementation package/evidence MUST report:

```text
exact canonical base/tree
exact Revision-03 specification bytes/SHA-256
exact changed path list
exact changed file bytes/SHA-256/Git blob
dependency changes = NONE
Python version observed
SQLite runtime version observed
ledger SQLite readback: DELETE / EXTRA(3) / FK=1 / busy=0 / EXCLUSIVE
authority SQLite readback: DELETE / EXTRA(3) / FK=1 / busy=0 / EXCLUSIVE
focused test result
full regression result
secret scan result
logical process-crash fault matrix result
physical_power_loss_qualification = NOT_PERFORMED unless separately authorized
network activity = NONE
credential activity = NONE
venue activity = NONE
repository/remote Git activity exactly as separately authorized
```

### PL-EVID-002 — deterministic authority/ledger evidence

Offline tests MUST materialize a synthetic deterministic review export and report:

```text
export bytes
export SHA-256
authority_instance_id
authority namespace/path identity hash
trusted sequence/hash
ledger instance/path identity hash
event count
terminal event hash
authority_ledger_relation
restart classification
unresolved-write count
writer-proof state
integrity result
```

### PL-EVID-003 — no mutable database files as ordinary review proof

Raw authority or ledger SQLite files are not required for routine review. If retained for debugging, they are local synthetic test output, not canonical project state, and must contain no real secrets or real imported legacy evidence.

## 29. Requirement traceability matrix

| Requirement | Future code location | Required test/evidence | Failure/result |
|---|---|---|---|
| `PL-BASE-001..005` | implementation gate / binding constants | exact repo/artifact identity checks | canonical/source mismatch halt |
| `PL-ARCH-001..003` | `execution_ledger.py`, `ledger_binding.py` | static API/import review | scope/boundary failure |
| `PL-SURFACE-001..003` | changed-path manifest | changed-path evidence | path-envelope violation |
| `PL-SQL-001..010` | `execution_ledger.py` SQLite open/txn layer | two-store configuration + commit fault tests | durability/storage halt |
| `PL-AUTH-001..008` | `execution_ledger.py` authority namespace/binding | authority init/open/anchor/split-brain tests | authority/identity halt |
| `PL-PATH-001..008` | authority/ledger path/open/init helpers | path/replacement/preledger tests | identity/path/history halt |
| `PL-SCHEMA-001..008` | schema initializers | schema/trigger/monotonic anchor tests | schema/integrity halt |
| `PL-CANON-001..005` | canonical codec | Decimal/float/Unicode/dup-key tests | encoding halt |
| `PL-EVENT-001..022` | event models/validators | event hash/type/parent tests | integrity/schema halt |
| `PL-APPEND-001..004` | append/batch/anchor API | atomicity/two-store/idempotency tests | commit/conflict halt |
| `PL-WRITE-001..005` | integration-facing ledger API | fake transport authority gate tests | no-send or unresolved |
| `PL-CRASH-001` | append/authority/replay integration | A-R fault matrix | deterministic restart state |
| `PL-LOCK-001..006` | authority + ledger writer/session API | multi-process/two-ledger tests | logical writer blocked |
| `PL-REPLAY-001..006` | replay projector | replay/export equivalence tests | integrity halt |
| `PL-RESTART-001..004` | restart classifier | authority precedence/no-network tests | closed restart enum |
| `PL-PROOF-001..005` | ledger binding/projection | exact authority+ledger proof binding tests | proof HELD/unavailable on doubt |
| `PL-LEGACY-001..024` | `ledger_binding.py` importer | exact legacy import tests | incomplete/conflict/unresolved |
| `PL-ID-001..005` | Kalshi binding | order/fill identity tests | binding/fill conflict |
| `PL-FAIL-001..003` | typed errors/result model | fault/corruption tests | closed failure code |
| `PL-SECRET-001..005` | codec + binding + export | recursive denylist scan | secret rejection |
| `PL-EXPORT-001..004` | deterministic export | byte/SHA repeatability | export/integrity failure |
| `PL-INTEG-001..005` | later lifecycle/recon hooks | synthetic fake-transport tests | no automatic I/O |
| `PL-TEST-001..013` | two new test modules | focused + full battery | acceptance failure |
| `PL-EVID-001..003` | implementation handoff/evidence | exact manifest/export | review evidence incomplete |

### Preserved Revision-02 correction traceability

| Preserved Revision-02 correction | SPEC REQUIREMENT | SPEC LOCATION | FUTURE TEST / EVIDENCE | STATUS |
|---|---|---|---|---|
| external anchor durability before send | `PL-SQL-006`, `PL-AUTH-006`, `PL-WRITE-001..003` | Sections 6, 7, 13 | boundary commit/anchor fail+unknown; transport count zero; crash M/N | `PRESERVED_FROM_SPEC_02` |
| logical conflict-domain writer authority | `PL-AUTH-001`, `PL-AUTH-005`, `PL-LOCK-001..003` | Sections 7, 15 | same domain + ledger A/B split-brain rejection; alternate namespace rejection | `PRESERVED_FROM_SPEC_02` |
| pre-ledger empty assertion prohibited | `PL-PATH-004`, `PL-PATH-007`, `PL-REPLAY-003` | Sections 7, 16 | caller/config empty-proof rejection | `PRESERVED_FROM_SPEC_02` |
| `DELETE + EXTRA` durability/fault model | `PL-SQL-003`, `PL-SQL-007`, `PL-TEST-002`, `PL-TEST-013` | Sections 6, 26 | synchronous readback `3`; logical-vs-power-loss evidence labels | `PRESERVED_FROM_SPEC_02` |
| ledger/anchor partial transitions | `PL-AUTH-007`, `PL-CRASH-001` J-Q | Sections 7, 14 | ledger-ahead catch-up; anchor-ahead/hash/missing failures | `PRESERVED_FROM_SPEC_02` |
| two-ledger split-brain rejection | `PL-LOCK-003` | Section 15 | ledger A authoritative; ledger B rejected/no proof/no send | `PRESERVED_FROM_SPEC_02` |
| no automatic resend | `PL-WRITE-004`, `PL-CRASH-001`, `PL-RESTART-003` | Sections 13, 14, 17 | all unresolved crash rows assert resend false | `PRESERVED_FROM_SPEC_02` |
| writer-proof continuity | `PL-PROOF-003..005` | Section 18 | proof binds authority + ledger terminals/paths; current proof HELD | `PRESERVED_FROM_SPEC_02` |

### Revision-03 correction traceability

| Corrected bootstrap defect | SPEC REQUIREMENT | SPEC LOCATION | FUTURE TEST / EVIDENCE | STATUS |
|---|---|---|---|---|
| restricted acquisition despite incomplete legacy history | `PL-LEGACY-015..017`, `PL-BEHAVIOR-006` | Section 19; Section 25 | normal-writer-blocked / import-only-permitted; restricted surface test | `CLOSED_IN_SPEC_03` |
| exact ledger-batch atomicity before COMMIT | `PL-LEGACY-010`, `PL-LEGACY-018` | Section 19 | zero-before-commit / exactly-two-after-commit tests | `CLOSED_IN_SPEC_03` |
| authority failure/unknown after committed import | `PL-LEGACY-019..021` | Section 19 | complete ledger-ahead two-event suffix retained; no retry; transport zero | `CLOSED_IN_SPEC_03` |
| reopen/catch-up without duplicate import | `PL-LEGACY-014`, `PL-LEGACY-022` | Section 19 | authority-equal + ledger-ahead reopen; append-zero assertions | `CLOSED_IN_SPEC_03` |
| normal writer remains blocked before import | `PL-LEGACY-023`, `PL-RESTART-002` | Sections 17, 19 | `RESTART_LEGACY_HISTORY_INCOMPLETE`; no normal writer handle | `CLOSED_IN_SPEC_03` |
| current legacy unresolved state | `PL-LEGACY-001`, `PL-LEGACY-024`, `PL-PROOF-005` | Sections 3, 18, 19 | exact disposition/upper-bound/unknown/proof/count assertions | `PRESERVED_UNRESOLVED` |
| no automatic resend | `PL-WRITE-004`, `PL-LEGACY-017..023` | Sections 13, 19 | all import paths transport zero; current unresolved write blocks send | `PRESERVED` |

## 30. Explicit non-goals and prohibitions

This specification does not specify, authorize, or perform:

```text
Kalshi Demo network access
Kalshi production access
credentials/signing
account access
CREATE
CANCEL
amend
decrease
replace
batch venue writes
WebSocket
funding
trading
market making
profitability accounting
arbitrage logic
strategy logic
multi-market scheduling
order-book streaming
automatic emergency cancellation
production canaries
Polymarket integration
repository modification
implementation
tests
package installation
remote Git writes
automatic repair of corrupt ledgers
automatic venue recovery on restart
automatic resend of unresolved writes
```

---

## 31. Specification completion criteria

This specification is complete when it has fixed, without implementation discretion on safety-relevant choices:

- Python standard-library SQLite for both execution ledger and trusted authority/anchor;
- `DELETE + EXTRA`, foreign-key, zero-busy-timeout, exclusive-locking settings for both stores;
- logical-process-crash versus conditional physical-power-loss claim;
- explicit authority namespace initialization/open/missing-store semantics;
- one exact conflict-domain -> authoritative ledger instance/path binding;
- authority-first then ledger lock ordering;
- trusted sequence/event-hash advancement after every authoritative ledger append;
- send-boundary authority advancement positively committed and verified before transport;
- exact ledger-ahead/equal/authority-ahead/hash-mismatch/missing-store restart handling;
- no automatic rewrite to an older anchor and no established-store recreation;
- only `LEGACY_IMPORT_REQUIRED` as the supported pre-ledger history mode;
- ledger identity/path/authority cross-binding;
- ledger and authority schema revision `1`;
- canonical JSON/Decimal rules;
- append-only event set and immutable event history;
- event identity/hash chain and contiguous sequence;
- deterministic replay/restart classifications;
- exact `LEGACY_IMPORT_ONLY` restricted acquisition with no normal writer/send surface;
- exact two-event legacy ledger-batch atomicity and distinct authority advancement;
- reopen recognition/catch-up after committed import without duplicate import;
- exact current unresolved legacy import semantics;
- logical writer exclusivity across different ledger files for the same conflict domain;
- exact authority+ledger writer-proof binding;
- order/fill identity persistence and fill deduplication;
- corruption/failure/no-repair behavior;
- secret boundary and deterministic secret-safe review export;
- first future writable path envelope unchanged from Revision 01;
- offline A-R crash/anchor/split-brain test contract;
- zero venue/credential capability of this artifact.

No production implementation or test execution is included.

`STOP_AFTER_PERSISTENT_LEDGER_AND_RESTART_RECOVERY_SPEC_03_AND_HANDOFF_DELIVERY`
